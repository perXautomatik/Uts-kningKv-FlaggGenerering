create procedure [sys].[sp_cdc_vupgrade_databases]
as
begin
	declare @db_name sysname
		,@stmt nvarchar(max)
		,@raised_error int
		,@raised_message nvarchar(4000)

    set nocount on

    -- Upgrade all CDC enabled databases
    declare #c_cdc_databases CURSOR LOCAL FORWARD_ONLY for 
        
        SELECT name
        FROM sys.databases
        WHERE is_cdc_enabled = 1 and is_read_only = 0

    open #c_cdc_databases
    fetch #c_cdc_databases into @db_name
    while (@@fetch_status != -1)
    begin 
		-- Call sp_cdc_vupgrade for the CDC enabled database
		set @stmt = quotename(@db_name) + N'.sys.sp_cdc_vupgrade'
		
		begin try
			exec sp_executesql @stmt
		end try
		
		begin catch
			-- Report error as information message and keep going
			select @raised_error = ERROR_NUMBER()
			select @raised_message = ERROR_MESSAGE()
			raiserror(22861, 10, -1, @db_name, @raised_error, @raised_message)  
		end catch
		
        fetch #c_cdc_databases into @db_name

    end -- while cursor

    close #c_cdc_databases
    deallocate #c_cdc_databases
    
    return 0

end
go

