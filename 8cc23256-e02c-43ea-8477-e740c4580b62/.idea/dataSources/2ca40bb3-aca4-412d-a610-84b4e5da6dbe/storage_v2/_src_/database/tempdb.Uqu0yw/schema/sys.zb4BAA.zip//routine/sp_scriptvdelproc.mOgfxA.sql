create procedure sys.sp_scriptvdelproc 
(
    @artid int
    ,@publishertype tinyint=1        -- 1 = mssqlserver, 2 = heterogeneous
    ,@publisher sysname=NULL		 -- May only be non-NULL if @publishertype = 2
)
as
begin
    declare @retcode int
    --
    -- security check
    --
    exec @retcode = sys.sp_MSreplcheck_publish
    if @@error <> 0 or @retcode <> 0
    begin
        return (1)
    end
    --
    -- call core function
    --
    exec @retcode = sys.sp_scriptdelproccore 
                @artid = @artid
                ,@format = 4            -- VCALL format
                ,@mode = 1              -- regular scripting mode
                ,@publishertype = @publishertype
                ,@publisher = @publisher
    return @retcode
end
go

