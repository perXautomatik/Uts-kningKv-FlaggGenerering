CREATE PROC sys.sp_help_spatial_geometry_index
(
	@tabname		NVARCHAR(776),		-- the TABLE to check for indexes
	@indexname		SYSNAME,		-- the INDEX name
	@verboseoutput	TINYINT,		-- OUTPUT all properties
	@query_sample	GEOMETRY		-- query window object
)
AS
BEGIN
	EXEC sys.sp_help_spatial_geometry_index_helper @tabname, @indexname, 0, null, @verboseoutput, @query_sample
END
go

