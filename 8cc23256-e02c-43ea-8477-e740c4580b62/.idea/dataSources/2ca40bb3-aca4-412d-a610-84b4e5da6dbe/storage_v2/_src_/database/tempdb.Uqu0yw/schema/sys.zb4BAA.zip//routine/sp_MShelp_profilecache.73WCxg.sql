
CREATE PROCEDURE sys.sp_MShelp_profilecache (        
    @profile_name sysname = NULL
)
as
    declare @profile_id int
    declare @retcode int

    --
    -- security check
    --
    exec @retcode = sys.sp_MSreplcheck_subscribe
    if @@ERROR <> 0 or @retcode <> 0
    begin
        return(1)
    end

    select @profile_id = NULL
    
    select parameter_name, value 
        from dbo.MSmerge_agent_parameters
        where profile_name = @profile_name
go

