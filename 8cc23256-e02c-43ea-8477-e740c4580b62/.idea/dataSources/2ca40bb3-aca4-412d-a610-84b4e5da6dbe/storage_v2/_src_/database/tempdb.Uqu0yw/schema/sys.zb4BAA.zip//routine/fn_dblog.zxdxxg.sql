create function sys.fn_dblog
	(
		@start 	 nvarchar (25) = NULL,
		@end   	 nvarchar (25) = NULL
	)

returns table
as
	return select *
	from OpenRowset (TABLE DBLOG, @start, @end, NULL, 1,
					 NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
					 NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
			 		 NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
 					 NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
 					 NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
 					 NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
 					 NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
 					 NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)
go

