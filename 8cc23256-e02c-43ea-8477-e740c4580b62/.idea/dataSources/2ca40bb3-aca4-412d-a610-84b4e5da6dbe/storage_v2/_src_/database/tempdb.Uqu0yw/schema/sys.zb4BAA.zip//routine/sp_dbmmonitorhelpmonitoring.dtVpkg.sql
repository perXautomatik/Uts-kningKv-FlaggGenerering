create procedure sys.sp_dbmmonitorhelpmonitoring 
as
begin
	set nocount on
	if (is_srvrolemember(N'sysadmin') <> 1 )
        begin
			raiserror(21089, 16, 1)
			return (1)
		end

	declare @freq_type				int,	-- 4 = daily
			@freq_interval			int,	-- Every 1 days 
			@freq_subday_type		int,	-- 4 = based on Minutes
			@freq_subday_interval	int,	-- interval
			@job_id					uniqueidentifier,
			@schedule_id			int,
			@retention_period		int,
			@jobname				nvarchar( 256 )

	select @jobname   = isnull( formatmessage( 32047 ), N'Database Mirroring Monitor Job' )

	select @job_id = job_id from msdb.dbo.sysjobs where name = @jobname
	if (@job_id is null)	-- if the job does not exist, error out
	begin
		raiserror( 32049, 16, 1 )
		return 1 
	end
	
	select @schedule_id = schedule_id from msdb.dbo.sysjobschedules where job_id = @job_id
	select	@freq_type = freq_type,
			@freq_interval = freq_interval, 
			@freq_subday_type = freq_subday_type,
			@freq_subday_interval = freq_subday_interval
		from msdb.dbo.sysschedules where schedule_id = @schedule_id

	-- If the frequency parameters are not what we expect then return an error
	-- Someone has changed the job schedule on us
	if (@freq_type <> 4) or (@freq_interval <> 1) or (@freq_subday_type <> 4)
	begin
		raiserror( 32037, 16, 1)
		return 1
	end

	select @freq_subday_interval update_period

	return 0
end
go

