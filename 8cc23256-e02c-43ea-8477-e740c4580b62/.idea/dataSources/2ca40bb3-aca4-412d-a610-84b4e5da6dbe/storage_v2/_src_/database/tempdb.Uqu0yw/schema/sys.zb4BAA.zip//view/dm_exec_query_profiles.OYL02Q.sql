CREATE VIEW sys.dm_exec_query_profiles AS
		SELECT *
		FROM OpenRowset (TABLE DM_EXEC_QUERY_PROFILES)
go

