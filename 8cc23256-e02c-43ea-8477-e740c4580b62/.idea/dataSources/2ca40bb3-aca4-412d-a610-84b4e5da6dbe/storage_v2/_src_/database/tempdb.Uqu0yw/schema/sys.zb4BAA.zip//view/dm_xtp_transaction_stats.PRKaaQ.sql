CREATE VIEW sys.dm_xtp_transaction_stats
AS
	SELECT
	*
	FROM OpenRowset(TABLE XTP_SYSTEM_STATS)
go

