create procedure sys.sp_helprole
	@rolename       sysname = NULL
AS
	if @rolename is not null
	begin
		-- VALIDATE GIVEN NAME
		if not exists (select * from sys.database_principals where name = @rolename and (type = 'R' or type = 'A'))
		begin
			raiserror(15409, -1, -1, @rolename)
			return (1)
		end

		-- RESULT SET FOR SINGLE ROLE
		select 'RoleName' = name, 'RoleId' = principal_id, 'IsAppRole' = case type when 'A' then 1 else 0 end
			from sys.database_principals
			where (name = @rolename) and (type = 'R' or type = 'A')
	end
	else
	begin
		-- RESULT SET FOR ALL ROLES
		select 'RoleName' = name, 'RoleId' = principal_id, 'IsAppRole' = case type when 'A' then 1 else 0 end
			from sys.database_principals where (type = 'R' or type = 'A')
	end

	return (0) -- sp_helprole
go

