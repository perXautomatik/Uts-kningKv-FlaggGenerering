create procedure sys.sp_MSclearresetpartialsnapshotprogressbit
(
    @agent_id int
)
as
begin
    set nocount on
    declare @retcode int
    
    set @retcode = 0

    --
    -- PAL Security Check
    --
    exec @retcode = sys.sp_MScheck_pull_access
        @agent_id = @agent_id,
        @agent_type = 0 -- distribution agent
    if @@error <> 0 or @retcode <> 0
        return (1)

    update dbo.MSdistribution_agents
       set reset_partial_snapshot_progress = 0
     where id = @agent_id 
    if @@error <> 0 or @retcode <> 0
        return (1)

end
go

