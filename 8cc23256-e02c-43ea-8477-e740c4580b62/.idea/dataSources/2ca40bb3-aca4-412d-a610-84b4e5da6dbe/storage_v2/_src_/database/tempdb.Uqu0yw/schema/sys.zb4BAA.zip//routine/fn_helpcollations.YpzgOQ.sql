create function sys.fn_helpcollations
	(
	)

returns table
as
	return select * from OpenRowset(TABLE COLLATIONS)
go

