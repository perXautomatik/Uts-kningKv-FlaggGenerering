
create procedure sys.sp_usertypes_rowset2
(
    @type_schema    sysname = null
)
as
    select
        UDT_CATALOGNAME         = db_name(),
        UDT_SCHEMANAME          = schema_name(u.schema_id),
        UDT_NAME                = convert(sysname,u.name),
        UDT_ASSEMBLY_TYPENAME   = u.assembly_qualified_name
    from
        sys.assemblies a inner join
        sys.assembly_types u on
            (
                a.assembly_id = u.assembly_id
            )
    where
        (@type_schema is null or @type_schema = schema_name(u.schema_id))
    order by 1, 2, 3
go

