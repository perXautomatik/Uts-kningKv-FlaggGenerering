create function sys.fn_MSdayasnumber (@day datetime)
	returns int
as
begin
	return (year(@day) - 2000) * 366 + datepart(dayofyear,@day)
end
go

