
create procedure sys.sp_check_constbytable_rowset
(
    @table_name         sysname,
    @table_schema       sysname = null,
    @constraint_name    sysname = null,
    @constraint_schema  sysname = null
)
as
    select
        TABLE_CATALOG       = s_ccr.TABLE_CATALOG,
        TABLE_SCHEMA        = s_ccr.TABLE_SCHEMA,
        TABLE_NAME          = s_ccr.TABLE_NAME,
        CONSTRAINT_CATALOG  = s_ccr.CONSTRAINT_CATALOG,
        CONSTRAINT_SCHEMA   = s_ccr.CONSTRAINT_SCHEMA,
        CONSTRAINT_NAME     = s_ccr.CONSTRAINT_NAME,
        CHECK_CLAUSE        = s_ccr.CHECK_CLAUSE,
        DESCRIPTION         = s_ccr.DESCRIPTION

    from
        sys.spt_check_constbytable_rowset s_ccr
    where
        (
            (@table_schema is null and s_ccr.TABLE_NAME = @table_name) or
            object_id(quotename(@table_schema) + '.' + quotename(@table_name)) = s_ccr.object_id
        ) and
        (@constraint_name is null or s_ccr.CONSTRAINT_NAME = @constraint_name) and
        (@constraint_schema is null or @constraint_schema = schema_name(s_ccr.schema_id))
    order by 1,2,3,4,5,6
go

