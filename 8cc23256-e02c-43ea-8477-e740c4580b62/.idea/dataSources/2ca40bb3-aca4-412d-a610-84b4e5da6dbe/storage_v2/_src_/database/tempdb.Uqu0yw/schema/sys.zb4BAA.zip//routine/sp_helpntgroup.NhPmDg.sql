create procedure sys.sp_helpntgroup
	@ntname       sysname = NULL
AS
	if @ntname is not null
	begin
		-- VALIDATE GIVEN NAME
		if not exists (select * from sysusers where name = @ntname and isntgroup = 1)
		begin
			raiserror(15420, -1, -1, @ntname)
			return (1)
		end

		-- RESULT SET FOR SINGLE GROUP
		select 'NTGroupName' = u.name, 'NtGroupId' = u.principal_id, 'SID' = u.sid, 'HasDbAccess' = case when p.state in ('G','W') then 1 else 0 end
			from sys.database_principals u
			left join sys.database_permissions p on p.class = 0 and p.major_id = 0 and p.minor_id = 0
				and p.grantee_principal_id = u.principal_id AND p.grantor_principal_id = 1 AND p.type = 'CO'
			where u.name = @ntname and u.type = 'G'
	end
	else
	begin
		-- RESULT SET FOR ALL GROUPS
		select 'NTGroupName' = u.name, 'NtGroupId' = u.principal_id, 'SID' = u.sid, 'HasDbAccess' = case when p.state in ('G','W') then 1 else 0 end
			from sys.database_principals u
			left join sys.database_permissions p on p.class = 0 and p.major_id = 0 and p.minor_id = 0
				and p.grantee_principal_id = u.principal_id AND p.grantor_principal_id = 1 AND p.type = 'CO'
			where u.type = 'G'
	end

	return (0) -- sp_helpntgroup
go

