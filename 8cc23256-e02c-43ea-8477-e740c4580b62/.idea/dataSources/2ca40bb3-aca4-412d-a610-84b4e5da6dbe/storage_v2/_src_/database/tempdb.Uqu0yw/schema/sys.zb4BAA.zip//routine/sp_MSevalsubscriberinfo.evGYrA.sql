create procedure sys.sp_MSevalsubscriberinfo 
    (@pubid uniqueidentifier)
as
    -- Security Checking 
    -- PAL users have access

    if ({fn ISPALUSER(@pubid)} <> 1)
    begin
        if (@pubid is NULL)
        begin
            RAISERROR (21723, 16, -1, 'sp_MSevalsubscriberinfo')
            return 1
        end
        else
        begin
            RAISERROR (14126, 11, -1)
            return 1
        end
    end
        
    declare @expr nvarchar(500)
    select @expr = validate_subscriber_info from dbo.sysmergepublications  where pubid = @pubid
    exec ('select ' + @expr)
    if @@error<>0 return(1)
    
    return(0)
go

