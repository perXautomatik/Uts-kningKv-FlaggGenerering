create function sys.fn_GetCurrentPrincipal
(@db_name sysname)
RETURNS sysname
as 
begin
	return 
	(
		select case when (db_mirroring.mirroring_role = 1)
			then @@servername
			else 
				case when db_mirroring.mirroring_partner_instance is NULL
					then @@servername
					else db_mirroring.mirroring_partner_instance
				end
			end	
		from sys.database_mirroring db_mirroring, sys.databases databases where 
		db_mirroring.database_id = databases.database_id
		and (databases.is_published = 1 or databases.is_merge_published = 1)
		and databases.name = @db_name
	)
end
go

