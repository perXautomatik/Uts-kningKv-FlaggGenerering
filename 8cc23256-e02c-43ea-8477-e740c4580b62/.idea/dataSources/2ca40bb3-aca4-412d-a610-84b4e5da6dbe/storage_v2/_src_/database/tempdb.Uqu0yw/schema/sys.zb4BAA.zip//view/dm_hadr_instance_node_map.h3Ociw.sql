CREATE view sys.dm_hadr_instance_node_map
as
	SELECT 
	*
	FROM OpenRowset(TABLE DM_HADR_INSTANCE_NODE_MAP)
go

