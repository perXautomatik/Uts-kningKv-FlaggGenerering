
create procedure sys.sp_db_ebcdic277_2
(
	@dbname sysname = null,
	@status varchar(6) = null
)
as
	return (0);
go

