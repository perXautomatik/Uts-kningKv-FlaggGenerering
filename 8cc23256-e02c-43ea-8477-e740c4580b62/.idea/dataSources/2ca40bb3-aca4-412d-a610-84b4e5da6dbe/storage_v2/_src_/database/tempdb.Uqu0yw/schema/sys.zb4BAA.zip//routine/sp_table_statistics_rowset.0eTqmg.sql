
create procedure sys.sp_table_statistics_rowset
(
    @table_name_dummy   sysname = null -- dummy parameter, for consistency with other SProcs, where 1st parameter is table_name
)
as
    select
        TABLE_CATALOG       = convert(sysname, null),
        TABLE_SCHEMA        = convert(sysname, null),
        TABLE_NAME          = convert(sysname, null),
        STATISTICS_CATALOG  = convert(sysname, null),
        STATISTICS_SCHEMA   = convert(sysname, null),
        STATISTICS_NAME     = convert(sysname, null),
        STATISTICS_TYPE     = convert(smallint,0),
        COLUMN_NAME         = convert(sysname, null),
        COLUMN_GUID         = convert(uniqueidentifier, null),
        COLUMN_PROPID       = convert(int, null),
        ORDINAL_POSITION    = convert(int, null),
        SAMPLE_PCT          = convert(smallint, null),
        LAST_UPDATE_TIME    = convert(datetime, null),
        NO_OF_RANGES        = convert(int, null),
        COLUMN_CARDINALITY  = convert(bigint, null),
        TUPLE_CARDINALITY   = convert(bigint, null),
        TABLE_CARDINALITY   = convert(bigint, null),
        AVG_COLUMN_LENGTH   = convert(int, null)
    where 1=0
go

