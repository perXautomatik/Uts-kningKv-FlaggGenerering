create procedure sys.sp_MScomputemergeunresolvedrefs
    @publication sysname, -- Must provide the publication name
    @article sysname = '%' -- '%' means all articles in the specified publication, otherwise an exact match is performed
AS
    SET NOCOUNT ON 
    DECLARE @pubid uniqueidentifier 
    declare @retcode int

    /* 
    ** Security Check and parameter check for @publication
    */
    -- We perform PAL check instead of db_owner check here so that client-
    -- requested dynamic snapshot can go through 
    SELECT @pubid = NULL
    exec @retcode = sys.sp_MSmerge_validate_publication_presence @publication, NULL, NULL, @pubid output
    if @retcode <> 0 or @@error <> 0
        return 1

	SELECT DISTINCT 
		   'article' = a.name, 
		   'dependent object' = o.name, 
		   'dependent object owner' = u.name, 
		   'dependent objectid' = o.object_id 
	  FROM dbo.sysmergeextendedarticlesview a
	INNER JOIN sys.sql_dependencies dep
		ON a.objid = dep.object_id
	   AND a.pubid = @pubid
	   AND (@article = '%' OR name = @article)
	   AND dep.referenced_major_id NOT IN (SELECT objid FROM dbo.sysmergeextendedarticlesview
							  WHERE pubid = @pubid 
								AND (@article = '%' OR name = @article))
	INNER JOIN sys.objects o
		ON dep.referenced_major_id = o.object_id
	INNER JOIN sys.schemas u
		ON u.schema_id = o.schema_id
go

