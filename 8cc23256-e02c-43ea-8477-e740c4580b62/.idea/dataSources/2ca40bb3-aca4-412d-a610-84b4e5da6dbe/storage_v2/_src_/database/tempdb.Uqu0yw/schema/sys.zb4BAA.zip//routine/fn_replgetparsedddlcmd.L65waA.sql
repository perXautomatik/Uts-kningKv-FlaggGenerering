--
-- Name: fn_replgetparsedddlcmd
--
-- Description: This helper function strips out the first part 
--	of DDL cmd, up to the point right after object name.
--	
--
-- Parameters: 	
--	@ddlcmd nvarchar(max)
--	,@FirstToken sysname
--	,@objectType sysname	-- comlete form: e.g. procedure/function/tigger
--	,@dbname sysname		-- not quoted
--	,@owner sysname			-- not quoted
--	,@objname sysname		-- not quoted
--	,@targetobject nvarchar(512)-- applies to alter trigger only
--
-- Returns: nvarchar(max) 
--
-- Notes: this is an internal helper function which assumes
--	incoming @ddlcmd is always valid, it strips out the first 
--	part of ddl so we can reconstruct with alternate
--	destination table/owner if so desired, it also helps to 
--	to avoid blandly sending DDL with fully qualified table 
--	name including publisher database:
--	e.g. 
--	fn_replgetparsedddlcmd(N'table pubs.dbo.authors add newcol1 int'
--											,'alter'
--											,'table'
--											,'pubs'
--											,'dbo'
--											,'authors')
--	should return: N'add newcol1 int'
--		
-- Security: not exposed to public
-- 
create function sys.fn_replgetparsedddlcmd (
    @ddlcmd nvarchar(max)
	,@FirstToken sysname
	,@objectType sysname	-- comlete form: e.g. procedure/function/tigger
	,@dbname sysname		-- not quoted
	,@owner sysname			-- not quoted
	,@objname sysname		-- not quoted
	,@targetobject nvarchar(512)-- applies to alter trigger only
)
returns nvarchar(max)
as
begin
declare @left_quote bigint
		,@right_quote bigint
		,@first_space bigint
        ,@first_tab bigint
        ,@start_pos bigint
		,@ddlcmd_len bigint
		,@ddloffset nvarchar(max)
		,@old_ddloffset nvarchar(max)
		,@trigger_dbname sysname
		,@trigger_owner sysname
		,@trigger_objname sysname

set @ddloffset = rtrim(ltrim(@ddlcmd))

-- strip out leading comments
set @ddloffset = sys.fn_replremoveleadingcomments(@ddloffset)
set @ddlcmd_len = len(@ddloffset)

-- return N'' immediately if the ddl statement does not match first token, this
-- can happen after Katmai DDL improvement
if lower(left(@ddloffset, len(@FirstToken)) collate SQL_Latin1_General_CP1_CS_AS) <> lower(@FirstToken collate SQL_Latin1_General_CP1_CS_AS)
	return N''

-- start with striping off ALTER at the begining
set @ddloffset = ltrim(right(@ddloffset, @ddlcmd_len - len(@FirstToken)))
set @ddlcmd_len = len(@ddloffset)

-- strip out any possible comments between alter and next token
set @ddloffset = sys.fn_replremoveleadingcomments(@ddloffset)
set @ddlcmd_len = len(@ddloffset)

-- now strip out objectType token, 
-- remember, this function is only used by DDL trigger where we know @ddlcmd coming in is valid
-- watch out for space after the second token, e.g. alter proc instead of alter procedure
-- watch out for comments, e.g. alter proc/*..*/myproc instead of alter procedure
set @first_space = patindex('% %', @ddloffset)
set @left_quote = patindex('%/*%', @ddloffset)
set @first_tab = patindex('%' + char(9)	+ '%', @ddloffset) -- char(9) is tab
if (@first_tab < @first_space) and (@first_tab > 0)
begin
    set @first_space = @first_tab
end
if (@first_space > 0 and @first_space < len(@objectType))
	or (@left_quote > 0 and @left_quote < len(@objectType))
begin
	if (@first_space > 0) and (@left_quote > 0)
	begin
		if (@left_quote > @first_space)
			set @left_quote = @first_space
	end
	else if (@first_space > 0) and (@left_quote = 0)
		set @left_quote = @first_space
end
else
	set @left_quote = len(@objectType) + 1
set @ddloffset = substring(@ddloffset, @left_quote, @ddlcmd_len - @left_quote + 1)

-- In the case where there are tabs between @ObjectType token and object name,
-- ltrim doesn't trim tabs.  Use patindex to find the first character
-- that is not a space or a tab, then take the substring after that leading
-- whitespace.
set @ddlcmd_len = len(@ddloffset)

-- Use patindex regular expression to find first char that is not space or tab
-- Then take substring to effectively do a ltrim that will also trim tabs.
set @start_pos = patindex('%[^' + ' ' + char(9) + ']%', @ddloffset)
set @ddloffset = substring(@ddloffset, @start_pos, @ddlcmd_len - @start_pos + 1)

-- strip out any possible comments between @ObjectType token and object name
set @ddloffset = sys.fn_replremoveleadingcomments(@ddloffset)

-- now strip out object name
-- deal with the following possibilities: w or w/o quotes
-- [db].[owner].[obj]
set @old_ddloffset = @ddloffset
set @ddloffset = sys.fn_replremovefullobj(@ddloffset, @dbname, @owner, @objname)

--This is to handle the case of a duplicate trigger from switch partition
if @old_ddloffset = @ddloffset
	return N''

-- might as well strip out any possible comments between object name and definition
set @ddloffset = sys.fn_replremoveleadingcomments(@ddloffset)

--alter trigger trigger_name on [db].[owner].[obj] as .... has the same issue, parse to the point before as
--so we can substitute with alter trigger trigger_name on [dest_owner].[dest_obj] as 
if UPPER(@objectType) = N'TRIGGER' and @targetobject is not NULL and len(@targetobject) > 0
begin 
	-- remove leading newline
	--if substring(@ddloffset, 1, 1) = CHAR(13)
		--set @ddloffset = substring(@ddloffset, 2, len(@ddloffset )-1)
	
	set @ddloffset = ltrim(right(@ddloffset, len(@ddloffset) - len(N'on ')))

	-- trim space,tab,cr,lf chars
	set @start_pos = patindex('%[^' + ' ' + char(9) + char(13) + char(10) + ']%', @ddloffset)
	set @ddloffset = substring(@ddloffset, @start_pos, len(@ddloffset) - @start_pos + 1)

	set @trigger_dbname = isnull(parsename(@targetobject, 3), isnull(parsename(quotename(@targetobject), 3), @dbname))
	set @trigger_owner = isnull(parsename(@targetobject, 2), isnull(parsename(quotename(@targetobject), 2), @owner))
	set @trigger_objname = isnull(parsename(@targetobject, 1), isnull(parsename(quotename(@targetobject), 1), @targetobject))
	
	set @ddloffset = sys.fn_replremovefullobj(@ddloffset, @trigger_dbname, @trigger_owner, @trigger_objname)
end
return (@ddloffset)
end
go

