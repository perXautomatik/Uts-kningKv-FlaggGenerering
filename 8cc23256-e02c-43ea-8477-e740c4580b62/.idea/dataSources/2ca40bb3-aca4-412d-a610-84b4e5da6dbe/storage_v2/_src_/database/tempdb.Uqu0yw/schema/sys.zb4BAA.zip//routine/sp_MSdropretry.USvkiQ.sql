
create procedure sys.sp_MSdropretry (@tname sysname, @pname sysname)
as
    declare @retcode int
    declare @quotedtname nvarchar(258) -- max characters that quotename can return
    declare @quotedpname nvarchar(258)

    /*
    ** Check to see if current publication has permission
    */
    exec @retcode = sys.sp_MSrepl_PAL_rolecheck 
    if (@retcode <> 0) or (@@error <> 0)
            return 1

    select @quotedtname = quotename(@tname)
    select @quotedpname = quotename(@pname)

    exec ('drop table ' + @quotedtname)
    if @@ERROR <> 0 return(1)
    exec ('drop procedure ' + @quotedpname)
    if @@ERROR <> 0 return(1)
    return (0)
go

