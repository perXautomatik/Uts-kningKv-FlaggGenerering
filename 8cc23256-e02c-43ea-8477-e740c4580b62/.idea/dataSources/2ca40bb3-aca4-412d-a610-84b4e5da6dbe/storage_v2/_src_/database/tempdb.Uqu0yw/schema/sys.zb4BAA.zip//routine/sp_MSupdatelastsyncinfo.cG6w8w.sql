create procedure sys.sp_MSupdatelastsyncinfo
    @publisher      sysname,                    -- publishing server name
    @publisher_db   sysname,                    -- publishing database name. If NULL then same as current db
    @publication    sysname,                    -- publication name,
    @subscription_type int,
    @last_sync_status     int,
    @last_sync_summary     sysname
AS
    set nocount on
    declare @retcode int

    --  Security Check
    EXEC @retcode = sys.sp_MSreplcheck_subscribe
    IF @@ERROR <> 0 or @retcode <> 0
        RETURN(1)

    if object_id('dbo.MSsubscription_agents') is null
        return(1)

    -- For non independent agent publications
    if @publication is null or @publication = ''
        set @publication = 'ALL'

    if not exists (select * from MSsubscription_agents where
            UPPER(publisher) = UPPER(@publisher)
            and publisher_db =  @publisher_db
            and publication = @publication
            and subscription_type = @subscription_type)
    begin
        exec sys.sp_MSinit_subscription_agent
            @publisher,
            @publisher_db,
            @publication,
            @subscription_type
    end

    update MSsubscription_agents set     
        last_sync_time = getdate(), 
        last_sync_status = @last_sync_status, 
        last_sync_summary = @last_sync_summary
        where UPPER(publisher) = UPPER(@publisher)
            and publisher_db =  @publisher_db
            and publication = @publication
            and subscription_type = @subscription_type

    update MSreplication_subscriptions set
        time = convert(smalldatetime, getdate()) 
    WHERE UPPER(publisher) = UPPER(@publisher) AND
        publisher_db  = @publisher_db AND
        ((@publication = N'ALL' and independent_agent = 0) or 
        @publication = publication) and
        subscription_type = @subscription_type
go

