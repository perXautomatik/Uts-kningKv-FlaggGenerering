
create procedure sys.sp_columns_rowset
(
    @table_name     sysname,
    @table_schema   sysname = NULL,
    @column_name    sysname = NULL
)
as
    select
        TABLE_CATALOG           = s_cv.TABLE_CATALOG,
        TABLE_SCHEMA            = s_cv.TABLE_SCHEMA,
        TABLE_NAME              = s_cv.TABLE_NAME,
        COLUMN_NAME             = s_cv.COLUMN_NAME,
        COLUMN_GUID             = s_cv.COLUMN_GUID,
        COLUMN_PROPID           = s_cv.COLUMN_PROPID,
        ORDINAL_POSITION        = s_cv.ORDINAL_POSITION,
        COLUMN_HASDEFAULT       = s_cv.COLUMN_HASDEFAULT,
        COLUMN_DEFAULT          = s_cv.COLUMN_DEFAULT,
        COLUMN_FLAGS            = s_cv.COLUMN_FLAGS_90,
        IS_NULLABLE             = s_cv.IS_NULLABLE,
        DATA_TYPE               = s_cv.DATA_TYPE_28, -- for backward compatibility
        TYPE_GUID               = s_cv.TYPE_GUID,
        CHARACTER_MAXIMUM_LENGTH= s_cv.CHARACTER_MAXIMUM_LENGTH_28, -- for backward compatibility
        CHARACTER_OCTET_LENGTH  = s_cv.CHARACTER_OCTET_LENGTH_28, -- for backward compatibility
        NUMERIC_PRECISION       = s_cv.NUMERIC_PRECISION,
        NUMERIC_SCALE           = s_cv.NUMERIC_SCALE,
        DATETIME_PRECISION      = s_cv.DATETIME_PRECISION_90,
        CHARACTER_SET_CATALOG   = s_cv.CHARACTER_SET_CATALOG_28, -- for backward compatibility
        CHARACTER_SET_SCHEMA    = s_cv.CHARACTER_SET_SCHEMA_28,  -- for backward compatibility
        CHARACTER_SET_NAME      = s_cv.CHARACTER_SET_NAME_28,    -- for backward compatibility
        COLLATION_CATALOG       = s_cv.COLLATION_CATALOG_28,     -- for backward compatibility
        COLLATION_SCHEMA        = s_cv.COLLATION_SCHEMA_28,      -- for backward compatibility
        COLLATION_NAME          = s_cv.COLLATION_NAME_28,        -- for backward compatibility
        DOMAIN_CATALOG          = s_cv.DOMAIN_CATALOG,
        DOMAIN_SCHEMA           = s_cv.DOMAIN_SCHEMA,
        DOMAIN_NAME             = s_cv.DOMAIN_NAME,
        DESCRIPTION             = s_cv.DESCRIPTION,
        COLUMN_LCID             = s_cv.COLUMN_LCID_28,           -- for backward compatibility
        COLUMN_COMPFLAGS        = s_cv.COLUMN_COMPFLAGS_28,      -- for backward compatibility
        COLUMN_SORTID           = s_cv.COLUMN_SORTID,
        COLUMN_TDSCOLLATION     = s_cv.COLUMN_TDSCOLLATION_28,   -- for backward compatibility
        IS_COMPUTED             = s_cv.IS_COMPUTED

    from
        sys.spt_columns_view s_cv

    where
        (
            (@table_schema is null and s_cv.TABLE_NAME = @table_name) or
            s_cv.object_id = object_id(quotename(@table_schema) + '.' + quotename(@table_name))
        ) and
        (@column_name = s_cv.COLUMN_NAME or @column_name is null)

    order by 1, 2, 3, 7
go

