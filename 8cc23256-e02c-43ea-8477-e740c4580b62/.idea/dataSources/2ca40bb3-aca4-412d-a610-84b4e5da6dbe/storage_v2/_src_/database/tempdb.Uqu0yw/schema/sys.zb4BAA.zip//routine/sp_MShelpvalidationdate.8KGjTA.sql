
create procedure sys.sp_MShelpvalidationdate(
@publication        sysname,
@subscriber            sysname,
@subscriber_db        sysname
)AS
declare @pubid                    uniqueidentifier
declare @retcode                int

-- Security check
if 1 <> is_member('db_owner')
begin    
    RAISERROR (15247, 11, -1)
    return (1)
end

select @pubid=pubid from dbo.sysmergepublications where name=@publication and UPPER(publisher)=UPPER(publishingservername()) and publisher_db=db_name()
if @pubid is NULL 
    return (0)

select last_validated, attempted_validate from dbo.sysmergesubscriptions 
    where pubid=@pubid and 
          db_name=@subscriber_db and 
          UPPER(subscriber_server) collate database_default = UPPER(@subscriber) collate database_default

return (0)
go

