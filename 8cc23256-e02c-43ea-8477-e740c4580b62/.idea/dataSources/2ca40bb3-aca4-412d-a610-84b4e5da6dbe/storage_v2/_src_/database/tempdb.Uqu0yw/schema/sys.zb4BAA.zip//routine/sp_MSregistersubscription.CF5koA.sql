
--
-- Name: sp_MSregistersubscription
--
-- Descriptions: 
--
-- Parameters: as defined in create statement
--
-- Returns: 0 - success
--          1 - Otherwise
--
-- Security: 
-- Requires Certificate signature for catalog access
--
create procedure sys.sp_MSregistersubscription (
    @replication_type            int, /* Transactional = 1, Merge = 2 */
    @publisher                     sysname,
    @publisher_db                 sysname,
    @publisher_security_mode    int = NULL,                        /* 0 standard; 1 integrated */
    @publisher_login            sysname = NULL,
    @publisher_password    nvarchar(524) = NULL,
    @publication                 sysname,         
    @subscriber                 sysname,
    @subscriber_db                 sysname,
    @subscriber_security_mode    int = NULL,                        /* 0 standard; 1 integrated */
    @subscriber_login            sysname = NULL,
    @subscriber_password        nvarchar(524) = NULL,
    @distributor                 sysname,
    @distributor_security_mode     int = NULL,
    @distributor_login             sysname = NULL,
    @distributor_password        nvarchar(524) = NULL,
    @subscription_id            uniqueidentifier ,
    @independent_agent            int = NULL,
    @subscription_type            int,
    @use_interactive_resolver    int = NULL,
    @failover_mode                int = NULL,
    @use_web_sync                bit = 0,
    @hostname                    sysname    = NULL
    ) AS

    SET NOCOUNT ON

    /* MobileSync Support */
    declare @regkey                            nvarchar(1000)
    declare @subidstr                        nvarchar(38)
    declare @profile_name                     nvarchar(100)
    declare @retcode                        int

    select @retcode = 0
    -- Security check: Sysadmin and DBO only
    exec @retcode = sys.sp_MSreplcheck_subscribe
    if @@error <> 0 or @retcode <> 0
    begin
        return 1
    end

    set @regkey = sys.fn_replgetsubscriptionregkey(@publisher, @publisher_db, @publication, @subscriber, @subscriber_db)
    set @subidstr = '{' + convert ( nchar(36), @subscription_id) + '}'
    set @profile_name = N'Windows Synchronization Manager profile' -- SyncMgr Profile

    EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                               @regkey,
                               'ProfileName',
                               'REG_SZ',
                                @profile_name    
    if @retcode <> 0 OR @@ERROR <> 0
        return 1

    EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                               @regkey,
                               'ReplicationType',
                               'REG_DWORD',
                                @replication_type    
    if @retcode <> 0 OR @@ERROR <> 0
        return 1

    EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                               @regkey,
                               'SubscriptionType',
                               'REG_DWORD',
                                @subscription_type    
    if @retcode <> 0 OR @@ERROR <> 0
        return 1

    EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                               @regkey,
                               'Subid',
                               'REG_SZ',
                                @subidstr    
    if @retcode <> 0 OR @@ERROR <> 0
        return 1

    EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                               @regkey,
                               'Publisher',
                               'REG_SZ',
                                @publisher                                        
    if @retcode <> 0 OR @@ERROR <> 0
        return 1

    EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                               @regkey,
                               'PublisherDb',
                               'REG_SZ',
                                @publisher_db
    if @retcode <> 0 OR @@ERROR <> 0
        return 1


    IF @use_interactive_resolver IS NOT NULL
    BEGIN
        EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                               @regkey,
                               'UseInteractiveResolver',
                               'REG_DWORD',
                                @use_interactive_resolver
        if @retcode <> 0 OR @@ERROR <> 0
            return 1
    END

    /* If Publisher security mode is NOT NULL, write out the entries */
    if @publisher_security_mode IS NOT NULL
    begin
        EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                                   @regkey,
                                   'PublisherSecurityMode',
                                   'REG_DWORD',
                                    @publisher_security_mode
        if @retcode <> 0 OR @@ERROR <> 0
            return 1

        EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                                   @regkey,
                                   'PublisherLogin',
                                   'REG_SZ',
                                    @publisher_login                                    
        if @retcode <> 0 OR @@ERROR <> 0
            return 1

    end
    EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                               @regkey,
                               'Publication',
                               'REG_SZ',
                                @publication
    if @retcode <> 0 OR @@ERROR <> 0
        return 1

    EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                               @regkey,
                               'Subscriber',
                               'REG_SZ',
                                @subscriber
    if @retcode <> 0 OR @@ERROR <> 0
        return 1

    /* If Subscriber security mode is NOT NULL, write out the entries */
    if @subscriber_security_mode IS NOT NULL
    begin
        EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                           @regkey,
                           'SubscriberSecurityMode',
                           'REG_DWORD',
                            @subscriber_security_mode
        if @retcode <> 0 OR @@ERROR <> 0
            return 1
            
        EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                           @regkey,
                           'SubscriberLogin',
                           'REG_SZ',
                            @subscriber_login                                    
        if @retcode <> 0 OR @@ERROR <> 0
            return 1
    end

    EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                               @regkey,
                               'SubscriberDb',
                               'REG_SZ',
                                @subscriber_db                                    
    if @retcode <> 0 OR @@ERROR <> 0
        return 1
                
    EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                               @regkey,
                               'Distributor',
                               'REG_SZ',
                                @distributor
    if @retcode <> 0 OR @@ERROR <> 0
        return 1

    /* If Distributor security mode is NOT NULL, write out the entries */
    if @distributor_security_mode IS NOT NULL
    begin
        EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                           @regkey,
                           'DistributorSecurityMode',
                           'REG_DWORD',
                            @distributor_security_mode
        if @retcode <> 0 OR @@ERROR <> 0
            return 1
            
        EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                           @regkey,
                           'DistributorLogin',
                           'REG_SZ',
                            @distributor_login                                    
        if @retcode <> 0 OR @@ERROR <> 0
            return 1
    end

    if @independent_agent IS NOT NULL
    begin
        EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                           @regkey,
                           'IndependentAgent',
                           'REG_DWORD',
                            @independent_agent    
        if @retcode <> 0 OR @@ERROR <> 0
            return 1
    end

    IF @failover_mode IS NOT NULL
    begin
        EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                           @regkey,
                           'FailoverMode',
                           'REG_DWORD',
                            @failover_mode    
        if @retcode <> 0 OR @@ERROR <> 0
            return 1

    end        
        
    IF @use_web_sync IS NOT NULL
    begin
        declare @use_web_sync_int int
        select @use_web_sync_int = convert(int, @use_web_sync)
        EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                           @regkey,
                           'WebSync',
                           'REG_DWORD',
                            @use_web_sync_int    
        if @retcode <> 0 OR @@ERROR <> 0
            return 1
    end            

    if @hostname is not null
    begin
        EXECUTE @retcode = master.dbo.xp_regwrite 'HKEY_LOCAL_MACHINE',
                              @regkey,
                              'HostName',
                              'REG_SZ',
                               @hostname
        if @retcode <> 0 OR @@ERROR <> 0
            return 1
    end

    -- Mark enabled_for_syncmgr bit if every thing succeeded.
    -- If the row exists in MSreplication_properties table, 
    -- set enabled_for_syncmgr bit
    -- The logic need to be here because UI call this sp directly.
    if object_id('MSsubscription_properties') is not NULL
    begin
        update MSsubscription_properties set enabled_for_syncmgr = 1 where
            UPPER(publisher) = UPPER(@publisher)
            and publisher_db =  @publisher_db
            and publication = @publication
        if @retcode <> 0 OR @@ERROR <> 0
            return 1
    end

    return 0
go

