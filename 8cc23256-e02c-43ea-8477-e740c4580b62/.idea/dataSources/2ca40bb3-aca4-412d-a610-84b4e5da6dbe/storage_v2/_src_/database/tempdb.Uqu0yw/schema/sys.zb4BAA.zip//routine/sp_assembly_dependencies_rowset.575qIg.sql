
create procedure sys.sp_assembly_dependencies_rowset
(
    @assembly_id            int = null,
    @assembly_schema        sysname = null,
    @assembly_referenced    int = null
)
as
    select
        ASSEMBLY_CATALOG        = db_name(),
        ASSEMBLY_SCHEMA         = user_name(a.principal_id),
        ASSEMBLY_ID             = ar.assembly_id,
        REFERENCED_ASSEMBLY_ID  = ar.referenced_assembly_id
    from
        sys.assembly_references ar inner join
        sys.assemblies a on
            (
                a.assembly_id = ar.assembly_id
            )
    where
        ar.assembly_id = @assembly_id and
        (@assembly_schema is null or a.principal_id = user_id(@assembly_schema)) and
        (@assembly_referenced is null or @assembly_referenced = 0 or @assembly_referenced = ar.referenced_assembly_id)
    order by 1, 2
go

