CREATE FUNCTION sys.dm_db_missing_index_columns (@handle int)
RETURNS TABLE
AS
	RETURN SELECT * 
		FROM OPENROWSET(TABLE MISSING_IDX_COLUMNS, @handle)
go

