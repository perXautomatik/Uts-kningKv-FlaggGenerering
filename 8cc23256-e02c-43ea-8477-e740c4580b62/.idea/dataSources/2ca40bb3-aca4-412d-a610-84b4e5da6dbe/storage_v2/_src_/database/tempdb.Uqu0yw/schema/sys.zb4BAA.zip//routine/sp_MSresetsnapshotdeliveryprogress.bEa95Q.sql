--
-- Name: sp_MSresetsnapshotdeliveryprogress
--
-- Description: This procedure removes all rows in the  
--              MSsnapshotdeliveryprogress table (if it exists) corresponding
--              to the specified snapshot delivery session. This will
--              effectively wipes out all memory of any previous 
--              progress that the snapshot delivery processes had made to
--              the subscriber database.
--
-- Notes: This procedure should be called at the subscriber database by
--        the distribution or the merge agent.
--
-- Parameter: @snapshot_session_token nvarchar(260) (mandatory)
--                - A UniCode string that uniquely identifies a snapshot
--                  delivery session. For now, this will be the snapshot
--                  generation folder of the snapshot being applied. 
--
-- Returns: 0 - succeeded
--          1 - failed
--
-- Security: Execute permission of this procedure is granted to public;
--           procedural security check will be performed to make sure
--           that the caller is either a db_owner of the current database
--           or a sysadmin. 
--
create procedure sys.sp_MSresetsnapshotdeliveryprogress
    @snapshot_session_token nvarchar(260)
as
begin
    set nocount on
    declare @retcode int
    select @retcode = 0
    exec @retcode = sys.sp_MSreplcheck_subscribe 
    if @retcode <> 0 or @@error <> 0
    begin
        select @retcode = 1
        goto FAILURE
    end
    if object_id('dbo.MSsnapshotdeliveryprogress') is not null
    begin
        delete dbo.MSsnapshotdeliveryprogress
        where session_token = @snapshot_session_token
        if @retcode <> 0 or @@error <> 0
        begin
            select @retcode = 1
            goto FAILURE
        end
    end
    if @retcode <> 0 or @@error <> 0
    begin
        select @retcode = 1
        goto FAILURE
    end


FAILURE:
    return @retcode    
end
go

