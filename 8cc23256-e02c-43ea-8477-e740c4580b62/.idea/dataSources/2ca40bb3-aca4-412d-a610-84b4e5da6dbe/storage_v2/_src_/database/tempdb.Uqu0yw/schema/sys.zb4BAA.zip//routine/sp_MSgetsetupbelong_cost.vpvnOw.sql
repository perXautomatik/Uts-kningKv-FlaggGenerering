
create procedure sys.sp_MSgetsetupbelong_cost
AS
        declare @article_statistics_table nvarchar(400)
        declare @quoted_article_statistics_table nvarchar(400)
        
    -- if the article statistics table does not exist do report any article statistics
    -- at the same time there is no need to raise an error if the table does not exits
    -- For article statistics to work the AGENT MUST create this temp table.
    -- if you change the table name change it here, in drprep.cpp (setupbelongs function) and in sp_MSsetupbelongs
    select @article_statistics_table = '#setupbelongs_article_statistics_table'
    if OBJECT_ID('tempdb..' + @article_statistics_table) is not NULL
    begin
            select @quoted_article_statistics_table = QUOTENAME(@article_statistics_table)
            exec ('select article_name, setupbelong_time from ' + @quoted_article_statistics_table)
            if @@ERROR<>0
                    return (1)
    end
go

