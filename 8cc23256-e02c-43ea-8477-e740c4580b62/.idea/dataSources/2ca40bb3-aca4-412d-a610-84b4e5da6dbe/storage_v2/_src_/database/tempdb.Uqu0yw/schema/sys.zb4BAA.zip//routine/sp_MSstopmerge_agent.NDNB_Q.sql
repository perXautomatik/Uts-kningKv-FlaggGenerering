create procedure sys.sp_MSstopmerge_agent
(
    @publisher      sysname,
    @publisher_db   sysname,
    @publication    sysname,
    @subscriber     sysname,
    @subscriber_db  sysname
)
as
begin
    set nocount on

    if (isnull(is_srvrolemember('sysadmin'),0) = 0)
    begin
        raiserror (21089, 16, -1)
        return 1
    end
    
    -- database must be distribution db
    if sys.fn_MSrepl_isdistdb(db_name()) <> 1
    begin
        raiserror (21482, 16, -1, 'sp_MSstopmerge_agent', 'distribution')
        return 1
    end

    declare @retcode int
            ,@stop tinyint

    set @stop = 1
    exec @retcode = sys.sp_MSmergeagentjobcontrol
        @publisher = @publisher,
        @publisher_db = @publisher_db,
        @publication = @publication,
        @subscriber = @subscriber,
        @subscriber_db = @subscriber_db,
        @action = @stop
    return @retcode
end
go

