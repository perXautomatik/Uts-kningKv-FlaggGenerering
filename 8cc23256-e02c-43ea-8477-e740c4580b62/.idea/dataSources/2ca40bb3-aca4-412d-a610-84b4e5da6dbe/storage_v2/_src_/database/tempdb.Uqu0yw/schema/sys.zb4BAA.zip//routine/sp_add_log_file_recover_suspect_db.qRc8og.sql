--
-- Name: sp_add_log_file_recover_suspect_db
-- Purpose: Adds a log file to a suspect database and runs
-- 		recovery on the database.  This SP should only be used
--		on databases that have been marked suspect due to
--		insufficient data (error 1105) or log (error 9002) space.
--
create procedure sys.sp_add_log_file_recover_suspect_db
	@dbName 	sysname			-- database name
	,@name		nvarchar(260)		-- logical file name
	,@filename	nvarchar(260)		-- OS file name
	,@size		nvarchar(20) 	= NULL	-- initial file size
	,@maxsize	nvarchar(20) 	= NULL	-- maximum file size
	,@filegrowth	nvarchar(20) 	= NULL	-- growth increment
as
	if (SERVERPROPERTY('IsMatrix') = 1)
	begin
		raiserror (28401, -1, -1, N'sys.sp_add_log_file_recover_suspect_db')
		return (1)
	end

	EXEC sys.sp_add_file_recover_suspect_db @dbName, 'LOG', NULL, @name, @filename, @size, @maxsize, @filegrowth
go

