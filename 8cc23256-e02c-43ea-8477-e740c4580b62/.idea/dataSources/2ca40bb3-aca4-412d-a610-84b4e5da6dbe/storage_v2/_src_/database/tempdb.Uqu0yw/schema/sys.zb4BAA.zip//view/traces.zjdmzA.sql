create view sys.traces as select * from OpenRowset(TABLE SYSTRACES)
go

