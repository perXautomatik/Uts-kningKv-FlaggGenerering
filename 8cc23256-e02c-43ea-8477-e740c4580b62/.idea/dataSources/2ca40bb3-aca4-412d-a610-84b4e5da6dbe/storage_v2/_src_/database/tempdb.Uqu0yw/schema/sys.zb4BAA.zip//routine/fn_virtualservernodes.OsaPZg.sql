create function sys.fn_virtualservernodes
	(
	)
returns @tab table(NodeName sysname NOT NULL, status int, status_description nvarchar(32), is_current_owner bit)
as
begin
	insert @tab
	select * from sys.dm_os_cluster_nodes

	return
end
go

