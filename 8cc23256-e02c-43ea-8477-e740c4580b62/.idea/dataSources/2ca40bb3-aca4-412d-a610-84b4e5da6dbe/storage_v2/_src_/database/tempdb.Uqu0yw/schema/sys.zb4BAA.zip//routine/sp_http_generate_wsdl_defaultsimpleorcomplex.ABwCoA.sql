
create procedure sys.sp_http_generate_wsdl_defaultsimpleorcomplex
	@EndpointID int,
	@IsSSL bit,
	@Host nvarchar(256),
	@QueryString nvarchar(256),
	@UserAgent nvarchar(256) as
begin
	select @QueryString = LOWER (@QueryString collate Latin1_General_CI_AS)
	if @QueryString = N'wsdl'
	begin
		exec sys.sp_http_generate_wsdl_simple @EndpointID, @IsSSL, @Host, N'wsdl', @UserAgent
		return
	end
	if @QueryString = N'wsdlsimple'
	begin
		exec sys.sp_http_generate_wsdl_simple @EndpointID, @IsSSL, @Host, N'wsdl', @UserAgent
		return
	end
	if @QueryString = N'wsdlcomplex'
	begin
		exec sys.sp_http_generate_wsdl_complex @EndpointID, @IsSSL, @Host, N'wsdl', @UserAgent
		return
	end
	raiserror(17885, 16, 1)
end
go

