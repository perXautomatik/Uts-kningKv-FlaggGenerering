
--
-- Name:
--		sp_adddatatypemapping
--
-- Description:
--		Add source/destination data type mapping
--
-- Returns:
--		0 if successful
--		1 if failed
--
-- Security:
--		public
--
-- Notes:
--		Implicitly will create a DBMS map if it doesn't
--		currently exist.  DBMS types must exist before
--		adding a mapping.  If no default currently
--		exists, this is set as the default mapping
--

CREATE PROCEDURE sys.sp_adddatatypemapping
(
	@source_dbms				sysname,
	@source_version				varchar(10) = NULL,
	@source_type				sysname,
	@source_length_min			bigint = NULL,
	@source_length_max			bigint = NULL,
	@source_precision_min		bigint = NULL,
	@source_precision_max		bigint = NULL,
	@source_scale_min			int = NULL,
	@source_scale_max			int = NULL,
	@source_nullable			bit = NULL,
	@destination_dbms			sysname,
	@destination_version		varchar(10) = NULL,
	@destination_type			sysname,
	@destination_length			bigint = NULL,
	@destination_precision		bigint = NULL,
	@destination_scale			int = NULL,
	@destination_nullable		bit = NULL,
	@destination_createparams	int = NULL,
	@dataloss					bit = 0,
	@is_default					bit = 0
)
AS
BEGIN
	DECLARE @retcode	int

	-- Issue unsupported warning
	RAISERROR(21769, 10, -1)

	-- Do data type mapping
	EXEC @retcode = sp_MSrepl_adddatatypemapping	@source_dbms				= @source_dbms,
													@source_version				= @source_version,
													@source_type				= @source_type,
													@source_length_min			= @source_length_min,
													@source_length_max			= @source_length_max,
													@source_precision_min		= @source_precision_min,
													@source_precision_max		= @source_precision_max,
													@source_scale_min			= @source_scale_min,
													@source_scale_max			= @source_scale_max,
													@source_nullable			= @source_nullable,
													@destination_dbms			= @destination_dbms,
													@destination_version		= @destination_version,
													@destination_type			= @destination_type,
													@destination_length			= @destination_length,
													@destination_precision		= @destination_precision,
													@destination_scale			= @destination_scale,
													@destination_nullable		= @destination_nullable,
													@destination_createparams	= @destination_createparams,
													@dataloss					= @dataloss,
													@is_default					= @is_default

	RETURN @retcode
END
go

