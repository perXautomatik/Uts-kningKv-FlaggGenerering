create procedure sys.sp_processlogshippingretentioncleanup 
(
    @agent_id uniqueidentifier
    ,@agent_type tinyint  -- 0 = backup, 1 = copy, 2 = restore
    ,@monitor_server sysname 
    ,@monitor_server_security_mode bit 
    ,@history_retention_period int
    ,@curdate_utc datetime
)
as
begin
    set nocount on
    declare @retcode int
    
    --
    -- security check
    --
    exec @retcode = sys.sp_MSlogshippingsysadmincheck
    if (@retcode != 0 or @@error != 0)
        return 1
    --
    -- This should be called only on the remote monitor server
    --
    if (@monitor_server is null or upper(@monitor_server) != upper(@@servername))
        return 0
    --
    -- must be invoked from MSDB
    --
    if (db_name() != N'msdb')
    begin
        raiserror (21482, 16, -1, N'sp_processlogshippingretentioncleanup', N'msdb')
        return 1
    end
    --
    -- call the internal proc now
    --
    exec @retcode = sys.sp_MSprocesslogshippingretentioncleanup
                    @agent_id = @agent_id
                    ,@agent_type = @agent_type
                    ,@monitor_server = @monitor_server
                    ,@monitor_server_security_mode = @monitor_server_security_mode
                    ,@history_retention_period = @history_retention_period
                    ,@curdate_utc = @curdate_utc
    if (@retcode != 0 or @@error != 0)
        return 1
    --
    -- all done
    --
    return 0
end
go

