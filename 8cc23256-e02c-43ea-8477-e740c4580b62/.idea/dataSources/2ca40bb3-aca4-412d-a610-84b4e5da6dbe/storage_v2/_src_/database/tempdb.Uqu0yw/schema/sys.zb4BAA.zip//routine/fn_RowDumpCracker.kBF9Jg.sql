-------------------------------------------------------------------------------
-- Name: sys.fn_RowDumpCracker 
--
-- Description:
--	Cracks the output of %%rowdump%% virtual column
--
-- Notes:
--	1. If inrowLength is 0 it implies the column is null or 0-length
--	2. If information about a column is not output then it must be a trailing 
--	   null or 0-length variable length column.
--	3. Filters out columns that have been dropped.
--	4. Filters out uniquifiers.
--	5. Does not report clustering key columns in non-clustered indexes
--    6. Rowdump format: this explains the constants used below
--		<rowset_id>|<colcount>|<col 1>| ... | <col N>
--		8 bytes    |4 bytes   |10bytes | ... | 10 bytes
-------------------------------------------------------------------------------

CREATE FUNCTION sys.fn_RowDumpCracker (@rowdump AS varbinary (max))
RETURNS @varColumns TABLE
(
  partition_id				BIGINT NOT NULL,		-- partition id to use for join against system views
  colName					sysname NULL,			-- name of column, NULL if a dropped column
  IsInrow					BIT NOT NULL,			-- is the column's value inlined or off-row
  IsSparse					BIT NOT NULL,			-- is the column a sparse column? 
  IsRecordPrefixCompressed	BIT NOT NULL,			-- is the record prefix compressed?
  IsSymbol					BIT NOT NULL,			-- is this column a symbol?
  PrefixBytes				INT NOT NULL,			-- the number of prefix bytes used by this column
  InRowLength				INT NOT NULL			-- what is the length of in-row content of the column
)
as
begin

	declare @offset			int
	declare @column_count	int
	declare @i				int
	declare @partition_id	bigint
	declare @column_offset	int
	declare @column_id		int
	declare @reserved_id int

	-- Check there are enough bytes for partition_id and var column count
	--
	if (datalength (@rowdump) < (8 + 4 + 4))
	BEGIN
		RETURN
	END

	select @offset = 1				-- Start at offset 1

	select @partition_id = convert (bigint, convert (binary(8), reverse (substring (@rowdump, @offset, 8))))

	if not exists (select * from sys.system_internals_partitions where partition_id = @partition_id)
	BEGIN
		RETURN
	END

	set @offset = @offset + 8		-- partition ID is 8 bytes

	select @reserved_id = convert (int, convert (binary(4), reverse (substring (@rowdump, @offset, 4)))) 
	set @offset = @offset + 4		-- Reserved ID is 4 bytes


	select @column_count = convert (int, convert (binary(4), reverse (substring (@rowdump, @offset, 4)))) 

	-- Quick return on bad bytes. Here the var column count is too large
	-- NOTE: 1024 is the same as COLCOUNT in code. +50 to account for hidden columns.
	--
	if (@column_count > 1024+50)
	BEGIN
		RETURN
	END
	
	select @offset = @offset + 4	-- Column count is 4 bytes

	-- Check enough bytes for number of variable length columns - need 2 bytes per column
	--
	if ((datalength (@rowdump) - @offset + 1) <> (@column_count * 10))
	BEGIN
		RETURN
	END

	set @i = 0
	while (@i < @column_count)
	begin
		
		declare @column_info smallint
		declare @inrow_len smallint
		declare @prefix_bytes int
		declare @inrow_len_offset int
		declare @colinfo_offset int
		declare @prefix_bytes_offset int
		declare @colName sysname
		declare @isSparse bit
		declare @isInRow bit
		declare @isSymbol bit
		declare @isRecPrefixed bit
		declare @column_id_offset int

		-- The column id corresponds to first 4 bytes of the column structure.
		--
		select @column_id_offset = @offset
		select @column_id = convert (int, convert (binary(4), reverse (substring (@rowdump, @column_id_offset, 4))))

		-- Next 2 bytes is the in-row length of the column value.
		--
		select @inrow_len_offset =  @column_id_offset + 4
		SET @inrow_len = convert (smallint, convert (binary (2), reverse (substring (@rowdump, @inrow_len_offset, 2))))

		-- Next 2 bytes is the column info flags.
		--
		select @colinfo_offset = @inrow_len_offset + 2
		SET @column_info = convert (smallint, convert (binary (2), reverse (substring (@rowdump, @colinfo_offset, 2))))

		-- Next 2 bytes is the prefix bytes block.
		--
		select @prefix_bytes_offset = @colinfo_offset + 2
		SET @prefix_bytes = convert (int, convert (binary (2), reverse (substring (@rowdump, @prefix_bytes_offset, 2))))

		if (@column_info & 0x1 != 0)	
			set @isInRow = 0 
		else
			set @isInRow = 1

		if (@column_info & 0x2 != 0)
			set @isSparse = 1
		else 
			set @isSparse = 0

		if (@column_info & 0x4 != 0)
			set @isSymbol = 1
		else
			set @isSymbol = 0

		if (@column_info & 0x8 != 0)
			set @isRecPrefixed = 1
		else
			set @isRecPrefixed = 0

		if (@column_id is not null)
		begin
			select @colName = name
			from sys.columns cols join
				(select ic.column_id, ic.object_id
				from sys.columns ic join sys.system_internals_partitions sip 
					on (ic.object_id = sip.object_id)
				where sip.partition_id = @partition_id and
					ic.column_id = @column_id) colidSrc
			on (colidSrc.object_id = cols.object_id and colidSrc.column_id = cols.column_id)

			insert into @varColumns values (@partition_id, @colName, @isInRow, @isSparse, @isRecPrefixed, @isSymbol, @prefix_bytes, @inrow_len)
		end

		-- Move to next column
		--
		set @offset = @offset + 10
		set @i = @i + 1

		-- These values have to be reinitialized after each iteration to ensure that our NULL checks 
		-- will succeeed.  If the join produces no rows, then the variable isn't automatically re-
		-- initialized.  That breaks us.
		--
		set @column_id = null
		set @colName = null
	end

	return
end

go

