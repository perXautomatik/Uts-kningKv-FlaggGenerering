
create procedure sys.sp_filestream_recalculate_container_size
(
	@dbname sysname,			-- name of the database to process
	@filename sysname = NULL	-- FILESTREAM file container name to recalculate
)
as
begin
	set nocount    on

	declare @returncode	int

	EXEC @returncode = sys.sp_filestream_recalculate_container_size_internal @dbname, @filename

	return @returncode
end
go

