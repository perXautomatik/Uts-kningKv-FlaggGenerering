create procedure sys.sp_dbmmonitordropmonitoring 
as
begin
	set nocount on
	if (is_srvrolemember(N'sysadmin') <> 1 )
        begin
			raiserror(21089, 16, 1)
			return 1
		end

	declare @retcode int,
			@jobname nvarchar(256)

	select @jobname=isnull( formatmessage( 32047 ), N'Database Mirroring Monitor Job' )

-- Drop the jobstep
-- TO DO: get the job_id and use that to delete the job and job step.
	exec @retcode = msdb.dbo.sp_delete_jobstep @job_name = @jobname,
		@step_id = 0								-- Removes all jobsteps from job
	if ( @@error != 0 OR @retcode != 0 )
		begin
			raiserror( 32035, 16, 1 )
			-- return 1					-- TO DO: handle errors better.  check retcode to see if the object was not there.  
										-- if it wasn't there, continue.
		end

-- Drop the job
	exec @retcode = msdb.dbo.sp_delete_job @job_name = @jobname, 
		@delete_history = 1,					-- Deletes the history
		@delete_unused_schedule = 1				-- Deletes the schedule
	if ( @@error != 0 OR @retcode != 0 )
		begin
			raiserror( 32035, 16, 2 )	-- TO DO: handle errors better.  check retcode to see if the object was not there.  
										-- if it wasn't there, continue.
			return 1
		end

return 0
end
go

