CREATE PROCEDURE sys.sp_sqlagent_verify_database_context
AS
BEGIN
  -- Check if we are in msdb context
  IF(LOWER(DB_NAME()) <> 'msdb')
  BEGIN
    DECLARE @dbname SYSNAME
    SET @dbname = 'database context: ' + DB_NAME()
    RAISERROR(14200, -1, -1, @dbname)
    RETURN(1) -- Failure
  END

  RETURN(0) -- success
END
go

