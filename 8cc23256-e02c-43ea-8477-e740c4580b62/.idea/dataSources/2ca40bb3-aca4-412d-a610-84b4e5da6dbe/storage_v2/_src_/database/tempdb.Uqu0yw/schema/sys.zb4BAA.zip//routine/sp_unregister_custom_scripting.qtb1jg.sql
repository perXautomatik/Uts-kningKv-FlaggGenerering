create procedure sys.sp_unregister_custom_scripting 
(
    @type varchar(16) 		-- one of 'insert', 'delete', 'update', 'custom_script'
    ,@publication sysname = NULL	-- publication to apply this to, NULL means all publications with articles  with @schema_option & 0x02 = 0x02
    ,@article sysname = NULL		-- article to apply this to, NULL means all articles with @schema_option & 0x02 = 0x02
)
as
begin
	declare @retcode int
	exec @retcode = sys.sp_register_custom_scripting @type = @type, @value = NULL, @publication = @publication, @article = @article
	return @retcode
end
go

