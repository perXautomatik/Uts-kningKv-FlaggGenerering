
create function sys.fn_replvarbintoint (@varbin varbinary(32))
returns int
as
begin
	return cast((substring(@varbin, 4, 1)  + substring(@varbin, 3, 1) + substring(@varbin, 2, 1) + substring(@varbin, 1, 1)) as int)
end
go

