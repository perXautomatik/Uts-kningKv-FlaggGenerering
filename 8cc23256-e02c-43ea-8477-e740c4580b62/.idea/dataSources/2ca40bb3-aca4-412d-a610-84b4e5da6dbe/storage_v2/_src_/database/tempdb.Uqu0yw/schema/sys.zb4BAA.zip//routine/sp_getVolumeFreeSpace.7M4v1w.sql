
CREATE PROCEDURE sys.sp_getVolumeFreeSpace
@database_name sysname,
@file_id int
AS
BEGIN

	IF(DB_NAME() != 'msdb')
	BEGIN
		RAISERROR(14416,-1,-1)
		RETURN 14416
	END
	IF ( HAS_PERMS_BY_NAME(null, null, 'VIEW SERVER STATE') != 1 )
	BEGIN
		RAISERROR(38002, -1, -1, 'View Server State')
		RETURN 38002
	END
	DECLARE @physicalfilename nvarchar(260)
	SELECT @physicalfilename = physical_name FROM sys.master_files WHERE database_id = DB_ID(@database_name) AND file_id = @file_id
	IF(@physicalfilename IS NULL)
	BEGIN
		RAISERROR(38001,-1,-1,@file_id,@database_name)
		RETURN 38001
	END
	SELECT sys.fn_getVolumeFreeSpace_internal(@physicalfilename)
END
go

