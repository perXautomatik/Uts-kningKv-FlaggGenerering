
create procedure sys.sp_MSSQLDMO90_version
as
	/* Values for this are same as @@microsoftversion */
   /* @@microsoftversion format is 0xaaiibbbb (aa = major, ii = minor, bb[bb] = build #) */
	declare @i int
	select @i = 0x09000000	/* Must be in hex! */

	/* Select the numeric value, and a conversion to make it readable */
	select N'Microsoft SQLDMO Scripts' = @i, N'Version' = convert(binary(4), @i)
go

