CREATE PROC sys.sp_help_spatial_geometry_index_xml
(
	@tabname		NVARCHAR(776),		-- the TABLE to check for indexes
	@indexname		SYSNAME,		-- the INDEX name
	@verboseoutput	TINYINT,		-- OUTPUT all properties
	@query_sample	GEOMETRY,		-- query window object
	@xml_output		XML OUTPUT		-- XML variable to OUTPUT
)
AS
BEGIN
	EXEC sys.sp_help_spatial_geometry_index_helper @tabname, @indexname, 1, @xml_output OUTPUT, @verboseoutput, @query_sample
END
go

