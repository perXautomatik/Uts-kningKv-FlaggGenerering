CREATE VIEW sys.dm_audit_class_type_map AS
	SELECT reverse(convert(char(2), convert(binary(2), class_type))) as [class_type],
		(SELECT spt.name 
			from master.dbo.spt_values spt where spt.type='EOD' AND spt.number = CONVERT(smallint, cl.class_type)) as [class_type_desc],
		(SELECT spt.name 
			from master.dbo.spt_values spt where spt.type='EOD' AND spt.number = CONVERT(smallint, cl.securable_class_id)) as [securable_class_desc]
	FROM OpenRowset(TABLE DM_AUDIT_CLASS_TYPE_MAP) cl
go

