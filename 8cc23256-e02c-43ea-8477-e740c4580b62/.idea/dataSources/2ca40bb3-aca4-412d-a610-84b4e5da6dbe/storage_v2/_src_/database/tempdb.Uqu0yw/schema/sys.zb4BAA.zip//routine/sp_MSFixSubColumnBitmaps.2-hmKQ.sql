create procedure sys.sp_MSFixSubColumnBitmaps
        @artid uniqueidentifier,
        @bm varbinary(128)
as
    declare @missing_col_count int
    declare @retcode int

    -- Security check
    if 1 <> is_member('db_owner')
    begin    
        RAISERROR (15247, 11, -1)
        return (1)
    end

    exec @retcode= sys.sp_MSBitmapCount
                    @bm1= @bm,
                    @count= @missing_col_count output

    update dbo.sysmergearticles 
        set     missing_cols         = @bm, 
            missing_col_count     = @missing_col_count
    where artid = @artid

    return (0)
go

