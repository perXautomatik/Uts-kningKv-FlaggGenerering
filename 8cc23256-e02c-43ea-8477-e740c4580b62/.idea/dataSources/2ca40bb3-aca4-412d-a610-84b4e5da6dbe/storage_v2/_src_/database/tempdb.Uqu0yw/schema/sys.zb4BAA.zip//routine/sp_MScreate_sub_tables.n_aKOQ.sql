create procedure sys.sp_MScreate_sub_tables 
(
    @tran_sub_table                 bit = 0,
    @property_table                 bit = 1,
    @sqlqueue_table                 bit = 0,
    @subscription_articles_table    bit = 0,
    @p2p_table                         bit = 0
)
as
BEGIN
    set nocount on
    declare @retcode int
    --
    -- security check
    --
    exec @retcode = sys.sp_MSreplcheck_subscribe 
    if @retcode <> 0 or @@error <> 0
        return 1
    --
    -- now invoke the internal routine
    --
    exec @retcode = sys.sp_MScreate_sub_tables_internal 
                            @tran_sub_table  = @tran_sub_table,
                            @property_table = @property_table,
                            @sqlqueue_table = @sqlqueue_table,
                            @subscription_articles_table = @subscription_articles_table,
                            @p2p_table = @p2p_table
    return @retcode
END
go

