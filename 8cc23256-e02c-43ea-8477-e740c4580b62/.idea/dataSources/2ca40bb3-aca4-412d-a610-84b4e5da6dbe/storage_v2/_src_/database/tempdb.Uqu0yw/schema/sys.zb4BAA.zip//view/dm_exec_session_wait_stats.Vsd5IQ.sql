
CREATE VIEW sys.dm_exec_session_wait_stats AS
	SELECT session_id, wait_type, waiting_tasks_count, wait_time_ms, max_wait_time_ms, signal_wait_time_ms
	FROM OpenRowset(TABLE SYSDMEXECSESSIONWAITSTATS)
go

