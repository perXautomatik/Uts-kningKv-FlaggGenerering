CREATE VIEW sys.dm_logpool_hashentries AS
	SELECT * 
	FROM OpenRowSet(TABLE DM_LOGPOOL_HASHENTRIES)
go

