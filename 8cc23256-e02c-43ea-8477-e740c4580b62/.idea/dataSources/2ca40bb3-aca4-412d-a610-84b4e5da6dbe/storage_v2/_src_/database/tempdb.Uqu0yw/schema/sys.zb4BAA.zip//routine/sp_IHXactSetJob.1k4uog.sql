
--
-- Name:
--		sp_IHXactSetJob
--
-- Description:
--		Manage the Oracle Poll Job used to force polling intervals
--		when the number of monitored changes exceeds a defined
--		threshold.
--
-- Inputs:
--		@publisher		== name of Oracle publisher
--		@enabled		== enabled flag
--		@interval		== minutes between Poll Job executions
--		@threshold		== number of changes to be exceeded
--					       prior to forcing new poll interval.
--		@LRinterval		== minutes between Poll Job executions
--                         when log reder is active
--		@LRthreshold	== number of changes to be exceeded
--					       prior to forcing new poll interval
--                         when log reader is active
--
-- Returns:
--		Return code (0 for success, 1 for failure)
--
-- Security:
--		public -- call must be sysadmin
--
-- Notes:
--		This stored procedure is provided so that the administrator of Oracle
--		publishing can activate, deactivate, and modify the parameters that
--		configure the execution of the Poll Job run at the Oracle database.
--      The settings are retained at the publisher in HREPL_XactSetJob.
--      All parameters default to NULL.  NULL parameters are not reset at the
--      publisher.
--

CREATE PROCEDURE sys.sp_IHXactSetJob
(
	@publisher		sysname,
	@enabled		bit = NULL,
	@interval		int = NULL,
	@threshold		int = NULL,
	@LRinterval		int = NULL,
	@LRthreshold	int = NULL
)
AS
BEGIN
	DECLARE @cmd			nvarchar(4000)
	DECLARE @retcode		int
	DECLARE @publisher_type	sysname

	--
	-- Security Check: require sysadmin
	--
	IF (ISNULL(IS_SRVROLEMEMBER('sysadmin'),0) = 0)
	BEGIN
		RAISERROR(21089,16,-1) 
		RETURN (1)
	END

	SET @retcode = 0

	EXEC @retcode = sys.sp_MSrepl_getpublisherinfo	@publisher		= @publisher,
													@rpcheader		= @cmd OUTPUT,
													@publisher_type	= @publisher_type OUTPUT,
													@hreplOnly		= 1
	
	IF @retcode <> 0
		RETURN (@retcode)

	-- Error if the publisher is not an Oracle publisher
	IF @publisher_type NOT LIKE 'ORACLE%'
	BEGIN
		RAISERROR (21696, 16, -1, @publisher, @publisher_type)
    		RETURN (1)
	END

	set @cmd = @cmd + N'sys.sp_ORAXactSetJob'
	
	EXEC @retcode = @cmd	@publisher,
				@enabled,
				@interval,
				@threshold,
				@LRinterval,
				@LRthreshold
	RETURN (@retcode)
END
go

