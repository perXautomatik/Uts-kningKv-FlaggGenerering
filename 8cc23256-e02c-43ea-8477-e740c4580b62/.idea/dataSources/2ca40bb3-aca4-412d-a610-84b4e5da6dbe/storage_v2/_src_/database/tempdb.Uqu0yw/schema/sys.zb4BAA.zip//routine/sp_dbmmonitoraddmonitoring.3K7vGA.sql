create procedure sys.sp_dbmmonitoraddmonitoring 
(
    @update_period		int = 1	-- in minutes
)
as
begin	
	set nocount on
	-- check to see if SYSADMIND
	if (is_srvrolemember(N'sysadmin') <> 1 )
    begin
		raiserror(21089, 16, 1)
		return (1)
	end

	declare @retcode		int,
			@category_id	int,
			@jobid			binary(16),
			@jobname		nvarchar( 256 ),
			@schedname		nvarchar( 256 )

	select @jobname   = isnull( formatmessage( 32047 ), N'Database Mirroring Monitor Job' )
	select @schedname = isnull( formatmessage( 32048 ), N'Database Mirroring Schedule' )

	-- Validate update_period to make sure that it is a reasonable number. 1 - 120 minutes for now. This value is int.
	-- Do not forget to change this in the sys.sp_dbmmonitorchangemonitoring below.
	if (@update_period < 1 or @update_period > 120)
	begin
 		raiserror ( 32032, 16, 1, @update_period )	-- specific message for the update period.
		return 1 
	end
	-- Find out if job is already there
	select @jobid = job_id, @category_id = category_id
        from msdb.dbo.sysjobs_view 
        where name = @jobname
	-- If the job already exists, error out
	if (@jobid is not null)	
	begin
		raiserror( 32033, 16, 1 )
		return 1 
	end

	-- By default, this job may run as the sql job agent.
	--
	exec @retcode = msdb.dbo.sp_add_job @job_name=@jobname, 
			@enabled=1, 
			@notify_level_eventlog=0, 
			@notify_level_email=2, 
			@notify_level_netsend=2, 
			@notify_level_page=2, 
			@delete_level=0, 
			@category_name=N'', -- TO DO: get another catagory_name.
			@job_id = @jobid output
	if (@@error != 0 or @retcode != 0 )
	begin
		raiserror( 32034, 16, 1 )
		return 1
	end

	exec @retcode = msdb.dbo.sp_add_jobserver @job_name=@jobname, @server_name = @@servername
	if ( @@error != 0 or @retcode != 0 )
	begin
		raiserror( 32034, 16, 2 )
		return 1
	end
	exec @retcode = msdb.dbo.sp_add_jobstep @job_name=@jobname,
			@step_name=N'', 
			@step_id=1, 
			@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_fail_action=2, 
			@retry_attempts=0, 
			@retry_interval=0, 
			@os_run_priority=0, @subsystem=N'TSQL', 
			@command=N'exec sys.sp_dbmmonitorupdate ', 
			@database_name=N'msdb', 
			@flags=0
	if ( @@error != 0 or @retcode != 0 )
	begin
		raiserror( 32034, 16, 3 )
		return 1
	end
	exec @retcode = msdb.dbo.sp_update_job @job_name=@jobname, 
			@enabled=1, 
			@start_step_id=1, 
			@notify_level_eventlog=0, 
			@notify_level_email=2, 
			@notify_level_netsend=2, 
			@notify_level_page=2, 
			@delete_level=0, 
			@description=N'', 
			@category_name=N'',  -- TO DO: get a catagory context: get from tools team.
			@notify_email_operator_name=N'', 
			@notify_netsend_operator_name=N'', 
			@notify_page_operator_name=N''
	if ( @@error != 0 OR @retcode != 0 )
	begin
		raiserror( 32034, 16, 4 )
		return 1
	end
	-- TO DO: if the job is already there, then we do not need to do these.
	-- TO DO: use the job_id for referencing the job.

	exec @retcode = msdb.dbo.sp_add_jobschedule @job_name=@jobname, @name=@schedname, 
			@enabled=1, 
			@freq_type=4, 
			@freq_interval=1, 
			@freq_subday_type=4,					-- this is in minutes
			@freq_subday_interval=@update_period,	-- this comes from the input to the proc.
			@freq_relative_interval=0, 
			@freq_recurrence_factor=1, 
			@active_start_date=null,
			@active_end_date=99991231, 
			@active_start_time=0, 
			@active_end_time=235959

	if ( @@error != 0 OR @retcode != 0 )
	begin
		raiserror( 32034, 16, 5 )
		return 1
	end
	
	return 0
end
go

