
-- this stored procedure is called by merge agent to release the application lock
-- acquired by sp_MSacquireSlotLock

create procedure sys.sp_MSreleaseSlotLock
@process_name   sysname,
@DbPrincipal    sysname = N'public'
AS
declare @retcode int

-- Security Checking 
-- sysadmin or db_owner or replication agent have access

exec @retcode = sys.sp_MSrepl_PAL_rolecheck 
if (@retcode <> 0) or (@@error <> 0)
begin
        RAISERROR (14126, 11, -1)
       return 1
end

exec @retcode=sys.sp_releaseapplock @process_name,@LockOwner=N'Session',@DbPrincipal=@DbPrincipal
IF (@retcode <> 0)
    BEGIN
        RAISERROR(21415, 16, -1)
        return (1)
    END
return @retcode
go

