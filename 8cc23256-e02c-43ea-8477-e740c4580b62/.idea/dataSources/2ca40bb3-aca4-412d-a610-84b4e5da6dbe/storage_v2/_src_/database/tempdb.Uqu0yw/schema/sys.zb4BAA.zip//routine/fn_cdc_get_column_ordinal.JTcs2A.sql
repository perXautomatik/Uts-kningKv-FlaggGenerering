create function sys.fn_cdc_get_column_ordinal				
(														
	@capture_instance	sysname,
	@column_name		sysname
)
returns int
with returns null on null input
as													
begin
	declare @ordinal_position int
		,@source_schema sysname
		,@source_name sysname
		
	-- Verify capture instance is not null or empty
	if (@capture_instance is null) or (rtrim(@capture_instance) = N'') 
	begin
		return null
	end
    
	-- Verify column name is not null or empty
	if (@column_name is null) or (rtrim(@column_name) = N'') 
	begin
		return null
	end
    
	set @source_schema = N'cdc'
	set @source_name = @capture_instance + N'_CT' 

	-- Caller must have select access to the source table
	if ([sys].[fn_cdc_has_select_access](@capture_instance) != 1)
	begin
		return null
	end
	
	select @ordinal_position = sys.fn_cdc_get_column_ordinal_internal(
		@source_schema, @source_name, @column_name)
	
	return @ordinal_position
end
go

