create procedure sys.sp_MSchange_mergepublication (
    @pubid uniqueidentifier,
    @property sysname = NULL,
    @value nvarchar(2000) = NULL
    ) AS

    set nocount on

    declare @value_numeric int
    declare @value_bit bit
    -- Security check
    if 1 <> is_member('db_owner')
    begin    
        RAISERROR (15247, 11, -1)
        return (1)
    end

    /*
    ** Parameter Check:     @property.
    ** Check to make sure that @property is a valid property
    */
    if @property IS NULL OR LOWER(@property collate SQL_Latin1_General_CP1_CS_AS) NOT in 
                                                    ('allow_subscription_copy',
                                                    'centralized_conflicts',
                                                    'conflict_logging',
                                                    'generation_leveling_threshold',
                                                    'automatic_reinitialization_policy')
    begin
        raiserror (21053, 16, -1, @property)
        return (1)
    end

    BEGIN TRAN MSchange_mergepublication    
    save tran MSchange_mergepublication
        
    if lower(@property collate SQL_Latin1_General_CP1_CS_AS) = 'allow_subscription_copy'
    begin
        if LOWER(@value collate SQL_Latin1_General_CP1_CS_AS) = 'true'
            select @value_bit = 1
        else 
            select @value_bit = 0

        UPDATE dbo.sysmergepublications 
            SET allow_subscription_copy = @value_bit
            WHERE pubid = @pubid
        if @@error <> 0
        BEGIN
           GOTO UNDO
        END
    end
    else if lower(@property collate SQL_Latin1_General_CP1_CS_AS) = 'centralized_conflicts'
    begin
        if LOWER(@value collate SQL_Latin1_General_CP1_CS_AS) = 'true'
            select @value_numeric = 1
        else 
            select @value_numeric = 0
    
        UPDATE dbo.sysmergepublications 
            SET centralized_conflicts = @value_numeric,
                decentralized_conflicts = case @value_numeric
                                            when 1 then 0
                                            else 0
                                          end
            WHERE pubid = @pubid
        if @@error <> 0
        BEGIN
           GOTO UNDO
        END
    end
    else if lower(@property collate SQL_Latin1_General_CP1_CS_AS) = 'conflict_logging'
    begin
        if LOWER(@value collate SQL_Latin1_General_CP1_CS_AS) = 'publisher'
            select @value_numeric = 1
        else if LOWER(@value collate SQL_Latin1_General_CP1_CS_AS) = 'both'
            select @value_numeric = 2
        else 
            select @value_numeric = 0
    
        UPDATE dbo.sysmergepublications 
            SET centralized_conflicts = case @value_numeric
                                            when 1 then 1
                                            when 2 then 1
                                            else 0
                                        end,
                decentralized_conflicts = case @value_numeric
                                            when 1 then 0
                                            when 2 then 1
                                            else 0
                                          end
            WHERE pubid = @pubid
        if @@error <> 0
        BEGIN
           GOTO UNDO
        END
    end
    else if lower(@property collate SQL_Latin1_General_CP1_CS_AS) = 'generation_leveling_threshold'
    begin
        select @value_numeric = convert(int, @value)
        
        UPDATE dbo.sysmergepublications 
            SET generation_leveling_threshold = @value_numeric
            WHERE pubid = @pubid
        if @@error <> 0
        BEGIN
           GOTO UNDO
        END
    end
    else if lower(@property collate SQL_Latin1_General_CP1_CS_AS) = 'automatic_reinitialization_policy'
    begin
        UPDATE dbo.sysmergepublications 
            SET automatic_reinitialization_policy = @value
            WHERE pubid = @pubid
        if @@error <> 0 GOTO UNDO
    end
                    
    COMMIT TRAN
    return 0

UNDO: 
    if @@TRANCOUNT > 0
    begin
        ROLLBACK TRANSACTION MSchange_mergepublication
        COMMIT TRANSACTION
    end

go

