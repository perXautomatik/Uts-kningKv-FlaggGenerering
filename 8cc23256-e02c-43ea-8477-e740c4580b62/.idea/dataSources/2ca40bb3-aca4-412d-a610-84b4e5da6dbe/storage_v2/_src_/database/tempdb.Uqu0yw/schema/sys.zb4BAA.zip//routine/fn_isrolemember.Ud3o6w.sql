create function sys.fn_isrolemember
(
    @mode int  -- 0 = generic pal role check in DB, 1 = DB owner role check, 2 = specific tran PAL role check
    ,@login sysname -- @login we need to check for
    ,@tranpubid int -- optional - needed for mode = 2
)
returns int
as
begin
    declare @fret int

    if (@mode not in (0,1,2))
        select @mode = 0
    if (@login is null)
        select @login = suser_sname()
    select @fret = 0

    if (@mode = 0)
    begin
        --
        -- generic PAL check in the current db
        --
        if exists (select * from sys.database_role_members
            where role_principal_id in (select principal_id 
                                                    from sys.database_principals 
                                                    where name like N'MSReplPAL_' + cast(db_id() as nvarchar(10)) + N'_%' 
                                                        or name like N'MSmerge_%')
                and member_principal_id = (select dp.principal_id
                                                        from sys.database_principals as dp join master.dbo.syslogins as s
                                                        on dp.sid = s.sid
                                                        and s.name = @login))
        begin
            --
            -- has access
            --
            select @fret = 1
        end
    end
    else if (@mode = 1)
    begin
        --
        -- db owner check
        --
        if exists (select * from sys.database_role_members
            where role_principal_id in (select principal_id 
                                                    from sys.database_principals 
                                                    where lower(name) = 'db_owner')
                and member_principal_id = (select dp.principal_id
                                                        from sys.database_principals as dp join master.dbo.syslogins as s
                                                        on dp.sid = s.sid
                                                        and s.name = @login))
        begin
            --
            -- has access
            --
            select @fret = 1
        end
    end
    else if (@mode = 2)
    begin
        --
        -- PAL role membership check for specific transactional publication
        --
        if exists (select * from sys.database_role_members
            where role_principal_id = (select principal_id 
                                                    from sys.database_principals 
                                                    where name = N'MSReplPAL_' + cast(db_id() as nvarchar(10)) + N'_' + cast(@tranpubid as nvarchar(10)) )
                and member_principal_id = (select dp.principal_id
                                                        from sys.database_principals as dp join master.dbo.syslogins as s
                                                        on dp.sid = s.sid
                                                        and s.name = @login))
        begin
            --
            -- has access
            --
            select @fret = 1
        end
    end
    --
    -- all done
    --
    return @fret
end
go

