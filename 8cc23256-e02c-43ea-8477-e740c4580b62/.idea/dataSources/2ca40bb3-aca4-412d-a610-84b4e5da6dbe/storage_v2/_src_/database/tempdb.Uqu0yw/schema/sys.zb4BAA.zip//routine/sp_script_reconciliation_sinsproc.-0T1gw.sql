create procedure sys.sp_script_reconciliation_sinsproc 
(
    @artid int
    ,@publishertype tinyint=1        -- 1 = mssqlserver, 2 = heterogeneous
    ,@publisher sysname=NULL         -- May only be non-NULL if @publishertype = 2
)
as
begin
    declare @retcode int
    --
    -- security check
    --
    exec @retcode = sys.sp_MSreplcheck_publish
    if @@error <> 0 or @retcode <> 0
    begin
        return (1)
    end
    --
    -- call core function
    --
    exec @retcode = sys.sp_scriptinsproccore 
                @artid = @artid
                ,@format = 5
                ,@mode = 2              -- snapshot reconciliation mode
                ,@publishertype = @publishertype
                ,@publisher = @publisher
    return @retcode
end
go

