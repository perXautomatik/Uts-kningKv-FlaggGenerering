create view sys.dm_io_cluster_valid_path_names
as
	select * from OpenRowset(TABLE SERVERSHAREDVALIDPATHS)
go

