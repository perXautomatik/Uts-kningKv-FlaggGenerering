
create procedure sys.sp_MSgetchangecount(
    @startgen   bigint,
    @changes    int output,
    @updates    int output,
    @deletes    int output)
as
        declare @retcode int
        -- security check
        exec @retcode = sys.sp_MSrepl_PAL_rolecheck
        if @@error <> 0 or @retcode <> 0
                return 1
                
    select @deletes = count(*) from dbo.MSmerge_tombstone where generation = 0 or generation > @startgen
    select @updates = count(*) from dbo.MSmerge_contents where generation = 0 or generation > @startgen
    select @changes = @updates + @deletes
    return (0)
go

