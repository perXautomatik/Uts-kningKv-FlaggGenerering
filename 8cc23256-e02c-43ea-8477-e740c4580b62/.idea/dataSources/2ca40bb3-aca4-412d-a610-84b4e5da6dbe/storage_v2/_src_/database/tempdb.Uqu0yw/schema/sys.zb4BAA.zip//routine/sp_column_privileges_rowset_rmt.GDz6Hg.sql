
create procedure sys.sp_column_privileges_rowset_rmt
(
    @table_server       sysname,
    @table_catalog      sysname = null,
    @table_name         sysname = null,
    @table_schema       sysname = null,
    @column_name        sysname = null,
    @grantor            sysname = null,
    @grantee            sysname = null
)
as
    select
        GRANTOR,
        GRANTEE,
        TABLE_CATALOG,
        TABLE_SCHEMA,
        TABLE_NAME,
        COLUMN_NAME,
        COLUMN_GUID,
        COLUMN_PROPID,
        PRIVILEGE_TYPE,
        IS_GRANTABLE
    from
        sys.fn_remote_column_privileges (
                                        @table_server,
                                        @table_catalog,
                                        @table_schema,
                                        @table_name,
                                        @column_name,
                                        @grantor,
                                        @grantee)
    order by 3, 4, 5, 6, 9, 1, 2
go

