CREATE FUNCTION sys.dm_db_stats_properties_internal (@object_id int, @stats_id int)
RETURNS TABLE
AS
	RETURN SELECT *	FROM OPENROWSET(TABLE DM_DB_STATS_PROPERTIES, @object_id, @stats_id)
go

