create procedure sys.sp_MSenumcolumns
    @pubid uniqueidentifier,
    @artid uniqueidentifier,
    @maxschemaguidforarticle uniqueidentifier = NULL,
    @show_filtering_columns bit = 0
AS
    declare @retcode            int
    declare @procname            sysname
    declare @nickname            int

    -- security check
    if ({fn ISPALUSER(@pubid)} <> 1)
    begin
        if (@pubid is NULL)
        begin
            RAISERROR (21723, 16, -1, 'sp_MSenumcolumns')
            return 1
        end
        else
        begin
            RAISERROR (14126, 11, -1)
            return 1
        end
    end
    
    --
    -- For security: break ownership chain as
    -- we have no control over the proc name is
    --
    declare @spretcode int
            ,@spcall nvarchar(256)
    select @procname = 'dbo.' + select_proc from dbo.sysmergearticles where pubid = @pubid and artid = @artid
    select @spcall = N'exec @p1 = ' + @procname + N' @maxschemaguidforarticle = '

    if @maxschemaguidforarticle is NULL
        select @spcall = @spcall + 'NULL'
    else
        select @spcall = @spcall + '''' + convert(nvarchar(40),@maxschemaguidforarticle) +  ''''

    select @spcall = @spcall + ', @type = 6 '
    
    exec @retcode = sys.sp_executesql @stmt = @spcall
        ,@params = N'@p1 int output'
        ,@p1 = @spretcode output
    IF @@error<>0 or @retcode<>0 or @spretcode != 0 
        return 1
    
    -- SQL2000 and lower agents pass @show_filtering_columns as 0. 
    if @show_filtering_columns = 1
    begin
        select @nickname = nickname from dbo.sysmergearticles
        where pubid = @pubid 
        and artid = @artid
        
        exec @retcode = sys.sp_MSgetfilteringcolumns @pubid = @pubid, @nickname = @nickname
        if @@error <> 0 or @retcode <> 0
            return 1
    end
    
    return 0

go

