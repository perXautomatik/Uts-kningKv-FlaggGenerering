CREATE VIEW sys.dm_os_threads AS
	SELECT *
	FROM OpenRowSet(TABLE SYSTHREADS)
go

