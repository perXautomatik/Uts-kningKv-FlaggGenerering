CREATE PROCEDURE sys.sp_MSget_subscription_guid 
(
    @agent_id int 
)
as
begin
	set nocount on

	-- You need to make change to sp_MShelp_distribution_agentid when changing
	-- this.	
	-- Get subscription_guid
	select a1.subscription_guid
	from MSdistribution_agents a1
	where
	-- for non anonymous agents
	((a1.virtual_agent_id is null and a1.id = @agent_id) or
	(   -- for anonymous agents
		a1.id = (select virtual_agent_id from MSdistribution_agents a2 where
			a2.id = @agent_id)) -- virtual account
	) 
end
go

