create procedure sys.sp_MSget_type_wrapper
(
    @tabid int, 
    @colid int, 
    @colname sysname output, 
    @typestring nvarchar(4000) output
)
as
begin
    declare @retcode int
    
    -- Since Merge needs this proc to be public we will put a dbo check here
    exec @retcode = sys.sp_MSreplcheck_publish
    if @retcode <> 0 or @@error<> 0
        return 1

    -- now we will call sp_MSget_type with tempdb context
    exec @retcode = tempdb.sys.sp_MSget_type @tabid, @colid, @colname output, @typestring output
    return @retcode
end
go

