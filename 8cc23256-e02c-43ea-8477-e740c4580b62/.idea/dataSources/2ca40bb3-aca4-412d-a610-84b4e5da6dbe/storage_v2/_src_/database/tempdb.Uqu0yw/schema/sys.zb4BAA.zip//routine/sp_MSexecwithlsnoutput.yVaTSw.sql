create procedure sys.sp_MSexecwithlsnoutput
(
	@command	nvarchar(max),
	@xact_seqno	varbinary(16) output
)
as
begin
	declare @retcode int

	select @xact_seqno = 0x0
	
	-- security check for subscriber
	-- Though the work below is related to a publisher, we use 
	-- a check for the subscriber because this is normally executed
	-- by the distribution agent at a subscriber (republisher).
	-- this should only be used by peer to peer subscribers.
	exec @retcode = sys.sp_MSreplcheck_subscribe 
    if @@error <> 0 or @retcode <> 0 
    begin
        return 1
    end

	begin transaction tran_sp_MSexecwithlsnoutput
	save transaction tran_sp_MSexecwithlsnoutput

	exec(@command)
	if @@error <> 0
    begin
        goto FAILURE
    end

    -- if this is not a republisher we will get an error. this is expected
    -- since we should never be calling this on a non-publisher database.
	exec @retcode = sys.sp_replincrementlsn @xact_seqno = @xact_seqno output
	if @@error <> 0 or @retcode <> 0 
	begin
		goto FAILURE
	end

	commit transaction tran_sp_MSexecwithlsnoutput
	
    return 0
FAILURE:
	rollback transaction tran_sp_MSexecwithlsnoutput
	commit transaction

	return 1
end
go

