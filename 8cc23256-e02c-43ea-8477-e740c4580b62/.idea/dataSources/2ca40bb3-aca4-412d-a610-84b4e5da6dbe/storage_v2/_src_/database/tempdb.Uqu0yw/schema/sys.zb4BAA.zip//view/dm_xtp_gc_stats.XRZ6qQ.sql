CREATE VIEW sys.dm_xtp_gc_stats
AS
	SELECT
	*
	FROM OpenRowset(TABLE XTP_SYSTEM_GC_STATS)
go

