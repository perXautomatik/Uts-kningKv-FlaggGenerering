create procedure sys.sp_addumpdevice	-- 1995/09/07 12:01
	@devtype varchar(20),				-- disk, tape, or virtual_device
	@logicalname   sysname,				-- logical name of the device
	@physicalname  nvarchar(260),		-- physical name of the device
	@cntrltype  smallint = null,		-- obsolete: controller type - ignored.
	@devstatus  varchar(40) = null      -- obsolete: device characteristics -ignored
as
	declare @type_enum	smallint -- devtype enumeration value
	declare @returncode int
	declare @devtypeIn varchar(20)
	select @devtypeIn = @devtype
		   ,@devtype = LOWER (@devtype collate Latin1_General_CI_AS)
	-- An open txn might jeopardize a recovery.
	set implicit_transactions off
	if @@trancount > 0
	begin
		raiserror(15002,-1,-1,'sys.sp_addumpdevice')
		return (1)
	end

	-- You must be SA to execute this sproc.
	if (not is_srvrolemember('diskadmin') = 1)
	begin
		raiserror(15247,-1,-1)
		return (1)
	end

	-- Check out the @devtype.
	select @type_enum = (case @devtype
		when 'disk'				then 2
		when 'tape'				then 5
		when 'virtual_device'	then 7
		end)

	if @type_enum is null
	begin
		raiserror(15044,-1,-1,@devtypeIn)
		return (1)
	end

	-- Check the args are not NULL.
	if @logicalname is null
	begin
		raiserror(15045,-1,-1)
		return(1)
	end

	-- Check to see that the @logicalname is valid.
	EXEC @returncode = sys.sp_validname @logicalname
	if @returncode <> 0
		return(1)

	if @physicalname is null
	begin
		raiserror(15046,-1,-1)
		return(1)
	end

	-- Prohibit certain special english words from being logical names.
	if (@logicalname IN ('disk', 'tape', 'virtual_device'))
	begin
		raiserror(15285,-1,-1,@logicalname)
		return (1)
	end

	BEGIN TRANSACTION
	-- Make sure that a device with @logicalname doesn't already exist.
	--  Always turn on the dump status bit, ignore @skip_tape (not in use)
	EXEC %%Device().NewDevice(Name = @logicalname, PhysicalName = @physicalname,
		Type = @type_enum, Size = 0)
	if @@error <> 0	-- duplicate logical name
	begin
		ROLLBACK TRANSACTION
		raiserror(15026,-1,-1,@logicalname)
		return (1)
	end

	-- Make sure physical file name would be unique among devices.
	if (select count(*) from master.dbo.sysdevices where phyname = @physicalname) > 1
	begin
		ROLLBACK TRANSACTION
		raiserror(15061,-1,-1,@physicalname)
		return (1)
	end

	COMMIT TRANSACTION

	return (0) -- sp_addumpdevice
go

