
CREATE PROCEDURE sys.sp_sqlagent_write_jobstep_log
    @job_id    UNIQUEIDENTIFIER, 
    @step_id   INT,
    @log_text  NVARCHAR(MAX)
AS
BEGIN
    DECLARE @retval INT

    -- Validate if current db context is supported
    EXEC @retval = sys.sp_sqlagent_verify_database_context
    IF (@retval <> 0)
    BEGIN
        RETURN(@retval)
    END

    -- If  job_id is null, then throw validation error
    IF(@job_id IS NULL)
    BEGIN
        RAISERROR(14262, -1, -1, '@job_id', 'NULL')
        RETURN(1) --Failure
    END

    -- Validate if given job_id exists in agent_jobs
    IF NOT EXISTS (SELECT name
                FROM sys.sqlagent_jobs
                WHERE job_id = @job_id)
    BEGIN
        DECLARE @job_id_as_char VARCHAR(36)
        SET @job_id_as_char = CONVERT(VARCHAR(36), @job_id)
        RAISERROR(14262, -1, -1, '@job_id', @job_id_as_char)
        RETURN(1) -- Failure
    END

    DECLARE @step_uid UNIQUEIDENTIFIER
        
    SELECT @step_uid = js.step_uid
    FROM sys.sqlagent_jobs j
    JOIN sys.sqlagent_jobsteps js
    ON js.job_id = j.job_id
    WHERE j.job_id = @job_id

    INSERT INTO sys.sqlagent_jobsteps_logs
    ([log_text], [date_created], [step_uid])
    VALUES(@log_text, GETDATE(), @step_uid)

    SET @retval = @@ERROR

    RETURN(@retval) -- 0 means success 
END
go

