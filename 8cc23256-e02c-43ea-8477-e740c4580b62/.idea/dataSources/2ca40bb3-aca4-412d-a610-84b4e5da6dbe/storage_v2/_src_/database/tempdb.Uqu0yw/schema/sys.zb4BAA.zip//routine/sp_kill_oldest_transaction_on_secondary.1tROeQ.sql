create procedure sys.sp_kill_oldest_transaction_on_secondary
(
	@database_name sysname,
	@kill_all bit = 0,
	@killed_xdests bigint = -1 output
)
as
	exec sys.sp_kill_oldest_transaction_on_secondary_internal @database_name, @kill_all, @killed_xdests output
go

