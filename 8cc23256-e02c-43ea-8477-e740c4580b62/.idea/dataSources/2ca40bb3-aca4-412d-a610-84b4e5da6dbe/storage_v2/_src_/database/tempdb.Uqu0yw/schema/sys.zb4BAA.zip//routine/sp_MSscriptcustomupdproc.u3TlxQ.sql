create procedure sys.sp_MSscriptcustomupdproc 
(
    @artid int
    ,@publishertype tinyint=1        -- 1 = mssqlserver, 2 = heterogeneous
    ,@publisher sysname=NULL		 -- May only be non-NULL if @publishertype = 2
    ,@usesqlclr bit=1
    ,@inDDLrepl bit=0
)
as
begin
	declare @retcode int
			,@scripting_proc nvarchar(512)
			,@updformat int
	--
	-- security check
	--
	exec @retcode = sys.sp_MSreplcheck_publish_withddladmin
	if @@error <> 0 or @retcode <> 0
	begin
	    return (1)
	end

	select @scripting_proc = quotename(object_name(upd_scripting_proc))
			,@updformat = case 
			    		when charindex( N'CALL', upper(upd_cmd collate SQL_Latin1_General_CP1_CS_AS) ) = 1 then 1  
			    		when charindex( N'MCALL', upper(upd_cmd collate SQL_Latin1_General_CP1_CS_AS) ) = 1 then 2  
			    		when charindex( N'XCALL', upper(upd_cmd collate SQL_Latin1_General_CP1_CS_AS) ) = 1 then 3  
			    		when charindex( N'VCALL', upper(upd_cmd collate SQL_Latin1_General_CP1_CS_AS) ) = 1 then 4
			    		when charindex( N'SCALL', upper(upd_cmd collate SQL_Latin1_General_CP1_CS_AS) ) = 1 then 5
			    		else 0 end
		    from sysarticles where artid = @artid

	-- SQL/None upd_cmd does not involve scripting, return without doing anything here.
	if @updformat = 0
		return (0)
	
	if @scripting_proc is null
	begin
        if @usesqlclr = 1 and @publishertype = 1
        begin
            exec @retcode = sys.sp_MSscriptcustomupdproc_sqlclr
                @artid = @artid
                ,@publisher = @publisher
        end
        else
        begin

		    select @scripting_proc = case @updformat when 1 then N'sys.sp_scriptupdproc'
			    								when 2 then N'sys.sp_scriptmappedupdproc'
				    							when 3 then N'sys.sp_scriptxupdproc'
					    						when 4 then N'sys.sp_scriptvupdproc'
						    					when 5 then N'sys.sp_scriptsupdproc'
							    				else N'' end
		    exec @retcode = @scripting_proc @artid = @artid
			    						,@publishertype = @publishertype
				    					,@publisher = @publisher
        end
	end
	else
 	begin
		--
		-- For security: break ownership chain as
		-- we have no control over the proc name is
		--
		declare @spretcode int
				,@spcall nvarchar(512)
		declare @temptext table(colidx int identity, col nvarchar(max) collate database_default) 
		select @spcall = N'exec @p1 = ' + @scripting_proc + N' @artid = @p2 '
		if @inDDLrepl = 1
		begin
			exec @retcode = sys.sp_executesql @stmt = @spcall
				,@params = N'@p1 int output, @p2 int'
				,@p1 = @spretcode output
				,@p2 = @artid
		end
		else
		begin
			insert @temptext(col) exec @retcode = sys.sp_executesql @stmt = @spcall
				,@params = N'@p1 int output, @p2 int'
				,@p1 = @spretcode output
				,@p2 = @artid
			select col from @temptext order by colidx
		end
		if (@retcode != 0 or @spretcode != 0)
			select @retcode = 1
	end
	
	return @retcode
end
go

