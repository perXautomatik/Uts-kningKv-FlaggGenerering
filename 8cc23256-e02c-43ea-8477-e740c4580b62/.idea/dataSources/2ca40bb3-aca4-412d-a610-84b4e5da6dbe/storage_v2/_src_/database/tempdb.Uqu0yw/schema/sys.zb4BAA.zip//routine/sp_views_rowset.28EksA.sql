
create procedure sys.sp_views_rowset
(
    @view_name      sysname,
    @view_schema    sysname = null
)
as
    select
        TABLE_CATALOG   = db_name(),
        TABLE_SCHEMA    = schema_name(a_v.schema_id),
        TABLE_NAME      = a_v.name,
        VIEW_DEFINITION = convert(nvarchar(1),null),
        CHECK_OPTION    = convert(bit, NULL),
        IS_UPDATABLE    = convert(bit, NULL),
        DESCRIPTION     = convert(nvarchar(1),null),
        DATE_CREATED    = a_v.create_date,
        DATE_MODIFIED   = convert(datetime,null)
    from
        sys.all_views a_v
    where
        (
            (@view_schema is null and a_v.name = @view_name) or
            object_id(quotename(@view_schema) + '.' + quotename(@view_name)) = a_v.object_id
        ) and
        has_perms_by_name(quotename(schema_name(a_v.schema_id)) + '.' + quotename(@view_name),
                          'object',
                          'select') = 1
    order by 1, 2, 3
go

