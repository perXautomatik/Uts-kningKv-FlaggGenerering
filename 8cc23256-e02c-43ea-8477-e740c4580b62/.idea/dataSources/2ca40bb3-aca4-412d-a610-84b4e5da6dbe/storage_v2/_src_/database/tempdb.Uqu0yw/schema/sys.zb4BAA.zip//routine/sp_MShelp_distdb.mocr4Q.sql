create procedure sys.sp_MShelp_distdb (     
    @publisher_name     sysname
)
as

-- Current user must have PAL access to at least one distribution database
declare @retcode int
exec @retcode = sys.sp_MSrepl_DistributorPALAccess
if @retcode <> 0 or @@error <> 0
BEGIN
    select NULL where 1=2   /* We still want an empty rowset for some agents */
    return(1)
end

if exists (select name from msdb.sys.objects where name = 'MSdistpublishers')
begin
    select distribution_db from msdb..MSdistpublishers
    where UPPER(name collate database_default) = UPPER(@publisher_name) collate database_default
end
else 
    select NULL where 1=2   /* We still want an empty rowset for some agents */
go

