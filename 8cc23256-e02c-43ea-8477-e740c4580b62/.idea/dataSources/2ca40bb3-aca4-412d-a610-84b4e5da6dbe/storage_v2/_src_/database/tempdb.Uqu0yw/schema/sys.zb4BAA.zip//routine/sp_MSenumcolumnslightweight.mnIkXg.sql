create procedure sys.sp_MSenumcolumnslightweight
	@pubid uniqueidentifier,
	@artid uniqueidentifier
AS
    declare @retcode	int
    declare @procname	sysname
	declare @postfix	nchar(32)

	exec @retcode= sys.sp_MSreplcheck_publish
	if @@error <> 0 or @retcode <> 0 return (1)


	select @postfix= procname_postfix
		from dbo.sysmergearticles 
		where artid = @artid and pubid = @pubid
	
	set @procname= quotename('MSmerge_lws_sp_multi_' + @postfix)

	exec @retcode= @procname @action=6
	if @@error<>0 or @retcode<>0 return (1)

	return 0
go

