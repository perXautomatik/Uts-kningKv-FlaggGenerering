--
-- Name:
-- 		sp_identitycolumnforreplication
--
-- Description:
--  	This procedure allows customers to set the NFR on
--		identity columns for a particular table.
--	
-- Returns:
--  	0-Success 1-Failure
--
-- Security: DBO check
--
-- Requires Certificate signature for catalog access
--
CREATE PROCEDURE sys.sp_identitycolumnforreplication
(
	@object_id	int,
	@value		bit
)
AS
BEGIN
	DECLARE @identity_column sysname

	IF IS_SRVROLEMEMBER('sysadmin') = 0
		AND IS_MEMBER('db_owner') = 0
	BEGIN
		RAISERROR(21050, 14, -1)
		RETURN 1
	END

	SELECT @identity_column = NULL

	SELECT @identity_column = name 
		FROM sys.columns
		WHERE object_id = @object_id
			AND COLUMNPROPERTY(object_id, name, 'IsIdentity') = 1
	IF @identity_column IS NOT NULL
	BEGIN
		EXEC %%ColumnEx(ObjectID = @object_id, Name = @identity_column).SetIdentityNotForRepl(Value = @value)
		IF @@ERROR <> 0 
			RETURN 1
	END

	RETURN 0
END
go

