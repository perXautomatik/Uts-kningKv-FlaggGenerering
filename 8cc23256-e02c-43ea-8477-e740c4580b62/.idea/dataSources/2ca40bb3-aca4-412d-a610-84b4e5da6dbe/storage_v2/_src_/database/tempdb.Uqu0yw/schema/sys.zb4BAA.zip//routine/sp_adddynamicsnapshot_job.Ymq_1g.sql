create procedure sys.sp_adddynamicsnapshot_job (
    @publication sysname,
    @suser_sname sysname = null,
    @host_name sysname = null,
    @dynamic_snapshot_jobname sysname = null output,
    @dynamic_snapshot_jobid uniqueidentifier = null output,

    -- Scheduling information
    @frequency_type              int = 2, -- 2 means OnDemand
    @frequency_interval          int = 1,
    @frequency_subday            int = 1,
    @frequency_subday_interval   int = 1,
    @frequency_relative_interval int = 1, 
    @frequency_recurrence_factor int = 1,
    @active_start_date           int = 0,
    @active_end_date             int = 0,
    @active_start_time_of_day    int = 0, 
    @active_end_time_of_day      int = 0
)
as
    declare @retcode int
    
    exec @retcode = sys.sp_MSreplcheck_publish
    if @@error <> 0 or @retcode <> 0
        return (1)

    if @suser_sname is NULL or ltrim(rtrim(@suser_sname)) = N''
        select @suser_sname = NULL
    if @host_name is NULL or ltrim(rtrim(@host_name)) = N''
        select @host_name = NULL
        
    exec @retcode = sys.sp_MSaddmergedynamicsnapshotjob 
            @publication = @publication, 
            @dynamic_filter_login = @suser_sname, 
            @dynamic_filter_hostname = @host_name, 
            @dynamic_snapshot_location = NULL, 
            @dynamic_snapshot_jobname = @dynamic_snapshot_jobname output,
            @dynamic_snapshot_jobid = @dynamic_snapshot_jobid output,
            @frequency_type = @frequency_type,
            @frequency_interval = @frequency_interval,
            @frequency_subday = @frequency_subday,
            @frequency_subday_interval = @frequency_subday_interval,
            @frequency_relative_interval = @frequency_relative_interval, 
            @frequency_recurrence_factor = @frequency_recurrence_factor,
            @active_start_date = @active_start_date,
            @active_end_date = @active_end_date,
            @active_start_time_of_day = @active_start_time_of_day, 
            @active_end_time_of_day = @active_end_time_of_day
     return @retcode
go

