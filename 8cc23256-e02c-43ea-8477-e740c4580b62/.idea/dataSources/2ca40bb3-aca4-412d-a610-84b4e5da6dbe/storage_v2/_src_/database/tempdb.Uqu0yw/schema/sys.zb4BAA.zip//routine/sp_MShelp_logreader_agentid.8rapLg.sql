CREATE PROCEDURE sys.sp_MShelp_logreader_agentid 
(
    @publisher_id       smallint,
    @publisher_db       sysname
)
AS
begin
    set nocount on
    declare @retcode int
    declare @publisher sysname
    declare @job_id binary(16)
    declare @qv_package	varchar(20)
    declare @desk_top		int
    declare @license_value int
    declare @qv_value_package int

    --
    -- security check
    -- only db_owner can execute this
    --
    if (is_member ('db_owner') != 1) 
    begin
        raiserror(14260, 16, -1)
        return (1)
    end

	select @qv_package = '845129433'
	select @license_value = 0 
	select @desk_top = 3
			
	exec @qv_value_package = sys.sp_MSinstance_qv @qv_package
	if @@ERROR<>0 
		begin
			raiserror(20089, 16, -1)
			return (1)
		end
	if @qv_value_package = 1		 --- 1 means desktop
		select @license_value = @desk_top   -- to be consistent with all other compenents.

    select logreaderAgent.id, logreaderAgent.name, @license_value, profileName.profile_name 
		from MSlogreader_agents as logreaderAgent 
		INNER JOIN msdb..MSagent_profiles as profileName 
		on logreaderAgent.profile_id = profileName.profile_id
		where 
        logreaderAgent.publisher_id = @publisher_id and 
        logreaderAgent.publisher_db = @publisher_db


    return(0)
end
go

