create function sys.dm_fts_index_keywords(
    @dbid int,
    @objid int)
returns table as return
	select 
	keyword, 
	fulltext_display_term(keyword) display_term, 
	colid column_id, 
	sum(doccount) document_count
	from openrowset(TABLE FTCOMPINDEX, @dbid, @objid, 0) compidx 
	group by keyword, colid, unusedPid
go

