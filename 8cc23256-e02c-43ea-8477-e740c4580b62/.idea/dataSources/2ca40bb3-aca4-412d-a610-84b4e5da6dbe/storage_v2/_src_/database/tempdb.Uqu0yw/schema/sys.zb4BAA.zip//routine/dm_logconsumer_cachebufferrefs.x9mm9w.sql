CREATE FUNCTION sys.dm_logconsumer_cachebufferrefs
	(
	@DatabaseId Int,
	@ConsumerId bigint
	)
RETURNS TABLE
as
	RETURN SELECT * FROM OpenRowset(TABLE DM_LOGCONSUMER_CACHEBUFFERREFS, @DatabaseId, @ConsumerId)
go

