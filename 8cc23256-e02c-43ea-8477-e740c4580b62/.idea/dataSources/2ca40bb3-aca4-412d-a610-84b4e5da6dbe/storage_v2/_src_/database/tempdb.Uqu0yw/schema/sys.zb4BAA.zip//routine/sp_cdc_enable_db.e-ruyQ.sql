create procedure [sys].[sp_cdc_enable_db]
as
begin
	declare @retcode int
			,@containment tinyint
			,@db_name sysname

    -- Verify SQL Server edition
    -- CDC is restricted to Eval, Enterprise, Developer, and Standard editions
    IF (sys.fn_MSrepl_editionid () not in (20,30,31))
    BEGIN
        DECLARE @edition sysname
        SELECT @edition = CONVERT(sysname, SERVERPROPERTY('Edition'))
        RAISERROR(22988, 16, -1, @edition)
        RETURN (1)
    END
    
    -- Verify caller is authorized to enable change data capture for the database 
    if (isnull(is_srvrolemember('sysadmin'),0) = 0) 
    begin
		raiserror(22902, 16, -1)
		return 1
    end

    -- Verify database does NOT contain memory optimized table.
    -- Enabling CDC does imply a database trigger being created for DROP_TABLE - as DDL 
    -- triggers are not supported with memory optimized table, drop of memory optimized 
    -- tables will fail in a database with CDC enabled.
    IF EXISTS (select object_id from sys.tables where is_memory_optimized = 1)
    BEGIN
        RAISERROR(41385, 16, -1)
        RETURN 1
    END

    /*
    ** Contained Database check (Replication is not yet supported on contained databases)
    ** If the current database is a contained database, then we error out.
    */
    SELECT @containment=containment FROM sys.databases WHERE
        database_id = db_id()
    if (@containment != 0)
    BEGIN
        set @db_name = db_name()
        RAISERROR(12839, 16, -1, @db_name)
        RETURN(1)
    END
    
    exec @retcode = sys.sp_cdc_enable_db_internal
    
    if (@@error <> 0) or (@retcode <> 0)
    begin
		return 1
	end
	
	return 0
end
go

