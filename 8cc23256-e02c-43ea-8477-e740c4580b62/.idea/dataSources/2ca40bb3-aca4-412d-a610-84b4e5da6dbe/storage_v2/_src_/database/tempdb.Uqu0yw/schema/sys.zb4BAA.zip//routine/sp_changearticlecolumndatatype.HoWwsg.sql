
--
-- Name:    
--          sp_chagnearticlecolumndatatype
--          
-- Description: 
--			Sets article column datatype mapping
--  
-- Security: 
--          Public
--
-- Returns:
--          Success (0) or failure (1)
--      
-- Owner:   
--          <current owner> 
--

create procedure sys.sp_changearticlecolumndatatype
(
	@publication	sysname,
	@article		sysname,
	@column			sysname,
	@mapping_id		int = NULL,
	@type			sysname = NULL,
	@length			bigint = NULL,
	@precision		bigint = NULL,
	@scale			bigint = NULL,
	@publisher		sysname = NULL
) 
AS
BEGIN
	DECLARE @cmd			nvarchar(4000)
	DECLARE @retcode		int
	DECLARE	@publisher_type	sysname
	
	SET @retcode = 0
	
	EXEC @retcode = sys.sp_MSrepl_getpublisherinfo	@publisher		= @publisher,
													@rpcheader		= @cmd OUTPUT,
													@publisher_type	= @publisher_type OUTPUT
	
	IF @retcode <> 0
		RETURN (@retcode)
		
	IF @publisher_type = N'MSSQLSERVER'
	BEGIN	
		RAISERROR (21659, 16, -1)
		RETURN (1)
	END

	-- Add sp
	SET @publisher = UPPER(@publisher) COLLATE DATABASE_DEFAULT
	set @cmd = @cmd + N'sys.sp_MSrepl_changearticlecolumndatatype'

	EXEC @retcode = @cmd
				@publication,
				@article,
				@column,
				@mapping_id,
				@type,
				@length,
				@precision,
				@scale,
				1,
				@publisher,
				@publisher_type

	RETURN (@retcode)
END
go

