

create procedure sys.sp_MSdeletemetadataactionrequest
(
    @pubid uniqueidentifier,
    @tablenick int,
    @rowguid1 uniqueidentifier,
    @rowguid2 uniqueidentifier = NULL,
    @rowguid3 uniqueidentifier = NULL,
    @rowguid4 uniqueidentifier = NULL,
    @rowguid5 uniqueidentifier = NULL,
    @rowguid6 uniqueidentifier = NULL,
    @rowguid7 uniqueidentifier = NULL,
    @rowguid8 uniqueidentifier = NULL,
    @rowguid9 uniqueidentifier = NULL,
    @rowguid10 uniqueidentifier = NULL,
    @rowguid11 uniqueidentifier = NULL,
    @rowguid12 uniqueidentifier = NULL,
    @rowguid13 uniqueidentifier = NULL,
    @rowguid14 uniqueidentifier = NULL,
    @rowguid15 uniqueidentifier = NULL,
    @rowguid16 uniqueidentifier = NULL,
    @rowguid17 uniqueidentifier = NULL,
    @rowguid18 uniqueidentifier = NULL,
    @rowguid19 uniqueidentifier = NULL,
    @rowguid20 uniqueidentifier = NULL,
    @rowguid21 uniqueidentifier = NULL,
    @rowguid22 uniqueidentifier = NULL,
    @rowguid23 uniqueidentifier = NULL,
    @rowguid24 uniqueidentifier = NULL,
    @rowguid25 uniqueidentifier = NULL,
    @rowguid26 uniqueidentifier = NULL,
    @rowguid27 uniqueidentifier = NULL,
    @rowguid28 uniqueidentifier = NULL,
    @rowguid29 uniqueidentifier = NULL,
    @rowguid30 uniqueidentifier = NULL,
    @rowguid31 uniqueidentifier = NULL,
    @rowguid32 uniqueidentifier = NULL,
    @rowguid33 uniqueidentifier = NULL,
    @rowguid34 uniqueidentifier = NULL,
    @rowguid35 uniqueidentifier = NULL,
    @rowguid36 uniqueidentifier = NULL,
    @rowguid37 uniqueidentifier = NULL,
    @rowguid38 uniqueidentifier = NULL,
    @rowguid39 uniqueidentifier = NULL,
    @rowguid40 uniqueidentifier = NULL,
    @rowguid41 uniqueidentifier = NULL,
    @rowguid42 uniqueidentifier = NULL,
    @rowguid43 uniqueidentifier = NULL,
    @rowguid44 uniqueidentifier = NULL,
    @rowguid45 uniqueidentifier = NULL,
    @rowguid46 uniqueidentifier = NULL,
    @rowguid47 uniqueidentifier = NULL,
    @rowguid48 uniqueidentifier = NULL,
    @rowguid49 uniqueidentifier = NULL,
    @rowguid50 uniqueidentifier = NULL,
    @rowguid51 uniqueidentifier = NULL,
    @rowguid52 uniqueidentifier = NULL,
    @rowguid53 uniqueidentifier = NULL,
    @rowguid54 uniqueidentifier = NULL,
    @rowguid55 uniqueidentifier = NULL,
    @rowguid56 uniqueidentifier = NULL,
    @rowguid57 uniqueidentifier = NULL,
    @rowguid58 uniqueidentifier = NULL,
    @rowguid59 uniqueidentifier = NULL,
    @rowguid60 uniqueidentifier = NULL,
    @rowguid61 uniqueidentifier = NULL,
    @rowguid62 uniqueidentifier = NULL,
    @rowguid63 uniqueidentifier = NULL,
    @rowguid64 uniqueidentifier = NULL,
    @rowguid65 uniqueidentifier = NULL,
    @rowguid66 uniqueidentifier = NULL,
    @rowguid67 uniqueidentifier = NULL,
    @rowguid68 uniqueidentifier = NULL,
    @rowguid69 uniqueidentifier = NULL,
    @rowguid70 uniqueidentifier = NULL,
    @rowguid71 uniqueidentifier = NULL,
    @rowguid72 uniqueidentifier = NULL,
    @rowguid73 uniqueidentifier = NULL,
    @rowguid74 uniqueidentifier = NULL,
    @rowguid75 uniqueidentifier = NULL,
    @rowguid76 uniqueidentifier = NULL,
    @rowguid77 uniqueidentifier = NULL,
    @rowguid78 uniqueidentifier = NULL,
    @rowguid79 uniqueidentifier = NULL,
    @rowguid80 uniqueidentifier = NULL,
    @rowguid81 uniqueidentifier = NULL,
    @rowguid82 uniqueidentifier = NULL,
    @rowguid83 uniqueidentifier = NULL,
    @rowguid84 uniqueidentifier = NULL,
    @rowguid85 uniqueidentifier = NULL,
    @rowguid86 uniqueidentifier = NULL,
    @rowguid87 uniqueidentifier = NULL,
    @rowguid88 uniqueidentifier = NULL,
    @rowguid89 uniqueidentifier = NULL,
    @rowguid90 uniqueidentifier = NULL,
    @rowguid91 uniqueidentifier = NULL,
    @rowguid92 uniqueidentifier = NULL,
    @rowguid93 uniqueidentifier = NULL,
    @rowguid94 uniqueidentifier = NULL,
    @rowguid95 uniqueidentifier = NULL,
    @rowguid96 uniqueidentifier = NULL,
    @rowguid97 uniqueidentifier = NULL,
    @rowguid98 uniqueidentifier = NULL,
    @rowguid99 uniqueidentifier = NULL,
    @rowguid100 uniqueidentifier = NULL
)
as
    if {fn ISPALUSER(@pubid)} <> 1
    begin
        raiserror(14260, 16, -1)
        return (1)
    end
    
    delete dbo.MSmerge_metadataaction_request with (rowlock)
    from
    (
        select @rowguid1 as rowguid union all
        select @rowguid2 as rowguid union all
        select @rowguid3 as rowguid union all
        select @rowguid4 as rowguid union all
        select @rowguid5 as rowguid union all
        select @rowguid6 as rowguid union all
        select @rowguid7 as rowguid union all
        select @rowguid8 as rowguid union all
        select @rowguid9 as rowguid union all
        select @rowguid10 as rowguid union all
        select @rowguid11 as rowguid union all
        select @rowguid12 as rowguid union all
        select @rowguid13 as rowguid union all
        select @rowguid14 as rowguid union all
        select @rowguid15 as rowguid union all
        select @rowguid16 as rowguid union all
        select @rowguid17 as rowguid union all
        select @rowguid18 as rowguid union all
        select @rowguid19 as rowguid union all
        select @rowguid20 as rowguid union all
        select @rowguid21 as rowguid union all
        select @rowguid22 as rowguid union all
        select @rowguid23 as rowguid union all
        select @rowguid24 as rowguid union all
        select @rowguid25 as rowguid union all
        select @rowguid26 as rowguid union all
        select @rowguid27 as rowguid union all
        select @rowguid28 as rowguid union all
        select @rowguid29 as rowguid union all
        select @rowguid30 as rowguid union all
        select @rowguid31 as rowguid union all
        select @rowguid32 as rowguid union all
        select @rowguid33 as rowguid union all
        select @rowguid34 as rowguid union all
        select @rowguid35 as rowguid union all
        select @rowguid36 as rowguid union all
        select @rowguid37 as rowguid union all
        select @rowguid38 as rowguid union all
        select @rowguid39 as rowguid union all
        select @rowguid40 as rowguid union all
        select @rowguid41 as rowguid union all
        select @rowguid42 as rowguid union all
        select @rowguid43 as rowguid union all
        select @rowguid44 as rowguid union all
        select @rowguid45 as rowguid union all
        select @rowguid46 as rowguid union all
        select @rowguid47 as rowguid union all
        select @rowguid48 as rowguid union all
        select @rowguid49 as rowguid union all
        select @rowguid50 as rowguid union all
        select @rowguid51 as rowguid union all
        select @rowguid52 as rowguid union all
        select @rowguid53 as rowguid union all
        select @rowguid54 as rowguid union all
        select @rowguid55 as rowguid union all
        select @rowguid56 as rowguid union all
        select @rowguid57 as rowguid union all
        select @rowguid58 as rowguid union all
        select @rowguid59 as rowguid union all
        select @rowguid60 as rowguid union all
        select @rowguid61 as rowguid union all
        select @rowguid62 as rowguid union all
        select @rowguid63 as rowguid union all
        select @rowguid64 as rowguid union all
        select @rowguid65 as rowguid union all
        select @rowguid66 as rowguid union all
        select @rowguid67 as rowguid union all
        select @rowguid68 as rowguid union all
        select @rowguid69 as rowguid union all
        select @rowguid70 as rowguid union all
        select @rowguid71 as rowguid union all
        select @rowguid72 as rowguid union all
        select @rowguid73 as rowguid union all
        select @rowguid74 as rowguid union all
        select @rowguid75 as rowguid union all
        select @rowguid76 as rowguid union all
        select @rowguid77 as rowguid union all
        select @rowguid78 as rowguid union all
        select @rowguid79 as rowguid union all
        select @rowguid80 as rowguid union all
        select @rowguid81 as rowguid union all
        select @rowguid82 as rowguid union all
        select @rowguid83 as rowguid union all
        select @rowguid84 as rowguid union all
        select @rowguid85 as rowguid union all
        select @rowguid86 as rowguid union all
        select @rowguid87 as rowguid union all
        select @rowguid88 as rowguid union all
        select @rowguid89 as rowguid union all
        select @rowguid90 as rowguid union all
        select @rowguid91 as rowguid union all
        select @rowguid92 as rowguid union all
        select @rowguid93 as rowguid union all
        select @rowguid94 as rowguid union all
        select @rowguid95 as rowguid union all
        select @rowguid96 as rowguid union all
        select @rowguid97 as rowguid union all
        select @rowguid98 as rowguid union all
        select @rowguid99 as rowguid union all
        select @rowguid100 as rowguid
    ) as rows
    inner join dbo.MSmerge_metadataaction_request m with (rowlock) 
    on m.rowguid = rows.rowguid and m.tablenick = @tablenick and rows.rowguid is not NULL
    option (force order, loop join)
    if @@error<>0
        return 1
go

