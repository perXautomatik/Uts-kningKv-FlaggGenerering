CREATE VIEW sys.dm_clr_properties AS
	SELECT
		name,
		value
	FROM OpenRowset(TABLE DM_CLR_PROPERTIES)
go

