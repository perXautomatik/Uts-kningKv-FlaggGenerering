--
-- Name: 
--	fn_repldecryptver4
-- 
-- Description: 
--	This function accepts an encrypted password as input 
--	and decrypts the value using the server provided crypto 
--	based on the master key created in the local database. 
--	If it detects that the logged on user is not DBO or that
--	the password has not been encrypted using the server dpapi
--	then the original password input is returned.
--
-- Parameters: 
--	See the procedure definition.
--
-- Returns: 
--	0 - On Success
--	1 - On Failure
--
-- Result: 
--	None
--
-- Security: 
--	DBO (func is public because snapshot agent calls it)
--
CREATE FUNCTION sys.fn_repldecryptver4 
(
	@password nvarchar(524)
)
RETURNS nvarchar(524)
AS
BEGIN
	-- if we are dbo and the encryption on the password
	-- is version 4 then we will decrypt using the cert
	IF IS_MEMBER('db_owner') = 1
		AND sys.fn_replencryptversion(@password) = 4
		AND EXISTS(SELECT *
					FROM sys.symmetric_keys 
					WHERE name = '##MS_DatabaseMasterKey##')
		AND EXISTS(SELECT *
					FROM sys.symmetric_keys 
					WHERE name = 'SQLSERVER_REPLICATION')
	BEGIN
    	SELECT @password = CONVERT(nvarchar(524), DECRYPTBYKEYAUTOCERT(CERT_ID('SQLSERVER_REPLICATION'), NULL, CONVERT(varbinary(4000), RIGHT(@password, LEN(@password) - 4))))
	END

	RETURN @password
END
go

