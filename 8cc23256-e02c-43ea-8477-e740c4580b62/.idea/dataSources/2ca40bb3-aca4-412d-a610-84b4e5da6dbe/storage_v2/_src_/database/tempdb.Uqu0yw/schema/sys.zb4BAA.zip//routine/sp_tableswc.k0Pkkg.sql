
create procedure sys.sp_tableswc
(
    @table_name         nvarchar(384)   = null,
    @table_owner        nvarchar(384)   = null,
    @table_qualifier    sysname = null,
    @table_type         varchar(100) = null,
    @fUsePattern        bit = 1, -- To allow users to explicitly disable all pattern matching.
    @fTableCreated      bit = 0  -- whether our caller created the table #sptableswc for us to insert into or we should create/drop it ourselves
)
as
    declare @databasename   sysname
    declare @qualprocname   nvarchar(142) -- 128 + '.sys.sp_tables'

    if (@fUsePattern = 1) -- Does the user want it?
    begin
        if ((@table_name is not null) and
            (@table_owner is not null) and
            (isnull(charindex('%', @table_name),0) = 0) and
            (isnull(charindex('_', @table_name),0) = 0) and
            (isnull(charindex('%', @table_owner),0) = 0) and
            (isnull(charindex('_', @table_owner),0) = 0))
        begin
             select @fUsePattern = 0 -- not a single wild char, so go the fast way.
        end
    end

    if @fTableCreated = 0
    begin
        create table #sptableswc
        (
            TABLE_QUALIFIER sysname collate catalog_default null,
            TABLE_OWNER sysname collate catalog_default null,
            TABLE_NAME sysname collate catalog_default null,
            TABLE_TYPE  varchar(32) collate catalog_default null,
            REMARKS varchar(254) collate catalog_default null
        )
    end

    if @fUsePattern = 0
    begin
        select @qualprocname = quotename(@table_qualifier) + '.sys.sp_tables'

        if object_id(@qualprocname) is null
        begin
            -- DB doesn't exist - request an empty resultset from current DB.
            select @qualprocname = 'sys.sp_tables'
            select @table_name = ' ' -- no tables with that name could possibly exist
        end

        /* -- Debug output, do not remove it.
        print '*************'
        print 'No pattern matching.'
        print @fUsePattern
        print isnull(@qualprocname, '@qualprocname = null')
        print isnull(@table_name, '@table_name = null')
        print isnull(@table_owner, '@table_owner = null')
        print isnull(@table_qualifier, '@table_qualifier = null')
        print isnull(@table_type, '@table_type = null')
        print '*************'
        */
        insert into #sptableswc exec @qualprocname @table_name, @table_owner, @table_qualifier, @table_type, @fUsePattern
    end
    else
    begin

        declare cursDB cursor local for
            select
                name
            from
                sys.databases d
            where
                d.name like @table_qualifier and
                d.name <> 'model' and
                has_dbaccess(d.name)=1
            for read only

        open cursDB

        fetch next from cursDB into @databasename
        while (@@FETCH_STATUS <> -1)
        begin
            if (charindex('%', @databasename) = 0)
            begin   -- Skip dbnames w/wildcard characters to prevent loop.
                select @qualprocname = quotename(@databasename) + '.sys.sp_tables'

                /* -- Debug output, do not remove it.
                print '*************'
                print 'THERE IS pattern matching!'
                print @fUsePattern
                print isnull(@qualprocname, '@qualprocname = null')
                print isnull(@table_name, '@table_name = null')
                print isnull(@table_owner, '@table_owner = null')
                print isnull(@databasename, '@databasename = null')
                print isnull(@table_type, '@table_type = null')
                print '*************'
                */
                insert into #sptableswc
                exec @qualprocname @table_name, @table_owner, @databasename, @table_type, @fUsePattern
            end
            fetch next from cursDB into @databasename
        end

        deallocate cursDB


    end

    if @fTableCreated = 0
    begin
        select
            *
        from
            #sptableswc
        order by 4, 1, 2, 3

        drop table #sptableswc
    end
go

