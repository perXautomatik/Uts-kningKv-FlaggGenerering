
create procedure sys.sp_MSquerysubtype (@pubid uniqueidentifier,@subscriber sysname, @subscriber_db sysname)
as
    -- Security check
    if (1 <> {fn ISPALUSER(@pubid)} and
        1 <> is_member('db_owner'))
    begin    
        RAISERROR (15247, 11, -1)
        return (1)
    end
    declare @subtype    int
    declare @deleted     int

    set @deleted = 2
    
    select @subtype = NULL
    select @subtype = subscription_type from dbo.sysmergesubscriptions where pubid=@pubid 
        and db_name=@subscriber_db 
        and UPPER(subscriber_server) collate database_default = UPPER(@subscriber) collate database_default 
        and status <> @deleted

    if @subtype is NULL
        select @subtype=2
    select @subtype
go

