create procedure sys.sp_delete_log_shipping_secondary_database
(
    @secondary_database sysname -- cannot be NULL
    ,@ignoreremotemonitor bit = 0
)
as
begin
    set nocount on
    declare @retcode int
    --
    -- security check
    --
    exec @retcode = sys.sp_MSlogshippingsysadmincheck
    if (@retcode != 0 or @@error != 0)
        return 1
    --
    -- must be invoked from master db
    --
    if (db_name() != N'master')
    begin
        raiserror(5001, 16,-1)
        return 1
    end
    --
    -- call internal SP
    --
    exec @retcode = sys.sp_delete_log_shipping_secondary_database_internal
                                    @secondary_database = @secondary_database
                                    ,@ignoreremotemonitor = @ignoreremotemonitor
                                    ,@overwrite = 0
    return @retcode
end
go

