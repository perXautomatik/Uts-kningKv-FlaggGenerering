-- This function returns the dynamic filter login (suser_sname) corresponding to the given
-- value of partitionid. If the publication uses both hostname and suser_sname for filtering
-- it uses the current value of hostname set on the connection to get the correct partition id.
create function sys.fn_MSget_dynamic_filter_login
(
    @publication_number int,
    @partition_id int
)
returns sysname
as
begin
    declare @pubid uniqueidentifier
    declare @retcode int
    declare @uses_host_name bit
    declare @suser_sname sysname
    declare @host_name sysname
    declare @select_command nvarchar(400)

    if (is_member('db_owner') <> 1)
    begin
        return NULL
    end
    
    select @pubid = pubid from dbo.sysmergepublications where publication_number = @publication_number
    if @pubid is NULL
        return NULL

    select @uses_host_name = sys.fn_MSpublication_uses_host_name(@pubid) 
    if @@error <> 0
        return NULL

    if @uses_host_name = 1
        select @host_name = host_name()
    else
        select @host_name = NULL

    -- the following is in dynamic sql because the hostname column may not exist when all publications
    -- use suser_sname for filtering
    if @uses_host_name = 1
        select @suser_sname = sys.fn_MSget_dynamic_filter_login_with_hostname(@publication_number, @partition_id)
    else
        select @suser_sname = SUSER_SNAME_FN from dbo.MSmerge_partition_groups 
            where publication_number = @publication_number
             and partition_id = @partition_id
        
    return @suser_sname
end
go

