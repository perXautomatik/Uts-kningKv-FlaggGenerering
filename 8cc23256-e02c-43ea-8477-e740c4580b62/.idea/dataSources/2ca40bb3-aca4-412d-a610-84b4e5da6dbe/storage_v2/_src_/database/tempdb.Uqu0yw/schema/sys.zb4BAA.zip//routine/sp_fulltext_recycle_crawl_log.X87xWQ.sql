create proc sys.sp_fulltext_recycle_crawl_log
    @ftcat      sysname        -- full-text catalog name
as
    set nocount on

    -- sp_fulltext_catalog will run under read committed isolation level --
    set transaction isolation level READ COMMITTED

    -- CHECK PERMISSIONS (must be a dbowner) --
    if (is_member('db_owner') = 0)
    begin
        raiserror(15247,-1,-1)
        return 1
    end

    if (db_name() in ('master','tempdb','model'))
    begin
        raiserror(9966, -1, -1)
        return 1
    end

    -- VALIDATE PARAMS --
    if @ftcat is null OR datalength(@ftcat) = 0 -- allow spaces in the name, but not a 0-length string
    begin
        raiserror(15600,-1,-1,'sys.sp_fulltext_recycle_crawl_log')
        return 1
    end

    -- DISALLOW USER TRANSACTION --
    set implicit_transactions off
    if @@trancount > 0
    begin
        raiserror(15002,-1,-1,'sys.sp_fulltext_recycle_crawl_log')
        return 1
    end

    declare @ftcatid smallint
    select @ftcatid = fulltext_catalog_id from sys.fulltext_catalogs where name = @ftcat
    if @ftcatid is null
    begin
		declare @curdbname sysname
		select @curdbname = db_name()
		declare @curdbnamelen int
		select @curdbnamelen = LEN(@curdbname)
		raiserror(7641,-1,-1,@ftcat, @curdbnamelen, @curdbname)
        return 1
    end

	DBCC CALLFULLTEXT ( 20, @ftcat) 

	return 0
go

