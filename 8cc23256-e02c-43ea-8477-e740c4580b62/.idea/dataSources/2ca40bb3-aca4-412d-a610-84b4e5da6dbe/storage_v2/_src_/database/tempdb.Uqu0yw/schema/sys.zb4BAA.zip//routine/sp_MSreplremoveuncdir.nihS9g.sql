--
-- Name: sp_MSreplremoveuncdir
--
-- Descriptions: 
--
-- Parameters: as defined in create statement
--
-- Returns: 0 - success
--          1 - Otherwise
--
-- Security: Public procedure invoked via RPC. db_owner check
--
-- Requires Certificate signature for catalog access
--
CREATE PROCEDURE sys.sp_MSreplremoveuncdir
(
    @dir            nvarchar(260),
    @ignore_errors  bit = 0
)
as
begin
    set nocount on

    declare @retcode int
    declare @local_dir nvarchar(260)
    declare @cmd nvarchar(1000)
    declare @machinename sysname
    set @retcode = 0
    --
    -- security check
    -- only sysadmin can execute this
    --
    if (isnull(is_srvrolemember('sysadmin'),0) = 0) 
    begin
        raiserror(14260, 16, -1)
        return (1)
    end

    /* Null\Empty paths == no-op */
    if @dir is null or rtrim(@dir) = N''
        return (0)

    /* Path truncation check */
    if len(@dir) = 260
        return (0)

    /* 
    ** We have to convert UNC to drive, otherwise will get 'Access denied' error in xp_cmdshell
    */
	select @machinename = convert(sysname, SERVERPROPERTY('machinename'))
    EXEC @retcode = master.dbo.sp_MSunc_to_drive @unc_path = @dir, 
        @local_server = @machinename, @local_path = @local_dir OUTPUT
    IF @retcode <> 0 or @@ERROR <> 0 
        RETURN(1)

    /*
    ** Delete directory in the distributor's directory.
    ** On Win9x, we have to use deltree instead
    */
    declare @platform_nt int 
    select @platform_nt = 0x1
    IF (( platform() & @platform_nt = @platform_nt))
    BEGIN 
        SELECT @cmd = 'if exist "' + sys.fn_escapecmdshellsymbolsremovequotes(@local_dir) collate database_default + '" rmdir /S /Q ' + '"' + sys.fn_escapecmdshellsymbolsremovequotes(@local_dir) collate database_default + '"'
    END
    ELSE
    BEGIN
        -- Don't need if exists check on Win9x but we do need 
        -- to remove the trailing slash
        IF SUBSTRING(@local_dir, LEN(@local_dir), 1) = N'\'
        BEGIN
            SELECT @local_dir = LEFT(@local_dir, LEN(@local_dir)-1)
        END
        SELECT @cmd = 'deltree /Y ' + '"' + sys.fn_escapecmdshellsymbolsremovequotes(@local_dir) collate database_default + '"'
    END

    EXECUTE  @retcode = master.dbo.xp_cmdshell @cmd, NO_OUTPUT
    
    if @ignore_errors <> 1
    begin
        if @retcode <> 0 or @@ERROR <> 0 
	    begin
		    raiserror(20015, 16, -1, @dir)
            return(1)
	    end
    end

    return (0)
end
go

