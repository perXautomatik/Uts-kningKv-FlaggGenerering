
create procedure sys.sp_xtp_slo_prepare_to_downgrade
(
	@database_name sysname,
	@xtp_can_downgrade bit OUTPUT
)
as
	exec sys.sp_xtp_slo_downgrade_helper_internal @database_name, 0, @xtp_can_downgrade OUTPUT
go

