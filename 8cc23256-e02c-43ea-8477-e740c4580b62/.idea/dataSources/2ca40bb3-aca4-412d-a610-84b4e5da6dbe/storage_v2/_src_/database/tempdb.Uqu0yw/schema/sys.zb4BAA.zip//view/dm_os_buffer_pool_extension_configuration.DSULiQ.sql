CREATE VIEW sys.dm_os_buffer_pool_extension_configuration AS
	SELECT *
	FROM OpenRowset(TABLE DM_OS_BPOOLEXTENSION_CONFIG)
go

