CREATE VIEW sys.dm_os_hosts AS
	SELECT *
	FROM OpenRowSet(TABLE SYSHOSTS)
go

