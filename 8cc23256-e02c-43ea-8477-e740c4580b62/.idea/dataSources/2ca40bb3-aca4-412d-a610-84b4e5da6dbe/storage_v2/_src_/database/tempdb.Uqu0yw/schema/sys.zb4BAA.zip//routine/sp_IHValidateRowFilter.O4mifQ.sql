
--
-- Name:
--		sp_IHValidateRowFilter
--
-- Description:
--		Validate a supplied row filter for an article within
--		a heterogeneous publication.
--
-- Inputs:
--		@publisher		== name of Oracle publisher
--		@owner			== table owner
--		@table			== table name
--		@columnmask		== mask identifying columns in article
--		@rowfilter		== row filter
--
-- Returns:
--		Return rowset with a single int value (0 for valid filter clause, 1 for invalid filter clause)
--
--		Return code (0 for success, 1 for failure)
--
--		NOTE:  Failure to provide a valid filter clause is not a failure
--		       with respect to the return code.
--
-- Security:
--		public -- call must be sysadmin
--
-- Notes:
--		This stored procedure is provided so that user interface can
--		pre-validate a user supplied filter priot to using it when
--		publishing an article.
--
--      If @columnmask is NULL, it is assumed that all columns of the
--      table are published.  If not secified, @columnmask defaults to NULL.
--

CREATE PROCEDURE sys.sp_IHValidateRowFilter
(
	@publisher		sysname,
	@owner			sysname,
	@table			sysname,
	@columnmask		binary(128) = NULL,
	@rowfilter		nvarchar(max)
)
AS
BEGIN
	DECLARE @cmd			nvarchar(4000)
	DECLARE @retcode		int
	DECLARE @publisher_type	sysname

	--
	-- Security Check: require sysadmin
	--
	IF (ISNULL(IS_SRVROLEMEMBER('sysadmin'),0) = 0)
	BEGIN
		RAISERROR(21089,16,-1) 
		RETURN (1)
	END

	--
	-- Parameter Check: columnlist and rowfilter must be non-NULL
	--
	if ( @rowfilter IS NULL)
	BEGIN
		RAISERROR (21784, 16, -1)
    		RETURN (1)
	END

	SET @retcode = 0

	EXEC @retcode = sys.sp_MSrepl_getpublisherinfo	@publisher		= @publisher,
													@rpcheader		= @cmd OUTPUT,
													@publisher_type	= @publisher_type OUTPUT,
													@hreplOnly		= 1
	
	IF @retcode <> 0
		RETURN (@retcode)

	-- Error if the publisher is not an Oracle publisher
	IF @publisher_type NOT LIKE 'ORACLE%'
	BEGIN
		RAISERROR (21696, 16, -1, @publisher, @publisher_type)
    		RETURN (1)
	END

	set @cmd = @cmd + N'sys.sp_ORAValidateRowFilter'
	
	EXEC @retcode = @cmd	@publisher,
				@owner,
				@table,
				@columnmask,
				@rowfilter,
				@publisher_type
	RETURN (@retcode)
END
go

