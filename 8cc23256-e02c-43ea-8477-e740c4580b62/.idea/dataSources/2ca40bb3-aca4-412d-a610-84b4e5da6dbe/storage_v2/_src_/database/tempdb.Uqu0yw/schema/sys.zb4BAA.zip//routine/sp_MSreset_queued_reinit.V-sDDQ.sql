create procedure sys.sp_MSreset_queued_reinit 
(
    @subscriber      sysname,                    -- subscriber server name
    @subscriber_db   sysname,                -- subscribing database name. 
    @artid    int                                   -- article id
)
as
begin
    set nocount on
    declare @retcode int
                ,@publication sysname
    --
    -- PAL security check
    -- Get publication name using artid
    --
    select @publication = p.name
    from syspublications p join sysarticles a on p.pubid = a.pubid
    where a.artid = @artid
    if (@publication is null)
    begin
        return (1)
    end
    exec @retcode = sys.sp_MSreplcheck_pull @publication = @publication
    if @@error <> 0 or @retcode <> 0
    begin
        return (1)
    end
    --
    -- Validate @subscriber
    --
    --
    -- validate @subscriber_db, @artid
    --
    if exists (select * 
        from dbo.syssubscriptions
        where artid = @artid 
            and srvname = UPPER(@subscriber) 
            and dest_db = @subscriber_db)
    begin
        --
        -- set the reinit flag
        --
        update dbo.syssubscriptions
        set queued_reinit = 0
        where artid = @artid 
            and srvname = UPPER(@subscriber) 
            and dest_db = @subscriber_db
        if (@@error != 0)
            return (1)
    end
    else
    begin
        return (1)
    end
    --
    -- all done
    --
    return (0)
end
go

