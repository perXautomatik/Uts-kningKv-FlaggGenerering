CREATE FUNCTION sys.fn_xe_file_target_read_file (
	@path nvarchar(260), 
	@mdpath nvarchar(260),
	@initial_file_name nvarchar(260) = NULL,
	@initial_offset bigint = NULL
)
RETURNS table
AS
	RETURN SELECT *
	FROM OpenRowSet(TABLE FN_XE_READ_FILE_TARGET_FILE, @path, @mdpath, @initial_file_name, @initial_offset)
go

