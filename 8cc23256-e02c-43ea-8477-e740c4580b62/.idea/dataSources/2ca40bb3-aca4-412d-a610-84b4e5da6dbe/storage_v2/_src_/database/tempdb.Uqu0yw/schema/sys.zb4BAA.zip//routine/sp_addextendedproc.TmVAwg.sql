
---------------------------- sp_addextendedproc ------------------------------
create procedure sys.sp_addextendedproc
	@functname nvarchar(517),	-- (owner.)name of function to call
	@dllname varchar(255)		-- name of DLL containing function
as
	-- If we're in a transaction, disallow the addition of the
	--  extended stored procedure.
	set implicit_transactions off
	if @@trancount > 0
	begin
		raiserror(15002,-1,-1,'sys.sp_addextendedproc')
		return (1)
	end

	-- Disallow 0-length string & NULL
	if @dllname is null or datalength(@dllname) = 0
	begin
		raiserror(15311,-1,-1,@dllname)
		return (1)
	end

	BEGIN TRANSACTION

	declare @dllwname nvarchar(255)
	set @dllwname = convert(nvarchar(255), @dllname)

	-- Create the extended procedure mapping.
	EXEC %%System().AddExtendedProc( Name = @functname, Value = @dllwname)
	if @@error <> 0
	begin
		ROLLBACK
		return 1
	end

	declare @objid int
	select @objid = object_id(@functname)

	-- EMDEventType(x_eet_Create_Extended_Procedure), EMDUniversalClass(x_eunc_Object), src major id, src minor id, src name
	-- -1 means ignore target stuff, target major id, target minor id, target name,
	-- # of parameters, 5 parameters
	EXEC %%System().FireTrigger(ID = 221, ID = 1, ID = @objid, ID = 0, Value = @functname,
		ID = -1, ID = 0, ID = 0, Value = NULL, 
		ID = 2, Value = @functname, Value = @dllname, Value = NULL, Value = NULL, Value = NULL, Value = NULL, Value = NULL)
	
	COMMIT

	return (0) -- sp_addextendedproc
go

