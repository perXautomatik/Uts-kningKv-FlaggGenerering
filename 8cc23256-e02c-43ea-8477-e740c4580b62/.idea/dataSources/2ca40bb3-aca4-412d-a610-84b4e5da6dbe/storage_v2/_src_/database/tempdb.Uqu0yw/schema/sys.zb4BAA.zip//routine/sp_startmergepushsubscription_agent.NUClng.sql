create procedure sys.sp_startmergepushsubscription_agent
(
    @publication    sysname,
    @subscriber     sysname,
    @subscriber_db  sysname
)
as
begin
    declare @retcode int
    declare @start tinyint
    set @retcode = 0
    set @start = 0

    exec @retcode = sys.sp_MSmergepushsubscriptionagentjobcontrol
        @publication = @publication,
        @subscriber = @subscriber,
        @subscriber_db = @subscriber_db,
        @action = @start
    return @retcode
end
go

