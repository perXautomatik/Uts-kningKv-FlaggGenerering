CREATE PROCEDURE sys.sp_MScheck_Jet_Subscriber
(
    @subscriber				sysname,
    @is_jet					int OUTPUT,
    @Jet_datasource_path	sysname OUTPUT
)
AS
begin
    --
    -- security check
    -- only db_owner can execute this
    --
    if (is_member ('db_owner') != 1) 
    begin
        raiserror(14260, 16, -1)
        return (1)
    end
    select @is_jet = 0
    IF EXISTS (select * from master.dbo.sysservers where UPPER(srvname) = UPPER(@subscriber)
                    and upper(providername) = 'MICROSOFT.JET.OLEDB.4.0')
    begin
    	select @is_jet = 1
    	select @Jet_datasource_path = datasource from master.dbo.sysservers where UPPER(srvname) = UPPER(@subscriber)
    end
    return (0)
end
go

