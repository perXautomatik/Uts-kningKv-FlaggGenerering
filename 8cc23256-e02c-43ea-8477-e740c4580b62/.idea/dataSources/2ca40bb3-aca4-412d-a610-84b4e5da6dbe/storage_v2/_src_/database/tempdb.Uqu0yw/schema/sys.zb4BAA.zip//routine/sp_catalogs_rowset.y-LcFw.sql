
create procedure sys.sp_catalogs_rowset
(
    @catalog_name       sysname
)
as
    select
        CATALOG_NAME    = name,
        DESCRIPTION     = convert(nvarchar(1),null)
    from
        sys.databases
    where
        name = @catalog_name and (has_dbaccess(name)=1 OR serverproperty('EngineEdition') = 5)
    order by 1
go

