
create procedure sys.sp_MSupdatereplicastate
        @pubid uniqueidentifier,
        @subid uniqueidentifier,
        @replicastate uniqueidentifier
as

        /*
        ** Check to see if current publication has permission
        */
        if ({ fn ISPALUSER(@pubid)} <> 1)
        begin   
                RAISERROR (14126, 11, -1)
                return (1)
        end

        update dbo.sysmergesubscriptions
                set replicastate= @replicastate
                where pubid = @pubid and subid = @subid

        return (0)
go

