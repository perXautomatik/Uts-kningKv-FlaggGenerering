create procedure sys.sp_MSgetpeerwinnerrow
(
	@originator_id nvarchar(32) = '%', --int
	@row_id nvarchar(19) = '%',   -- timestamp
	@conflict_table nvarchar(270)
)
as 
begin
    set nocount on
    declare @retcode int = 0
				,@cmd nvarchar(4000) 
				,@whcmd nvarchar(4000) = N'__$is_winner = 1 '

	select @cmd = N'select ''__$origin_datasource_srvname'' = h.originator_node,  ''__$origin_datasource_db'' = h.originator_db, * from ' + ISNULL(NULLIF(QUOTENAME(PARSENAME(@conflict_table, 2)) + N'.', N'.'), N'') + QUOTENAME(PARSENAME(@conflict_table, 1))
	
    /*
    ** Security Check.
    */
    exec @retcode = sys.sp_MSreplcheck_publish
    if @@ERROR <> 0 or @retcode <> 0
        return(1)
    --
    -- passed the security check
    --

    if (@originator_id != N'%')
    begin
            select @whcmd = @whcmd + N' and __$originator_id = ' + quotename(@originator_id, '''')
    end
    if (@row_id != N'%')
    begin
            select @whcmd = @whcmd + N' and ((__$change_id is not null and __$change_id = ' + @row_id
					+ N') or(__$change_id is null and __$row_id in (select __$change_id from ' 
					+ ISNULL(NULLIF(QUOTENAME(PARSENAME(@conflict_table, 2)) + N'.', N'.'), N'') + QUOTENAME(PARSENAME(@conflict_table, 1)) 
					+ N' where __$row_id = ' + @row_id + N')))'
    end
    select @cmd = @cmd + N' c join MSpeer_originatorid_history h on c.__$origin_datasource = h.originator_id where ' + @whcmd

    --
    -- execute the generated select
    --
    execute (@cmd)
    --
    -- all done
    --
end
go

