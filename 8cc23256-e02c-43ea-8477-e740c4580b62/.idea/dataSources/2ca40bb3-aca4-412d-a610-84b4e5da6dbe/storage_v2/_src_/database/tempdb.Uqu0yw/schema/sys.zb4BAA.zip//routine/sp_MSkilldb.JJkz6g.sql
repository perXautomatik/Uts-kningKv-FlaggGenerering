
create proc sys.sp_MSkilldb
	@dbname nvarchar(258)
as
	if (@@trancount > 0) begin
		RAISERROR (15002, -1, -1, N'sp_MSkilldb')
		return 1
	end

	if (is_member(N'db_owner') <> 1 and is_member(N'db_ddladmin') <> 1) begin
		RAISERROR (15003, -1, -1, N'')
		return 1
	end

	declare @stmt nvarchar(1000)
	select @stmt=N'drop database ' + QUOTENAME(@dbname)
	execute sys.sp_executesql @stmt
	return 0
go

