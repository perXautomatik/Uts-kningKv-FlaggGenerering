CREATE view sys.dm_hadr_cluster 
as
	SELECT 
	*
	FROM OpenRowset(TABLE DM_HADR_CLUSTER)
go

