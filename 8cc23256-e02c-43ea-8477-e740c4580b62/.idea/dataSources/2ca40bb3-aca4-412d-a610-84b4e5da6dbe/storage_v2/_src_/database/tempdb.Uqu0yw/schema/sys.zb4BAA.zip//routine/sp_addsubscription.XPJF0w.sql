create procedure sys.sp_addsubscription
(
    @publication					sysname,
    @article						sysname = 'all',
    @subscriber						sysname = NULL,
    @destination_db					sysname = NULL,
    @sync_type						nvarchar (255) = 'automatic',
    @status							sysname = NULL,
    @subscription_type				nvarchar(4) = 'push',
    -- SyncTran
    @update_mode					nvarchar(30) = 'read only',		-- Can be 'read only', 'sync tran', 'queued tran', 'failover', 'queued failover'
    @loopback_detection				nvarchar(5) = NULL,				-- 'true' or 'false'
    -- end SyncTran
    @frequency_type					int = NULL, -- defaults to 64
    @frequency_interval				int = NULL, -- defaults to 1
    @frequency_relative_interval	int = NULL, -- defaults to 1
    @frequency_recurrence_factor	int = NULL, -- defaults to 0
    @frequency_subday				int = NULL, -- defaults to 4
    @frequency_subday_interval		int = NULL, -- defaults to 5
    @active_start_time_of_day		int = NULL, -- defaults to 0
    @active_end_time_of_day			int = NULL, -- defaults to 235959
    @active_start_date				int = NULL, -- defaults to 0
    @active_end_date				int = NULL, -- defaults to 99991231
    @optional_command_line			nvarchar(4000) = NULL,
    
    @reserved						nvarchar(10) = NULL,			-- reserved, used when calling from other system
																	-- stored procedures, it will be set to 'internal'.
																	-- It should never be used directly
    @enabled_for_syncmgr			nvarchar(5) = NULL,			-- Enabled for SYNCMGR: true or false
    -- Agent offload
    @offloadagent					bit = 0,
    @offloadserver					sysname = NULL,
    -- End of agent offload
    -- DTS package name
    @dts_package_name				sysname  = NULL,				-- value will be sent and validated at distributor
    @dts_package_password			sysname = NULL,
    @dts_package_location			nvarchar(12) = NULL,
    @distribution_job_name			sysname = NULL,
    @publisher						sysname = NULL,
    -- Backup device specification for @sync_method = 'autonosync with backup'
    @backupdevicetype				nvarchar(20) = 'logical',
    @backupdevicename				nvarchar(1000) = null,
    @mediapassword					sysname = null,
    @password						sysname = null,
    @fileidhint						int = null,
    @unload							bit = 1,
    -- No-sync subscription LSN for @sync_method = 'autonosync with lsn'
    @subscriptionlsn				binary(10) = null
    -- expose -SubscriptionStreams functionality
    ,@subscriptionstreams tinyint	= null -- value provided should fall between 1 and 64
    ,@subscriber_type				tinyint = 0  -- defaults of SQL Server
    ,@memory_optimized				bit = 0  -- defaults of non-memory-optimized, 1 for memory-optimized
)
AS
BEGIN
	DECLARE @cmd			nvarchar(4000)
	DECLARE @retcode		int
	DECLARE @publisher_type	sysname

	SET @retcode = 0
	
	EXEC @retcode = sys.sp_MSrepl_getpublisherinfo	@publisher		= @publisher,
													@rpcheader		= @cmd OUTPUT,
													@publisher_type	= @publisher_type OUTPUT
	
	IF @retcode <> 0
		RETURN (@retcode)

	-- Add sp
	SET @publisher = UPPER(@publisher) COLLATE DATABASE_DEFAULT
	set @cmd = @cmd + N'sys.sp_MSrepl_addsubscription'
	
	EXEC @retcode = @cmd
					@publication,
					@article,
					@subscriber,
					@destination_db,
					@sync_type,
					@status,
					@subscription_type,
					@update_mode,
					@loopback_detection,
					@frequency_type,
					@frequency_interval,
					@frequency_relative_interval,
					@frequency_recurrence_factor,
					@frequency_subday,
					@frequency_subday_interval,
					@active_start_time_of_day,
					@active_end_time_of_day,
					@active_start_date,
					@active_end_date,
					@optional_command_line,
					@reserved,
					@enabled_for_syncmgr,
					@offloadagent,
					@offloadserver,
					@dts_package_name,
					@dts_package_password,
					@dts_package_location,
					@distribution_job_name,
					@publisher,
					@backupdevicetype,
					@backupdevicename,
					@mediapassword,
					@password,
					@fileidhint,
					@unload,
					@subscriptionlsn,
					@publisher_type
					,@subscriptionstreams
					,@subscriber_type
					,@memory_optimized
	RETURN (@retcode)
END
go

