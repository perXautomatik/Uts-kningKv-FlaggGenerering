
create procedure sys.sp_xml_schema_rowset2
(
    @schema_name        sysname = null,
    @target_namespace   sysname = null
)
as
---------------------------------------------------------------------------------------------
-- copy & pasted from version 1 of the SProc and removed checks for 1st parameter !
---------------------------------------------------------------------------------------------
    select
        SCHEMACOLLECTION_CATALOGNAME    = xsv.SCHEMACOLLECTION_CATALOGNAME,
        SCHEMACOLLECTION_SCHEMANAME     = xsv.SCHEMACOLLECTION_SCHEMANAME,
        SCHEMACOLLECTIONNAME            = xsv.SCHEMACOLLECTIONNAME,
        TARGETNAMESPACEURI              = xsv.TARGETNAMESPACEURI,
        SCHEMACONTENT                   = xsv.SCHEMACONTENT

    from
        sys.spt_xml_schema_view xsv

    where
        xsv.xml_collection_id > 1 and -- skip 'sys' entry
        (@schema_name is null or xsv.schema_id = schema_id(@schema_name)) and
        (@target_namespace is null or @target_namespace = xsv.targetnamespaceuri)

    order by 1,2,3,4
go

