CREATE FUNCTION sys.dm_exec_xml_handles (@spid int)
RETURNS table
AS
	RETURN SELECT *
	FROM OpenRowSet(TABLE DM_EXEC_XML_HANDLES, @spid)
go

