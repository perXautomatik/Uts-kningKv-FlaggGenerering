CREATE FUNCTION sys.fn_MSxe_read_event_stream (
	@source nvarchar(260),
	@source_opt int = 0
)
RETURNS table
AS
	RETURN SELECT *
	FROM OpenRowSet(TABLE FN_MSXE_READ_EVENT_STREAM, @source, @source_opt, db_id ())
go

