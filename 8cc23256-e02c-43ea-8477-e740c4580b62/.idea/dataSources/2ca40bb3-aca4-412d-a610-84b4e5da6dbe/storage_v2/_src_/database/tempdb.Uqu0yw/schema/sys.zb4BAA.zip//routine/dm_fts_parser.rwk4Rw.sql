create function sys.dm_fts_parser(
    @querystring nvarchar(4000),
    @lcid int,
    @stoplistid int,
    @accentsensitive bit)
returns table as return
    select keyword, groupid group_id, phraseid phrase_id, occurrence,
	case matchop
		when 0 then N'Exact Match'
		when 2 then N'Noise Word'
		when 3 then N'End Of Sentence'
		when 4 then N'End of Paragraph'
		when 5 then N'End of Chapter'
		else N'Unknown'
	end special_term,
	fulltext_display_term(keyword) display_term, expansiontype expansion_type, sourceterm source_term
	from openrowset(TABLE WORDBREAK, @querystring, @lcid, @stoplistid, @accentsensitive) pars
go

