CREATE PROCEDURE sys.sp_MSget_subscription_dts_info 
(
    @job_id varbinary(16)
) 
AS
begin
    SET NOCOUNT ON
    --
    -- security check
    -- only db_owner can execute this
    --
    if (is_member ('db_owner') != 1) 
    begin
        raiserror(14260, 16, -1)
        return (1)
    end

    select dts_package_name, dts_package_location 
    from MSdistribution_agents where
    job_id = @job_id

    RETURN (0)
end
go

