
/*
 * The following three scripts must retain the SQLOLE nomenclature as we provide them to be an informative
 * notification to downlevel connections.
 */
create procedure sys.sp_MSSQLDMO70_version
as
	/* localize message without changing message number */
	declare @errtxt nvarchar(1024)
	select @errtxt=text from sys.messages, sys.syslanguages
	where message_id = 29001 
		and language_id=sys.syslanguages.lcid 
		and sys.syslanguages.langid = @@langid

	if @errtxt IS NULL
	begin
		select top(1) @errtxt=text from sys.messages, sys.syslanguages
		where message_id = 29001 
	end
	RAISERROR(55555, 16, 1); -- @errtxt
	
	RETURN 1
go

