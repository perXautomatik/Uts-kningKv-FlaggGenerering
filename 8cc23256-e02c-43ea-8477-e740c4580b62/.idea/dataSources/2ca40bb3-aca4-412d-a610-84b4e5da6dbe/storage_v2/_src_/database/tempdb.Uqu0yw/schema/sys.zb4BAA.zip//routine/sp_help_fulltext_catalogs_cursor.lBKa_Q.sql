create procedure sys.sp_help_fulltext_catalogs_cursor
	@cursor_return CURSOR VARYING OUTPUT,
	@fulltext_catalog_name		sysname = NULL		-- full-text catalog name
as
	-- FULLTEXT MUST BE ACTIVE IN DATABASE --
	if DatabasePropertyEx(db_name(), 'IsFulltextEnabled') = 0
	begin
		raiserror(15601,-1,-1)
		return 1
	end

	-- CATALOG MUST EXIST IF SPECIFIED --
	if @fulltext_catalog_name is not null
	begin
		declare @ftcatid smallint
		select @ftcatid = fulltext_catalog_id from sys.fulltext_catalogs where name = @fulltext_catalog_name
		if @ftcatid is null
		begin
			declare @curdbname sysname
			declare @curdbnamelen int
			select @curdbname = db_name()
			select @curdbnamelen = LEN(@curdbname)
			raiserror(7641,-1,-1,@fulltext_catalog_name, @curdbnamelen, @curdbname)
			return 1
		end
	end

	-- SELECT ANY ROWS THAT MEET THE CRITERIA --
	set @cursor_return =	CURSOR LOCAL SCROLL STATIC FOR
	select CAT.fulltext_catalog_id as ftcatid,
	       CAT.name as NAME,
		   isnull(sysfs.physical_name, CAT.path) as PATH,
		   FullTextCatalogProperty(CAT.name, 'PopulateStatus') AS STATUS ,
		   (select COUNT(*)
			  from sys.fulltext_indexes
			  where fulltext_catalog_id = CAT.fulltext_catalog_id
		   ) as NUMBER_FULLTEXT_TABLES
	from sys.fulltext_catalogs as CAT left outer join sys.database_files as sysfs on (sysfs.file_id = CAT.file_id)
	where ( @fulltext_catalog_name is null or CAT.name = @fulltext_catalog_name )
	order by fulltext_catalog_id

	open @cursor_return

	-- SUCCESS --
	return 0	-- sp_help_fulltext_catalogs_cursor
go

