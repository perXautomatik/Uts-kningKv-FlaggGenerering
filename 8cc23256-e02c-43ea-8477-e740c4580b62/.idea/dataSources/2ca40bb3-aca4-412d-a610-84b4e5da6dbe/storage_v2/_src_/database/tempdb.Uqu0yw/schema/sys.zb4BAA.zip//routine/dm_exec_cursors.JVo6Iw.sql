CREATE FUNCTION sys.dm_exec_cursors (@spid int)
RETURNS table
AS
	RETURN SELECT *
	FROM OpenRowSet(TABLE DM_EXEC_CURSORS, @spid)
go

