create procedure sys.sp_copysnapshot
(
    @publication        sysname,
    @destination_folder nvarchar(255),
    @subscriber         sysname = NULL,
    @subscriber_db      sysname = NULL,
    @publisher            sysname = NULL
)
AS
BEGIN
    DECLARE @cmd        	nvarchar(4000)
    DECLARE @retcode    	int
    DECLARE @publisher_type sysname

    SET @retcode = 0
    
    EXEC @retcode = sys.sp_MSrepl_getpublisherinfo	@publisher      = @publisher,
                                                    @rpcheader      = @cmd OUTPUT,
                                                    @publisher_type = @publisher_type OUTPUT
    
    IF @retcode <> 0
        RETURN (@retcode)

    -- Add sp
	SET @publisher = UPPER(@publisher) COLLATE DATABASE_DEFAULT
    set @cmd = @cmd + N'sys.sp_MSrepl_copysnapshot'
    
    EXEC @retcode = @cmd
                    @publication,
                    @destination_folder,
                    @subscriber,
                    @subscriber_db,
                    @publisher

    RETURN (@retcode)
END
go

