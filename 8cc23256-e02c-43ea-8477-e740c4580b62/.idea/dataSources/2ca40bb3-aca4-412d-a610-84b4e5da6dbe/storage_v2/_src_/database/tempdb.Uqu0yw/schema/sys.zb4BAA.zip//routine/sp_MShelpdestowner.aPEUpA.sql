create procedure sys.sp_MShelpdestowner(
@spname sysname
)
AS

-- Security check
if (1 <> is_member('db_owner') and
    not exists (select * from dbo.sysmergepublications 
                    where 1 = {fn ISPALUSER(pubid)}))
begin    
    RAISERROR (15247, 11, -1)
    return (1)
end

if exists (select * from sys.parameters where name = '@destowner' and object_id = object_id(@spname))
    select 1
else
    select 0
go

