CREATE FUNCTION sys.dm_io_virtual_file_stats
	(
	@DatabaseId Int = null,
	@FileId Int = null
	)
RETURNS TABLE
as
	RETURN SELECT *	FROM OpenRowset(TABLE VIRTUALFILESTATS, @DatabaseId, @FileId)
go

