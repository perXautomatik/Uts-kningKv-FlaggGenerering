
create procedure sys.sp_provider_types_rowset
(
    @data_type  smallint = null,
    @best_match tinyint  = null
)
as
    select
        TYPE_NAME           = s_ptv.TYPE_NAME,
        DATA_TYPE           = s_ptv.DATA_TYPE_28,   -- for backward compatibility
        COLUMN_SIZE         = s_ptv.COLUMN_SIZE_28, -- for backward compatibility
        LITERAL_PREFIX      = s_ptv.LITERAL_PREFIX,
        LITERAL_SUFFIX      = s_ptv.LITERAL_SUFFIX,
        CREATE_PARAMS       = s_ptv.CREATE_PARAMS_90,
        IS_NULLABLE         = s_ptv.IS_NULLABLE,
        CASE_SENSITIVE      = s_ptv.CASE_SENSITIVE,
        SEARCHABLE          = s_ptv.SEARCHABLE,
        UNSIGNED_ATTRIBUTE  = s_ptv.UNSIGNED_ATTRIBUTE,
        FIXED_PREC_SCALE    = s_ptv.FIXED_PREC_SCALE,
        AUTO_UNIQUE_VALUE   = s_ptv.AUTO_UNIQUE_VALUE,
        LOCAL_TYPE_NAME     = s_ptv.LOCAL_TYPE_NAME,
        MINIMUM_SCALE       = s_ptv.MINIMUM_SCALE_90,
        MAXIMUM_SCALE       = s_ptv.MAXIMUM_SCALE_90,
        GUID                = s_ptv.GUID,
        TYPELIB             = s_ptv.TYPELIB,
        VERSION             = s_ptv.VERSION,
        IS_LONG             = s_ptv.IS_LONG,
        BEST_MATCH          = s_ptv.BEST_MATCH_28,
        IS_FIXEDLENGTH      = s_ptv.IS_FIXEDLENGTH_90
    from
        sys.spt_provider_types_view s_ptv
    where
        (@data_type is null or s_ptv.DATA_TYPE_28 = @data_type) and
        (@best_match is null or s_ptv.BEST_MATCH_28 = @best_match)
    order by 2, 20, 19, 8 -- Adding BEST_MATCH, IS_LONG and CASE_SENSITIVE to workaround a bug in DTS wizard (see SQL BU 372342)
go

