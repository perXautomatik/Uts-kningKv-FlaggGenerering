
create procedure sys.sp_xtp_bind_db_resource_pool
(
	@database_name sysname,
	@pool_name sysname
)
as
	exec sys.sp_xtp_bind_db_resource_pool_internal @database_name, @pool_name
go

