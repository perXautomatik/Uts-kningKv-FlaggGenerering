--
-- Name: sp_MScleanupdynamicsnapshotfolder
--
-- Description: This procedure is used to cleanup the specified dynamic 
--              snapshot folder. It is designed to be called through the 
--              distributor RPC link.
--
-- Parameters: @publisher                   sysname
--             @publisher_db                sysname
--             @publication                 sysname
--             @dynamic_filter_login        sysname
--             @dynamic_filter_hostname     sysname
--             @dynamic_snapshot_location   nvarchar(260)
--             @partition_id                int
--
--
-- Security: Public procedure invoked via RPC. db_owner check
-- Requires Certificate signature for catalog access
-- 
CREATE PROCEDURE sys.sp_MScleanupdynamicsnapshotfolder
(
    @publisher                   sysname,
    @publisher_db                sysname,
    @publication                 sysname,
    @dynamic_filter_login        sysname,
    @dynamic_filter_hostname     sysname,
    @dynamic_snapshot_location   nvarchar(260),
    @partition_id                int
)
as
begin
    set nocount on
    declare @retcode int
    declare @publisher_id int
    declare @publication_id int
    
    set @retcode = 0
    set @publisher_id = null
    set @publication_id = null

    set @dynamic_filter_login = coalesce(@dynamic_filter_login, N'')
    set @dynamic_filter_hostname = coalesce(@dynamic_filter_hostname, N'')

    --
    -- security check
    -- only db_owner can execute this
    --
    if (is_member('db_owner') != 1)
    begin
        raiserror(14260, 16, -1)
        return (1)
    end
    --
    -- security check
    -- Has to be executed from distribution database
    --
    if (sys.fn_MSrepl_isdistdb (db_name()) != 1)
    begin
        raiserror(21482, 16, -1, 'sp_MSdrop_publication', 'distribution')
        return (1)
    end
    
    -- Check if publisher is a defined as a distribution publisher in the current database
    exec @retcode = sys.sp_MSvalidate_distpublisher @publisher, @publisher_id OUTPUT
    if @retcode <> 0
    begin
        return(1)
    end

    -- Make sure publication exists
    select @publication_id = publication_id
        from dbo.MSpublications where publication = @publication and
        publisher_id = @publisher_id and publisher_db = @publisher_db
    if @publication_id is NULL
    begin
        -- We don't know whether or not it is a third party or not so we can not 
        -- return error.
        -- raiserror(20026, 16, -1, @publication)
        -- return (1)
        return (0)
    end
   
    if @dynamic_snapshot_location is null or rtrim(@dynamic_snapshot_location) = N''
        return (0)

    declare @publication_snapshot_folder nvarchar(260)


    if substring(@dynamic_snapshot_location, len(@dynamic_snapshot_location), 1) <> N'\'
    begin
        set @dynamic_snapshot_location = @dynamic_snapshot_location + N'\'
    end
	
    exec @retcode = sys.sp_MSreplremoveuncdir @dynamic_snapshot_location
    if @retcode <> 0 or @@error <> 0
   			return(1)    

    return (0)
end
go

