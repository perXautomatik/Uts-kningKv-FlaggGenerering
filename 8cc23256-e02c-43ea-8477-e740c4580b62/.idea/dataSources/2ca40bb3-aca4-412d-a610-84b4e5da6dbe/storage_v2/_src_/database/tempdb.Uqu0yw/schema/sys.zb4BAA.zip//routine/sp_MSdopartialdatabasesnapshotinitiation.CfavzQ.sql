--
-- Name: sp_MSdopartialdatabasesnapshotinitiation
--
-- Description: This procedure is called by the snapshot agent to perform the
--              the necessary (article & subscription) initiation procedures
--              when generating a partial snapshot from a database snapshot.
-- Parameter: @publication sysname (mandatory)
--
-- Notes: This procedure is assumed to be run within a transaction from the
--        snapshot agent. As such, no explicit error handling is performed
--        in it. This procedure will also return 1 immediately if one of the 
--        following is not true:
--        1) Caller is not member of db_owner role
--        2) Caller is not a replication agent connection
--        3) @@trancount < 1
--
--        *This procedure assumes that the #partial_snapshot_artids temporary
--        table has already been created prior to its invocation.
--
-- Returns: 0 - succeeded
--          1 - failed
--  
-- Security: Public interface, non-db_owner caller will result in no-op
--
create procedure sys.sp_MSdopartialdatabasesnapshotinitiation (
    @publication sysname
    )
as
begin
    set nocount on

    if @@trancount < 1 return 1

    if sessionproperty('replication_agent') <> 1 return 1

    if object_id(N'dbo.syspublications', 'U') is null return 1

    declare @retcode int
    set @retcode = 0

    exec @retcode = sys.sp_MSreplcheck_publish
    if @@error <> 0 or @retcode <> 0
        return 1

    declare @qualifiedname nvarchar(520),
            @objid int,
            @articletype tinyint,
            @pubid int,
            @repl_freq tinyint,
            @error int

    set @pubid = null
    set @error = 0

    select @pubid = pubid,
           @repl_freq = repl_freq
      from dbo.syspublications
     where name = @publication

    if @pubid is null return 1

        update dbo.syssubscriptions
           set status = 3
          from dbo.syssubscriptions subs
    inner join dbo.sysextendedarticlesview arts
            on subs.artid = arts.artid
    inner join #partial_snapshot_artids snaparts
            on arts.artid = snaparts.artid
         where arts.pubid = @pubid
           and (subs.status in (0, 1) and subs.sync_type = 1 
                or subs.srvid = -1)

    update dbo.sysarticles
       set status = status | 1
     where artid in
        (select subs.artid
           from syssubscriptions subs
     inner join dbo.sysarticles arts
             on subs.artid = arts.artid
     inner join #partial_snapshot_artids snaparts
             on arts.artid = snaparts.artid
          where arts.pubid = @pubid)

    update dbo.sysschemaarticles
       set status = status | 1
     where artid in
        (select subs.artid
           from syssubscriptions subs
     inner join dbo.sysschemaarticles arts
             on subs.artid = arts.artid
     inner join #partial_snapshot_artids snaparts
             on arts.artid = snaparts.artid
          where arts.pubid = @pubid)

    exec @retcode = sys.sp_replflush          
    return @retcode
end
go

