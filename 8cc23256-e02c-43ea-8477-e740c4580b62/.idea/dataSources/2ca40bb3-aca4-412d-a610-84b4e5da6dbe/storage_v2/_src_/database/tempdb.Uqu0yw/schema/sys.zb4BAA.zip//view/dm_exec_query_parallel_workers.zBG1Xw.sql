CREATE VIEW sys.dm_exec_query_parallel_workers AS
	SELECT A.*
	FROM OpenRowset(TABLE DM_EXEC_PARALLEL_WORKERS) A
go

