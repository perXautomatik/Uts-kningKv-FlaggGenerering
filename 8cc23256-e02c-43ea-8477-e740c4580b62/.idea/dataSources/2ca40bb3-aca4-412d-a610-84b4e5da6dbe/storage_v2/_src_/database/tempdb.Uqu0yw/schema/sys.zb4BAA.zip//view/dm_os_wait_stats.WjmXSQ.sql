CREATE VIEW sys.dm_os_wait_stats AS
	SELECT *
	FROM OpenRowset(TABLE SYSWAITSTATS)
go

