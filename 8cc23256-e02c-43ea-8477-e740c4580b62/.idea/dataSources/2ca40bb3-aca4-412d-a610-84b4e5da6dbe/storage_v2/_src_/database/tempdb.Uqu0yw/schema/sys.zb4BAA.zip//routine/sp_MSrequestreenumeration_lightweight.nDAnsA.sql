create procedure sys.sp_MSrequestreenumeration_lightweight
						@tablenick int,
						@rowguid uniqueidentifier
						
as
	declare @retcode int
	declare @err int
	declare @rc int
	declare @METADATA_ACTION_ForceReenumeration tinyint

	set @METADATA_ACTION_ForceReenumeration= 5

	-- security check
    exec @retcode = sys.sp_MSreplcheck_subscribe 
    if @retcode <> 0 or @@error <> 0 return 1

	update dbo.MSmerge_metadataaction_request
		set action= @METADATA_ACTION_ForceReenumeration,
			generation=null,
			changed= sys.fn_MSdayasnumber(getdate())
		where tablenick=@tablenick and rowguid=@rowguid

	select @err= @@error, @rc=@@rowcount
	if @err<>0 return 1
	if @rc>0 return 0

	insert into dbo.MSmerge_metadataaction_request
						(tablenick,
						 rowguid,
						 action,
						 generation,
						 changed)
					values
						(@tablenick,
						 @rowguid,
						 @METADATA_ACTION_ForceReenumeration,
						 null,
						 sys.fn_MSdayasnumber(getdate()))
						 
	if @err<>0 return 1
	return 0
go

