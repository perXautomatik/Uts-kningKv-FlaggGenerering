--
-- Name: sp_unregistercustomresolver
--
-- Descriptions: 
--          Delete the custom resolver row from the MSmerge_articleresolver table in the distribution database
--          this proc should be called in the context of the distribution database
--
-- Parameters: as defined in create statement
--
-- Returns: 0 - success
--          1 - Otherwise
--
--
create procedure sys.sp_unregistercustomresolver
    @article_resolver nvarchar(255)

    AS

    declare @retcode  int
    
    exec @retcode = sys.sp_MSreplcheck_publish
    if (@retcode <> 0 or @@error <> 0)
        return 1

    -- check to make sure we are executing from the distribution database context
    if (sys.fn_MSrepl_isdistdb (db_name()) != 1)
    begin
        raiserror(21482, 16, -1, N'sp_unregistercustomresolver', N'distribution')
        return (1)
    end

    if @article_resolver IS NULL or @article_resolver = ''
    begin
        RAISERROR (21717, 16, -1)
        return 1
    end

    delete from dbo.MSmerge_articleresolver where article_resolver = LTRIM(RTRIM(@article_resolver))
    
    return @retcode
go

