create procedure sys.sp_user_counter9 @newvalue int as
dbcc setinstance ('SQLServer:User Settable', 'Query', 'User counter 9', @newvalue)
go

