create procedure sys.sp_user_counter10 @newvalue int as
dbcc setinstance ('SQLServer:User Settable', 'Query', 'User counter 10', @newvalue)
go

