CREATE VIEW sys.dm_exec_query_optimizer_memory_gateways AS
	SELECT A.*
	FROM OpenRowset(TABLE DM_QO_GATES) A
go

