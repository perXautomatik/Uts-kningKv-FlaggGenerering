
CREATE PROCEDURE sys.sp_replrethrow 
AS
    IF ERROR_NUMBER() IS NULL
        RETURN;

    DECLARE 
        @ErrorMessage    NVARCHAR(4000) = N'Error %d, Level %d, State %d, Procedure %s, Line %d, ' 
					+ 'Message: '+ ERROR_MESSAGE(),
        @ErrorNumber     INT = ERROR_NUMBER(),
        @ErrorSeverity   INT = ERROR_SEVERITY(),
        @ErrorState      INT = ERROR_STATE(),
        @ErrorLine       INT = ERROR_LINE(),
        @ErrorProcedure  NVARCHAR(200) = ISNULL(ERROR_PROCEDURE(), '-');

    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        1,               
        @ErrorNumber,    -- parameter: original error number.
        @ErrorSeverity,  -- parameter: original error severity.
        @ErrorState,     -- parameter: original error state.
        @ErrorProcedure, -- parameter: original error procedure name.
        @ErrorLine       -- parameter: original error line number.
        );
go

