CREATE view sys.dm_hadr_name_id_map
as
	SELECT 
	*
	FROM OpenRowset(TABLE DM_HADR_NAME_ID_MAP)
go

