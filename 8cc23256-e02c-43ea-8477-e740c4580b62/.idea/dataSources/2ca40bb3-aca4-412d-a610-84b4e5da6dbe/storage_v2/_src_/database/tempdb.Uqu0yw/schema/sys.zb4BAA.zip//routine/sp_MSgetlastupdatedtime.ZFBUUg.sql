create procedure sys.sp_MSgetlastupdatedtime(
    @publisher sysname,
    @publisher_db sysname,
    @publication sysname,
    @subscription_type int,
    @publication_type int  -- 1 - transactional/snapshot, 2 - merge
    )
as
begin
    set nocount on
    declare @retcode int
    select @retcode = 0

    -- Security check
    exec @retcode = sys.sp_MSreplcheck_subscribe    
    if @retcode<>0 or @@error<>0
        return 1

    if @publication_type in (0,1)
    begin
        exec @retcode = sys.sp_MSgettranlastupdatedtime @publisher,
                                                        @publisher_db,
                                                        @publication,
                                                        @subscription_type
    end
    else
    begin
        exec @retcode = sys.sp_MSgetmergelastupdatedtime @publisher,
                                                         @publisher_db,
                                                         @publication,
                                                         @subscription_type
    end
    return @retcode
end
go

