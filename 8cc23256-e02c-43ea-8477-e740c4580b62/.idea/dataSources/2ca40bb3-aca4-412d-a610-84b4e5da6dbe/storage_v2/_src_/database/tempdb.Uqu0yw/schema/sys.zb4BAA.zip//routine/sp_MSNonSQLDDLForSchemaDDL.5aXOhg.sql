-- ===========================
-- Name:            sp_MSNonSQLDDLForSchemaDDL
-- Description:      translate DDL for schema change so SSCE can pick up
-- Caller:            sp_MSmerge_alterview
--                        sp_MSmerge_altertrigger
--                        sp_MSmerge_schemaonly
-- Security:         Public interface, in resource DB
-- Returns:          0 : success
--                        1 : failure          
-- Owner:           zhenl
-- ===========================
create procedure sys.sp_MSNonSQLDDLForSchemaDDL(
@artid uniqueidentifier,
@pubid uniqueidentifier,
@ddlcmd nvarchar(max)
)
AS
    -- SSCE does not support these for now
    return 0
go

