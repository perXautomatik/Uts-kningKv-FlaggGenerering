
create procedure sys.sp_tables_rowset_rmt
(
    @table_server       sysname,
    @table_catalog      sysname = null,
    @table_name     sysname = null,
    @table_schema       sysname = null,
    @table_type     sysname = null
)
as
    select
        TABLE_CATALOG,
        TABLE_SCHEMA,
        TABLE_NAME,
        TABLE_TYPE,
        TABLE_GUID,
        DESCRIPTION,
        TABLE_PROPID = null,    -- ISSUE these 3 columns must be exported by the server
        DATE_CREATED = null,    -- in \yukon\sql\ntdbms\msql\ddl\sysoledb.cpp :
        DATE_MODIFIED = null    -- const SCHEMA_COLUMNS xCol_TABLES = {
    from
        sys.fn_remote_tables (@table_server,
                              @table_catalog,
                              @table_schema,
                              @table_name,
                              @table_type)
    order by 4,1,2,3
go

