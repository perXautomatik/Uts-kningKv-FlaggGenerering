
create procedure sys.sp_MSgetlastsentrecgens
    (@repid uniqueidentifier)
as
    declare @retcode    int

    if (@repid is null)
        begin
            RAISERROR(14043, 16, -1, '@repid', 'sp_MSgetlastsentrecgens')
            return (1)
        end

    /*
    ** do permission checking
    */
    exec @retcode = sys.sp_MSrepl_PAL_rolecheck @repid = @repid
    if @retcode<>0 or @@ERROR<>0 return (1)
        
    select sentgen, sentguid, recgen, recguid from dbo.sysmergesubscriptions where subid = @repid
    return (0)
go

