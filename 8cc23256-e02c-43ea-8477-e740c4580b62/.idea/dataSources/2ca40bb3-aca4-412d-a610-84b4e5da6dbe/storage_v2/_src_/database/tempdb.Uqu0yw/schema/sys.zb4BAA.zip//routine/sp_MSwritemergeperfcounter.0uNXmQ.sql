create procedure sys.sp_MSwritemergeperfcounter 
(
    @agent_id int,
    @thread_num int,
    @counter_desc nvarchar(100),
    @counter_value int
)
AS
begin
	-- only sysadmin or db_owner have access to call this function
    if is_member('db_owner') <> 1
        return 1

	if object_id('MSmerge_perfcounters') is NULL
	begin
		create table dbo.MSmerge_perfcounters
		(
			agent_id int NOT NULL,
			thread_num int NULL,
			counter_desc nvarchar(100) NOT NULL,
			counter_value int NOT NULL,
			cur_time datetime NOT NULL
		)
	end

	insert into dbo.MSmerge_perfcounters values (@agent_id, @thread_num, @counter_desc, @counter_value, getdate())

	return 0
end
go

