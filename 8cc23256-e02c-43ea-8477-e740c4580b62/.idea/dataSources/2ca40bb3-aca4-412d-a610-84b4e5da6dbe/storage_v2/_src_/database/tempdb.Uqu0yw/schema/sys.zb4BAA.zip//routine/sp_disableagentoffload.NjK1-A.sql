create procedure sys.sp_disableagentoffload (
    @job_id         VARBINARY(16),
    @offloadserver  sysname = NULL,
    @agent_type     sysname = NULL -- 'distribution' or 'merge', case insensitive
) AS
    SET NOCOUNT ON
    
    RAISERROR(21023, 16, -1, 'sp_disableagentoffload')
    
    RETURN (1)
go

