
create procedure sys.sp_columns_90_rowset_rmt
(
    @table_server       sysname,
    @table_catalog      sysname = null,
    @table_name         sysname = null,
    @table_schema       sysname = null,
    @column_name        sysname = null
)
as
-----------------------------------------
-- copy & pasted from version 5 !
-----------------------------------------
    select
        TABLE_CATALOG,
        TABLE_SCHEMA,
        TABLE_NAME,
        COLUMN_NAME,
        COLUMN_GUID,
        COLUMN_PROPID,
        ORDINAL_POSITION,
        COLUMN_HASDEFAULT,
        COLUMN_DEFAULT,
        COLUMN_FLAGS,
        IS_NULLABLE,
        DATA_TYPE,
        TYPE_GUID,
        CHARACTER_MAXIMUM_LENGTH,
        CHARACTER_OCTET_LENGTH,
        NUMERIC_PRECISION,
        NUMERIC_SCALE,
        DATETIME_PRECISION,
        CHARACTER_SET_CATALOG,
        CHARACTER_SET_SCHEMA,
        CHARACTER_SET_NAME,
        COLLATION_CATALOG,
        COLLATION_SCHEMA,
        COLLATION_NAME,
        DOMAIN_CATALOG,
        DOMAIN_SCHEMA,
        DOMAIN_NAME,
        DESCRIPTION,
        -- ISSUE - These columns are not exposed by engine.
        -- ISSUE - See SQL BU 70074, which is postponed to Acadia!
        COLUMN_LCID = null,     -- ISSUE these columns must be exported by the server
        COLUMN_COMPFLAGS = null,-- in \yukon\sql\ntdbms\msql\ddl\sysoledb.cpp :
        COLUMN_SORTID = null,   -- const SCHEMA_COLUMNS xCol_COLUMNS = {
        COLUMN_TDSCOLLATION = null,
        IS_COMPUTED = null,
        SS_XML_SCHEMACOLLECTION_CATALOGNAME = null,
        SS_XML_SCHEMACOLLECTION_SCHEMANAME = null,
        SS_XML_SCHEMACOLLECTIONNAME = null,
        SS_UDT_CATALOGNAME = null,
        SS_UDT_SCHEMANAME = null,
        SS_UDT_NAME = null,
        SS_UDT_ASSEMBLY_TYPENAME = null
    from
        sys.fn_remote_columns (@table_server, @table_catalog, @table_schema, @table_name, @column_name)
    order by 1, 2, 3, 7
go

