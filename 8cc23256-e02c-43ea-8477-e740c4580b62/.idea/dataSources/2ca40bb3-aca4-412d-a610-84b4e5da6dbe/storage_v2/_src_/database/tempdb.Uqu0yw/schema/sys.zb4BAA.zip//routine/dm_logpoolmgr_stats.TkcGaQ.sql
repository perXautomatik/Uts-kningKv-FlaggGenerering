CREATE FUNCTION sys.dm_logpoolmgr_stats
	(
	@DatabaseId Int = 0
	)
RETURNS TABLE
as
	RETURN SELECT * FROM OpenRowset(TABLE DM_LOGPOOLMGR_STATS, @DatabaseId)
go

