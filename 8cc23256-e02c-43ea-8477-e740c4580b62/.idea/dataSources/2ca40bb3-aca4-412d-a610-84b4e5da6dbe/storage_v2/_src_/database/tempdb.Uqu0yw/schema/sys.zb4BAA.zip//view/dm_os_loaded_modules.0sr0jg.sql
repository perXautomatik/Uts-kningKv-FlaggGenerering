CREATE VIEW sys.dm_os_loaded_modules AS
	SELECT *
	FROM OpenRowSet(TABLE SYSMODULES)
go

