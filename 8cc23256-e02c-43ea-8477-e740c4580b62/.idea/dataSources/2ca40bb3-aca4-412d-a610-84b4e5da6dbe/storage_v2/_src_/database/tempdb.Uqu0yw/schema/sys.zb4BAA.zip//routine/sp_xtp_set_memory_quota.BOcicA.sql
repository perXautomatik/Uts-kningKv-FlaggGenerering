
create procedure sys.sp_xtp_set_memory_quota
( 
	@database_name sysname,
	@target_user_memory_quota bigint
)
as
	exec sys.sp_xtp_set_memory_quota_internal @database_name, @target_user_memory_quota
go

