CREATE view sys.dm_fts_outstanding_batches
AS
	SELECT * FROM OpenRowset(TABLE FTBATCHES)
go

