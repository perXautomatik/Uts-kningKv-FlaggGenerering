create procedure sys.sp_scriptvupdproc 
(
    @artid int                  -- id of the article we are processing
    ,@mode tinyint = 1    -- 1 = static scripting, 2 = dynamic scripting
    ,@publishertype tinyint=1        -- 1 = mssqlserver, 2 = heterogeneous
    ,@publisher sysname=NULL		 -- May only be non-NULL if @publishertype = 2
)
as
begin
    declare @retcode int
    --
    -- security check
    --
    exec @retcode = sys.sp_MSreplcheck_publish
    if @@error <> 0 or @retcode <> 0
    begin
        return (1)
    end
    --
    -- call core function
    --
    exec @retcode = sys.sp_scriptupdproccore 
             @artid = @artid
            ,@format = 4        -- VCALL format
            ,@mode = @mode
            ,@publishertype = @publishertype
            ,@publisher = @publisher
    return @retcode
end
go

