create procedure sys.sp_unsetapprole
    @cookie varbinary(8000)        -- cookie 
as
    -- SETUP RUNTIME OPTIONS / DECLARE VARIABLES --
	set nocount on

    -- DISALLOW USER TRANSACTION --
	set implicit_transactions off
	if (@@trancount > 0)
	begin
		raiserror(15002,-1,-1,'sys.sp_setapprole')
		return (1)
	end

    -- SP MUST BE CALLED AT ADHOC LEVEL --
    if (@@nestlevel > 1)
    begin
        raiserror(15422,-1,-1)
        return (1)
    end

    EXEC %%AppRole().Unset(Cookie = @cookie)
	
    -- RETURN SUCCESS/FAILURE --
    if (@@error <> 0)
        return (1)
    return (0)	-- sp_unsetapprole
go

