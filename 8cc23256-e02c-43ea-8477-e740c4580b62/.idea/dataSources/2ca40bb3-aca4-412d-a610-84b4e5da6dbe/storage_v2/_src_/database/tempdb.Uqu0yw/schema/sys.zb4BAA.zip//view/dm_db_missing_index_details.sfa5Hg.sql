CREATE VIEW sys.dm_db_missing_index_details AS
	SELECT *
	FROM OpenRowset(TABLE MISSING_IDX_DETAILS)
go

