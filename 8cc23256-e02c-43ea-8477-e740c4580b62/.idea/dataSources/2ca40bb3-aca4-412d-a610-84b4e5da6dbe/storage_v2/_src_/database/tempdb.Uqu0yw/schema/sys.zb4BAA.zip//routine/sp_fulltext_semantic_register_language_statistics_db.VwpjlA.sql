create proc sys.sp_fulltext_semantic_register_language_statistics_db
	@dbname sysname
as
begin
	set nocount	on
	declare @returncode int
	EXEC @returncode = sys.sp_fulltext_semantic_register_language_statistics_db_internal @dbname
	return @returncode
end
go

