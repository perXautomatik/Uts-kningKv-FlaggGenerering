
CREATE PROCEDURE sys.sp_addpublication_snapshot
(
    @publication					sysname,    
    @frequency_type					int = 4 ,		/* 4== Daily */
    @frequency_interval				int = 1,		/* Every day */
    @frequency_subday				int = 4,		/* Sub interval = Minute */
    @frequency_subday_interval		int = 5,		/* Every five minutes */
    @frequency_relative_interval	int = 1, 
    @frequency_recurrence_factor	int = 0, 
    @active_start_date				int = 0, 
    @active_end_date				int = 99991231 , 
    @active_start_time_of_day		int = 0, 
    @active_end_time_of_day			int = 235959,
    @snapshot_job_name				nvarchar(100) = NULL,
	@publisher_security_mode		int = NULL,
	@publisher_login				sysname = NULL,
	@publisher_password 			sysname = NULL,
	@job_login 						nvarchar(257) = NULL,
	@job_password 					sysname = NULL,
	@publisher						sysname	= NULL
)
AS
BEGIN
	DECLARE @cmd			nvarchar(4000)
	DECLARE @retcode		int
	DECLARE @publisher_type	sysname

	SET @retcode = 0
	
	EXEC @retcode = sys.sp_MSrepl_getpublisherinfo	@publisher		= @publisher,
													@publisher_type	= @publisher_type OUTPUT,
													@rpcheader		= @cmd            OUTPUT
	
	IF @retcode <> 0
		RETURN (@retcode)

	-- Add sp
	SET @publisher = UPPER(@publisher) COLLATE DATABASE_DEFAULT
	set @cmd = @cmd + N'sys.sp_MSrepl_addpublication_snapshot'

	
	EXEC @retcode = @cmd
					@publication,
					@frequency_type,
					@frequency_interval,
					@frequency_subday,
					@frequency_subday_interval,
					@frequency_relative_interval,
					@frequency_recurrence_factor,
					@active_start_date,
					@active_end_date,
					@active_start_time_of_day,
					@active_end_time_of_day,
					@snapshot_job_name,
					@publisher_security_mode,
					@publisher_login,
					@publisher_password,
					@job_login,
					@job_password,
					@publisher,
					@publisher_type

	RETURN (@retcode)
END
go

