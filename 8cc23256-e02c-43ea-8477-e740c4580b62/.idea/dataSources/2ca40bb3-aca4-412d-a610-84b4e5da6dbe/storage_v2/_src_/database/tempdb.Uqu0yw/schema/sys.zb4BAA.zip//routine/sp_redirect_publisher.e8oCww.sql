--
-- Name: sp_redirect_publisher
--
-- Descriptions: Redirect the publisher of a published database to a 
--               new target publisher. Target can be an explicit node
--               or a HADRon virtual network name.
--
--               If the target of the redirection is NULL, the current
--               entry for the publisher database pair, if it exists,
--               is removed.
--
-- Parameters: as defined in create statement
--
-- Returns: 0 - success, 1 - failure
--          raise error on failure
--
-- Security: Public procedure invoked via RPC. db_owner check
--
create procedure sys.sp_redirect_publisher
(
    @original_publisher sysname,
    @publisher_db sysname,
    @redirected_publisher sysname = null
)
as
begin
    set nocount on
   
    declare @dbname sysname = db_name()
 
    -- Security check
    --
    if is_member(N'db_owner') <> 1
    begin
        raiserror (21873, 16, -1, 'sys.sp_redirect_publisher')
        return 1
    end
    
    -- Has to be executed from a distribution database
    --
    if (sys.fn_MSrepl_isdistdb (@dbname) <> 1)
    begin
        raiserror(21874, 16, -1, 'sys.sp_redirect_publisher', @dbname)
        return 1
    end
 
    -- Input parameters must both be non-null
    --
    if @original_publisher is null or
        @publisher_db is null
    begin
        raiserror (21875, 16, -1, 'sys.sp_redirect_publisher')
        return 1
    end
	
    if exists 
        (	select redirected_publisher from MSredirected_publishers
            where publisher_db = rtrim(@publisher_db)
            and   upper(original_publisher) = upper(rtrim(@original_publisher)))
    begin
        if @redirected_publisher is not null
        begin
            update MSredirected_publishers 
            set redirected_publisher = rtrim(@redirected_publisher)
            where publisher_db = rtrim(@publisher_db)
            and   upper(original_publisher) = upper(rtrim(@original_publisher))
        end
        else
        begin
            delete from MSredirected_publishers 
            where publisher_db = rtrim(@publisher_db)
            and   upper(original_publisher) = upper(rtrim(@original_publisher))			
        end
    end
    else	
    begin
        insert into MSredirected_publishers
        values (rtrim(@original_publisher), rtrim(@publisher_db), rtrim(@redirected_publisher))
    end	 
		
    return 0		  				
end
go

