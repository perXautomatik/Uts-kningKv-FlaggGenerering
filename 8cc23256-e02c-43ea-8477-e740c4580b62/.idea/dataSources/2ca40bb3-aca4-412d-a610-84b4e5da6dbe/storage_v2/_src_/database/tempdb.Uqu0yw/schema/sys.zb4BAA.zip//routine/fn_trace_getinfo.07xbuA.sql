create function sys.fn_trace_getinfo
	(@handle int = 0
	)
returns @tab table(traceid int NOT NULL,
	property int NOT NULL,
	value sql_variant)
as
begin
	insert @tab
	select * from OpenRowset(TABLE TRACEINFO, @handle)

	return
end -- fn_trace_getinfo
go

