create procedure sys.sp_MSreplcheck_subscribe_withddladmin
as
begin
    --
    -- Only the System Administratr (SA) or the Database Owner (dbo) 
    -- can subscribe from the subscribing database.
    --
    -- Do the sysadmin check first as it is 4 times more efficient
    -- than is_member call and reduces performance overhead in case 
    -- the user has sysadmin privileges
    --
    if  is_srvrolemember('sysadmin') = 1 or is_member ('db_owner') = 1         
        or is_member ('db_ddladmin') = 1
    begin
        return (0)
    end
    else
    begin
        raiserror (21551, 14, -1)
        return (1)
    end
end
go

