
create procedure sys.sp_MScreate_all_article_repl_views
    @snapshot_application_finished bit = 0
as
    declare @pubid uniqueidentifier, @artid uniqueidentifier, @retcode int

    -- security check
    exec @retcode = sys.sp_MSreplcheck_subscribe
    if @retcode<>0 or @@ERROR<>0
        return 1
    
    select @retcode = 0
    
    if object_id('sysmergesubsetfilters','U') is NULL
        return 0
    
    declare artidpubid CURSOR LOCAL FAST_FORWARD FOR 
    select artid, pubid from dbo.sysmergearticles 
    FOR READ ONLY
    
    open artidpubid
    
    fetch artidpubid into @artid, @pubid

    while (@@fetch_status <> -1)
    begin
    
        exec @retcode = sys.sp_MScreate_article_repl_view @pubid, @artid
        if @@ERROR<>0 OR @retcode<>0 
        begin
            select @retcode = 1
            goto error
        end
        
        fetch next from artidpubid into @artid, @pubid
    end

    if @snapshot_application_finished = 1
    begin
        -- potentially there can be other post snapshot steps that can be done here
        execute @retcode= sys.sp_MSrepl_ddl_triggers @type='merge', @mode='add'
        if @@ERROR <> 0 or @retcode <> 0 
        begin
            select @retcode = 1
            goto error
        end
    end

error:
    close artidpubid
    deallocate artidpubid
    return @retcode
go

