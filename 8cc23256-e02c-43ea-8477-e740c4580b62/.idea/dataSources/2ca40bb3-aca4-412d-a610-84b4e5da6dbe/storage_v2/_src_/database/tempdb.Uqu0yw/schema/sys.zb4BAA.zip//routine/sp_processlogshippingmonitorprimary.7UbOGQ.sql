create procedure sys.sp_processlogshippingmonitorprimary 
(
    @mode tinyint -- 1 = add, 2 = delete, 3 = update
    ,@primary_id uniqueidentifier
    ,@primary_server sysname = NULL -- needed for add
    ,@monitor_server sysname 
    ,@monitor_server_security_mode bit 
    ,@primary_database sysname = NULL -- needed for add
    ,@backup_threshold int = NULL 
    ,@threshold_alert int = NULL
    ,@threshold_alert_enabled bit = NULL
    ,@last_backup_file nvarchar(500) = NULL
    ,@last_backup_date datetime = NULL
    ,@last_backup_date_utc datetime = NULL
    ,@history_retention_period int = NULL
)
as
begin
    set nocount on
    declare @retcode int
    
    --
    -- security check
    --
    exec @retcode = sys.sp_MSlogshippingsysadmincheck
    if (@retcode != 0 or @@error != 0)
        return 1
    --
    -- This should be called only on the remote monitor server
    --
    if (@monitor_server is null or upper(@monitor_server) != upper(@@servername) 
            or upper(@monitor_server) = upper(@primary_server))
        return 0
    --
    -- must be invoked from MSDB
    --
    if (db_name() != N'msdb')
    begin
        raiserror (21482, 16, -1, N'sp_processlogshippingmonitorprimary', N'msdb')
        return 1
    end
    --
    -- call the internal proc now
    --
    exec @retcode = sys.sp_MSprocesslogshippingmonitorprimary @mode = @mode
                ,@primary_id = @primary_id
                ,@primary_server = @primary_server
                ,@monitor_server = @monitor_server
                ,@monitor_server_security_mode = @monitor_server_security_mode
                ,@primary_database = @primary_database
                ,@backup_threshold = @backup_threshold
                ,@threshold_alert = @threshold_alert
                ,@threshold_alert_enabled = @threshold_alert_enabled
                ,@last_backup_file = @last_backup_file
                ,@last_backup_date = @last_backup_date
                ,@last_backup_date_utc = @last_backup_date_utc
                ,@history_retention_period = @history_retention_period
    if (@retcode != 0 or @@error != 0)
        return 1
    --
    -- all done
    --
    return 0
end
go

