
CREATE FUNCTION sys.fn_sqlagent_jobs(
    @job_id UNIQUEIDENTIFIER NULL 
 )
RETURNS @agent_jobs TABLE (
        job_id                  UNIQUEIDENTIFIER    NOT NULL, 
        name                    SYSNAME             NOT NULL, 
        [enabled]               BIT                 NOT NULL, 
        [description]           NVARCHAR(512)       NULL, 
        start_step_id           INT                 NOT NULL, 
        notify_level_eventlog   BIT                 NOT NULL, 
        delete_level            INT                 NOT NULL, 
        date_created            DATETIME            NOT NULL, 
        date_modified           DATETIME            NOT NULL 
    )
AS
BEGIN
    -- Check if we are in msdb database context
    IF(LOWER(DB_NAME()) = 'msdb')
    BEGIN
        INSERT INTO @agent_jobs
        SELECT job_id,
            name,
            [enabled],
            [description],
            start_step_id,
            notify_level_eventlog,
            delete_level,
            date_created,
            date_modified
        FROM sys.sqlagent_jobs
        WHERE ISNULL(@job_id, job_id) = job_id
    END
    RETURN
END
go

