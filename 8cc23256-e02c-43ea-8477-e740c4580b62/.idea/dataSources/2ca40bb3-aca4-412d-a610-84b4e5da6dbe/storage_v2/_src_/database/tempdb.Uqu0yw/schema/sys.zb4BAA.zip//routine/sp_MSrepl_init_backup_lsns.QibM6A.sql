create procedure sys.sp_MSrepl_init_backup_lsns
as
begin
    -- The stored procedure is called by sp_replicationdboption when changing a dist
    -- db to 'sync with backup' mode
    set nocount on	
    --
    -- security check
    -- only db_owner can execute this
    --
    if (is_member ('db_owner') != 1) 
    begin
        raiserror(14260, 16, -1)
        return (1)
    end
    -- Set the truncate lsns to null. By doing this
    -- the distribution agent will stop calling sp_repldone untill a dist db
    -- backup is done.
    update MSrepl_backup_lsns set valid_xact_seqno = NULL,
    	valid_xact_id = NULL
    if @@error <> 0
    	return 1
    return 0
end
go

