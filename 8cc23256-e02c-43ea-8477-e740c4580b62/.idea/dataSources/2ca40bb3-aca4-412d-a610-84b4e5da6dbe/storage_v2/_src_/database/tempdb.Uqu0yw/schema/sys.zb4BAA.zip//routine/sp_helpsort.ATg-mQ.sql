create procedure sys.sp_helpsort
AS
	set nocount on

	-- Now display the server default collation name
	declare @servercollation sysname
	select @servercollation = convert(sysname, serverproperty('collation'))

	if @servercollation is not NULL
	begin
		select 'Server default collation' = description
			from sys.fn_helpcollations() C
			where @servercollation = C.name
	end

	set nocount off
	return(0) -- sp_helpsort
go

