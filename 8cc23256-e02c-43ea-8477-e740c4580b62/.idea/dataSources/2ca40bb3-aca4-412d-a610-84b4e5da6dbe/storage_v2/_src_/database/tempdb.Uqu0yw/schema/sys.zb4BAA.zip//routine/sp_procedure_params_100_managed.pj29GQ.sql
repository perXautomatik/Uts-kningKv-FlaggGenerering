
create procedure sys.sp_procedure_params_100_managed
(
	@procedure_name 	sysname,
	@group_number		int = 1,
	@procedure_schema	sysname = null,
	@parameter_name 	sysname = null
)
as
	select
		PARAMETER_NAME,
		PARAMETER_TYPE,
		MANAGED_DATA_TYPE,
		CHARACTER_MAXIMUM_LENGTH,
		NUMERIC_PRECISION,
		NUMERIC_SCALE,
		TYPE_CATALOG_NAME			= SS_TYPE_CATALOG_NAME,
		TYPE_SCHEMA_NAME			= SS_TYPE_SCHEMANAME,
		TYPE_NAME,
		XML_CATALOGNAME 			= SS_XML_SCHEMACOLLECTION_CATALOGNAME,
		XML_SCHEMANAME				= SS_XML_SCHEMACOLLECTION_SCHEMANAME,
		XML_SCHEMACOLLECTIONNAME	= SS_XML_SCHEMACOLLECTIONNAME,
		SS_DATETIME_PRECISION

	from
		sys.fn_procedure_params_90_rowset(
			@procedure_name,
			@group_number,
			@procedure_schema,
			@parameter_name)

	order by PROCEDURE_SCHEMA, PROCEDURE_NAME, ORDINAL_POSITION
	option (OPTIMIZE CORRELATED UNION ALL)
go

