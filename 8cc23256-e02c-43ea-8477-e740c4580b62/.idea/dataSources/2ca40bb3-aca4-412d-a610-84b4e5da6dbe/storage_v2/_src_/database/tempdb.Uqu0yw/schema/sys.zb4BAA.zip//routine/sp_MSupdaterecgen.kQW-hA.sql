-- updates info about received generations, or inserts a corresponding row
create procedure sys.sp_MSupdaterecgen
        @altrepid uniqueidentifier,
        @altrecguid uniqueidentifier,
        @altrecgen bigint
as

        -- Security check
        declare @retcode int
        exec @retcode = sys.sp_MSrepl_PAL_rolecheck 
        if (@retcode <> 0) or (@@error <> 0)
                return 1

        update dbo.sysmergesubscriptions
                set recguid = @altrecguid, recgen = @altrecgen,
                    last_local_recgen = case when recguid = @altrecguid or recguid is null or recguid = '00000000-0000-0000-0000-000000000000' then last_local_recgen else NULL end,
                    last_local_recguid = case when recguid = @altrecguid or recguid is null or recguid = '00000000-0000-0000-0000-000000000000' then last_local_recguid else recguid end
                where subid = @altrepid and 
                          (recgen < @altrecgen or recgen is null)

        return (0)
go

