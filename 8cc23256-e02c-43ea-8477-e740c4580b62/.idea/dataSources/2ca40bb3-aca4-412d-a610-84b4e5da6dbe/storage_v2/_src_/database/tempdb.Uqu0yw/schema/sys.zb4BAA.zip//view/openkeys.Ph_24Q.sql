CREATE VIEW sys.openkeys AS
	SELECT * FROM OpenRowset(TABLE OPENKEYS)
go

