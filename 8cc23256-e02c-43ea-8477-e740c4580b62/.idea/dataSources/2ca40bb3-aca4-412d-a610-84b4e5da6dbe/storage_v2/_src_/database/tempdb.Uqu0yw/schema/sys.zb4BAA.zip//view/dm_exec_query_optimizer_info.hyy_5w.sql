CREATE VIEW sys.dm_exec_query_optimizer_info AS
	SELECT *
	FROM OpenRowSet(TABLE OPTIMIZERINFO)
go

