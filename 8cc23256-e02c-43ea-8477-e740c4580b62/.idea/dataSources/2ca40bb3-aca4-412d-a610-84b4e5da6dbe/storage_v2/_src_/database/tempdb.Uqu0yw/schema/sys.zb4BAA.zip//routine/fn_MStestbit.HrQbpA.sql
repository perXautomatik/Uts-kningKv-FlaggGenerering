create function sys.fn_MStestbit (@bitmap varbinary(128), @colidx smallint)
returns bit
as
begin
	-- size of bitmap is 1024 bits
	if @colidx < 1 or @colidx > 1024 return 0

	declare @byte binary(1)
	declare @mask tinyint
	declare @idxinbyte tinyint
	declare @shift tinyint

	set @byte= substring(@bitmap, (@colidx-1)/8+1, 1)
	set @shift= @colidx%8
	if @shift = 0
		set @shift= 7
	else
		set @shift= @shift -1
	set @mask= power(2, @shift)
	return @byte & @mask
end
go

