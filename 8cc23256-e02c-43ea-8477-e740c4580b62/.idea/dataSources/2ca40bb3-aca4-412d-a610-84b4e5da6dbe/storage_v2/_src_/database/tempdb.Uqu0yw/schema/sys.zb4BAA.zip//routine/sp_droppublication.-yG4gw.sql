
--
-- Name:    
--          sp_droppublication
--          
-- Description: 
--          Drops a publication and its associated articles.
--			This stored procedure is executed at the Publisher on the publication database.
--  
-- Security: 
--          Public with checks for sysadmin/dbo
--
-- Returns:
--          Success (0) or failure (1)
--      
-- Owner:   
--          <current owner> 

create procedure sys.sp_droppublication
(
	@publication		sysname,
	@ignore_distributor	bit = 0,
	@publisher			sysname = NULL,	-- optional publisher for heterogeneous publications
    @from_backup        bit = 0
)
AS
BEGIN
	DECLARE @cmd			nvarchar(4000)
	DECLARE @retcode		int
	DECLARE @publisher_type	sysname

	SET @retcode = 0
	
	EXEC @retcode = sys.sp_MSrepl_getpublisherinfo	@publisher		= @publisher,
													@rpcheader		= @cmd OUTPUT,
													@publisher_type	= @publisher_type OUTPUT
	
	IF @retcode <> 0
		RETURN (@retcode)

	-- Add sp
	SET @publisher = UPPER(@publisher) COLLATE DATABASE_DEFAULT
	set @cmd = @cmd + N'sys.sp_MSrepl_droppublication'

	EXEC @retcode = @cmd
					@publication,
					@ignore_distributor,
					@publisher,
					@publisher_type,
                    @from_backup

	RETURN (@retcode)
END
go

