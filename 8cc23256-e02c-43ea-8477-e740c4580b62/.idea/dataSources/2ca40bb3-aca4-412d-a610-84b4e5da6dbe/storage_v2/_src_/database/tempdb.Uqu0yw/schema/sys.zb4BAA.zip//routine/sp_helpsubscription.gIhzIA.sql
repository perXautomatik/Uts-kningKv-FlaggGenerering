
--
-- Name:    
--          sp_helpsubscription
--          
-- Description: 
--          Lists subscription information associated with a particular publication, article,
--			Subscriber, or set of subscriptions. This stored procedure is executed at a Publisher
--			on the publication database.
--  
-- Security: 
--          Public
--
-- Returns:
--          Result set of subscription properties
--      
-- Owner:   
--          <current owner> 

create procedure sys.sp_helpsubscription
(
	@publication	sysname = '%',
	@article		sysname = '%',
	@subscriber		sysname = N'%',
	@destination_db	sysname = '%',
	@found			int = 23456 OUTPUT,
	@publisher		sysname = NULL
)
AS
BEGIN
	DECLARE @cmd			nvarchar(4000)
	DECLARE @retcode		int
	DECLARE @publisher_type	sysname

	SET @retcode = 0

    EXEC @retcode = sys.sp_MSrepl_getpublisherinfo	@publisher			= @publisher,
													@publisher_type		= @publisher_type OUTPUT,
													@rpcheader			= @cmd OUTPUT,
													@skipSecurityCheck	= 1

    IF @retcode <> 0
        RETURN (@retcode)

	SET @publisher = UPPER(@publisher) COLLATE DATABASE_DEFAULT
    set @cmd = @cmd + N'sys.sp_MSrepl_helpsubscription'
	
    EXEC @retcode = @cmd
					@publication,
					@article,
					@subscriber,
					@destination_db,
					@found OUTPUT,
					@publisher,
					@publisher_type

	RETURN (@retcode)
END
go

