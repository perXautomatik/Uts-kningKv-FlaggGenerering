CREATE FUNCTION sys.fn_translate_permissions
                 ( @level nvarchar(60), @perms varbinary(16))
RETURNS table
AS
RETURN (
        SELECT * FROM OpenRowset(TABLE TRANSLATEPERMISSIONS, @level, @perms)
       )
go

