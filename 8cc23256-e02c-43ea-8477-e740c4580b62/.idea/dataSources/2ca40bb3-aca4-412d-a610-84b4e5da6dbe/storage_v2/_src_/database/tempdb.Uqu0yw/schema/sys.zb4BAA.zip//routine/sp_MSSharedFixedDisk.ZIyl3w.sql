
create proc sys.sp_MSSharedFixedDisk
as
   set nocount on

   create table #Tmp1
      (
      name         nvarchar(132),
      low          int,
      high         int,
      media        int,
      )
   create table #Tmp2
      (
      drivename    nvarchar(132),
      )
   declare @DriveName nvarchar(132)

   declare hC cursor global for select * from ::fn_servershareddrives()
   open hC
   fetch next from hC into @DriveName
   while (@@FETCH_STATUS = 0)
      begin
      insert #Tmp2 select @DriveName
      fetch next from hC into @DriveName
      end
   close hC
   deallocate hC

   insert into #Tmp1
   execute sys.xp_availablemedia 15

   select 'name' = name, 'low free' = low, 'high free' = high, 'media type' = media from #Tmp1, #Tmp2
          where (SUBSTRING(#Tmp1.name, 1, 1)) like (SUBSTRING(#Tmp2.drivename, 1, 1))

go

