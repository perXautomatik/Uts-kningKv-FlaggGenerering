CREATE PROCEDURE sys.sp_changelogreader_agent 
(
	@job_login					nvarchar(257)	= NULL,
	@job_password				sysname 		= NULL,
	@publisher_security_mode	smallint		= NULL,
	@publisher_login			sysname 		= NULL,
	@publisher_password 		sysname 		= NULL,
	@publisher					sysname 		= NULL
)
AS
BEGIN
	DECLARE @cmd			nvarchar(4000)
	DECLARE @retcode		int
	DECLARE @publisher_type	sysname
	
	SET @retcode = 0
	
	EXEC @retcode = sys.sp_MSrepl_getpublisherinfo	@publisher		= @publisher,
													@publisher_type = @publisher_type OUTPUT,
													@rpcheader		= @cmd OUTPUT

	IF @retcode <> 0
		RETURN (@retcode)

	-- Add sp
	SET @publisher = UPPER(@publisher) COLLATE DATABASE_DEFAULT
	set @cmd = @cmd + N'sys.sp_MSrepl_changelogreader_agent'

	EXEC @retcode = @cmd
					@job_login					= @job_login,
					@job_password				= @job_password,
					@publisher_security_mode	= @publisher_security_mode,
					@publisher_login			= @publisher_login,
					@publisher_password 		= @publisher_password,
					@publisher					= @publisher,
					@publisher_type 			= @publisher_type

	RETURN (@retcode)
END
go

