CREATE VIEW sys.dm_os_memory_node_access_stats AS
	SELECT *
	FROM OpenRowSet(TABLE DM_OS_MEMORYNODEACCESSSTATS)
go

