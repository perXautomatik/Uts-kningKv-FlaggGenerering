CREATE FUNCTION sys.dm_db_log_stats
	(
	@DatabaseId Int = null
	)
RETURNS TABLE
as
	RETURN
	SELECT *
	FROM OpenRowset(TABLE DM_DB_LOG_STATS, @DatabaseId)
go

