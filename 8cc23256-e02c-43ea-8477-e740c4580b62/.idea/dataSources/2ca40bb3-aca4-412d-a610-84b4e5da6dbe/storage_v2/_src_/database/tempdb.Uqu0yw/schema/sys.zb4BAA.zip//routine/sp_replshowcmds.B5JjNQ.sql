
create procedure sys.sp_replshowcmds 
(
    @maxtrans int = 1
)
as
begin

    set nocount on
    declare @query nvarchar(1024)
                ,@retcode int

    /*
    ** Security Check.
    */
    exec @retcode = sys.sp_MSreplcheck_publish
    if @@ERROR <> 0 or @retcode <> 0
        return(1)
    if (sys.fn_MSrepl_istranpublished (db_name(),0) != 1)
    begin
        raiserror(18757, 16, -1)
        return (1)
    end

    select @query = N'exec sys.sp_replcmds ' + cast (@maxtrans as nvarchar(12))
    execute @retcode = sys.sp_printstatement @query
    return @retcode
end
go

