
CREATE FUNCTION sys.dm_exec_cached_plan_dependent_objects(@planhandle varbinary(64))
RETURNS TABLE
AS
	RETURN SELECT * FROM OPENROWSET(TABLE SYSDMEXECCACHEDPLANDEPENDENTOBJECTS, @planhandle)
go

