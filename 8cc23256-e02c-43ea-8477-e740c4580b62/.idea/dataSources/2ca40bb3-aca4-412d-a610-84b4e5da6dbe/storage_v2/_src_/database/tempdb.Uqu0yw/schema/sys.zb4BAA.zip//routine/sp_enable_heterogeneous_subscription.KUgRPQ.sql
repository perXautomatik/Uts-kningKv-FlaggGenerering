
--
-- Name:    
--          sp_enable_heterogeneous_subscription
--          
-- Description: 
--          Enable or disable publication properties for
--			supporting heterogeneous subscriptions.
--  
-- Security: 
--          sysadmin or DBO of publisher db
--
-- Returns:
--      
-- Owner:   
--          <current owner> 
--

create procedure sys.sp_enable_heterogeneous_subscription
(
    @publication	sysname = NULL,
    @publisher		sysname = NULL
) 
AS
BEGIN
	DECLARE @cmd			nvarchar(4000)
	DECLARE @retcode		int
	DECLARE @publisher_type	sysname

	SET @retcode = 0
	
	EXEC @retcode = sys.sp_MSrepl_getpublisherinfo	@publisher		= @publisher,
													@rpcheader		= @cmd OUTPUT,
													@publisher_type	= @publisher_type OUTPUT
	
	IF @retcode <> 0
		RETURN (@retcode)

	-- Add sp
	SET @publisher = UPPER(@publisher) COLLATE DATABASE_DEFAULT
	set @cmd = @cmd + N'sys.sp_MSrepl_enable_heterogeneous_subscription'
	
	EXEC @retcode = @cmd
					@publication,
					@publisher,
					@publisher_type

	RETURN (@retcode)
END
go

