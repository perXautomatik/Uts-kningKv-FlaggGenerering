create procedure sys.sp_MSget_MSmerge_rowtrack_colinfo as
set nocount on

create table #temp_MSmerge_rowtrack
(
        tablenick                       int not null,
        rowguid                         uniqueidentifier not null,
        changetype                      tinyint not null,
        changed                         int not null,
        rowvector                       varbinary(11) null,
        changedcolumns          varbinary(128) null,
        columns_enumeration     tinyint not null, -- COLUMNS_ENUMERATED
        -- sync_cookie is set upon enumerating a change. It allows to determine
        -- for what publisher/publication the upload takes place.
        sync_cookie                     int null
)
select * from #temp_MSmerge_rowtrack where 1 = 2
drop table #temp_MSmerge_rowtrack
go

