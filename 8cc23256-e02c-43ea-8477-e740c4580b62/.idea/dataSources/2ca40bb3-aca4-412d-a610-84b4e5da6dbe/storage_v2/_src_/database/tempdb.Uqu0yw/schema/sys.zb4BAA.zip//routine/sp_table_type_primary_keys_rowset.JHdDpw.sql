
create procedure sys.sp_table_type_primary_keys_rowset
(
    @table_name         sysname = null,
    @table_schema       sysname = null
)
as
    select
        TABLE_CATALOG   = s_pkv.TABLE_CATALOG,
        TABLE_SCHEMA    = s_pkv.TABLE_SCHEMA,
        TABLE_NAME      = s_pkv.TABLE_NAME,
        COLUMN_NAME     = s_pkv.COLUMN_NAME,
        COLUMN_GUID     = s_pkv.COLUMN_GUID,
        COLUMN_PROPID   = s_pkv.COLUMN_PROPID,
        ORDINAL         = s_pkv.ORDINAL,
        PK_NAME         = s_pkv.PK_NAME
    from
        sys.spt_table_type_primary_keys_view s_pkv
    where
        (@table_name is null or s_pkv.TABLE_NAME = @table_name) and
        (@table_schema is null or schema_id(@table_schema) = s_pkv.schema_id)
    order by 2, 3
go

