
create procedure sys.sp_check_constraints_rowset2
(
    @constraint_schema  sysname = null
)
as
-------------------------------------------------------------------------------------------
-- copy & pasted from version 1 of the SProc and removed checks for 1st parameter !
-------------------------------------------------------------------------------------------
    select
        CONSTRAINT_CATALOG  = db_name(),
        CONSTRAINT_SCHEMA   = schema_name(o.schema_id),
        CONSTRAINT_NAME     = o.name,
        CHECK_CLAUSE        = convert(nvarchar(4000), m.definition), -- keep the type as it used to be in Shiloh
        DESCRIPTION         = convert(nvarchar(1), null)
    from
        sys.all_objects o inner join
        sys.check_constraints m on (o.type = 'C ' and m.object_id = o.object_id)
    where
        @constraint_schema is null or schema_id(@constraint_schema) = o.schema_id -- check schema IDs

    order by 1,2,3
go

