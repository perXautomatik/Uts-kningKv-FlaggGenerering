CREATE VIEW sys.dm_exec_valid_use_hints AS
	SELECT name
	FROM OpenRowset(TABLE VALID_USE_HINTS)
go

