create procedure sys.sp_addscriptexec
(
    @publication    sysname,
    @scriptfile        nvarchar (4000),
    @skiperror        bit = 0,
    @publisher        sysname = NULL
)
AS
BEGIN
    DECLARE @cmd        nvarchar(4000)
    DECLARE @retcode    int

    SET @retcode = 0
    
    EXEC @retcode = sys.sp_MSrepl_getpublisherinfo    @publisher    = @publisher,
                                                    @rpcheader    = @cmd OUTPUT
    
    IF @retcode <> 0
        RETURN (@retcode)

    -- Add sp
	SET @publisher = UPPER(@publisher) COLLATE DATABASE_DEFAULT
    set @cmd = @cmd + N'sys.sp_MSrepl_addscriptexec'

    EXEC @retcode = @cmd
                    @publication,
                    @scriptfile,
                    @skiperror

    RETURN (@retcode)
END
go

