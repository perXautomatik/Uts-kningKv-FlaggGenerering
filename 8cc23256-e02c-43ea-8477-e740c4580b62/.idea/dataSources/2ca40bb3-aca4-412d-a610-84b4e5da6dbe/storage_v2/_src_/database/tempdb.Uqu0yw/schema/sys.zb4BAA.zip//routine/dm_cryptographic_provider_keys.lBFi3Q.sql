CREATE FUNCTION sys.dm_cryptographic_provider_keys
	(
	@ProviderId			INT			= 0
	)
RETURNS TABLE
AS
	RETURN SELECT * FROM OPENROWSET
		(
		TABLE DM_CRYPTO_PROVIDER_KEYS, 
		@ProviderId
		)
go

