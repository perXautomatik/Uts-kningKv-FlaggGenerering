create function sys.fn_replreplacesinglequoteplusprotectstring (
    @pstrin nvarchar(4000) )
returns nvarchar(4000)
as
begin
    declare @pstrout nvarchar(4000)

    if (@pstrin is not null)
    begin
        select @pstrout = REPLACE(@pstrin, N'''', N'''''')
        select @pstrout = N'''' + @pstrout + N''''
    end
    else
        select @pstrout = N'NULL'

    return @pstrout
end
go

