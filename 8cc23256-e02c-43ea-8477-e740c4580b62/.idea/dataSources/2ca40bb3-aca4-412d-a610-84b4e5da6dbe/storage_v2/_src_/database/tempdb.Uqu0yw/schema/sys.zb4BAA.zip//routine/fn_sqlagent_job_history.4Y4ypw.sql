
CREATE FUNCTION sys.fn_sqlagent_job_history(
    @job_id UNIQUEIDENTIFIER NULL,
    @step_id INT NULL
 )
RETURNS @job_history TABLE (
        instance_id          INT              NOT NULL,
        job_id               UNIQUEIDENTIFIER NOT NULL,
        step_id              INT              NOT NULL,
        sql_message_id       INT              NOT NULL,
        sql_severity         INT              NOT NULL,
        [message]            NVARCHAR(4000)   NULL,
        run_status           INT              NOT NULL,
        run_date             INT              NOT NULL,
        run_time             INT              NOT NULL,
        run_duration         INT              NOT NULL,
        operator_id_emailed  INT              NOT NULL,
        operator_id_paged    INT              NOT NULL,
        retries_attempted    INT              NOT NULL
    )
AS
BEGIN
    -- Check if we are in msdb database context
    IF(LOWER(DB_NAME()) = 'msdb')
    BEGIN
        INSERT INTO @job_history
        SELECT instance_id,
            job_id,
            step_id,
            sql_message_id,
            sql_severity,
            [message],
            run_status,
            run_date,
            run_time,
            run_duration,
            operator_id_emailed,
            operator_id_paged,
            retries_attempted
        FROM sys.sqlagent_job_history
        WHERE ISNULL(@job_id, job_id) = job_id
        AND ISNULL(@step_id, step_id) = step_id
    END
    RETURN
END
go

