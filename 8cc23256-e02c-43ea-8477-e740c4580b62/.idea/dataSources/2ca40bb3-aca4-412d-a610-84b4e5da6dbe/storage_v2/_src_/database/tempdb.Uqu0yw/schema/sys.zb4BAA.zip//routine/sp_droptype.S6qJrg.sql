create procedure sys.sp_droptype
	@typename sysname		-- the user type to drop
as
	
	declare @schid int

--  Find the user type with @typename.  It must be a user type (xusertype > 256)
--  and you must be db_owner, db_ddladmin or sa (covered by db_owner check) to
-- drop the type. Only types owned by dbo are accessible thru sp_droptype.
	select @schid = schema_id from sys.types
			where name = @typename and user_type_id > 256 and schema_id = 1
	if (@schid is null)
		begin
			raiserror(15036,-1,-1, @typename)
			return (1)
		end
		
	if (is_member('db_owner') = 0 AND
		is_member('db_ddladmin') = 0)
	begin
		raiserror(15036,-1,-1, @typename)
		return (1)
	end

	declare @stmt nvarchar(384)

	select @stmt = 'drop type [dbo].' + quotename(@typename)
		
	-- Drop user defined type
	EXEC(@stmt)

	return (@@error) -- sp_droptype
go

