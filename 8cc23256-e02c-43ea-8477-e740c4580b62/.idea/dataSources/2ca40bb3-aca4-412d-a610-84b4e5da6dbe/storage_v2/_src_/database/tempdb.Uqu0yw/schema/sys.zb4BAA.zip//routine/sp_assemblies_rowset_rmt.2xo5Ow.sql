
create procedure sys.sp_assemblies_rowset_rmt
(
    @server_name        sysname,
    @catalog_name       sysname,
    @assembly_name      sysname = null,
    @assembly_schema    sysname = null,
    @assembly_id        int = null
)
as
    select
        ASSEMBLY_CATALOG,
        ASSEMBLY_SCHEMA,
        ASSEMBLY_NAME,
        ASSEMBLY_ID,
        PERMISSION_SET,
        DEBUG_MODE,
        ASSEMBLY_BINARY
    from
        -- ISSUE - below pseudo-function is not exposed by metadata code!
        sys.fn_remote_assemblies(@server_name,
                                 @catalog_name,
                                 @assembly_name,
                                 @assembly_schema,
                                 @assembly_id)
    order by 1,2,3
go

