
--
-- Name:    
--          sp_helparticle
--          
-- Description: 
--          Returns information about a publication article.  If the article
--          name is not specified, it returns information for all publication
--          articles.
--
--          For a SQL Server publication, this stored procedure is executed
--          at the Publisher on the publication database.  For a heterogeneous
--          publication, this stored procedure may be executed in any database
--          at the distributor for the associated publisher.
--  
-- Security: 
--          SQL Server publication:     'sysadmin', db_owner of publishing database, PAL
--          Heterogeneous publication:  'sysadmin', db_owner of distribution database, PAL
--
-- Returns:
--          Result set of article properties
--      
-- Owner:   
--          <current owner> 
--

create procedure sys.sp_helparticle
(
    @publication sysname,         /* The publication name */
    @article sysname = '%',       /* The article name */
    @returnfilter bit = 1,        /* Return filter flag */
    @publisher sysname = NULL,
    @found	int  = 0 OUTPUT
)
AS
BEGIN
    DECLARE @cmd nvarchar(4000)
	DECLARE @retcode int
	DECLARE @publisher_type sysname

    select @retcode = 0

    EXEC @retcode = sys.sp_MSrepl_getpublisherinfo	@publisher			= @publisher,
													@publisher_type		= @publisher_type OUTPUT,
													@rpcheader			= @cmd OUTPUT,
													@skipSecurityCheck	= 1
													
    IF @retcode <> 0
        RETURN (@retcode)

	SET @publisher = UPPER(@publisher) COLLATE DATABASE_DEFAULT

	IF @publisher_type <> N'MSSQLSERVER'
	BEGIN
		select @cmd = @cmd + N'sys.sp_IHhelparticle'

		EXEC @retcode = @cmd
						@publication,
						@article,
						@returnfilter,
						@publisher,
						@publisher_type,
						@found OUTPUT
	END
	ELSE
	BEGIN
		select @cmd = @cmd + N'sys.sp_MSrepl_helparticle'

		EXEC @retcode = @cmd
				@publication,
				@article,
				@returnfilter,
				@publisher,
				@found OUTPUT
	END
	
    RETURN (@retcode)
END
go

