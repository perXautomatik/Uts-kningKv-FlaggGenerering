-- this proc returns the max generation to bcp out. This essentially same
-- as finding a possible watermark generation. The generation is the max
-- closed generation lower than the min open generation.
-- this proc is called by snapshot to determine till how much it should bcp
create procedure sys.sp_MSgetmaxbcpgen
    @max_closed_gen bigint output
as
    declare @retcode int

    exec @retcode = sys.sp_MSreplcheck_publish
    if @@error <> 0 or @retcode <> 0
        return 1

    select @max_closed_gen = max(g.generation) 
        from MSmerge_genhistory g,
        (select isnull(gen2.generation, gen1.generation) as generation
            from (select max(generation) as generation from dbo.MSmerge_genhistory where genstatus in (1,2)) as gen1,
                 (select min(generation) as generation from dbo.MSmerge_genhistory where genstatus in (0,4)) as gen2
        ) as minopengen
    where g.generation <= minopengen.generation and g.genstatus in (1,2)

    if @max_closed_gen is NULL
        select @max_closed_gen = 0
go

