CREATE PROCEDURE sys.sp_articleview
(
    @publication                sysname,                /* Publication name */
    @article                    sysname,                /* Article name */
    @view_name                    nvarchar (386) = NULL,    /* View name */
    @filter_clause                nvarchar(max) = NULL,            /* Article's filter clause */
    @change_active                int = 0,
    @force_invalidate_snapshot    bit = 0,                /* Force invalidate existing snapshot */
    @force_reinit_subscription    bit = 0,                /* Force reinit subscription */
    @publisher                    sysname = NULL,
    @refreshsynctranprocs         bit = 1,    -- 1 = regenerate synctran procedures inside this SP for filter change
    @internal                     bit = 0
)
AS
BEGIN
    set nocount on
    DECLARE @cmd            nvarchar(4000)
                ,@retcode        int
                ,@publisher_type    sysname

    if (@publisher is NULL)
    begin
        EXEC @retcode = sys.sp_MSrepl_articleview
                    @publication,
                    @article,
                    @view_name,
                    @filter_clause,
                    @change_active,
                    @force_invalidate_snapshot,
                    @force_reinit_subscription,
                    @refreshsynctranprocs,
                    @internal
    end
    else
    begin
        -- Heterogeneous articles are handled directly by sp_IHarticleview
        EXEC @retcode = sys.sp_MSrepl_getpublisherinfo   @publisher        = @publisher,
                                                                            @publisher_type    = @publisher_type OUTPUT,
                                                                            @rpcheader        = @cmd OUTPUT
        IF @retcode <> 0
            RETURN (@retcode)
            
        SET @publisher = UPPER(@publisher)
        
        set @cmd = @cmd + N'dbo.sp_IHarticleview '
        EXEC @retcode = @cmd
                    @publication,
                    @article,
                    @view_name,
                    @filter_clause,
                    @change_active,
                    @force_invalidate_snapshot,
                    @force_reinit_subscription,
                    @publisher,
                    @publisher_type
    end    

    RETURN (@retcode)
END
go

