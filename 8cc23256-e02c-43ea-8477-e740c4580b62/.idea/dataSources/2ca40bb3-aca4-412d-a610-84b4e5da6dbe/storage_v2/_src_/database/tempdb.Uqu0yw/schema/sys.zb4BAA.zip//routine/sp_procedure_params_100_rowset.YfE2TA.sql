
create procedure sys.sp_procedure_params_100_rowset
(
    @procedure_name     sysname,
    @group_number       int = 1,
    @procedure_schema   sysname = null,
    @parameter_name     sysname = null
)
as
    select
        PROCEDURE_CATALOG                     = s_pp.PROCEDURE_CATALOG,
        PROCEDURE_SCHEMA                      = s_pp.PROCEDURE_SCHEMA,
        PROCEDURE_NAME                        = s_pp.PROCEDURE_NAME,
        PARAMETER_NAME                        = s_pp.PARAMETER_NAME,
        ORDINAL_POSITION                      = s_pp.ORDINAL_POSITION,
        PARAMETER_TYPE                        = s_pp.PARAMETER_TYPE,
        PARAMETER_HASDEFAULT                  = s_pp.PARAMETER_HASDEFAULT,
        PARAMETER_DEFAULT                     = s_pp.PARAMETER_DEFAULT,
        IS_NULLABLE                           = s_pp.IS_NULLABLE,
        DATA_TYPE                             = s_pp.DATA_TYPE,
        CHARACTER_MAXIMUM_LENGTH              = s_pp.CHARACTER_MAXIMUM_LENGTH,
        CHARACTER_OCTET_LENGTH                = s_pp.CHARACTER_OCTET_LENGTH,
        NUMERIC_PRECISION                     = s_pp.NUMERIC_PRECISION,
        NUMERIC_SCALE                         = s_pp.NUMERIC_SCALE,
        DESCRIPTION                           = s_pp.DESCRIPTION,
        TYPE_NAME                             = s_pp.TYPE_NAME,
        LOCAL_TYPE_NAME                       = s_pp.LOCAL_TYPE_NAME,
        SS_XML_SCHEMACOLLECTION_CATALOGNAME   = s_pp.SS_XML_SCHEMACOLLECTION_CATALOGNAME,
        SS_XML_SCHEMACOLLECTION_SCHEMANAME    = s_pp.SS_XML_SCHEMACOLLECTION_SCHEMANAME,
        SS_XML_SCHEMACOLLECTIONNAME           = s_pp.SS_XML_SCHEMACOLLECTIONNAME,
        SS_UDT_CATALOGNAME                    = s_pp.SS_UDT_CATALOGNAME,
        SS_UDT_SCHEMANAME                     = s_pp.SS_UDT_SCHEMANAME,
        SS_UDT_NAME                           = s_pp.SS_UDT_NAME,
        SS_UDT_ASSEMBLY_TYPENAME              = s_pp.SS_UDT_ASSEMBLY_TYPENAME,
        SS_TYPE_CATALOG_NAME                  = s_pp.SS_TYPE_CATALOG_NAME,
        SS_TYPE_SCHEMANAME                    = s_pp.SS_TYPE_SCHEMANAME,
        SS_DATETIME_PRECISION                 = s_pp.SS_DATETIME_PRECISION
    from
        sys.fn_procedure_params_90_rowset(
          @procedure_name,
          @group_number,
          @procedure_schema,
          @parameter_name) s_pp

    order by 2, 3, 5
    option (OPTIMIZE CORRELATED UNION ALL)
go

