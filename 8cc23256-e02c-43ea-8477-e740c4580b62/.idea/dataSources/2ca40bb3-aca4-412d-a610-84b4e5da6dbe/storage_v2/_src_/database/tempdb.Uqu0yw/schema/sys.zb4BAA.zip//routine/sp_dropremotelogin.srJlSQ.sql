create procedure sys.sp_dropremotelogin
	@remoteserver	sysname,			-- name of remote server
	@loginame		sysname = NULL,		-- user's local user name
	@remotename		sysname = NULL		-- user's remote name
as
	declare @sid varbinary(85)

	-- DISALLOW USER XACT --
	set implicit_transactions off
	if @@trancount > 0
	begin
		raiserror(15002,-1,-1,'sys.sp_dropremotelogin')
		return (1)
	end

	-- CHECK PERMISSIONS
	if not (has_perms_by_name(null, null, 'alter any login') = 1)
	begin
		EXEC %%System().AuditEvent(ID = 1380207698, Success = 0, TargetLoginName = @loginame, TargetUserName = NULL, Role = NULL, Object = @remotename, Provider = NULL, Server = @remoteserver)
		raiserror(15247,-1,-1)
		return (1)
	end
	else
		EXEC %%System().AuditEvent(ID = 1380207698, Success = 1, TargetLoginName = @loginame, TargetUserName = NULL, Role = NULL, Object = @remotename, Provider = NULL, Server = @remoteserver)


	-- CHECK FOR INVALID PARAMETER SYNTAX --
	if @remoteserver is null OR (@loginame is null and @remotename is not null)
	begin
		raiserror(15600,-1,-1,'sys.sp_dropremotelogin')
		return (1)
	end

	BEGIN TRAN

	-- VALIDATE/LOCK SERVER NAME --
	EXEC %%LinkedServer ( Name = @remoteserver ) . Lock ( Exclusive = 1 )
	IF @@ERROR <> 0
	begin
		ROLLBACK TRAN
		raiserror(15015,-1,-1,@remoteserver)
		return (1)
	end

	-- VALIDATE/LOCK @loginame --
	if @loginame is not null
	begin
		-- share-lock the local login
		EXEC %%LocalLogin ( Name = @loginame ) . Lock ( Exclusive = 0 )
		IF @@ERROR = 0
			select @sid = sid from sys.server_principals
				where name = @loginame and type = 'S'		-- cannot map to NT login
		if @sid is null
		begin
			ROLLBACK TRAN
			raiserror(15007,-1,-1,@loginame)
			return (1)
		end
	end

	-- CHECK IF REQUESTED MAPPING ACTUALLY EXISTS --
	IF NOT EXISTS (SELECT * FROM master.dbo.sysremotelogins WHERE
			remoteserverid IN (SELECT srvid FROM master.dbo.sysservers WHERE srvname = @remoteserver)
			AND ((@sid IS NULL and sid IS NULL) or sid = @sid)
			AND ((@remotename IS NULL and remoteusername IS NULL) or remoteusername = @remotename) )
	BEGIN
		ROLLBACK TRAN
		raiserror(15185,-1,-1,@remotename,@loginame,@remoteserver)
		return (1)
	END

	-- DROP REMOTE LOGIN --
	EXEC %%LinkedServer(Name=@remoteserver).RemoveRemoteLogin( RemoteName = @remotename )

	-- SUCCESS --
	COMMIT TRAN
	return (0)	-- sp_dropremotelogin
go

