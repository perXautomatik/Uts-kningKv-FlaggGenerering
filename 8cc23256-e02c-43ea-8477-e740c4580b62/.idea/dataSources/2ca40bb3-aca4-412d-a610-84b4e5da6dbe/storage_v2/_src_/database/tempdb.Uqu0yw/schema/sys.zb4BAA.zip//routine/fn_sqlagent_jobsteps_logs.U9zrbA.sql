
CREATE FUNCTION sys.fn_sqlagent_jobsteps_logs(
    @step_uid UNIQUEIDENTIFIER NULL
 )
RETURNS @jobstep_logs TABLE (
        [log_id]        INT NOT NULL,
        [log_text]      NVARCHAR(MAX) NOT NULL,
        [date_created]  DATETIME NOT NULL,
        [step_uid]      UNIQUEIDENTIFIER NOT NULL 
    )
AS
BEGIN
    -- Check if we are in msdb database context
    IF(LOWER(DB_NAME()) = 'msdb')
    BEGIN
        INSERT INTO @jobstep_logs
        SELECT log_id,
            log_text,
            date_created,
            step_uid
        FROM sys.sqlagent_jobsteps_logs
        WHERE ISNULL(@step_uid, step_uid) = step_uid
    END
    RETURN
END
go

