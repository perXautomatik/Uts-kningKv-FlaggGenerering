
create procedure sys.sp_table_constraints_rowset
(
    @table_name         sysname,
    @table_schema       sysname = null,
    @table_catalog      sysname = null,
    @constraint_name    sysname = null,
    @constraint_schema  sysname = null,
    @constraint_catalog sysname = null,
    @constraint_type    nvarchar(255) = null
)
as
    select
        CONSTRAINT_CATALOG  = db_name(),
        CONSTRAINT_SCHEMA   = schema_name(o.schema_id),
        CONSTRAINT_NAME     = o.name,
        TABLE_CATALOG       = db_name(),
        TABLE_SCHEMA        = schema_name(t_obj.schema_id),
        TABLE_NAME          = t_obj.name,
--        CONSTRAINT_TYPE     = case (syscon.status & 0xf)
        CONSTRAINT_TYPE     = case syscon.type
--                                when 1 then N'PRIMARY KEY'
                                when 'PK' then N'PRIMARY KEY'
--                                when 2 then N'UNIQUE'
                                when 'UQ' then N'UNIQUE'
--                                when 3 then N'FOREIGN KEY'
                                when 'F' then N'FOREIGN KEY'
--                                when 4 then N'CHECK'
                                when 'C' then N'CHECK'
                                else null
                              end,
        IS_DEFERRABLE       = convert(bit, 0),
        INITIALLY_DEFERRED  = convert(bit, 0),
        DESCRIPTION         = convert(nvarchar(1), null)

    from
        sys.all_objects o,
        sys.all_objects t_obj,
--        sysconstraints syscon
        sys.all_objects syscon
    where
        t_obj.name  = @table_name and
        t_obj.type in ('U','S') and
        (@table_catalog is null or @table_catalog = db_name()) and
        (@table_schema is null or @table_schema = schema_name(t_obj.schema_id)) and
        syscon.parent_object_id = t_obj.object_id and
        (syscon.type in ('PK', 'UQ', 'F', 'C')) and
        o.object_id    = syscon.object_id and
        o.schema_id = schema_id() and
        (@constraint_name is null or o.name = @constraint_name) and
        (@constraint_catalog is null or @constraint_catalog = db_name()) and
        (@constraint_schema is null or @constraint_schema = schema_name(o.schema_id)) and
        (@constraint_type is null or
         syscon.type = case @constraint_type
                       when N'PRIMARY KEY' then 'PK'
                       when N'UNIQUE' then 'UQ'
                       when N'FOREIGN KEY' then 'F'
                       when N'CHECK' then 'C'
                       end)
    order by 2,3,5,6,7
go

