create procedure sys.sp_MSrequestreenumeration
                                                @tablenick int,
                                                @rowguid uniqueidentifier
as
    declare @retcode int
    declare @err int
    declare @rc int
    declare @METADATA_ACTION_ForceReenumeration tinyint

    set @METADATA_ACTION_ForceReenumeration= 5

    exec @retcode= sys.sp_MSrepl_PAL_rolecheck @tablenick = @tablenick
    if (@retcode <> 0) or (@@error <> 0) return 1
    
    update dbo.MSmerge_metadataaction_request
            set action= @METADATA_ACTION_ForceReenumeration,
                    generation=0,
                    changed= null
            where tablenick=@tablenick and rowguid=@rowguid

    select @err= @@error, @rc=@@rowcount
    if @err<>0 return 1
    if @rc>0 return 0

    insert into dbo.MSmerge_metadataaction_request
                                            (tablenick,
                                             rowguid,
                                             action,
                                             generation,
                                             changed)
                                    values
                                            (@tablenick,
                                             @rowguid,
                                             @METADATA_ACTION_ForceReenumeration,
                                             0,
                                             null)
                                             
    if @err<>0 return 1
    return 0
go

