--
-- Name: 
--		sp_MSupdate_tracer_history
-- 
-- Description: 
--		This procedure will update the tracer history row's distrib_commit 
--		time to getdate(). 
--  
-- Parameters: 
--		@tracer_id	int		Id of the tracer to be updated
--
-- Returns: 
--		0 - succeeded
--      1 - failed
--
-- Result: 
--		None
--
-- Security: 
--		Sysadmin/dbo (run by logreader only)
--
create procedure sys.sp_MSupdate_tracer_history
(
	@tracer_id	int
)
as
begin
	set nocount on
	
    --
    -- security check
    -- only db_owner can execute this
    --
    if (is_member ('db_owner') != 1) 
    begin
        raiserror(14260, 16, -1)
        return (1)
    end

	-- update the requested tracer token
	-- if the tracer token row no longer exists then
	-- we will exit with no error because this may happen
	-- if cleanup comes bye and removes the token row
	update MStracer_tokens
		set distributor_commit = getdate()
		where tracer_id = @tracer_id
	if @@error <> 0
	begin
		return 1
	end

	return 0
end
go

