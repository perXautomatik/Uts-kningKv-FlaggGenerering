
create procedure sys.sp_linkedservers_rowset
(
    @srvname    sysname
)
as
    select
        SVR_NAME            = s_s.name,
        SVR_PRODUCT         = s_s.product,
        SVR_PROVIDERNAME    = s_s.provider,
        SVR_DATASOURCE      = s_s.data_source,
        SVR_PROVIDERSTRING  = s_s.provider_string,
        SVR_LOCATION        = s_s.location,
        SVR_CATALOG         = s_s.catalog
    from
        sys.servers s_s
    where
        s_s.name = @srvname and
        -- Don't use s_s.is_linked, because 0 there means old-style linked server, 1 means new-style.
        s_s.is_data_access_enabled = 1
    order by 1
go

