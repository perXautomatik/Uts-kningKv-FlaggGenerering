create procedure sys.sp_startmergepullsubscription_agent
(
    @publisher      sysname,
    @publisher_db   sysname,
    @publication    sysname
)
as
begin
    set nocount on
    declare @retcode int
            ,@start tinyint

    set @retcode = 0
    set @start = 0

    -- Security check
    exec @retcode = sys.sp_MSreplcheck_subscribe
    if @@error <> 0 or @retcode <> 0
        return 1

    exec @retcode = sys.sp_MSmergepullsubscriptionagentjobcontrol
        @publisher = @publisher,
        @publisher_db = @publisher_db,
        @publication = @publication,
        @action = @start
    return @retcode 
end
go

