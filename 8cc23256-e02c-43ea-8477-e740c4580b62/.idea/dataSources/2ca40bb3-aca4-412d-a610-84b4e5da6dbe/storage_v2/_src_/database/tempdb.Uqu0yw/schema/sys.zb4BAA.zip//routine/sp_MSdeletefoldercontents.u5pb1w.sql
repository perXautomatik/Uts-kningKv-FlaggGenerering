--
-- Name: sp_MSdeletefoldercontents
--
-- Description: This is a lighweight wrapper for deleting all files in the
--              specified directory. This procedure is meant to be called by 
--              a remote publisher for deleting files in the distributor's 
--              context.
--
-- Parameter: @folder nvarchar(255) (mandatory)
--
-- Returns 0 - succeeded
--         1 - failed
--
-- Security: Only members of the sysadmin server role and members of the 
-- db_owner role of the distribution database can execute this function. This
-- procedure is intended to be called through the distribution_admin remote 
-- login from remote publishers
--
-- Requires Certificate signature for catalog access
--
create procedure sys.sp_MSdeletefoldercontents 
(
    @folder nvarchar(255)
)
as
begin
    set nocount on

    declare @command_prefix nvarchar(4000)
    declare @command nvarchar(4000)
    declare @retcode int

    --
    -- security check
    -- only sysadmin can execute this
    --
    if (isnull(is_srvrolemember('sysadmin'),0) =0) 
    begin
        raiserror(21089, 16, -1)
        return (1)
    end
    select @retcode = 0
    if len(@folder) = 0 or @folder is null
    begin
        return 0
    end

    -- \ terminate path
    if substring(@folder, len(@folder), 1) <> N'\'
    begin
        select @folder = @folder + N'\'
    end 


    if (platform() & 0x1) = 0x1 
    begin
        select @command_prefix = 'del /q /f "' + sys.fn_escapecmdshellsymbolsremovequotes(@folder) collate database_default
    end
    else
    begin
        -- Win9x 'del' command does not support the /q and /f switches
        select @command_prefix = 'del "' + sys.fn_escapecmdshellsymbolsremovequotes(@folder) collate database_default
    end

    -- Hardwired merge system table files without embedded _
    set @command = @command_prefix + N'sysmergesubsetfilters*.sch"'
    exec @retcode = master..xp_cmdshell @command, no_output

    set @command = @command_prefix + N'sysmergesubsetfilters*.bcp"'
    exec @retcode = master..xp_cmdshell @command, no_output
    
    -- .sch extensio
    set @command = @command_prefix + N'*_*.sch"'
    exec @retcode = master..xp_cmdshell @command, no_output

    -- .bcp extension
    set @command = @command_prefix + N'*_*.bcp"'
    exec @retcode = master..xp_cmdshell @command, no_output

    -- .idx extension
    set @command = @command_prefix + N'*_*.idx"'
    exec @retcode = master..xp_cmdshell @command, no_output

    -- .sql extension
    set @command = @command_prefix + N'*_*.sql"'
    exec @retcode = master..xp_cmdshell @command, no_output

    -- .ftx extension
    set @command = @command_prefix + N'*_*.ftx"'
    exec @retcode = master..xp_cmdshell @command, no_output
    
    -- .pre extension
    set @command = @command_prefix + N'*_*.pre"'
    exec @retcode = master..xp_cmdshell @command, no_output

    -- snapshot.cab
    set @command = @command_prefix + N'snapshot.cab"'
    exec @retcode = master..xp_cmdshell @command, no_output

    -- dynsnapvalidation.tok
    set @command = @command_prefix + N'dynsnapvalidation.tok"'
    exec @retcode = master..xp_cmdshell @command, no_output

    -- .pre extension
    set @command = @command_prefix + N'snapshot.pre"'
    exec @retcode = master..xp_cmdshell @command, no_output

    -- .trg extension
    set @command = @command_prefix + N'*_*.trg"'
    exec @retcode = master..xp_cmdshell @command, no_output

    -- .xpp extension
    set @command = @command_prefix + N'*_*.xpp"'
    exec @retcode = master..xp_cmdshell @command, no_output

    -- .cft extension
    set @command = @command_prefix + N'*_*.cft"'
    exec @retcode = master..xp_cmdshell @command, no_output

    -- .dri extension
    set @command = @command_prefix + N'*_*.dri"'
    exec @retcode = master..xp_cmdshell @command, no_output

    -- .prc extension
    set @command = @command_prefix + N'*_*.prc"'
    exec @retcode = master..xp_cmdshell @command, no_output

Failure:

    return @retcode

end
go

