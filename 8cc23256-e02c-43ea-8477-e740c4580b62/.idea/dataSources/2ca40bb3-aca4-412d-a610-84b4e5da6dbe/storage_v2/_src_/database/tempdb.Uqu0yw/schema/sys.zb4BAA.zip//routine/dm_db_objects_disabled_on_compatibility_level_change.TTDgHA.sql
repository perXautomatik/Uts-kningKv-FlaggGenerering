
CREATE FUNCTION sys.dm_db_objects_disabled_on_compatibility_level_change(@compatibility_level int)
RETURNS TABLE AS		
	RETURN SELECT * FROM OPENROWSET(TABLE SYSTEM_REFERENCES, 0, @compatibility_level, NULL, NULL)
go

