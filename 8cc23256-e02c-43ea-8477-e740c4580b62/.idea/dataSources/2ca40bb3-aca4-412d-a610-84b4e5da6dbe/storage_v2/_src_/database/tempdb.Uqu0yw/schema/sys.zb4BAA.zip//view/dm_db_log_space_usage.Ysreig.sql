CREATE VIEW sys.dm_db_log_space_usage AS
	SELECT *
	FROM OpenRowset(TABLE DM_DB_LOG_SPACE_USAGE)
go

