
create proc sys.sp_MSGetServerProperties
as
   set nocount on

   DECLARE @auto_start                  INT
   DECLARE @startup_account             NVARCHAR(100)

   -- Read the values from the registry
   IF ((PLATFORM() & 0x1) = 0x1) -- NT
   BEGIN
      EXECUTE sys.xp_instance_regread N'HKEY_LOCAL_MACHINE',
                                             N'SYSTEM\CurrentControlSet\Services\MSSQLServer',
                                             N'Start',
                                             @auto_start OUTPUT,
                                             N'no_output'
      EXECUTE sys.xp_instance_regread N'HKEY_LOCAL_MACHINE',
                                             N'SYSTEM\CurrentControlSet\Services\MSSQLServer',
                                             N'ObjectName',
                                             @startup_account OUTPUT,
                                             N'no_output'
   END ELSE
   BEGIN
      SELECT @auto_start = 3 -- Manual start
      SELECT @startup_account = NULL
   END

   -- Return the values to the client
   SELECT auto_start = CASE @auto_start
                       WHEN 2 THEN 1 -- 2 means auto-start
                       WHEN 3 THEN 0 -- 3 means don't auto-start
                       ELSE 0        -- Safety net
                       END,
          startup_account = @startup_account

go

