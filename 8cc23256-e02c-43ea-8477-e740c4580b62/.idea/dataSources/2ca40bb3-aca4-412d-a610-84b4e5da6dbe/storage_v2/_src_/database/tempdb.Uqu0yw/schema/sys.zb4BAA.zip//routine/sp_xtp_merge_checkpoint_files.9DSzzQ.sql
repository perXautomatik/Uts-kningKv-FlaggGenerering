
create procedure sys.sp_xtp_merge_checkpoint_files
( 
	@database_name sysname,
	@transaction_lower_bound bigint,
	@transaction_upper_bound bigint
)
as
	exec sys.sp_xtp_merge_checkpoint_files_internal @database_name, @transaction_lower_bound, @transaction_upper_bound
go

