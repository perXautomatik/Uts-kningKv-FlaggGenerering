CREATE VIEW sys.dm_db_xtp_index_stats
AS
	SELECT
	*
	FROM OpenRowset(TABLE XTP_INDEX_STATS)
go

