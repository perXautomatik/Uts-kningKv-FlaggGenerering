
create procedure sys.sp_table_types
(
    @table_name         nvarchar(384)   = null,
    @table_owner        nvarchar(384)   = null,
    @table_qualifier    sysname = null,
    @table_type         varchar(100) = null,
    @fUsePattern        bit = 1
)
as
    -- @table_type and @fUsePattern are intentionally unused parameters
    -- so that the procedure parameters for sp_table_types match the
    -- parameters for sp_tables.
    --
    if @table_qualifier is not null
    begin
        if db_name() <> @table_qualifier
        begin
            if @table_qualifier = ''
            begin  -- If empty qualifier supplied, force an empty result set.
                select @table_name = ''
                select @table_owner = ''
            end
            else
            begin   -- If qualifier doesn't match current database.
                raiserror (15250, -1,-1)
                return
            end
        end
    end
    select @table_qualifier = null -- it's not needed anymore

    select
        TABLE_QUALIFIER = convert(sysname,db_name()),
        TABLE_OWNER     = convert(sysname,schema_name(tt.schema_id)),
        TABLE_NAME      = convert(sysname,tt.name),
        TABLE_TYPE      = convert(varchar(32),'TABLE TYPE'),
        REMARKS = convert(varchar(254),null)    -- Remarks are NULL.
    from
        sys.table_types tt

    where
        (@table_name  is NULL or tt.name like @table_name) and
        (@table_owner is NULL or schema_name(tt.schema_id) like @table_owner)
    order by 4, 1, 2, 3
go

