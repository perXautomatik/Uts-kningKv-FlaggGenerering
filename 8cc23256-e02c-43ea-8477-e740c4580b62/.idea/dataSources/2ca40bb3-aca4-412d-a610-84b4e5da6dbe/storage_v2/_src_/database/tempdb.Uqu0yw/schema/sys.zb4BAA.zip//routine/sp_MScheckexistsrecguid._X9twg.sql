create procedure sys.sp_MScheckexistsrecguid
	@recguid	uniqueidentifier,
	@exists		bit output
as
    declare @retcode int
    
	exec @retcode = sys.sp_MSreplcheck_subscribe 
    if @retcode <> 0 or @@error <> 0 return 1

	if exists (select * from dbo.sysmergesubscriptions where recguid=@recguid)
	begin
		set @exists= 1
	end
	else
	begin
		set @exists= 0
	end

	return 0
go

