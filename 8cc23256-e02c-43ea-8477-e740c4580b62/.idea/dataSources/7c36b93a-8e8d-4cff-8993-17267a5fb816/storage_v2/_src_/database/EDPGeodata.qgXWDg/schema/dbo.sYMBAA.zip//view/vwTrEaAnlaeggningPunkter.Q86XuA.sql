


CREATE VIEW [dbo].[vwTrEaAnlaeggningPunkter]
AS

SELECT
    K.recKoordinatID AS Id,
    T.recTillsynsobjektID AS Tillsynsobjekt,
    AT.strAnlaeggningstyp AS Anläggningstyp,
    AKI.strAnlaeggningskategori AS Anläggningskategori,
    A.decVolym AS Volym,
    A.datBeslutsdatum AS Beslutsdatum,
    A.datBesiktningsdatum as Besiktningsdatum,
    A.intToemningsintervall AS Tömningsintervall,
    A.strText AS Text,
    A.strStatus as Status,
    A.datStatusDatum as Datum,
    A.intExterntTjaenstID as ExterntTjaenstID,
    A.strCertifieringstyp as Certifieringstyp,
    A.datToemningsdispensFrOM as ToemningsdispensFrOM,
    A.strToaletttyp as ToalettTyp,
[geometry]::Point(K.decY, K.decX, 3015) AS Shape
FROM EDPVisionRegionGotlandTest.dbo.tbTrEaAnlaeggning AS A
INNER JOIN EDPVisionRegionGotlandTest.dbo.tbTrEaAvloppsanlaeggning AS AA ON A.recAvloppsanlaeggningID = AA.recAvloppsanlaeggningID
INNER JOIN EDPVisionRegionGotlandTest.dbo.tbTrTillsynsobjekt AS T ON AA.recTillsynsobjektID = T.recTillsynsobjektID
LEFT OUTER JOIN EDPVisionRegionGotlandTest.dbo.tbTrEaAnlaeggningstyp AS AT ON A.recAnlaeggningstypID = AT.recAnlaeggningstypID
LEFT OUTER JOIN EDPVisionRegionGotlandTest.dbo.tbTrEaAnlaeggningskategori AS AKI ON A.recAnlaeggningskategoriID = AKI.recAnlaeggningskategoriID
INNER JOIN EDPVisionRegionGotlandTest.dbo.tbTrEaAnlaeggningKoordinat AS AK ON A.recAnlaeggningID = AK.recAnlaeggningID
INNER JOIN EDPVisionRegionGotlandTest.dbo.tbVisKoordinat AS K ON AK.recKoordinatID = K.recKoordinatID
WHERE K.strPunkttyp='Efterföljande rening' OR K.strPunkttyp='Ansluten byggnad' OR K.strPunkttyp='Extra inventeringsin' OR K.strPunkttyp='Tank'

go

