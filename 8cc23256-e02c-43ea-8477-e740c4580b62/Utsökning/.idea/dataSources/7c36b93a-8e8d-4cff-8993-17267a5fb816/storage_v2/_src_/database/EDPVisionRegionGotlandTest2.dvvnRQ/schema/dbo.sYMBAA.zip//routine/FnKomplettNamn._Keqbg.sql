
            CREATE FUNCTION [dbo].[FnKomplettNamn]    
              (@enamn AS VARCHAR(100)      
             , @fnamn AS VARCHAR(100))     
              RETURNS VARCHAR(201)    
            AS    

            BEGIN  
             DECLARE @fullName AS VARCHAR(201)    
             SET @fullName = LTRIM(ISNULL(RTRIM(@fnamn), '') + ISNULL(' ' + RTRIM(LTRIM(@enamn)), ''))   
             RETURN @fullName  
            END
            go

