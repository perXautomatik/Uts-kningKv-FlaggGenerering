
                            CREATE VIEW dbo.vwMmRiktvaerdeNat
AS
SELECT     dbo.tbMmRiktvaerdeNat.recRiktvaerdeNatID, dbo.tbMmRiktvaerdeNat.strMarkanvaendning, dbo.tbMmRiktvaerdeNat.strMatris,
                      dbo.tbMmRiktvaerdeNat.strMarktaethet, dbo.tbMmRiktvaerdeNat.intOrganiskHalt, dbo.tbMmRiktvaerdeNat.intLerhalt, dbo.tbMmRiktvaerdeNat.intAartal,
                      dbo.tbMmRiktvaerdeNat.decVaerde, dbo.tbMmAemne.strAemneNamn, dbo.tbMmAemne.strAemneKemBeteckning, dbo.tbMmAemne.bolEditOk,
                      dbo.tbMmRiktvaerdetyp.strRiktvaerdetypNamn, dbo.tbMmRiktvaerdeNat.recRiktvaerdeNatID AS intRecnum, dbo.tbMmRiktvaerdeNat.strEnhet,
                      dbo.tbMmRiktvaerdeNat.strKommentar, dbo.tbMmRiktvaerdeNat.decFraanDjup, dbo.tbMmRiktvaerdeNat.decTillDjup,
                      dbo.tbMmRiktvaerdeNat.guidAemneID, dbo.tbMmRiktvaerdeNat.guidRiktvaerdetypID
FROM         dbo.tbMmRiktvaerdeNat LEFT OUTER JOIN
                      dbo.tbMmAemne ON dbo.tbMmRiktvaerdeNat.guidAemneID = dbo.tbMmAemne.guidAemneID LEFT OUTER JOIN
                      dbo.tbMmRiktvaerdetyp ON dbo.tbMmRiktvaerdeNat.guidRiktvaerdetypID = dbo.tbMmRiktvaerdetyp.guidRiktvaerdetypID
                            go

