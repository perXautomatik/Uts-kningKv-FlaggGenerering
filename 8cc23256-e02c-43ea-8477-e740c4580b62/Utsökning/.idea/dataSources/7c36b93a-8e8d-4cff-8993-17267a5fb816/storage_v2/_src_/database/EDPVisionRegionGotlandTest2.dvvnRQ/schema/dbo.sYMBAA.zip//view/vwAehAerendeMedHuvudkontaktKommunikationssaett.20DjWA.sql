

CREATE VIEW [dbo].[vwAehAerendeMedHuvudkontaktKommunikationssaett]
AS
WITH HuvudkontaktKommunikationssaett
AS (
	SELECT recAerendeID
		,(
			SELECT TOP (1) strOrginisationPersonnummer
			FROM tbVisEnstakaKontakt
			WHERE recEnstakaKontaktID IN (
					SELECT TOP (1) recEnstakaKontaktID
					FROM tbAehAerendeEnstakaKontakt
					WHERE recAerendeID = vwAehAerende.recAerendeID
						AND bolHuvudkontakt = 1
					ORDER BY recAerendeEnstakaKontaktID DESC
					)
			) AS strHuvudkontaktensOrganisationsPersonnummer
		,(
			REPLACE((
					SELECT strVaerde + ', '
					FROM tbVisKommunikationssaett
					WHERE strKommunikationsaettTyp = 'Telefon'
						AND tbVisKommunikationssaett.recKommunikationssaettID IN (
							SELECT recKommunikationssaettID
							FROM tbVisEnstakaKontaktKommunikationssaett
							WHERE recEnstakaKontaktID IN (
									SELECT TOP (1) recEnstakaKontaktID
									FROM tbAehAerendeEnstakaKontakt
									WHERE recAerendeID = vwAehAerende.recAerendeID
										AND bolHuvudkontakt = 1
									ORDER BY recAerendeEnstakaKontaktID DESC
									)
							)
					FOR XML PATH('')
					) + '...', ', ...', '')
			) AS strHuvudkontaktensTelefon
		,(
			REPLACE((
					SELECT strVaerde + ', '
					FROM tbVisKommunikationssaett
					WHERE strKommunikationsaettTyp = 'Mobil'
						AND tbVisKommunikationssaett.recKommunikationssaettID IN (
							SELECT recKommunikationssaettID
							FROM tbVisEnstakaKontaktKommunikationssaett
							WHERE recEnstakaKontaktID IN (
									SELECT TOP (1) recEnstakaKontaktID
									FROM tbAehAerendeEnstakaKontakt
									WHERE recAerendeID = vwAehAerende.recAerendeID
										AND bolHuvudkontakt = 1
									ORDER BY recAerendeEnstakaKontaktID DESC
									)
							)
					FOR XML PATH('')
					) + '...', ', ...', '')
			) AS strHuvudkontaktensMobil
		,(
			REPLACE((
					SELECT strVaerde + ', '
					FROM tbVisKommunikationssaett
					WHERE strKommunikationsaettTyp = 'Fax'
						AND tbVisKommunikationssaett.recKommunikationssaettID IN (
							SELECT recKommunikationssaettID
							FROM tbVisEnstakaKontaktKommunikationssaett
							WHERE recEnstakaKontaktID IN (
									SELECT TOP (1) recEnstakaKontaktID
									FROM tbAehAerendeEnstakaKontakt
									WHERE recAerendeID = vwAehAerende.recAerendeID
										AND bolHuvudkontakt = 1
									ORDER BY recAerendeEnstakaKontaktID DESC
									)
							)
					FOR XML PATH('')
					) + '...', ', ...', '')
			) AS strHuvudkontaktensFax
		,(
			REPLACE((
					SELECT strVaerde + ', '
					FROM tbVisKommunikationssaett
					WHERE strKommunikationsaettTyp = 'E-post'
						AND tbVisKommunikationssaett.recKommunikationssaettID IN (
							SELECT recKommunikationssaettID
							FROM tbVisEnstakaKontaktKommunikationssaett
							WHERE recEnstakaKontaktID IN (
									SELECT TOP (1) recEnstakaKontaktID
									FROM tbAehAerendeEnstakaKontakt
									WHERE recAerendeID = vwAehAerende.recAerendeID
										AND bolHuvudkontakt = 1
									ORDER BY recAerendeEnstakaKontaktID DESC
									)
							)
					FOR XML PATH('')
					) + '...', ', ...', '')
			) AS strHuvudkontaktensEpost
	FROM vwAehAerende
	)
SELECT dbo.vwAehAerende.recAerendeID
	,dbo.vwAehAerende.strDiarienummerSerie
	,dbo.vwAehAerende.intDiarienummerLoepNummer
	,dbo.vwAehAerende.strDiarienummer
	,dbo.vwAehAerende.strAerendemening
	,dbo.vwAehAerende.strSoekbegrepp
	,dbo.vwAehAerende.strAerendeKommentar
	,dbo.vwAehAerende.recFoervaltningID
	,dbo.vwAehAerende.recEnhetID
	,dbo.vwAehAerende.recAvdelningID
	,dbo.vwAehAerende.recExterntID
	,dbo.vwAehAerende.recDiarieAarsSerieID
	,dbo.vwAehAerende.strPublicering
	,dbo.vwAehAerende.recLastAerendeStatusLogID
	,dbo.vwAehAerende.intRecnum
	,dbo.vwAehAerende.strFastighetsbeteckning
	,dbo.vwAehAerende.strFnrID
	,dbo.vwAehAerende.recFastighetID
	,dbo.vwAehAerende.datInkomDatum
	,dbo.vwAehAerende.datDatum
	,dbo.vwAehAerende.strLogKommentar
	,dbo.vwAehAerende.strAerendeStatusPresent
	,dbo.vwAehAerende.strLocalizationCode
	,dbo.vwAehAerende.strSignature
	,dbo.vwAehAerende.strUserVisasSom
	,dbo.vwAehAerende.intUserID
	,dbo.vwAehAerende.recDiarieSerieID
	,dbo.vwAehAerende.intDiarieAar
	,dbo.vwAehAerende.intSerieStartVaerde
	,dbo.vwAehAerende.strDiarieSerieKod
	,dbo.vwAehAerende.strSekretess
	,dbo.vwAehAerende.strBegraensa
	,dbo.vwAehAerende.strSekretessMyndighet
	,dbo.vwAehAerende.datSekretessDatum
	,dbo.vwAehAerende.recProjektID
	,dbo.vwAehAerende.recEnstakaKontaktID
	,dbo.vwAehAerende.strVisasSom
	,dbo.vwAehAerende.strGatuadress
	,dbo.vwAehAerende.strPostnummer
	,dbo.vwAehAerende.strPostort
	,dbo.vwAehAerende.strRoll
	,dbo.vwAehAerende.recKontaktRollID
	,dbo.vwAehAerende.recAerendeEnstakaKontaktID
	,dbo.vwAehAerende.recEnstakaFakturamottagareID
	,dbo.vwAehAerende.recKommunID
	,dbo.vwAehAerende.strProjektNamn
	,dbo.vwAehAerende.datBeslutsDatum
	,dbo.vwAehAerende.strBeslutsNummer
	,dbo.vwAehAerende.strBeslutsutfall
	,dbo.vwAehAerende.recHaendelseID
	,dbo.vwAehAerende.recHaendelseBeslutID
	,dbo.vwAehAerende.strAerendeTyp
	,dbo.vwAehAerende.strAerendekategori
	,dbo.vwAehAerende.strAerendetypKod
	,dbo.vwAehAerende.recAerendetypID
	,dbo.vwAehAerende.bolKomplettAerende
	,dbo.vwAehAerende.strEnhetNamn
	,dbo.vwAehAerende.strEnhetKod
	,dbo.vwAehAerende.strFoervaltningNamn
	,dbo.vwAehAerende.strFoervaltningKod
	,dbo.vwAehAerende.strAvdelningKod
	,dbo.vwAehAerende.strAvdelningNamn
	,vwAehAerende.strFakturamottagare
	,dbo.vwAehAerende.strKommunNamn
	,dbo.vwAehAerende.datKomplett
	,dbo.vwAehAerende.datMoetesDatum
	,dbo.vwAehAerende.intArbetsdagar
	,vwAehAerende.strSummaTidposter
	,HuvudkontaktKommunikationssaett.strHuvudkontaktensTelefon
	,HuvudkontaktKommunikationssaett.strHuvudkontaktensMobil
	,HuvudkontaktKommunikationssaett.strHuvudkontaktensFax
	,HuvudkontaktKommunikationssaett.strHuvudkontaktensEpost
	,HuvudkontaktKommunikationssaett.strHuvudkontaktensOrganisationsPersonnummer
	,dbo.vwAehAerende.recExternTjaenstID
	,dbo.vwAehAerende.strExternTjaenst
	,dbo.vwAehAerende.strETjaenstNamn
	,dbo.vwAehAerende.datBeslutExpedierat
	,dbo.vwAehAerende.datArkiverat
	,dbo.vwAehAerende.datGallrat
FROM dbo.vwAehAerende
LEFT OUTER JOIN HuvudkontaktKommunikationssaett ON HuvudkontaktKommunikationssaett.recAerendeID = vwAehAerende.recAerendeID
go

