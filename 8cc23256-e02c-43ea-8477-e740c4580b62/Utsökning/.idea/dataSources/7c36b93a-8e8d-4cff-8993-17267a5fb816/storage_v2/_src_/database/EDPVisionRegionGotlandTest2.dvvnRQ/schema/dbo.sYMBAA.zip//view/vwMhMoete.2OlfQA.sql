


CREATE VIEW [dbo].[vwMhMoete]
AS
SELECT  dbo.tbMhOrgan.strOrgannamn + ' ' + ISNULL(dbo.tbMhMoete.strMoetesRubrik + ' ', '')
    + SUBSTRING(CONVERT(varchar(10), dbo.tbMhMoete.datMoetesDatum, 20), 0, 11) + ISNULL(' '
    + dbo.tbMhMoete.strStarttid, '') AS strMoete,
    dbo.tbMhOrgan.strOrgannamn,
    dbo.tbMhMoete.recMoeteID,
    dbo.tbMhMoete.recOrganID,
    dbo.tbMhMoete.datMoetesDatum,
    dbo.tbMhMoete.datSenasteDatum,
    dbo.tbMhMoete.strVeckodag,
    dbo.tbMhMoete.strStarttid,
    dbo.tbMhMoete.strSluttid,
    dbo.tbMhMoete.strSenasteTid,
    dbo.tbMhMoete.strPlats,
    dbo.tbMhMoete.strAnteckning,
    dbo.tbMhMoete.datJusteringsDatum,
    dbo.tbMhMoete.strMoetesRubrik,
    dbo.tbMhMoete.recMoeteID AS intRecnum,
    dbo.tbMhMoete.strRum,
    dbo.tbMhMoete.strPostort,
    dbo.tbMhMoete.strAdress,
    dbo.tbMhMoete.strPostnr,
    dbo.tbMhMoete.bolStandardMoetesPunkterInkopplade,
    dbo.tbMhMoete.bolUtskickadDagordning,
    dbo.tbMhMoete.strJusteringsTid,
    dbo.tbMhMoete.bolKlarAttPubliceraMoete,
    dbo.tbMhMoete.bolKlarAttPubliceraProtokoll,

    (SELECT COUNT(recMoeteID) FROM tbMhMoete As innerTB
      WHERE tbMhMoete.recOrganID = innerTB.recOrganID
      AND innerTB.datMoetesDatum BETWEEN (DATEADD(yy, DATEDIFF(yy,0,tbMhMoete.datMoetesDatum), 0))
      AND tbMhMoete.datMoetesDatum) As intAntalOrganMoetenPaerAar,

    (SELECT TOP 1 vwMhPerson.strNamn FROM tbMhMoetePerson
       LEFT OUTER JOIN tbMHMoetesRoll
         ON tbMhMoetePerson.strMoetesRoll = tbMHMoetesRoll.strMoetesRoll
       LEFT OUTER JOIN vwMhPerson
         ON tbMhMoetePerson.recPersonID = vwMhPerson.recPersonID
       WHERE recMoeteID = tbMhMoete.recMoeteID
       AND tbMHMoetesRoll.guid = '5c19aec5-084f-40ec-a988-7f7362f3f9db') AS strOrdfoerande,

    (SELECT TOP 1 strFullName FROM vwMhOrgan
         WHERE vwMhOrgan.recOrganID = tbMhMoete.recOrganID)
         AS strSekreterare,

    (SELECT TOP 1 vwMhPerson.strNamn FROM tbMhMoetePerson
       LEFT OUTER JOIN tbMHMoetesRoll
         ON tbMhMoetePerson.strMoetesRoll = tbMHMoetesRoll.strMoetesRoll
       LEFT OUTER JOIN vwMhPerson
         ON tbMhMoetePerson.recPersonID = vwMhPerson.recPersonID
       WHERE tbMhMoetePerson.recMoeteID = tbMhMoete.recMoeteID
       AND tbMHMoetesRoll.guid = '4d7f8a94-9b8a-4d1e-ba78-d1e0df201047') AS strJusteringsman,
      dbo.tbMhMoete.intWebID,
      dbo.tbMhMoete.datWebbDatum
FROM  dbo.tbMhMoete
LEFT OUTER JOIN dbo.tbMhOrgan
ON dbo.tbMhMoete.recOrganID = dbo.tbMhOrgan.recOrganID
go

