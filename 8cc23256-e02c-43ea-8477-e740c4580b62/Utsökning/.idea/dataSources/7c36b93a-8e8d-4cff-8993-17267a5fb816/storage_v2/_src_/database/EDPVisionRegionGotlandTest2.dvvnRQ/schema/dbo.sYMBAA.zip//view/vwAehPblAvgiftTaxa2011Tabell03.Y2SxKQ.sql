
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell03]
AS
SELECT     
	dbo.tbAehPblAvgiftTaxa2011Tabell03.recPblAvgiftTaxa2011Tabell03ID,
	dbo.tbAehPblAvgiftTaxa2011Tabell03.recPblAvgiftTaxa2011Tabell03ID AS intRecnum, 
	dbo.tbAehPblAvgiftTaxa2011Tabell03.recAvgiftID, 
	dbo.tbAehPblAvgiftTaxa2011Tabell03.bolDebiterad, 
	dbo.tbAehPblAvgiftTaxa2011Tabell03.decAvgift, 
	dbo.tbAehPblAvgiftTaxa2011Tabell03.intKOM, 
	dbo.tbAehPblAvgiftTaxa2011Tabell03.decmPBB, 
	dbo.tbAehPblAvgiftTaxa2011Tabell03.decN, 
	dbo.tbAehPblAvgiftTaxa2011Tabell03.decAnnonskostnad, 
	dbo.tbAehPblAvgiftTaxa2011Tabell03.decAvgiftTotalt
FROM dbo.tbAehPblAvgiftTaxa2011Tabell03

go

