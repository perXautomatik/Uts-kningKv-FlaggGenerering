
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell20]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell20.recPblAvgiftTaxa2011Tabell20ID,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.recPblAvgiftTaxa2011Tabell20ID AS intRecnum,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.recAvgiftID,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.bolHaemtaHF1,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.bolHaemtaHF2,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.bolDebiterad,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.bolTidsersaettning,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.bolHandlaeggningsfaktor,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.decAvgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.decOF,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.decHF1,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.decHF2,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.decmPBB,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.decN,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.decOFJustering,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.decHF1Justering,
  dbo.tbAehPblAvgiftTaxa2011Tabell20.decHF2Justering
FROM  dbo.tbAehPblAvgiftTaxa2011Tabell20

go

