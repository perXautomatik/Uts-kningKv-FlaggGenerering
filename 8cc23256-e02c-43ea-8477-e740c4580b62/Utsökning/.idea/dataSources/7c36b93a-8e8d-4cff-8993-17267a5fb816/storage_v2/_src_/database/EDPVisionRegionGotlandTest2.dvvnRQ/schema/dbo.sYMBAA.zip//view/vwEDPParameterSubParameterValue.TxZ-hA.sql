CREATE VIEW [dbo].[vwEDPParameterSubParameterValue]
AS
SELECT     TOP (100) PERCENT dbo.tbEDPParameterSubParameterValue.intSubParameterID, dbo.tbEDPParameterSubParameterValue.strSubParameterValue, 
                      dbo.tbEDPParameterSubParameterValue.strValue, dbo.tbEDPParameterSubParameterValue.intGroupID, dbo.tbEDPValueType.strValueTypeName, 
                      dbo.tbEDPParameterSubParameter.intSubParameterPriority, dbo.tbEDPParameter.strParameterName, dbo.tbEDPSubParameter.strSubParameterName, 
                      dbo.tbEDPSearchMethod.strSearchMethodName, dbo.tbEDPParameter.intParameterID, dbo.tbEDPParameter.strParameterValueLookUpID, 
                      dbo.tbEDPSubParameter.strSubParameterValueLookUpID
FROM         dbo.tbEDPParameterSubParameterValue INNER JOIN
                      dbo.tbEDPParameter ON dbo.tbEDPParameterSubParameterValue.intParameterID = dbo.tbEDPParameter.intParameterID INNER JOIN
                      dbo.tbEDPValueType ON dbo.tbEDPParameter.intParameterValueTypeID = dbo.tbEDPValueType.intValueTypeID INNER JOIN
                      dbo.tbEDPParameterSubParameter ON dbo.tbEDPParameter.intParameterID = dbo.tbEDPParameterSubParameter.intParameterID INNER JOIN
                      dbo.tbEDPSubParameter ON dbo.tbEDPParameterSubParameterValue.intSubParameterID = dbo.tbEDPSubParameter.intSubParameterID AND 
                      dbo.tbEDPParameterSubParameter.intSubParameterID = dbo.tbEDPSubParameter.intSubParameterID INNER JOIN
                      dbo.tbEDPSearchMethod ON dbo.tbEDPSubParameter.intSubParameterSearchMethodID = dbo.tbEDPSearchMethod.intSearchMethodID
ORDER BY dbo.tbEDPParameterSubParameter.intSubParameterPriority, dbo.tbEDPParameterSubParameterValue.strSubParameterValue, 
                      dbo.tbEDPParameterSubParameterValue.intGroupID

go

