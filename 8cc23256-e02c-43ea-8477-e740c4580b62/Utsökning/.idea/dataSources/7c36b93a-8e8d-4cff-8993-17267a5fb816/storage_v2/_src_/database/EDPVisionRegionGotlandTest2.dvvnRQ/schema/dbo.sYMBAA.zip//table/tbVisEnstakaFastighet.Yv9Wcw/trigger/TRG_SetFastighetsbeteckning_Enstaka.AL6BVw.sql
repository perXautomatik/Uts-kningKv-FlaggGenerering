
        -- Trigger för beräkning av strFastighetsbeteckning
        CREATE TRIGGER TRG_SetFastighetsbeteckning_Enstaka ON tbVisEnstakaFastighet
        AFTER INSERT, UPDATE
        AS
        BEGIN

        IF @@ROWCOUNT = 0
        RETURN

            UPDATE tbVisEnstakaFastighet
            SET tbVisEnstakaFastighet.strFastighetsbeteckning = RTRIM(ISNULL(strTrakt, '') + ' ' + ISNULL(strBlock, '') + ISNULL(strTkn, '') + ISNULL(LTRIM(STR(intEnhet)), ''))
            WHERE  tbVisEnstakaFastighet.recFastighetID IN (SELECT INSERTED.recFastighetID FROM INSERTED)

        END
        go

