

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell19Master]
AS
SELECT        recPblAvgiftTaxa2011Tabell19MasterID
			, recPblAvgiftTaxa2011Tabell19ID
			, recPblAvgiftTaxa2011Tabell19ID as 'intRecnum'
			, strObjekt
			, strBeskrivning
			, intHF1
			, intHF2
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell19Master
go

