
            CREATE VIEW dbo.vwMmGatuadress
            AS
            SELECT     dbo.tbMmGatuadress.recGatuadressID, dbo.tbMmGatuadress.recOmrID, dbo.tbMmGatuadress.strAdress, dbo.tbMmGatuadress.bolHuvudadress, 
                                  dbo.tbMmGatuadress.recGatuadressID AS intRecnum, dbo.vwMmOmraade.strOmraadeKod, dbo.vwMmOmraade.strOmrNamn
            FROM         dbo.tbMmGatuadress LEFT OUTER JOIN
                                  dbo.vwMmOmraade ON dbo.tbMmGatuadress.recOmrID = dbo.vwMmOmraade.recOmrID
            go

