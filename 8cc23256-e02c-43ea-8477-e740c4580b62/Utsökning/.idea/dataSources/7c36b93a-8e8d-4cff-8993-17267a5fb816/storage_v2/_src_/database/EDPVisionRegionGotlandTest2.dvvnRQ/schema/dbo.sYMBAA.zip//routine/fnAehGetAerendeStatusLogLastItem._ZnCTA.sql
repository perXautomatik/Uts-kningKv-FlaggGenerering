
            CREATE FUNCTION [dbo].[fnAehGetAerendeStatusLogLastItem]
            (
	            -- Add the parameters for the function here
	            @recAerendeID as int
            )
            RETURNS int
            AS
            BEGIN
	            -- Declare the return variable here
	            DECLARE @AerendeStatusLogID as int

		            SELECT TOP (1) @AerendeStatusLogID = recAerendeStatusLogID 
		            FROM tbAehAerendeStatusLog 
		            INNER JOIN dbo.tbAehAerendeStatusLogTyp ON 
                    dbo.tbAehAerendeStatusLog.recAerendeStatusLogTypID = dbo.tbAehAerendeStatusLogTyp.recAerendeStatusLogTypID
		            WHERE recAerendeID = @recAerendeID AND strLocalizationCode <> 'huvbes'
		            ORDER BY datDatum DESC

	            -- Return the result of the function
	            RETURN @AerendeStatusLogID
            END
            go

