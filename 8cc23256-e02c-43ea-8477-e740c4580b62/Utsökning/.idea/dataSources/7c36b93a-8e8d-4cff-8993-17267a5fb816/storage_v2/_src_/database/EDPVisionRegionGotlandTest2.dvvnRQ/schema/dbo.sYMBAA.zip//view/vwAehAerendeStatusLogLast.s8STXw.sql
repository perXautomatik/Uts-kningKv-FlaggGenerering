
CREATE VIEW [dbo].[vwAehAerendeStatusLogLast]
AS
SELECT     recAerendeStatusLogID, recAerendeStatusLogTypID, recAerendeID, intUserID, datDatum, strAerendeStatusLogTyp, strLocalizationCode, strSignature,
                      intRecnum, strAerendeStatusPresent, strKommentar
FROM         dbo.vwAehAerendeStatusLog as ASL
WHERE    recAerendeStatusLogID = (
  	SELECT TOP (1) recAerendeStatusLogID
		FROM dbo.vwAehAerendeStatusLog
		WHERE recAerendeID = ASL.recAerendeID
		  AND strLocalizationCode <> 'huvbes'
		ORDER BY datDatum DESC)
go

