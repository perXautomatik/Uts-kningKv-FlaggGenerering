

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell21OevrigaAerenden]
AS
SELECT     recAehPblAvgiftTaxa2011Tabell21OevrigaAerendenID,recAehPblAvgiftTaxa2011Tabell21OevrigaAerendenID as intRecnum, strAerendeTyp, recAehPblAvgiftTaxa2011Tabell21ID, strBeskrivning, intHF
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell21OevrigaAerenden


go

