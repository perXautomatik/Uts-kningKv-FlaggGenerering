

CREATE VIEW [dbo].[vwEDPFileObjectMoetespunktHaendelseLookUp]
AS
WITH FileObjectHaendelse AS(
  SELECT tbMhMoetespunkt.recMoetespunktID, tbAehHaendelseFileObject.recFileobjectID, MIN(tbMhMoetespunktHaendelse.recHaendelseID) AS recHaendelseID FROM tbMhMoetespunkt
  INNER JOIN tbMhMoetespunktHaendelse
    ON tbMhMoetespunktHaendelse.recMoetespunktID = tbMhMoetespunkt.recMoetespunktID
  INNER JOIN tbAehHaendelseFileObject
    ON tbAehHaendelseFileObject.recHaendelseID = tbMhMoetespunktHaendelse.recHaendelseID
  WHERE tbAehHaendelseFileObject.recFileObjectID NOT IN 
    (SELECT recFileObjectID FROM tbMhMoetespunktFileObject WHERE tbMhMoetespunktFileObject.recMoetespunktID = tbMhMoetespunkt.recMoetespunktID)
  GROUP BY tbMhMoetespunkt.recMoetespunktID, tbAehHaendelseFileObject.recFileobjectID
)
SELECT tbEDPFileObject.recFileObjectID, 
  tbEDPFileObject.recFileObjectID AS intRecnum, 
  tbEDPFileObject.strFileName,
  tbEDPFileObject.strDescription,
  vwAehHaendelse.strDiarienummer + ISNULL(':' + CONVERT(NVARCHAR, vwAehHaendelse.intLoepnummer), '') AS strHaendelse, 
  vwAehHaendelse.datHaendelseDatum, 
  vwAehHaendelse.strRubrik,
  FileObjectHaendelse.recMoetespunktID,
  FileObjectHaendelse.recHaendelseID
FROM FileObjectHaendelse
INNER JOIN tbEDPFileObject
  ON tbEDPFileObject.recFileobjectID = FileObjectHaendelse.recFileobjectID
INNER JOIN vwAehHaendelse
  ON vwAehHaendelse.recHaendelseID = FileObjectHaendelse.recHaendelseID

go

