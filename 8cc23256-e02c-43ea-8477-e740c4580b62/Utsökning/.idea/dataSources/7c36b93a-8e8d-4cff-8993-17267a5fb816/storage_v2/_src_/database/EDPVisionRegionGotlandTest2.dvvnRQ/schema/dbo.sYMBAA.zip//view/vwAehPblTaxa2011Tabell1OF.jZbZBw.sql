
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell1OF]
AS
SELECT     recT1OfID, 
           recT1OfID as 'intRecnum', 
		   intFraanYta, 
		   intTillYta,
		   intOF, 
		   recTaxa2011ID,
		   tbAehPblTaxa2011Tabell1OF.recTabell1ID
FROM         dbo.tbAehPblTaxa2011Tabell1OF
LEFT OUTER JOIN vwAehPblTaxa2011Tabell1
ON vwAehPblTaxa2011Tabell1.recTabell1ID = tbAehPblTaxa2011Tabell1OF.recTabell1ID



go

