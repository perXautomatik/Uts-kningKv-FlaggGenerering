CREATE VIEW vwTrSkapaUppgiftAlternativ
AS
SELECT 'Automatiskt' as alternativ, 1 as intRecnum
UNION
SELECT 'Fråga' as alternativ, 2 as intRecnum
UNION 
SELECT 'Nej' as alternativ, 3 as intRecnum


go

