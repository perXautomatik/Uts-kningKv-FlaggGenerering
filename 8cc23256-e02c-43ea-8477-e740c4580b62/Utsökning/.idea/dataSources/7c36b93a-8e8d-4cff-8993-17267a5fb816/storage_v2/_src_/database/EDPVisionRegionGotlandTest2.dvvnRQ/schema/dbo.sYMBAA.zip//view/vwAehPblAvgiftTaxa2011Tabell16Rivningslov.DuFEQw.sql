

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell16Rivningslov]
AS
SELECT     
recAehPblAvgiftTaxa2011Tabell16RivningslovID, 
recAehPblAvgiftTaxa2011Tabell16ID, 
recAehPblAvgiftTaxa2011Tabell16RivningslovID as 'intRecnum', 
strYta,
strBeskrivning,
intHF
	
FROM dbo.tbAehPblAvgiftTaxa2011Tabell16Rivningslov



go

