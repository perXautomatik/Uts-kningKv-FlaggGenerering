

CREATE VIEW [dbo].[vwEDPFileObject]
AS
SELECT DISTINCT 
  dbo.tbEDPFileObject.recFileObjectID, 
  dbo.tbEDPFileObject.strDescription, 
  dbo.tbEDPFileObject.strFileName,
  dbo.tbEDPFileObject.strHandlingstyp,
  dbo.tbEDPFileObjectLocked.recFileObjectLockedID, 
  dbo.tbEDPFileObjectLocked.strCheckedOutFileName, 
  dbo.tbEDPFileObjectLocked.datCheckOutDateTime, 
  dbo.tbEDPFileObjectLocked.intUserID, 
  dbo.tbEDPUser.strSignature,	
  dbo.tbEDPFileVersion.strFiletype,			
  CASE 
    WHEN datCheckOutDateTime IS NOT NULL 
      THEN CAST(1 AS BIT) 
    WHEN datCheckOutDateTime IS NULL 
      THEN CAST(0 AS BIT) ELSE NULL
    END AS bolCheckedOut, 
  dbo.tbEDPFileObject.recFileObjectID AS intRecnum,
  dbo.tbEDPFileVersion.intFileVersion AS intMaxFileVersion,
  dbo.tbEDPFileVersion.datFileVersionDate AS datLastFileVersionDate,
  dbo.tbEDPFileObject.bolWriteProtected,
  dbo.tbEDPFileObject.bolKanInnehaallaPersonuppgifter,
  CASE 
    WHEN tbEDPMailTemplate.recFileObjectID IS NOT NULL 
      THEN CAST(1 AS BIT) 
    WHEN tbEDPMailTemplate.recFileObjectID IS NULL
      THEN 
        CASE 
          WHEN tbEDPDocumentTemplate.recFileObjectID IS NOT NULL 
            THEN CAST(1 AS BIT) 
          ELSE CAST(0 AS BIT)
        END
    END AS isTemplate,
  CASE 
    WHEN datCheckOutDateTime IS NOT NULL 
      THEN 'Utcheckad'
    WHEN datCheckOutDateTime IS NULL 
      THEN ''
    END AS strStatus,
	dbo.tbEDPFileVersion.lngFileSize
	
FROM
  dbo.tbEDPFileObject 
  INNER JOIN dbo.tbEDPFileVersion 
    ON dbo.tbEDPFileObject.recFileObjectID = dbo.tbEDPFileVersion .recFileObjectID
    AND dbo.tbEDPFileVersion.recFileVersionID = 
      (SELECT TOP 1 recFileVersionID FROM tbEDPFileVersion
        WHERE tbEDPFileVersion.recFileObjectID = tbEDPFileObject.recFileObjectID
        ORDER BY recFileVersionID DESC)
  LEFT OUTER JOIN dbo.tbEDPFileObjectLocked 
    ON dbo.tbEDPFileObjectLocked.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID
  LEFT OUTER JOIN	dbo.tbEDPUser
    ON dbo.tbEDPUser.intUserID = dbo.tbEDPFileObjectLocked.intUserID
  LEFT JOIN tbEDPDocumentTemplate 
    ON tbEDPDocumentTemplate.recFileObjectID = tbEDPFileObject.recFileObjectID
  LEFT JOIN tbEDPMailTemplate 
    ON tbEDPMailTemplate.recFileObjectID = tbEDPFileObject.recFileObjectID
WHERE NOT EXISTS (SELECT tbEDPDocumentTemplate.recFileObjectID FROM tbEDPDocumentTemplate WHERE tbEDPDocumentTemplate.recFileObjectID = tbEDPFileObject.recFileObjectID)
	AND NOT EXISTS (SELECT tbEDPMailTemplate.recFileObjectID FROM tbEDPMailTemplate WHERE tbEDPMailTemplate.recFileObjectID = tbEDPFileObject.recFileObjectID)



go

