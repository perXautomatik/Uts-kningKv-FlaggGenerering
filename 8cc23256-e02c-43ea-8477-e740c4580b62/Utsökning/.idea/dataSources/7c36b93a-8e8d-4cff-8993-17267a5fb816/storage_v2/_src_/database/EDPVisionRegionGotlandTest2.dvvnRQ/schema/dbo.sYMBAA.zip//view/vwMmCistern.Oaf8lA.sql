CREATE VIEW dbo.vwMmCistern
AS
SELECT     dbo.tbMmCistern.recCisternID, dbo.tbMmCistern.recOmrID, dbo.tbMmCistern.bolUnderMark, dbo.tbMmCistern.strMaterial, dbo.tbMmCistern.decVolym,
                      dbo.tbMmCistern.strInnehaall, dbo.tbMmCistern.strBeskrivning, dbo.tbMmCistern.recCisternID AS intRecnum, dbo.vwMmOmraade.strOmraadeKod,
                      dbo.vwMmOmraade.strOmrNamn, dbo.tbMmCistern.strCisterntyp
FROM         dbo.tbMmCistern LEFT OUTER JOIN
                      dbo.vwMmOmraade ON dbo.tbMmCistern.recOmrID = dbo.vwMmOmraade.recOmrID
go

