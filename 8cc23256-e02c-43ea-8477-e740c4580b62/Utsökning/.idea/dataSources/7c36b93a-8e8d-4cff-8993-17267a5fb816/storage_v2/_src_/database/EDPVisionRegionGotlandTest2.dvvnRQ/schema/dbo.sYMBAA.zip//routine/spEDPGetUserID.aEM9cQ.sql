create PROCEDURE [dbo].[spEDPGetUserID]
	@strUserName varchar(50),
	@strPassword varchar(50)
AS
SELECT     intUserID
FROM         tbEDPUser
WHERE     (strPassword = @strPassword) AND (strUserWindowsAccount = @strUserName)
RETURN
go

