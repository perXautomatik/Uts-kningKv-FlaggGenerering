


CREATE VIEW [dbo].[vwAehAerendeLookup]
AS
SELECT
	tbAehAerende.recAerendeID AS intRecnum,
	tbAehAerende.recAerendeID,
	tbAehAerende.strAerendemening,
	tbAehAerendeData.strDiarienummer,
	tbAehAerendeData.strLocalizationCode,
	tbAehAerendetyp.strAerendeTyp
FROM tbAehAerende
LEFT JOIN tbAehAerendeData ON tbAehAerende.recAerendeID = tbAehAerendeData.recAerendeID
LEFT JOIN tbAehAerendetyp ON tbAehAerende.recAerendetypID = tbAehAerendetyp.recAerendetypID

go

