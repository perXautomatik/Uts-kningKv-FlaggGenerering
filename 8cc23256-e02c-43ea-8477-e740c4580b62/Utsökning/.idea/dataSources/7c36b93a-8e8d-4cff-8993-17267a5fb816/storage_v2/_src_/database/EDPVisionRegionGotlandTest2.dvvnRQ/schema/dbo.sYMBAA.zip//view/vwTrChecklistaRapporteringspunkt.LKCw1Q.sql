

CREATE VIEW [dbo].[vwTrChecklistaRapporteringspunkt]
AS

SELECT	recChecklistaRapporteringspunktID
		,recChecklistaRapporteringspunktID AS intRecNum
		,strPunktnummer
		,strOmraade
		,strPunkt
		,intAar
		,"sortcolumn" =
			CASE 
				WHEN strpunktnummer <'99999' THEN RIGHT('000' + SUBSTRING(strPunktnummer,1,CHARINDEX('.', strPunktnummer)-1), 3) + '.' + RIGHT('000' + SUBSTRING(strPunktnummer,CHARINDEX('.', strPunktnummer)+1, len(strPunktnummer)), 3) 
			ELSE
				strpunktnummer
			END 
		
FROM	tbTrChecklistaRapporteringspunkt


go

