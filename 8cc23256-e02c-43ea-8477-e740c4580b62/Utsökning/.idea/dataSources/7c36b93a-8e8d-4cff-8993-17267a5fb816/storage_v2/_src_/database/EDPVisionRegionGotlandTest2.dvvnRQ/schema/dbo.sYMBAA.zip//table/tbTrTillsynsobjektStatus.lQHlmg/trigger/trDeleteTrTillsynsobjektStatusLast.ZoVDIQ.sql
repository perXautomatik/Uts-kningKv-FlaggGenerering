
        CREATE TRIGGER trDeleteTrTillsynsobjektStatusLast ON
        tbTrTillsynsobjektStatus
        AFTER DELETE
        AS
        BEGIN

        DECLARE delete_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recTillsynsobjektID FROM DELETED
        OPEN delete_cursor
        DECLARE @recTillsynsobjektID as INT
        FETCH NEXT FROM delete_cursor INTO @recTillsynsobjektID
        WHILE (@@fetch_status = 0)
        BEGIN
            UPDATE tbTrTillsynsobjekt SET recLastLogPostID =
            (
                SELECT TOP (1) recTillsynsobjektStatusID
                FROM tbTrTillsynsobjektStatus
                WHERE recTillsynsobjektID = @recTillsynsobjektID
                ORDER BY datDatum DESC
            )
            WHERE recTillsynsobjektID = @recTillsynsobjektID

            FETCH NEXT FROM delete_cursor INTO @recTillsynsobjektID
        END
        CLOSE delete_cursor
        DEALLOCATE delete_cursor
        END
        go

