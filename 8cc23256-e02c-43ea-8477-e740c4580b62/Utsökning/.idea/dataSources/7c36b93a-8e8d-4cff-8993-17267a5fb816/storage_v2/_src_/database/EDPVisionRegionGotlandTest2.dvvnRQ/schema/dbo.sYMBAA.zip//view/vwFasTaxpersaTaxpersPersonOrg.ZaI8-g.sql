
CREATE VIEW [dbo].[vwFasTaxpersaTaxpersPersonOrg]
AS
SELECT  vwFasTaxpersaTaxpers.strARID, vwFasTaxpersaTaxpers.strID_TAXENHETID, 
  vwFasTaxpersaTaxpers.strAGTYP, vwFasTaxpersaTaxpers.strPersonnr, 
  vwFasPersonOrg.strORGKORTNAMN, vwFasPersonOrg.strCO, vwFasPersonOrg.strAdress, 
  vwFasPersonOrg.strAdress1, vwFasPersonOrg.strPOSTNR, vwFasPersonOrg.strPOSTORT, 
  vwFasTaxpersaTaxpers.recTAXPERS AS intRecNum, vwFasTaxpersaTaxpers.strFNRID, 
  vwFasTaxpersaTaxpers.intNAMNAND, vwFasTaxpersaTaxpers.intTALJAND, 
  tbFasFASTIGH.strLANKOD, tbFasFASTIGH.strKOMKOD, tbFasFASTIGH.strKOMMUN
FROM dbo.vwFasTaxpersaTaxpers 
LEFT OUTER JOIN dbo.tbFasFASTIGH
  ON vwFasTaxpersaTaxpers.strFNRID = tbFasFASTIGH.strFNRID 
LEFT OUTER JOIN dbo.vwFasPersonOrg 
  ON vwFasPersonOrg.strPersonnr  = vwFasTaxpersaTaxpers.strPersonnr

go

