CREATE VIEW dbo.vwMmFoeroreningAemne
AS
SELECT     dbo.tbMmFoeroreningAemne.recFoeroreningAemneID, dbo.tbMmFoeroreningAemne.recFoeroreningID, dbo.tbMmFoeroreningAemne.strFarlighet,
                      dbo.tbMmFoeroreningAemne.strFoeroreningsnivaa, dbo.tbMmFoeroreningAemne.strSpridningsrisk, dbo.tbMmFoerorening.strFoeroreningNamn,
                      dbo.tbMmAemne.strAemneNamn, dbo.tbMmAemne.strAemneKemBeteckning, dbo.tbMmFoeroreningAemne.recFoeroreningAemneID AS intRecnum,
                      dbo.tbMmFoeroreningAemne.strBeskrivning, dbo.vwMmOmraade.strOmraadeKod, dbo.vwMmOmraade.strOmrNamn,
                      dbo.tbMmFoerorening.recMediumID, dbo.tbMmFoerorening.recOmrID, dbo.tbMmMedium.strMediumNamn,
                      dbo.tbMmFoeroreningAemne.guidAemneID
FROM         dbo.vwMmOmraade RIGHT OUTER JOIN
                      dbo.tbMmFoerorening ON dbo.vwMmOmraade.recOmrID = dbo.tbMmFoerorening.recOmrID LEFT OUTER JOIN
                      dbo.tbMmMedium ON dbo.tbMmFoerorening.recMediumID = dbo.tbMmMedium.recMediumID RIGHT OUTER JOIN
                      dbo.tbMmFoeroreningAemne LEFT OUTER JOIN
                      dbo.tbMmAemne ON dbo.tbMmFoeroreningAemne.guidAemneID = dbo.tbMmAemne.guidAemneID ON
                      dbo.tbMmFoerorening.recFoeroreningID = dbo.tbMmFoeroreningAemne.recFoeroreningID
go

