
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell15]
AS
SELECT     

recTabell15ID, 
recTaxa2011ID, 
recTabell15ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell15.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell15.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell15

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell15.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell15.recTjaenstID


go

