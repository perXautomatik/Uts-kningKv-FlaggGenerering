
CREATE VIEW [dbo].[vwTrFtLaekemedel]
AS
SELECT       recLaekemedelID
			,recLaekemedelID as intRecnum
			,recTillsynsobjektID
			,datAnmaelningsdatum
			,datFoersaeljningsstart
			,datFoersaeljningUpphoert
			,strFoersaeljning
			,bolServeringstillstaand
			,bolLaekemedelsobjekt
			,

			CASE
				WHEN (SELECT TOP(1) strHuvudflik FROM tbTrTillsynsobjektHuvudflik
						WHERE recTillsynsobjektID  = dbo.tbTrFtLaekemedel.recTillsynsobjektID
						ORDER BY recTillsynsobjektHuvudflikID ASC) = 'TRLaekemedel' THEN
					CAST(1 as bit)
				ELSE
					CAST(0 as bit)
			END AS bolHuvudflik
FROM dbo.tbTrFtLaekemedel
go

