CREATE VIEW [dbo].[vwHistoryLog]
AS
SELECT     *
FROM         dbo.tbHistoryLog
go

