
        CREATE TRIGGER TRG_tbAehAerendeEnstakaFastighet_INSERT_UPDATE_DELETE ON tbAehAerendeEnstakaFastighet
        AFTER INSERT, UPDATE, DELETE
        AS
        BEGIN
        SET NOCOUNT ON;

        DECLARE aerende_fastighet_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recAerendeID FROM INSERTED UNION SELECT recAerendeID FROM DELETED
        OPEN aerende_fastighet_cursor
        DECLARE @recAerendeID INT
        FETCH NEXT FROM aerende_fastighet_cursor INTO @recAerendeID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehAerendeDataUpdateFastighet @recAerendeID

            FETCH NEXT FROM aerende_fastighet_cursor INTO @recAerendeID
        END
        CLOSE aerende_fastighet_cursor
        DEALLOCATE aerende_fastighet_cursor
        END
        go

