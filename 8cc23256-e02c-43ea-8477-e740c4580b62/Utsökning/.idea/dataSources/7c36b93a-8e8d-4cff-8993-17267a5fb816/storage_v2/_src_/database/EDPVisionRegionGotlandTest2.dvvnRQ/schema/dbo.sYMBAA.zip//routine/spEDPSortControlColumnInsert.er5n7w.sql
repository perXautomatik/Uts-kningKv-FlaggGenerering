

CREATE PROCEDURE dbo.spEDPSortControlColumnInsert
	(
		@strFormName varchar(100),
		@strControlColumnName varchar(100),
		@strControlTableName varchar(100),
		@intControlColumnID int output
	)
AS

	SET NOCOUNT ON
	IF (SELECT COUNT(intControlColumnID) AS TOT FROM tbEDPSortControlColumn WHERE strFormName = @strFormName AND strControlColumnName = @strControlColumnName)>0
		BEGIN
			SELECT @intControlColumnID = (SELECT intControlColumnID FROM tbEDPSortControlColumn WHERE strFormName = @strFormName AND strControlColumnName = @strControlColumnName)
		END
	ELSE
	BEGIN	
		INSERT INTO tbEDPSortControlColumn
													(strFormName, strControlColumnName, strControlTableName)
		VALUES     (@strFormName, @strControlColumnName, @strControlTableName)
		
		select @intcontrolColumnid = (scope_identity())
	END	

	RETURN



go

