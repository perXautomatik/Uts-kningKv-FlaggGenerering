
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell24]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell24.recPblAvgiftTaxa2011Tabell24ID, 
	dbo.tbAehPblAvgiftTaxa2011Tabell24.recPblAvgiftTaxa2011Tabell24ID AS intRecnum,
  dbo.tbAehPblAvgiftTaxa2011Tabell24.recAvgiftID,
  dbo.tbAehPblAvgiftTaxa2011Tabell24.bolDebiterad, 
  dbo.tbAehPblAvgiftTaxa2011Tabell24.decAvgift, 
  dbo.tbAehPblAvgiftTaxa2011Tabell24.intUF, 
  dbo.tbAehPblAvgiftTaxa2011Tabell24.decmPBB, 
  dbo.tbAehPblAvgiftTaxa2011Tabell24.decN,
  dbo.tbAehPblAvgiftTaxa2011Tabell24.strUtstakningavgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell24.intUtstakningsprocent,
  dbo.tbAehPblAvgiftTaxa2011Tabell24.decAvgiftTotalt
FROM dbo.tbAehPblAvgiftTaxa2011Tabell24

go

