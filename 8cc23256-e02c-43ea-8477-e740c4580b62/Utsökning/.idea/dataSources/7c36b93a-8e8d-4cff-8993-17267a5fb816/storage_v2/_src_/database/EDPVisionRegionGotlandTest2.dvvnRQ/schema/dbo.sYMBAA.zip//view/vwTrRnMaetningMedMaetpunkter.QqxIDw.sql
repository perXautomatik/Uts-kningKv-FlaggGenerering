
CREATE VIEW [dbo].[vwTrRnMaetningMedMaetpunkter]
AS
SELECT dbo.tbTrRnMaetning.recMaetningID
  , dbo.tbTrRnMaetning.recByggnadsID
  , dbo.tbTrRnMaetning.recTillsynsobjektID
  , dbo.tbTrRnMaetning.datStartDatum
  , dbo.tbTrRnMaetning.strLaegenhetsNr
  , dbo.tbTrRnMaetning.strMaetAdress
  , dbo.tbTrRnMaetning.intAarsMedelvaerde
  , Maetpunkter.intResultat1, Maetpunkter.strVaaningsplan1
  , Maetpunkter.intResultat2, Maetpunkter.strVaaningsplan2
  , Maetpunkter.intResultat3, Maetpunkter.strVaaningsplan3
  , Maetpunkter.intResultat4, Maetpunkter.strVaaningsplan4
				
FROM dbo.tbTrRnMaetning 
LEFT OUTER JOIN
( SELECT recMaetningID 
  , (SELECT intResultat FROM tbTrRnMaetpunkt WHERE recMaetpunktID = [1]) AS intResultat1
  , (SELECT strVaaningsplan FROM tbTrRnMaetpunkt WHERE recMaetpunktID = [1]) AS strVaaningsplan1
  , (SELECT intResultat FROM tbTrRnMaetpunkt WHERE recMaetpunktID = [2]) AS intResultat2
  , (SELECT strVaaningsplan FROM tbTrRnMaetpunkt WHERE recMaetpunktID = [2]) AS strVaaningsplan2
  , (SELECT intResultat FROM tbTrRnMaetpunkt WHERE recMaetpunktID = [3]) AS intResultat3
  , (SELECT strVaaningsplan FROM tbTrRnMaetpunkt WHERE recMaetpunktID = [3]) AS strVaaningsplan3
  , (SELECT intResultat FROM tbTrRnMaetpunkt WHERE recMaetpunktID = [4]) AS intResultat4
  , (SELECT strVaaningsplan FROM tbTrRnMaetpunkt WHERE recMaetpunktID = [4]) AS strVaaningsplan4
  FROM
  ( SELECT recMaetningID, recMaetpunktID, ROW_NUMBER() OVER (PARTITION BY recMaetningID ORDER BY recMaetpunktID ASC) AS Nr
    FROM tbTrRnMaetpunkt) AS Maetpunkt
  PIVOT
  ( AVG(recMaetpunktID)
    FOR Nr IN ([1], [2], [3], [4])) AS MaetpunktPivot
  ) AS Maetpunkter
ON Maetpunkter.recMaetningID = dbo.tbTrRnMaetning.recMaetningID
go

