
CREATE PROCEDURE dbo.spGettbEDPRegisterTabell
/* $Date: 2005-10-20 12:22:20+02:00 $ */
@strTableName varchar(128),
@strColumnNameList varchar(1000)
AS

EXEC ('SELECT ' + @strColumnNameList + ' FROM ' + @strTableName)

go

