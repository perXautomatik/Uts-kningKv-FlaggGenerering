


CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell3]
AS
SELECT     

recTabell3ID, 
recTaxa2011ID, 
recTabell3ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell3.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell3.recFakturatextID,
decAnnonskostnad,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell3

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell3.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell3.recTjaenstID



go

