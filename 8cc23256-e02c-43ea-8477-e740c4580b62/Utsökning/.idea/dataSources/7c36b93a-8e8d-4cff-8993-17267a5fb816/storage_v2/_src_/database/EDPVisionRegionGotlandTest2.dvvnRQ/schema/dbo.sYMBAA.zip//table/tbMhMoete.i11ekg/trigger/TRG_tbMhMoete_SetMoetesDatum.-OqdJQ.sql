
        CREATE TRIGGER TRG_tbMhMoete_SetMoetesDatum ON tbMhMoete
        AFTER  UPDATE, DELETE

        AS
BEGIN
DECLARE moete_cursor CURSOR FAST_FORWARD
FOR
    SELECT recMoeteID FROM DELETED
OPEN moete_cursor
    DECLARE @moetesID as INT
    FETCH NEXT FROM moete_cursor INTO @moetesID
    WHILE (@@fetch_status = 0)
    BEGIN
        DECLARE	aerendeid_cursor CURSOR FAST_FORWARD
        FOR
                SELECT recAerendeID FROM dbo.fnGetAerendeIdFromMoete(@moetesID)
        OPEN aerendeid_cursor
        DECLARE @aerendeId as INT
        FETCH NEXT FROM aerendeid_cursor INTO @aerendeId
        WHILE (@@fetch_status = 0)
        BEGIN
            UPDATE tbAehAerende SET datMoetesDatum = dbo.FnAehAerendeMoetesDatum(@aerendeId)
                WHERE recAerendeID = @aerendeId
            FETCH NEXT FROM aerendeid_cursor INTO @aerendeId
        END
        CLOSE aerendeid_cursor
        DEALLOCATE aerendeid_cursor

        FETCH NEXT FROM moete_cursor INTO @moetesID
    END
CLOSE moete_cursor
DEALLOCATE moete_cursor
END
        go

