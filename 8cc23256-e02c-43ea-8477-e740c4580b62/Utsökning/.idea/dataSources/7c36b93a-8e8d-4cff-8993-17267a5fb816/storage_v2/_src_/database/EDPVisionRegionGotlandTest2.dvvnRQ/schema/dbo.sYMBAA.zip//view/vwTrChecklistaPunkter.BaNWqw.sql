


CREATE VIEW [dbo].[vwTrChecklistaPunkter]
AS
SELECT    recChecklistaPunktID, recChecklistaPunktID As 'intRecnum',
          tbTrChecklistaPunkt.recChecklistamallVersionVaerdenID,
          tbTrChecklistamallVersionPunkt.recChecklistamallVersionVaerdeListaID As 'intValbaraVardenID',
		  bolEjKontrollerad,
		  strAvvikelse, 
          tbOmraade.intNummer as 'intOmraadesnummer',
          strIakttagelse,
          strVaerde,
          intOrdning, 
          bolPositivt, 
          intVikt, 
          recTillsynsbesoekID,
		  tbTrChecklistamallVersionPunkt.strNamn As 'strPunktNamn', 
          tbTrChecklistamallVersionPunkt.intNummer As 'intPunktNummer', 		  
          strRapporteringsPunkt,
          tbOmraade.recChecklistamallVersionOmraadeID,
          tbTrChecklistaPunkt.recChecklistamallVersionPunktID,
		  tbOmraade.strNamn As 'strOmraadesNamn', 
          tbTrChecklistamallVersion.recChecklistaVersionID

FROM         dbo.tbTrChecklistaPunkt

LEFT OUTER JOIN dbo.tbTrChecklistamallVersionVaerden 
      ON dbo.tbTrChecklistaPunkt.recChecklistamallVersionVaerdenID = dbo.tbTrChecklistamallVersionVaerden.recChecklistamallVersionVaerdenID
LEFT OUTER JOIN dbo.tbTrChecklistamallVersionPunkt 
      ON dbo.tbTrChecklistaPunkt.recChecklistamallVersionPunktID = dbo.tbTrChecklistamallVersionPunkt.recChecklistamallVersionPunktID
LEFT OUTER JOIN dbo.tbTrChecklistamallVersionOmraade As tbOmraade
      ON dbo.tbTrChecklistamallVersionPunkt.recChecklistamallVersionOmraadeID = tbOmraade.recChecklistamallVersionOmraadeID
LEFT OUTER JOIN dbo.tbTrChecklistamallVersion
      ON dbo.tbTrChecklistamallVersion.recChecklistaVersionID = tbOmraade.recChecklistaVersionID


go

