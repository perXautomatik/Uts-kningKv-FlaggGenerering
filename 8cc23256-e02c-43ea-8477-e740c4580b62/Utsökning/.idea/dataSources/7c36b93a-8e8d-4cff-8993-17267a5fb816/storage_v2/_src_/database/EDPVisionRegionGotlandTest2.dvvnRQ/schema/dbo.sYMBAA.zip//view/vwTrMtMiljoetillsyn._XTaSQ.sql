
CREATE VIEW [dbo].[vwTrMtMiljoetillsyn]
AS
SELECT     
	tbTrMtMiljoetillsyn.recMiljoetillsynID, 
	tbTrMtMiljoetillsyn.recMiljoetillsynID as intRecnum, 
	
       (REPLACE( (SELECT strKvalitetsmaal + ', ' 
    FROM tbTrMtMiljoeKvalitetsMaal
    WHERE tbTrMtMiljoeKvalitetsMaal.recMiljoetillsynID = tbTrMtMiljoetillsyn.recMiljoetillsynID
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strMiljoemaal,
	
	CASE 
		WHEN (SELECT TOP(1) strHuvudflik FROM tbTrTillsynsobjektHuvudflik WHERE recTillsynsobjektID  = tbTrMtMiljoetillsyn.recTillsynsobjektID ORDER BY recTillsynsobjektHuvudflikID ASC) = 'TrMtMiljö' THEN 
			CAST(1 as bit)
		ELSE 
			CAST(0 as bit)
	END AS bolHuvudflik,

	tbTrMtMiljoetillsyn.strTillsynsmyndighet, 
	tbTrMtMiljoetillsyn.strBefintiligProevning, 
	tbTrMtMiljoetillsyn.strProevningsinstans, 
	tbTrMtMiljoetillsyn.datProevningsdatum, 
	tbTrMtMiljoetillsyn.strLSTAnlaeggningsnummer, 
	tbTrMtMiljoetillsyn.intOenskvaertAvstaand, 
	tbTrMtMiljoetillsyn.intSkyddsavstaandTillBostaeder, 
	tbTrMtMiljoetillsyn.strVattendistrikt, 
	tbTrMtMiljoetillsyn.strVattenskyddsomraade, 
	tbTrMtMiljoetillsyn.strAvrinningsomraade, 
	tbTrMtMiljoetillsyn.strRecipient, 
	tbTrMtMiljoetillsyn.strSeveso, 
	tbTrMtMiljoetillsyn.strIPPC, 
	tbTrMtMiljoetillsyn.strHUR, 
	tbTrMtMiljoetillsyn.strNACESNI, 	
	tbTrMtMiljoetillsyn.strMiljoeledningssystem, 
	tbTrMtMiljoetillsyn.recTillsynsobjektID,
	tbTrMtMiljoetillsyn.bolMiljoobjekt

FROM dbo.tbTrMtMiljoetillsyn
go

