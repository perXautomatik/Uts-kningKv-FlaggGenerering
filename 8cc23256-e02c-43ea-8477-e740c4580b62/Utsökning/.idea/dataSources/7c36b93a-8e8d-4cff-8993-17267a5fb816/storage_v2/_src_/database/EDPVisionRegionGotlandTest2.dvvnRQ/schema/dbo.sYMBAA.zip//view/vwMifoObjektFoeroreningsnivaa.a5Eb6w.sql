CREATE VIEW dbo.vwMifoObjektFoeroreningsnivaa
AS
SELECT     dbo.tbMifoFoeroreningsnivaa.recFoeroreningsnivaaID, dbo.tbMifoFoeroreningsnivaa.recObjektID, dbo.tbMifoFoeroreningsnivaa.strFoeroreningsnivaa,
                      dbo.tbMifoFoeroreningsnivaa.strMedium, dbo.tbMifoObjekt.strObjektId, dbo.tbMifoObjekt.strObjektNamn,
                      dbo.tbMifoFoeroreningsnivaa.recFoeroreningsnivaaID AS intRecnum, dbo.tbMifoFoeroreningsnivaa.strAemnesgrupp
FROM         dbo.tbMifoObjekt RIGHT OUTER JOIN
                      dbo.tbMifoFoeroreningsnivaa ON dbo.tbMifoObjekt.recObjektID = dbo.tbMifoFoeroreningsnivaa.recObjektID
go

