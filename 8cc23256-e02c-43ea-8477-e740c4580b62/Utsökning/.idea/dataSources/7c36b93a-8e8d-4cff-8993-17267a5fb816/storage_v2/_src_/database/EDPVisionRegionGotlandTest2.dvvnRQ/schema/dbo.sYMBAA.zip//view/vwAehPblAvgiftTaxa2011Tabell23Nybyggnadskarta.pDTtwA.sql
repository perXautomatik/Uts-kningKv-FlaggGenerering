


CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell23Nybyggnadskarta]
AS
SELECT        
	recAehPblAvgiftTaxa2011Tb23NybyggID,
	recAehPblAvgiftTaxa2011Tb23NybyggID as 'intRecnum',
	intNKF, 
	strBeskrivning, 
	strAatgaerd, 
	recPblAvgiftTaxa2011Tabell23ID
FROM
    dbo.tbAehPblAvgiftTaxa2011Tabell23Nybyggnadskarta



go

