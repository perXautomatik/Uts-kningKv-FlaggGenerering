



CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell07Besked]
AS
SELECT		recPblAvgiftTaxa2011Tabell07ID, 
			recPblAvgiftTaxa2011Tabell07BeskedID as 'intRecnum',
			recPblAvgiftTaxa2011Tabell07BeskedID,
			strTypAvBesked,
			strBeskrivning,
			decAntalmPBB,
			bolAnvaendN,
			decAvgift

FROM         dbo.tbAehPblAvgiftTaxa2011Tabell07Besked

go

