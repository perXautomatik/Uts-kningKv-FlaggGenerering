

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell28Utskrift]
AS
SELECT    recPblAvgiftTaxa2011Tabell28UtskriftID
		, recPblAvgiftTaxa2011Tabell28UtskriftID as intRecnum
		, recPblAvgiftTaxa2011Tabell28ID
		, strAatgaerd
		, strBeskrivning
		, decAAF
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell28Utskrift
go

