
CREATE VIEW [dbo].[vwMmOmraade]
AS
SELECT     dbo.tbMmOmraade.strRegKod + '-' + dbo.tbMmOmraade.strOmrNr + '-' + dbo.tbMmOmraade.strLopNr AS strOmraadeKod, CASE WHEN recHuvudOmrID IS NULL
                      THEN CAST(1 AS bit) WHEN recHuvudOmrID IS NOT NULL THEN CAST(0 AS bit) ELSE NULL END AS bolHuvudOmr, dbo.tbMmOmraade.strRegKod,
                      dbo.tbMmOmraade.strOmrNr, dbo.tbMmOmraade.strLopNr, dbo.tbMmOmraade.strOmrNamn, dbo.tbMmOmraade.recFasID, dbo.tbMmOmraade.strTillsyn,
                      dbo.tbMmOmraade.strAnvNutid, dbo.tbMmOmraade.strAnvFramtid, dbo.tbMmOmraade.strAvstaandBostadsomr, dbo.tbMmOmraade.intYta, dbo.tbMmFas.strFasNamn,
                      dbo.tbMmOmraade.recOmrID AS intRecnum, dbo.tbMmOmraade.recOmrID, dbo.vwMmHuvudadress.strAdress, dbo.tbMmOmraade.recHuvudOmrID,
                      dbo.tbMmOmraade.strVattenskyddsomraade, dbo.tbMmOmraade.strOmraadeBeskrivning, dbo.vwMmHuvudKlassning.strKlassningNamn,
                      dbo.tbMmOmraade.strAnledning, dbo.vwMmHuvudadress.recGatuadressID, dbo.tbMmGeologi.strGeoText, dbo.tbMmGeologi.decGrundvattenDjup,
                      dbo.tbMmGeologi.recGeologiID, dbo.vwMmHuvudKlassning.recOmrKlassningID, dbo.vwMmHuvudKlassning.strKlassningvaerde,
                      dbo.tbMmOmraadeLaege.strStadsdel, dbo.tbMmOmraadeLaege.strOrt, dbo.tbMmOmraadeLaege.strKommun, dbo.tbMmOmraadeLaege.strLaen,
                      dbo.tbMmOmraadeLaege.recOmraadeLaegeID, dbo.tbMmOmraadeLaege.strOrt + ' / ' + dbo.tbMmOmraadeLaege.strKommun AS strLaege,
                      dbo.tbMmOmraade.bolFasAvslutad, dbo.vwMmOmraadeHuvudHandlaeggare.intUserID, dbo.vwMmOmraadeHuvudHandlaeggare.strSignature,
                      dbo.tbMmAnsvar.strBeskrivning, dbo.tbMmOmraade.strStatus, dbo.tbMmOmraade.strEBHNummer, dbo.vwMmHuvudfastighet.recOmraadeDeladFastighetID, dbo.vwMmHuvudfastighet.strFnrID,
                      dbo.vwMmHuvudfastighet.bolHuvudfastighet, dbo.vwMmHuvudfastighet.strFastighetsbeteckning
FROM         dbo.tbMmOmraade LEFT OUTER JOIN
                      dbo.vwMmHuvudfastighet ON dbo.tbMmOmraade.recOmrID = dbo.vwMmHuvudfastighet.recOmrID LEFT OUTER JOIN
                      dbo.tbMmAnsvar ON dbo.tbMmOmraade.recOmrID = dbo.tbMmAnsvar.recOmrID LEFT OUTER JOIN
                      dbo.vwMmOmraadeHuvudHandlaeggare ON dbo.tbMmOmraade.recOmrID = dbo.vwMmOmraadeHuvudHandlaeggare.recOmrID LEFT OUTER JOIN
                      dbo.tbMmOmraadeLaege ON dbo.tbMmOmraade.recOmrID = dbo.tbMmOmraadeLaege.recOmrID LEFT OUTER JOIN
                      dbo.tbMmGeologi ON dbo.tbMmOmraade.recOmrID = dbo.tbMmGeologi.recOmrID LEFT OUTER JOIN
                      dbo.vwMmHuvudKlassning ON dbo.tbMmOmraade.recOmrID = dbo.vwMmHuvudKlassning.recOmrID LEFT OUTER JOIN
                      dbo.vwMmHuvudadress ON dbo.tbMmOmraade.recOmrID = dbo.vwMmHuvudadress.recOmrID LEFT OUTER JOIN
                      dbo.tbMmFas ON dbo.tbMmOmraade.recFasID = dbo.tbMmFas.recFasID
go

