CREATE VIEW dbo.vwMifoBranschNamn
AS
SELECT DISTINCT strBranschNamn, intBranschIdMIFO
FROM         dbo.tbMmBransch
go

