
        CREATE TRIGGER TRG_tbAehAerendeHaendelse_INSERT_UPDATE_DELETE ON tbAehAerendeHaendelse
        AFTER INSERT, UPDATE, DELETE
        AS
        BEGIN
        SET NOCOUNT ON;

        DECLARE aerende_cursor1 CURSOR FAST_FORWARD
        FOR
        SELECT recAerendeID FROM INSERTED UNION SELECT recAerendeID FROM DELETED
        OPEN aerende_cursor1
        DECLARE @recAerendeID as INT
        FETCH NEXT FROM aerende_cursor1 INTO @recAerendeID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC CalculateHuvudbeslutOnAerende @aerendeId = @recAerendeID

            FETCH NEXT FROM aerende_cursor1 INTO @recAerendeID
        END
        CLOSE aerende_cursor1
        DEALLOCATE aerende_cursor1
        END
        go

