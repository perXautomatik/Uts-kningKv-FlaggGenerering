
CREATE VIEW [dbo].[vwAehAerendetsFakturamottagare]
AS
SELECT tbAehAerende.recAerendeID,
  tbAehAerende.recAerendeID AS intRecnum,
  vwVisEnstakaFakturamottagare.recEnstakaFakturamottagareID,
  vwVisEnstakaFakturamottagare.strFoernamn,
  vwVisEnstakaFakturamottagare.strEfternamn,
  vwVisEnstakaFakturamottagare.strFoeretag,
  vwVisEnstakaFakturamottagare.strTitel,
  vwVisEnstakaFakturamottagare.strKontaktTyp,
  vwVisEnstakaFakturamottagare.strGatuadress,
  vwVisEnstakaFakturamottagare.strCoadress,
  vwVisEnstakaFakturamottagare.strPostnummer,
  vwVisEnstakaFakturamottagare.strPostort,
  vwVisEnstakaFakturamottagare.strLand,
  LTRIM(vwVisEnstakaFakturamottagare.strFoernamn + ' ' + vwVisEnstakaFakturamottagare.strEfternamn) AS strNamn,
  vwVisEnstakaFakturamottagare.strVisasSom,
  vwVisEnstakaFakturamottagare.strSammanslagenAdress,
  vwVisEnstakaFakturamottagare.intIdNummer,
  vwVisEnstakaFakturamottagare.strExterntIdNummer,
  vwVisEnstakaFakturamottagare.strMotpartKoncernkod,
  vwVisEnstakaFakturamottagare.strSkanningskod,
  vwVisEnstakaFakturamottagare.bolIntern,
  vwVisEnstakaFakturamottagare.strGLN,
  vwVisEnstakaFakturamottagare.strKommun,
  vwVisEnstakaFakturamottagare.strReferensnummer,
  vwVisEnstakaFakturamottagare.strOrginisationPersonnummer,
  vwVisEnstakaFakturamottagare.strIntBokfoeringsKonto,
  vwVisEnstakaFakturamottagare.recEnstakaKontaktID,
  (SELECT REPLACE(((SELECT strVaerde + ', '
    FROM tbVisKommunikationssaett
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID
      AND strKommunikationsaettTyp = 'E-Post'
    FOR XML PATH(''))
    + '...'), ', ...', '')
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = vwVisEnstakaFakturamottagare.recEnstakaKontaktID) AS strEpost,
  (SELECT REPLACE(((SELECT strVaerde + ', '
    FROM tbVisKommunikationssaett
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID
      AND strKommunikationsaettTyp = 'Fax'
    FOR XML PATH(''))
    + '...'), ', ...', '')
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = vwVisEnstakaFakturamottagare.recEnstakaKontaktID) AS strFax,
  (SELECT REPLACE(((SELECT strVaerde + ', '
    FROM tbVisKommunikationssaett
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID
      AND strKommunikationsaettTyp = 'Telefon'
    FOR XML PATH(''))
    + '...'), ', ...', '')
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = vwVisEnstakaFakturamottagare.recEnstakaKontaktID) AS strTelefon,
  (SELECT REPLACE(((SELECT strVaerde + ', '
    FROM tbVisKommunikationssaett
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID
      AND strKommunikationsaettTyp = 'Mobil'
    FOR XML PATH(''))
    + '...'), ', ...', '')
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = vwVisEnstakaFakturamottagare.recEnstakaKontaktID) AS strMobil
FROM tbAehAerende
INNER JOIN vwVisEnstakaFakturamottagare
  ON vwVisEnstakaFakturamottagare.recEnstakaFakturamottagareID = tbAehAerende.recEnstakaFakturamottagareID

go

