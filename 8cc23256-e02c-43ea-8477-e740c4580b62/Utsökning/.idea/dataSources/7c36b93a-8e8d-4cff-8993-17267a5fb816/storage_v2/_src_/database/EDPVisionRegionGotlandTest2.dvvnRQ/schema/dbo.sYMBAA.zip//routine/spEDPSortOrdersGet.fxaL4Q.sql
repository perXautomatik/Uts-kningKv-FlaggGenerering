

CREATE PROCEDURE dbo.spEDPSortOrdersGet
	(
		@strFormName varchar(100)
	)
AS

SELECT     tbEDPSortControlColumn.strControlColumnName, tbEDPSortOrder.intOrderID, tbEDPSortOrder.bolDefault, tbEDPSortColumn.strColumnName, 
                      tbEDPSortColumn.strTableName
FROM         tbEDPSortOrder INNER JOIN
                      tbEDPSortControlColumn ON tbEDPSortOrder.intControlColumnID = tbEDPSortControlColumn.intControlColumnID INNER JOIN
                      tbEDPSortOrderSortColumn ON tbEDPSortOrder.intOrderID = tbEDPSortOrderSortColumn.intOrderID INNER JOIN
                      tbEDPSortColumn ON tbEDPSortOrderSortColumn.intColumnID = tbEDPSortColumn.intColumnID
WHERE     (tbEDPSortControlColumn.strFormName = @strFormName)
ORDER BY tbEDPSortControlColumn.strControlColumnName, tbEDPSortOrder.intAppearanceOrder, tbEDPSortOrderSortColumn.intAppearanceOrder

	RETURN

go

