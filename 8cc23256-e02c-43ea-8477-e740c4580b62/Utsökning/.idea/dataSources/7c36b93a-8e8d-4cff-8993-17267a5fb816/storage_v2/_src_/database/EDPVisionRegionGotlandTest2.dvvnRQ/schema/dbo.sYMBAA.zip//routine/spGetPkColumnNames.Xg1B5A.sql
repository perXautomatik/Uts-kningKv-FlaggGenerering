-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spGetPkColumnNames]
	-- Add the parameters for the stored procedure here
	@TableName nvarchar(300)	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT ccu.COLUMN_NAME AS KolumnNamn
	FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
	INNER JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name
	WHERE tc.CONSTRAINT_TYPE = 'Primary Key' AND ccu.TABLE_NAME = @TableName
END
go

