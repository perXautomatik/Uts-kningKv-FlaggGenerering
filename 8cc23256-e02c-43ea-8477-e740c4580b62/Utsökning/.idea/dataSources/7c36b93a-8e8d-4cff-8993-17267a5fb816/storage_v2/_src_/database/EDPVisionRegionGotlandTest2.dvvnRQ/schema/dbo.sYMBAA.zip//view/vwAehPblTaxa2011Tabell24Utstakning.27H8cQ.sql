
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell24Utstakning]
AS
SELECT     

tbAehPblTaxa2011Tabell24Utstakning.recTabell24ID, 
recUtstakningID, 
recUtstakningID as 'intRecnum', 
strObjekt,
strBeskrivning,
recTaxa2011ID,
intUF
	
FROM dbo.tbAehPblTaxa2011Tabell24Utstakning	
LEFT OUTER JOIN vwAehPblTaxa2011Tabell24 
ON vwAehPblTaxa2011Tabell24.recTabell24ID = tbAehPblTaxa2011Tabell24Utstakning.recTabell24ID


go

