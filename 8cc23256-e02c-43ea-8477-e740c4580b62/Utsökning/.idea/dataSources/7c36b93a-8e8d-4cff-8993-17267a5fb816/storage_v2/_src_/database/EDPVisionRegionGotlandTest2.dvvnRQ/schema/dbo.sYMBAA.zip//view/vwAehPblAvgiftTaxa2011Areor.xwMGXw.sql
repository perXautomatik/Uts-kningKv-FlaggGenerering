


CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Areor]
AS
SELECT     
	tbAehPblAvgiftTaxa2011Areor.*, recAreaID As 'intRecnum'

FROM dbo.tbAehPblAvgiftTaxa2011Areor

go

