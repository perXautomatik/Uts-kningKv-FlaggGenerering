
-- Ny version av spEDPGetObjectChildrenByObjectID
CREATE PROCEDURE [dbo].[spEDPGetObjectChildrenByObjectID]
	(
		@intObjectID int
	)
AS
SELECT     dbo.tbEDPObject.intObjectID, dbo.tbEDPObjectType.strObjectTypeName, dbo.tbEDPObject.strObjectName
FROM         dbo.tbEDPObject INNER JOIN
                      dbo.tbEDPObject tbEDPObject_1 ON dbo.tbEDPObject.intParentObjectID = tbEDPObject_1.intObjectID INNER JOIN
                      dbo.tbEDPObjectType ON dbo.tbEDPObject.intObjectTypeID = dbo.tbEDPObjectType.intObjectTypeID
WHERE     (tbEDPObject_1.intObjectID = @intObjectID) ORDER By tbEDPObject.intSortOrder

	RETURN
go

