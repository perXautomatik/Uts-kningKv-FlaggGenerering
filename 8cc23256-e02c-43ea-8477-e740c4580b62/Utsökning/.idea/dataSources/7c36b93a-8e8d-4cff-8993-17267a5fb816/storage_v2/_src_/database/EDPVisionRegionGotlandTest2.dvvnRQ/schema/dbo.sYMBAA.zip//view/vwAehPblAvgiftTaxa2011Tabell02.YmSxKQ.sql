
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell02]
AS
SELECT dbo.tbAehPblAvgiftTaxa2011Tabell02.recPblAvgiftTaxa2011Tabell02ID, 
       dbo.tbAehPblAvgiftTaxa2011Tabell02.recPblAvgiftTaxa2011Tabell02ID AS intRecnum, 
       dbo.tbAehPblAvgiftTaxa2011Tabell02.decAvgiftTotalt, 
       dbo.tbAehPblAvgiftTaxa2011Tabell02.recAvgiftID,
       dbo.tbAehPblAvgift.recTaxa2011ID,
       dbo.tbAehPblTaxa2011.decPbb,
       dbo.tbAehPblTaxa2011.recAvdelningID,
       dbo.tbAehPblTaxa2011.intTimpris
FROM dbo.tbAehPblAvgiftTaxa2011Tabell02
LEFT OUTER JOIN dbo.tbAehPblAvgift
  ON dbo.tbAehPblAvgift.recAvgiftID = dbo.tbAehPblAvgiftTaxa2011Tabell02.recAvgiftID 
LEFT OUTER JOIN dbo.tbAehPblTaxa2011
  ON dbo.tbAehPblTaxa2011.recTaxa2011ID = dbo.tbAehPblAvgift.recTaxa2011ID

go

