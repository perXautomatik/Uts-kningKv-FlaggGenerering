
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell10]
AS
SELECT     

recTabell10ID, 
recTaxa2011ID, 
recTabell10ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell10.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell10.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell10

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell10.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell10.recTjaenstID


go

