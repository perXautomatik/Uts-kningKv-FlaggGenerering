CREATE VIEW dbo.vwMmHuvudKlassning
AS
SELECT     dbo.tbMmOmrKlassning.recOmrKlassningID, dbo.tbMmOmrKlassning.recOmrID, dbo.tbMmOmrKlassning.recKlassningID,
                      dbo.tbMmOmrKlassning.bolHuvudklassning, dbo.tbMmKlassning.strKlassningNamn, dbo.tbMmKlassningvaerde.strKlassningvaerde
FROM         dbo.tbMmKlassning RIGHT OUTER JOIN
                      dbo.tbMmOmrKlassning ON dbo.tbMmKlassning.recKlassningID = dbo.tbMmOmrKlassning.recKlassningID LEFT OUTER JOIN
                      dbo.tbMmKlassningvaerde ON dbo.tbMmOmrKlassning.recKlassningvaerdeID = dbo.tbMmKlassningvaerde.recKlassningvaerdeID
WHERE     (dbo.tbMmOmrKlassning.bolHuvudklassning = 1)
go

