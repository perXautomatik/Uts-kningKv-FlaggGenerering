
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell14UtanKonstruktion]
AS
SELECT     tbAehPblTaxa2011Tabell14UtanKonstruktion.recTabell14ID, 
           recUtanKonstruktionID as 'intRecnum', 
		   recUtanKonstruktionID,
		   strObjekt,
		   strBeskrivning,
		   intOF, 
		   intHF1, 
		   recTaxa2011ID,
		   intHF2 
FROM         dbo.tbAehPblTaxa2011Tabell14UtanKonstruktion
LEFT OUTER JOIN tbAehPblTaxa2011Tabell14 
ON tbAehPblTaxa2011Tabell14UtanKonstruktion.recTabell14ID = tbAehPblTaxa2011Tabell14.recTabell14ID

go

