
CREATE VIEW [dbo].[vwAehHaendelsensHuvudfastighet]
AS
SELECT tbAehHaendelseEnstakaFastighet.recHaendelseID,
  tbAehHaendelseEnstakaFastighet.recHaendelseEnstakaFastighetID,
  tbAehHaendelseEnstakaFastighet.recFastighetID,
  vwVisEnstakaFastighet.strFnrID,
  vwVisEnstakaFastighet.strTrakt,
  vwVisEnstakaFastighet.strBlock,
  vwVisEnstakaFastighet.strTkn,
  vwVisEnstakaFastighet.intEnhet,
  vwVisEnstakaFastighet.strFastighetsbeteckning,
  vwVisEnstakaFastighet.strAdress,
  vwVisEnstakaFastighet.strPostnr,
  vwVisEnstakaFastighet.strPostort,
  vwVisEnstakaFastighet.strKommunNamn  

FROM tbAehHaendelseEnstakaFastighet
INNER JOIN vwVisEnstakaFastighet
  ON vwVisEnstakaFastighet.recFastighetID = tbAehHaendelseEnstakaFastighet.recFastighetID
WHERE tbAehHaendelseEnstakaFastighet.bolHuvudfastighet = 1
go

