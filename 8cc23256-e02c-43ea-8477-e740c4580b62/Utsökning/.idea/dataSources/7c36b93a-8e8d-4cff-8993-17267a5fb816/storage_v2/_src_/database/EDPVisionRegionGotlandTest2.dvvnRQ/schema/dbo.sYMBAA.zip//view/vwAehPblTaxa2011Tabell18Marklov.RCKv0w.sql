

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell18Marklov]
AS
SELECT     tbAehPblTaxa2011Tabell18Marklov.recTabell18ID, 
           recMarklovID as 'intRecnum', 
		   recMarklovID,
		   strAatgaerd,
		   strBeskrivning,
		   recTaxa2011ID,
		   decAntalmPBB
FROM         dbo.tbAehPblTaxa2011Tabell18Marklov
LEFT OUTER JOIN vwAehPblTaxa2011Tabell18 
ON vwAehPblTaxa2011Tabell18.recTabell18ID = tbAehPblTaxa2011Tabell18Marklov.recTabell18ID


go

