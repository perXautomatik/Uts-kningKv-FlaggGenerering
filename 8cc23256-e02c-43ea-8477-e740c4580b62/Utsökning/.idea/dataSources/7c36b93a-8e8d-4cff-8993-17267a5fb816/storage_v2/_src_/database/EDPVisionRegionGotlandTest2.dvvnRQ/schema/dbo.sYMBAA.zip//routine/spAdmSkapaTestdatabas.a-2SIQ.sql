CREATE PROCEDURE [dbo].[spAdmSkapaTestdatabas]
/* Skapa testdatabas-procedur ursprungligen skapad 2003-02-04 av Arvid Dellien, EDP Consult AB,

Testdatabas (kopia där suffixet Test läggs till i slutet av namnet) skapas av den databas som aktuell koppling är upprättad mot.
Man behöver inte ange någon inparameter, men man kan skicka in databasnamn för att ange vilken
databas som ska kopieras.

Ett "backup device" med namnet testdbBackup tas bort om det existerar och skapas sedan på nytt och innehåller då en
backup (.bak-fil) av databasen som kopierats. Backupfilen, med namnet [Namnet på EDP Future-databasen]_bak.bak,
hamnar i samma katalog som den skarpa databasens datafil (.mdf).

OBS! Proceduren kan inte hantera databaser som består av flera datafiler (ndf-filer).

Exempel på anrop av proceduren (skapar en kopia, med namnet EDPFutureADTest, av databasen EDPFutureAD):
EXEC spAdmSkapaTestdatabas 'EDPFuture[kundnamn]'

2006-03-02 MM: Ändrade proceduren så att man kollar var loggfilen ligger så även loggfilen för testdatabasen lägger sig på samma ställe.
2007-01-19 HM: Ändrade proceduren så att testdatabasen får suffixet Test istället för _test i slutet av databasnamnet.
2009-05-20 JH: Har lagt till ett databasnamn-suffix, eftersom en del kunder vill kunna skapa flera testdatabaser.
Gammal funktionalitet med ett eller utan argument har bibehållts, plus ett extra arg på suffix, tex:
1. spAdmSkapaTestdatabas	-> Skapar/skriver över en db med namn EDPFuture[kundnamn]Test, såvida man anropar proceduren i databasen EDPFuture[kundnamn]
2. spAdmSkapaTestdatabas 'EDPFuture[kundnamn]' -> Skapar/skriver över en db med namn EDPFuture[kundnamn]Test
3. spAdmSkapaTestdatabas default, 'TestNr3' -> Skapar/skriver över en db med namn EDPFuture[kundnamn]TestNr3, såvida man anropar proceduren i databasen EDPFuture[kundnamn]
4. spAdmSkapaTestdatabas 'EDPFuture[kundnamn]', 'TestNr4'  -> Skapar/skriver över en db med namn EDPFuture[kundnamn]TestNr4
2009-09-23 HM: Har ändrat så att proceduren inte försöker plocka bort testdbBackup ("backup device") om det inte existerar.
Därmed försvinner problemet med att proceduren returnerar ett felmeddelande första gången den körs.
2010-06-02 HEMA: Har lagt till COPY_ONLY i backup-satsen för att undvika att bryta backup-kedjor,
som är beroende av den senaste fullständiga backupen.
2010-10-18 LINI: Lagt till så att testdatabasens tbEDPJob rensas så att inga jobb kopieras från skarp db till test db.
2010-11-01 HEMA: Modifierat så att tabellen tbEDPJob bara rensas om den existerar.
2010-11-01 HEMA: Lagt till så att man mha inparametrar kan bestämma destinationen för mdf- resp. ldf-filen.
Exempel på anrop om man vill skapa en testdatabas med suffixet 'Test' av aktuell databas och lägga databasfilerna på specifika platser:
EXEC spAdmSkapaTestdatabas default, default, 'C:\SQLDATA\', 'D:\SQLLOG';
2016-03-24 SVGR: Lagt till att man ställer om måldatabasen till SINGLE_USER innan man försöker ersätta den.
*/

-- Namnet på databasen som ska kopieras. - Default: Aktuell databas.
@inDatabasnamn varchar(200) = null,
-- Alternativt suffix. - Default: Test.
@inDatabasnamnSuffix varchar(20) = null,
-- Sökväg till destinationen för testdatabasens mdf-fil. - Default: Samma mapp som källdatabasens mdf-fil ligger i.
@inDestPathMdf varchar(200) = null,
-- Sökväg till destinationen för testdatabasens ldf-fil. - Default: Samma mapp som källdatabasens ldf-fil ligger i.
@inDestPathLdf varchar(200) = null,
-- Sökväg till destinationen för testdatabasens bak-fil. - Default: Samma mapp som källdatabasens mdf-fil ligger i.
@inDestPathBak varchar(200) = null

as
declare @sysfile varchar(200)
declare @logfile varchar(200)
declare @katalog varchar(200)
declare @katalogLog varchar(200)
declare @katalogBak varchar(200)
declare @dbnamn varchar(200)
declare @sqlstr varchar(200)
declare @datafilnamn varchar(200)
declare @loggfilnamn varchar(200)
declare @slashpos int
declare @slashposLog int
declare @filnamn varchar(200)
declare @backupsokvag varchar(200)
declare @datapos int
declare @testdbnamn varchar(200)
declare @destdatafil varchar(200)
declare @destloggfil varchar(200)
declare @sqlEDPFramework nvarchar(200)

set @sysfile = (select filename from sysfiles where fileid = 1)
set @datafilnamn = (select name from sysfiles where fileid = 1)
set @logfile = (select filename from sysfiles where fileid = 2)
set @loggfilnamn = (select name from sysfiles where fileid = 2)

set @sysfile = rtrim(@sysfile)
set @slashpos = (charindex('\', reverse(@sysfile)))
/*print @sysfile
print @slashpos*/
set @katalog = left(@sysfile, (len(@sysfile) - (@slashpos - 1)))
/*print @katalog*/

set @logfile = rtrim(@logfile)
set @slashposLog = (charindex('\', reverse(@logfile)))
/*print @logfile
print @slashposLog*/
set @katalogLog = left(@logfile, (len(@logfile) - (@slashposLog - 1)))
/*print @katalogLog*/

set @katalogBak = null

/* för att säkert veta namnet på databasen vi är i måste vi använda master-databasen men det kan vi inte göra,
därför gissar vi att namnet är antingen filnamn utan _data eller bara filnamn, om _data saknas */
set @filnamn = right(@sysfile, (@slashpos - 1))
/*print @filnamn*/

/* nu kollar om vi om _data ingår i filnamnet */
set @datapos = (charindex('_Data', @filnamn))
/*print @datapos*/

/* om datapos är större än 0 så blir dbnamn filnamn - ws_data annars blir db-namn samma som filnamn)*/

if (@datapos > 0)
  begin
    set @dbnamn = (left(@filnamn, (@datapos - 1)))
  end
  else
    begin
   set @dbnamn = (left(@filnamn, len(@filnamn) - 4))
end

if (@indatabasnamn is not null)
begin
 set @dbnamn = (@indatabasnamn)
end
/*print @dbnamn*/
if (@inDatabasnamnSuffix is not null)
	begin
	 set @testdbnamn = (@dbnamn + @inDatabasnamnSuffix)
	end
else
	begin
	 set @testdbnamn = (@dbnamn + 'Test')
	end

-- Måste slänga ut ev inloggade användare i testdatabasen (ifall den finns) --
declare @singleuser nvarchar(200)
BEGIN TRY
  set @singleuser = 'ALTER DATABASE [' + @testdbnamn + '] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;'
  exec sp_executesql @singleuser
END TRY
BEGIN CATCH
END CATCH

/* ok så långt då kan vi göra det vi skulle från början */

-- Om destination för backupfilerna har angivits så ska default-sökvägen ersättas
-- Bak-filen
if @inDestPathBak is not null
begin
	if right(@inDestPathBak,1) = '\'
	begin
		set @katalogBak = @inDestPathBak
	end
	else
	begin
		set @katalogBak = @inDestPathBak+'\';
	end

    set @backupsokvag = (@katalogBak +  @dbnamn + '_bak.bak')
end
else
begin
	set @backupsokvag = (@katalog +  @dbnamn + '_bak.bak')
end

print 'Backup destination: '+@backupsokvag

-- Tar bort "dumpdevicet" testdbBackup om det existerar
IF EXISTS (SELECT * FROM sys.backup_devices WHERE [name] = 'testdbBackup')
BEGIN
  EXEC sp_dropdevice 'testdbBackup', 'delfile'
END
-- Skapa "dumpdevicet" testdbBackup på nytt
EXEC sp_addumpdevice 'disk', 'testdbBackup', @backupsokvag
print 'Device added.'
-- Ta en fullständig backup av databasen och lägg den i testdbBackup (hamnar i samma katalog som den skarpa databasens datafil (.mdf))
BACKUP DATABASE @dbnamn TO testdbBackup WITH COPY_ONLY

-- Om destination för databasfilerna har angivits så ska default-sökvägarna ersättas
-- Mdf-filen
if @inDestPathMdf is not null
  if right(@inDestPathMdf,1) = '\'
    set @katalog = @inDestPathMdf
  else
    set @katalog = @inDestPathMdf+'\';
-- Ldf-filen
if @inDestPathLdf is not null
  if right(@inDestPathLdf,1) = '\'
    set @katalogLog = @inDestPathLdf
  else
    set @katalogLog = @inDestPathLdf+'\';

-- Bygg hela sökvägarna inklusive databasnamn till databasfilerna
set @destdatafil = (@katalog + @testdbnamn + '_data.mdf')
set @destloggfil = (@katalogLog + @testdbnamn + '_log.ldf')
/*print @testdbnamn
print @datafilnamn
print @destdatafil
print @loggfilnamn
print @destloggfil*/

-- Återställer (skapar ny/skriver över befintlig) testdatabas
RESTORE DATABASE @testdbnamn FROM testdbBackup WITH
  MOVE @datafilnamn to @destdatafil,
  MOVE @loggfilnamn to @destloggfil,
  REPLACE

-- Specifik kod för databaser baserade på EDP Framework.
BEGIN TRY
  SET @sqlEDPFramework = 'USE ' +  @testdbnamn + ';' + ' DELETE FROM tbEDPJob'
  EXEC sp_executesql @sqlEDPFramework
  PRINT 'Tabellen tbEDPJob i databasen '+@testdbnamn+' rensades.'
END TRY
BEGIN CATCH
  --PRINT 'Tabellen tbEDPJob finns inte i databasen '+@testdbnamn+' och rensas följaktligen inte.'
END CATCH;
go

