CREATE PROCEDURE [dbo].[spAehHaendelseUpdateKontakt]
  @recHaendelseID int
AS
BEGIN
  SET NOCOUNT ON;
  
  UPDATE dbo.tbAehHaendelseData SET
    recEnstakaKontaktID = dbo.tbVisEnstakaKontakt.recEnstakaKontaktID,
    strGatuadress = dbo.tbVisEnstakaKontakt.strGatuadress,
    strPostnummer = dbo.tbVisEnstakaKontakt.strPostnummer,
    strPostort = dbo.tbVisEnstakaKontakt.strPostort,
    strVisasSom = dbo.tbVisEnstakaKontakt.strVisasSom,
    strRoll = dbo.tbAehHaendelseEnstakaKontakt.strRoll,
    recKontaktRollID = dbo.tbVisKontaktRoll.recKontaktRollID,
    recHaendelseEnstakaKontaktID = dbo.tbAehHaendelseEnstakaKontakt.recHaendelseEnstakaKontaktID
  FROM dbo.tbAehHaendelseData
  LEFT OUTER JOIN dbo.tbAehHaendelseEnstakaKontakt
    ON dbo.tbAehHaendelseEnstakaKontakt.recHaendelseID = dbo.tbAehHaendelseData.recHaendelseID 
    AND dbo.tbAehHaendelseEnstakaKontakt.bolHuvudKontakt = 1 
  LEFT OUTER JOIN dbo.tbVisEnstakaKontakt 
    ON dbo.tbAehHaendelseEnstakaKontakt.recEnstakaKontaktID = dbo.tbVisEnstakaKontakt.recEnstakaKontaktID
  LEFT OUTER JOIN dbo.tbVisKontaktRoll
    ON dbo.tbVisKontaktRoll.strRoll = dbo.tbAehHaendelseEnstakaKontakt.strRoll
  WHERE dbo.tbAehHaendelseData.recHaendelseID = @recHaendelseID
END
go

