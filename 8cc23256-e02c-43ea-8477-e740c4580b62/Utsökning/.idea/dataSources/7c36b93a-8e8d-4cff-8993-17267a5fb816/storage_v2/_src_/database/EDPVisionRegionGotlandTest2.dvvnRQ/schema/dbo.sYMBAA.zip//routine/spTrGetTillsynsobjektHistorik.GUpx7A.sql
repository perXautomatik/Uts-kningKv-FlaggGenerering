CREATE PROCEDURE [dbo].[spTrGetTillsynsobjektHistorik] (
	@id INTEGER = NULL
)
AS
  -- ERROR HANDLING
  IF @id IS NULL
    BEGIN
      PRINT 'ERROR: First param "id" must be specified and can not be NULL.'
      RETURN(1)
    END
  -- NO ERROR
  BEGIN
    -- SAVE TIME
	SET NOCOUNT ON;
		
		SELECT	recTillsynsobjektHistorikID,
				intMainTableID,
				datSkapad,
				recVerksamhetID,
				strObjektsNamn,
				strAdress,
				strOrt,
				strSoekbegrepp,
				strAnteckning
		FROM tbTrTillsynsobjektHistorik
		WHERE intMainTableID = @id
		ORDER BY datSkapad DESC;

    RETURN(0)
  END


go

