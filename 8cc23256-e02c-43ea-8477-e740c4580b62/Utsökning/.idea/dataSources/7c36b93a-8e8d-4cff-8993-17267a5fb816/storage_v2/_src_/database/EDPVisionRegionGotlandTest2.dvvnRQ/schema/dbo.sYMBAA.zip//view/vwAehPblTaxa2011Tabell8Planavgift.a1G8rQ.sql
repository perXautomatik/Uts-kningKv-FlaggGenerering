

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell8Planavgift]
AS
SELECT     tbAehPblTaxa2011Tabell8Planavgift.recTabell8ID, 
           recPlanavgiftID as 'intRecnum', 
		   recPlanavgiftID, 
		   strObjekt,
		   recTaxa2011ID,
			strBeskrivning, 
			intPF
FROM         dbo.tbAehPblTaxa2011Tabell8Planavgift
LEFT OUTER JOIN vwAehPblTaxa2011Tabell8
ON vwAehPblTaxa2011Tabell8.recTabell8ID = tbAehPblTaxa2011Tabell8Planavgift.recTabell8ID



go

