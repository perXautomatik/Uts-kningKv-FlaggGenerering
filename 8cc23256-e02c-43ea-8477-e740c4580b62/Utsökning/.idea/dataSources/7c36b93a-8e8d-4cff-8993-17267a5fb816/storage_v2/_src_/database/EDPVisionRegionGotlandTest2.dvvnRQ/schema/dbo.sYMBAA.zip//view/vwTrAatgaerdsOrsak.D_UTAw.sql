



CREATE VIEW [dbo].[vwTrAatgaerdsOrsak]
AS

SELECT 
			tblPunkt.recChecklistamallVersionPunktID,
			tblPunkt.recChecklistamallVersionOmraadeID,
			tblPunkt.strNamn,
			tblPunkt.intNummer,
			tblPunkt.strHjaelpText,
			tblPunkt.recChecklistamallVersionVaerdeListaID,
			tblPunkt.strRapporteringsPunkt,
			'Orsak ' + CAST(tblOmraade.intNummer AS VARCHAR) + '.' + CAST(tblPunkt.intNummer AS VARCHAR) AS Orsak
FROM		
			tbTrChecklistamallVersionPunkt AS tblPunkt 
LEFT JOIN	
			tbTrChecklistamallVersionOmraade AS tblOmraade 
			ON tblOmraade.recChecklistamallVersionOmraadeID = tblPunkt.recChecklistamallVersionOmraadeID



go

