CREATE VIEW [dbo].[vwEDPFileVersion]
AS
SELECT     dbo.tbEDPFileVersion.recFileVersionID, dbo.tbEDPFileVersion.recFileObjectID, dbo.tbEDPFileVersion.recFileStorageLocationID, 
                      dbo.tbEDPFileVersion.intFileVersion, dbo.tbEDPFileVersion.strFileType, dbo.tbEDPFileVersion.intFileVersionStorageSubDirectoryPath, 
                      dbo.tbEDPFileVersion.datFileVersionDate, dbo.tbEDPFileVersion.lngFileSize, dbo.tbEDPFileVersion.strFileVersionComment, 
                      dbo.tbEDPFileVersion.intUserID, dbo.tbEDPUser.strSignature
FROM         dbo.tbEDPFileVersion LEFT OUTER JOIN
                      dbo.tbEDPUser ON dbo.tbEDPFileVersion.intUserID = dbo.tbEDPUser.intUserID

go

