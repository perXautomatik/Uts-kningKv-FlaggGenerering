
CREATE PROCEDURE dbo.spEDPDeleteRoleObjectPropertyByObjectID 
	(
	@intObjectID int
	)
AS
  DELETE FROM tbEDPRoleObjectProperty WHERE intObjectID = @intObjectID
	RETURN @@ROWCOUNT

go

