
        CREATE TRIGGER TRG_TaBortKontaktIfraanHuvudtabell ON tbTrTillsynsobjektDeladKontakt
        AFTER DELETE
        AS
        BEGIN
        SET NOCOUNT ON;
        DECLARE @kontaktperson bit
        DECLARE @verksamhetsutoevare bit
        DECLARE @recTillsynsobjektID INT

        DECLARE tbTrTillsynsobjektDeladKontakt_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recTillsynsobjektID, bolHuvudkontaktperson, bolHuvudverksamhetsutoevare  FROM DELETED

        OPEN tbTrTillsynsobjektDeladKontakt_cursor
        FETCH NEXT FROM tbTrTillsynsobjektDeladKontakt_cursor INTO @recTillsynsobjektID, @kontaktperson, @verksamhetsutoevare
        WHILE (@@fetch_status = 0)
        BEGIN
            IF @kontaktperson = 1
                BEGIN
                    UPDATE tbTrTillsynsobjekt
                    SET tbTrTillsynsobjekt.recKontaktPersonID = NULL
                    WHERE recTillsynsobjektID =@recTillsynsobjektID
                END
            IF @verksamhetsutoevare = 1
                BEGIN
                    UPDATE tbTrTillsynsobjekt
                    SET tbTrTillsynsobjekt.recVerksamhetsutoevareKontaktID = NULL
                    WHERE recTillsynsobjektID =@recTillsynsobjektID
                END
            FETCH NEXT FROM tbTrTillsynsobjektDeladKontakt_cursor INTO @recTillsynsobjektID, @kontaktperson, @verksamhetsutoevare
        END

        CLOSE tbTrTillsynsobjektDeladKontakt_cursor
        DEALLOCATE tbTrTillsynsobjektDeladKontakt_cursor
        END
        go

