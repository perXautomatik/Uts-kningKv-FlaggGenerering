CREATE VIEW dbo.vwMifoRevidering
AS
SELECT     dbo.tbMifoRevidering.recRevideringID, dbo.tbMifoRevidering.recObjektID, dbo.tbMifoRevidering.strRevNamn, dbo.tbMifoRevidering.datRevDatum,
                      dbo.tbMifoObjekt.strObjektId, dbo.tbMifoObjekt.strObjektNamn, dbo.tbMifoRevidering.recRevideringID AS intRecnum,
                      dbo.tbMifoRevidering.strBlankettNamn, dbo.tbMifoRevidering.bolUppraettad
FROM         dbo.tbMifoRevidering LEFT OUTER JOIN
                      dbo.tbMifoObjekt ON dbo.tbMifoRevidering.recObjektID = dbo.tbMifoObjekt.recObjektID
go

