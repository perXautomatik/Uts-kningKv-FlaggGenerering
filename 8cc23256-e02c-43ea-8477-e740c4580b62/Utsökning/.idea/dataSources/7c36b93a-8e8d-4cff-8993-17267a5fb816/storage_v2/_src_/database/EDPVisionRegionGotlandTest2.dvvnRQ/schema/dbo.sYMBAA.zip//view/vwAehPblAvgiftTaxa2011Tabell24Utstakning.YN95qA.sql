


CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell24Utstakning]
AS
SELECT  recPblAvgiftTaxa2011Tabell24UtstakningID, 
		recPblAvgiftTaxa2011Tabell24UtstakningID as 'intRecnum',
		recPblAvgiftTaxa2011Tabell24ID,
		strObjekt, 
		intUF, 
		strBeskrivning,
		strReducering
		
FROM    dbo.tbAehPblAvgiftTaxa2011Tabell24Utstakning



go

