CREATE VIEW dbo.vwFasDelaegandeFastighet
AS
SELECT     dbo.tbFasSAGAFAST.strFNRID, dbo.tbFasSAGAFAST.strDELFNRID, dbo.tbFasSAGAFAST.strSORT, dbo.tbFasSAGAFAST.strANDEL, dbo.tbFasSAGAFAST.recSAGAFAST, 
                      dbo.tbFasSAGAFAST.recSAGAFAST AS intRecnum, dbo.tbFasSAGAFAST.strDATUMLOP, dbo.tbFasSAGAFAST.strOTYP, dbo.vwFasFastighet.strFastighetsbeteckning, 
                      dbo.vwFasFastighet.strKOMMUN, dbo.vwFasFastighet.strTRAKT, dbo.vwFasFastighet.strBLOCK, dbo.vwFasFastighet.strTKN, dbo.vwFasFastighet.intENHET
FROM         dbo.tbFasSAGAFAST LEFT OUTER JOIN
                      dbo.vwFasFastighet ON dbo.tbFasSAGAFAST.strDELFNRID = dbo.vwFasFastighet.strFNRID
go

