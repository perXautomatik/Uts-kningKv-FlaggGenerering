CREATE VIEW [dbo].[vwEDPLogins]
AS
SELECT     TOP (100) PERCENT dbo.tbEDPLogins.intLoginID AS intRecnum, dbo.tbEDPLogins.intUserID, dbo.tbEDPUser.strUserWindowsAccount, 
					  dbo.tbEDPLogins.datTime, dbo.tbEDPLoginAction.strLoginAction
FROM         dbo.tbEDPUser INNER JOIN
					  dbo.tbEDPLogins ON dbo.tbEDPUser.intUserID = dbo.tbEDPLogins.intUserID INNER JOIN
					  dbo.tbEDPLoginAction ON dbo.tbEDPLogins.loginAction = dbo.tbEDPLoginAction.intLoginActionID
go

