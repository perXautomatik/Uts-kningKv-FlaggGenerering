
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell4]
AS
SELECT     

recTabell4ID, 
recTaxa2011ID, 
recTabell4ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell4.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell4.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell4

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell4.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell4.recTjaenstID


go

