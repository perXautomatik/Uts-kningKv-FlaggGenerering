
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell14]
AS
SELECT     

recTabell14ID, 
recTaxa2011ID, 
recTabell14ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell14.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell14.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell14

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell14.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell14.recTjaenstID


go

