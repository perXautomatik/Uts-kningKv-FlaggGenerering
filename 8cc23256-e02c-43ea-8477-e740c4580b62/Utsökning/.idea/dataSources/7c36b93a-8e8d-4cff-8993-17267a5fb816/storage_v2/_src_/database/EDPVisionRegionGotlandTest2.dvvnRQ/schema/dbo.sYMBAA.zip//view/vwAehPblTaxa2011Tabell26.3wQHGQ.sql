


CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell26]
AS
SELECT	recTabell26ID,
		recTabell26ID as 'intRecnum', 
		recTaxa2011ID, 
		tbAehPblTaxa2011Tabell26.recTjaenstID, 
		tbAehPblTaxa2011Tabell26.recFakturatextID, 		
		strFritext, 
		decMoms,
		tbVisTjaenst.strTjaenstKod,
		tbVisTjaenst.strTjaenst,
		tbVisFakturatext.strFakturatextkod

FROM	dbo.tbAehPblTaxa2011Tabell26

LEFT OUTER JOIN tbVisFakturatext
	ON tbVisFakturatext.recFakturatextID = tbAehPblTaxa2011Tabell26.recFakturatextID
	
LEFT OUTER JOIN tbVisTjaenst
	ON tbVisTjaenst.recTjaenstID = tbAehPblTaxa2011Tabell26.recTjaenstID



go

