
CREATE VIEW [dbo].[vwTrAatgaerd]
AS
SELECT  
tbTrAatgaerd.recAatgaerdID, 
		tbTrAatgaerd.recAatgaerdID AS intRecnum, 
		tbTrAatgaerd.strRapporteringsID, 
		tbTrAatgaerd.datBeslutsdatum, 
		tbTrAatgaerd.intVitesbelopp, 
        tbTrAatgaerd.strVitestyp, 
        tbTrAatgaerd.strAatgaerd, 
        tbTrAatgaerd.recTillsynsobjektID, 
        tbTrTillsynsobjekt.strObjektsNamn, 
        tbTrVerksamhet.strVerksamhetnamn, 
        tbTrVerksamhet.strVerksamhetnamn + ISNULL(' / ' + tbTrTillsynsobjekt.strObjektsNamn, '') 
        AS strVerksamhetnamnObjektnamn, 
        tbTrTillsynsbesoek.recTillsynsbesoekID, 
        CONVERT(VARCHAR, tbTrAatgaerd.recTillsynsobjektID) + '/' + 
        CONVERT(VARCHAR(10), tbTrAatgaerd.datBeslutsdatum, 121) AS UFIC, 
        CONVERT(VARCHAR, tbTrAatgaerd.recTillsynsobjektID) + ISNULL('/' + 
        CONVERT(VARCHAR(10), tbTrTillsynsbesoek.datDatum, 121), '') AS strTillsynsbesoek, 
        /* Skapa kommaseparerad lista med orsaker*/ 
        
        STUFF ((SELECT     ', Orsak ' + CAST(tbTrChecklistamallVersionPunkt.strRapporteringsPunkt  AS VARCHAR)
FROM    tbTrAatgaerdChecklistamallVersionPunkt LEFT JOIN
        tbTrChecklistamallVersionPunkt 
ON 
        tbTrAatgaerdChecklistamallVersionPunkt.recChecklistamallVersionPunktID =				tbTrChecklistamallVersionPunkt.recChecklistamallVersionPunktID 
LEFT JOIN
        tbTrChecklistamallVersionOmraade 
ON 
        tbTrChecklistamallVersionOmraade.recChecklistamallVersionOmraadeID = tbTrChecklistamallVersionPunkt.recChecklistamallVersionOmraadeID
WHERE   tbTrAatgaerdChecklistamallVersionPunkt.recAatgaerdID = tbTrAatgaerd.recAatgaerdID 
AND (tbTrChecklistamallVersionPunkt.strRapporteringsPunkt <>'NULL' AND tbTrChecklistamallVersionPunkt.strRapporteringsPunkt <> '')
FOR XML PATH('')), 1, 2, '') AS strOrsakerRapportering
,
        
        
        STUFF ((SELECT     ', Orsak ' + CAST(tbTrChecklistamallVersionOmraade.intNummer AS VARCHAR) 
        + '.' + CAST(tbTrChecklistamallVersionPunkt.intNummer AS VARCHAR)
FROM    tbTrAatgaerdChecklistamallVersionPunkt LEFT JOIN
        tbTrChecklistamallVersionPunkt 
ON 
        tbTrAatgaerdChecklistamallVersionPunkt.recChecklistamallVersionPunktID =				tbTrChecklistamallVersionPunkt.recChecklistamallVersionPunktID 
LEFT JOIN
        tbTrChecklistamallVersionOmraade 
ON 
        tbTrChecklistamallVersionOmraade.recChecklistamallVersionOmraadeID = tbTrChecklistamallVersionPunkt.recChecklistamallVersionOmraadeID
WHERE   tbTrAatgaerdChecklistamallVersionPunkt.recAatgaerdID = tbTrAatgaerd.recAatgaerdID 
FOR XML PATH('')), 1, 2, '') AS strOrsaker
FROM    tbTrAatgaerd 
LEFT JOIN tbTrTillsynsobjekt ON tbTrTillsynsobjekt.recTillsynsobjektID = tbTrAatgaerd.recTillsynsobjektID 
LEFT JOIN tbTrVerksamhet ON tbTrVerksamhet.recVerksamhetID = tbTrTillsynsobjekt.recVerksamhetID 
LEFT JOIN tbTrTillsynsbesoekAatgaerd ON tbTrTillsynsbesoekAatgaerd.recAatgaerdID = tbTrAatgaerd.recAatgaerdID 
LEFT JOIN tbTrTillsynsbesoek ON tbTrTillsynsbesoek.recTillsynsbesoekID = tbTrTillsynsbesoekAatgaerd.recTillsynsbesoekID

go

