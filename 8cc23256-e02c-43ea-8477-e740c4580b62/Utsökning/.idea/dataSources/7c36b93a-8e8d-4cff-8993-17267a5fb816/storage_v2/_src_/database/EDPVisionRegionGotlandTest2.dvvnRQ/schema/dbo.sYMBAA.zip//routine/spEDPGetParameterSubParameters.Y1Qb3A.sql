CREATE PROCEDURE [dbo].[spEDPGetParameterSubParameters]
	-- Add the parameters for the stored procedure here
	@intParameterID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
SELECT     tbEDPParameterSubParameter.intParameterID, tbEDPParameterSubParameter.intSubParameterID, 
                      tbEDPParameterSubParameter.intSubParameterPriority, tbEDPSubParameter.strSubParameterName, 
                      tbEDPSubParameter.strSubParameterValueLookUpID, tbEDPSubParameter.intSubParameterValueLength, tbEDPValueType.strValueTypeName
FROM         tbEDPParameterSubParameter INNER JOIN
                      tbEDPSubParameter ON tbEDPParameterSubParameter.intSubParameterID = tbEDPSubParameter.intSubParameterID INNER JOIN
                      tbEDPValueType ON tbEDPSubParameter.intSubParameterValueTypeID = tbEDPValueType.intValueTypeID
WHERE     (tbEDPParameterSubParameter.intParameterID = @intParameterID)
ORDER BY tbEDPParameterSubParameter.intSubParameterPriority
END
go

