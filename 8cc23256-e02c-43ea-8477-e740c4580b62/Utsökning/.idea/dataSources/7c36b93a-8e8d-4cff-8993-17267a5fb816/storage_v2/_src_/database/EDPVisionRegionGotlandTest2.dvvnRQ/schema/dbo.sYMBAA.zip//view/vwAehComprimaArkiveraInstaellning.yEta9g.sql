
-- Vyer
CREATE VIEW [dbo].[vwAehComprimaArkiveraInstaellning]
AS
SELECT 
	recInstaellningID
	, recInstaellningID As intRecNum
	, strRubrik
	, decNivaa
	, strCertificat
	, strBehaallFiler
	, strURL
	, strUser
	, strPassword
	, strRegister
	, strSoekUrl
FROM tbAehComprimaArkiveraInstaellning

go

