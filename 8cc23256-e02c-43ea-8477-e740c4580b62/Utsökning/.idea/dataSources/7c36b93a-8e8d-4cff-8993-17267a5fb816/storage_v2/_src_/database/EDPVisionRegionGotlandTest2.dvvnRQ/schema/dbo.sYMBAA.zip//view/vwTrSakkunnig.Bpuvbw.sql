

CREATE VIEW [dbo].[vwTrSakkunnig]
AS
WITH KontaktKommunikationssaett AS (
SELECT recEnstakaKontaktID, 
   
    (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Telefon' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
       WHERE  dbo.tbTrSakkunnig.recEnstakaKontaktID = dbo.tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strTelefon,

   (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Mobil' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
       WHERE  dbo.tbTrSakkunnig.recEnstakaKontaktID = dbo.tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strMobil	,

   (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Fax' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
       WHERE  dbo.tbTrSakkunnig.recEnstakaKontaktID = dbo.tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strFax,	

   (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'E-post' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
       WHERE  dbo.tbTrSakkunnig.recEnstakaKontaktID = dbo.tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strEpost	


FROM tbTrSakkunnig
)


SELECT		strTelefon,
			strMobil,
			strFax,
			strEpost,
			tbTrSakkunnig.recSakkunnigID, 
			tbTrSakkunnig.recSakkunnigID AS intRecnum, 
			tbTrSakkunnig.recEnstakaKontaktID, 
			tbTrSakkunnig.strAnteckning, 
			tbTrSakkunnig.bolEjAktuell, 
			tbTrSakkunnig.recServiceFoeretagID,
			
			sakkunnig.strFoernamn, 
			sakkunnig.strEfternamn, 
			sakkunnig.strOrginisationPersonnummer, 
			sakkunnig.strTitel, 
			sakkunnig.strKontaktTyp, 
			sakkunnig.strGatuadress, 
			sakkunnig.strCoadress, 
			sakkunnig.strPostnummer, 
			sakkunnig.strPostort, 
			sakkunnig.strLand, 
			sakkunnig.strSammanslagenAdress, 
			
			--sakkunnig.strVisasSom, 
			(SELECT ISNULL(sakkunnig.strFoernamn, '') + ' ' + ISNULL(sakkunnig.strEfternamn, '') + 
			  ISNULL(' (' + serviceföretag.strFoeretag + ')', '')) AS strVisasSom, 
			
			serviceföretag.strFoeretag, 
			
			(SELECT ISNULL(sakkunnig.strFoernamn, '') + ' ' + ISNULL(sakkunnig.strEfternamn, '')) AS strNamn,
					
			STUFF(
				(	
				SELECT ',' + strKommunikationsaettTyp + '-' + strVaerde 
				FROM tbVisKommunikationssaett 
				INNER JOIN dbo.tbVisEnstakaKontaktKommunikationssaett
					ON dbo.tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID 
				WHERE dbo.tbTrSakkunnig.recEnstakaKontaktID = dbo.tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID
				FOR XML PATH('')
				)
				, 1, 1, ''
			) AS strKommunikationTypVaerde,

			STUFF(
				(
					SELECT		',  ' + ISNULL(strCertifieringsTyp, '') + ' / ' + ISNULL(strBehoerighet, '')+ ' / ' + ISNULL(strCertifieringsnummer, '')  + ' / ' + ISNULL(CONVERT(varchar(10), datCertifieradTillOchMed, 20), '')
					FROM dbo.tbTrCertifiering						
					INNER JOIN dbo.tbTrCertifieringSakkunnig
							ON dbo.tbTrCertifieringSakkunnig.recCertifieringID = tbTrCertifiering.recCertifieringID
					WHERE tbTrCertifieringSakkunnig.recSakkunnigID = tbTrSakkunnig.recSakkunnigID
					ORDER BY strCertifieringsTyp
					for xml path('')
				)
				, 1, 2, ''
			) AS strCertifieringsdataCSV

FROM		dbo.tbTrSakkunnig 

inner JOIN	tbVisEnstakaKontakt AS sakkunnig 
			ON sakkunnig.recEnstakaKontaktID = tbTrSakkunnig.recEnstakaKontaktID
LEFT JOIN	tbTrServiceFoeretag
			ON tbTrServiceFoeretag.recServiceFoeretagID = tbTrSakkunnig .recServiceFoeretagID
left JOIN	tbVisEnstakaKontakt AS serviceföretag
			ON serviceföretag.recEnstakaKontaktID = tbTrServiceFoeretag.recEnstakaKontaktID

LEFT OUTER JOIN KontaktKommunikationssaett
  ON KontaktKommunikationssaett.recEnstakaKontaktID = tbTrSakkunnig.recEnstakaKontaktID



go

