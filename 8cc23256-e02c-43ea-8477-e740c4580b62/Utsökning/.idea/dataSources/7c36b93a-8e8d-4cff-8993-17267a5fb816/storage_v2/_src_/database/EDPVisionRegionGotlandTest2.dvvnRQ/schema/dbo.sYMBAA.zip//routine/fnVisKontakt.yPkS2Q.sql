
CREATE FUNCTION [dbo].[fnVisKontakt] (@datSkapad DATETIME)
RETURNS TABLE 
AS
  RETURN (
    SELECT * FROM [dbo].[vwVisKontaktHistorik]
    WHERE recKontaktHistorik IN (
      SELECT TOP 1 recKontaktHistorik FROM [dbo].[tbVisKontaktHistorik]
      WHERE tbVisKontaktHistorik.intMainTableID = recKontaktID
      AND datSkapad <= ISNULL(@datSkapad, GETDATE())
      ORDER BY datSkapad DESC
    )
);
go

