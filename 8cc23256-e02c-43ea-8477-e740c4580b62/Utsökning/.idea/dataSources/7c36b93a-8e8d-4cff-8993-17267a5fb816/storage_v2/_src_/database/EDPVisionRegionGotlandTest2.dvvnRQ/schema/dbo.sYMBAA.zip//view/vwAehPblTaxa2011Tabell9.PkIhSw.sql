
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell9]
AS
SELECT     

recTabell9ID, 
recTaxa2011ID, 
recTabell9ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell9.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell9.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell9

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell9.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell9.recTjaenstID


go

