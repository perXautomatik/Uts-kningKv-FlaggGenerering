

CREATE VIEW [dbo].[vwEDPFileUnmanagedFiles]
AS
SELECT    recUnmanagedfileID
		, recUnmanagedfileID as intRecnum
		, strFullFilePath
		, recHaendelseID
		, recMoeteID
		, recMoetespunktID
		, strFileName
		, intUserID
		, datDatum
		, recFilMallID
		, bolMassbrev

FROM    dbo.tbEDPFileUnmanagedFiles
go

