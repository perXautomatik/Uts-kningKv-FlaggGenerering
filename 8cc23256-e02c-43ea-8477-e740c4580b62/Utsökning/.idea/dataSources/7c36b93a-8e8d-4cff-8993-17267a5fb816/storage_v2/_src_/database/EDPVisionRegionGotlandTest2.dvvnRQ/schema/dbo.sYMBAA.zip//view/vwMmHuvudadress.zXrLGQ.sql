CREATE VIEW dbo.vwMmHuvudadress
AS
SELECT     bolHuvudadress, recGatuadressID, recOmrID, strAdress
FROM         dbo.tbMmGatuadress
WHERE     (bolHuvudadress = 1)
go

