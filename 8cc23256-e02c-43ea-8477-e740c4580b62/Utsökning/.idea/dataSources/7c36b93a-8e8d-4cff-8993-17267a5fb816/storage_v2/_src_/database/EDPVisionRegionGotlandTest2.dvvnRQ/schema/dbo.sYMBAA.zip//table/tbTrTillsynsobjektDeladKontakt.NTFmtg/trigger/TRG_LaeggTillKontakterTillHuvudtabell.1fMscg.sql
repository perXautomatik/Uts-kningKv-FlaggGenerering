
        CREATE TRIGGER TRG_LaeggTillKontakterTillHuvudtabell ON tbTrTillsynsobjektDeladKontakt
        AFTER INSERT, UPDATE
        AS
        BEGIN
        SET NOCOUNT ON;
        DECLARE @recTillsynsobjektID INT
        DECLARE tbTrTillsynsobjektDeladKontakt_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recTillsynsobjektID FROM INSERTED

        OPEN tbTrTillsynsobjektDeladKontakt_cursor
        FETCH NEXT FROM tbTrTillsynsobjektDeladKontakt_cursor INTO @recTillsynsobjektID
        WHILE (@@fetch_status = 0)
        BEGIN
            UPDATE tbTrTillsynsobjekt
            SET recKontaktPersonID =
                (SELECT TOP 1 recDeladKontaktID FROM tbTrTillsynsobjektDeladKontakt
                WHERE recTillsynsobjektID = @recTillsynsobjektID
                AND bolHuvudkontaktperson = 1
                AND strRoll = 'Kontaktperson')
            WHERE tbTrTillsynsobjekt.recTillsynsobjektID = @recTillsynsobjektID

            UPDATE tbTrTillsynsobjekt
            SET recVerksamhetsutoevareKontaktID =
                (SELECT TOP 1 recDeladKontaktID FROM tbTrTillsynsobjektDeladKontakt
                WHERE recTillsynsobjektID = @recTillsynsobjektID
                AND bolHuvudverksamhetsutoevare = 1
                AND strRoll = 'Verksamhetsutövare')
            WHERE tbTrTillsynsobjekt.recTillsynsobjektID = @recTillsynsobjektID

            FETCH NEXT FROM tbTrTillsynsobjektDeladKontakt_cursor INTO @recTillsynsobjektID
        END

        CLOSE tbTrTillsynsobjektDeladKontakt_cursor
        DEALLOCATE tbTrTillsynsobjektDeladKontakt_cursor
        END
        go

