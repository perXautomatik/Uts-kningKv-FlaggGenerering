-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spGetRelationBetweenTables]
	-- Add the parameters for the stored procedure here
	@LeftTableName nvarchar(300),
	@RightTableName nvarchar(300)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
;WITH CTE AS
(
SELECT
	OBJECT_NAME(foreign_keys.parent_object_id) As TabellNamn,
	OBJECT_NAME(foreign_keys.referenced_object_id) As OtherTabellNamn,
	sys.columns.name AS KolumnNamn,
	sys.types.name As DataTyp
FROM sys.foreign_keys
INNER JOIN sys.foreign_key_columns ON sys.foreign_key_columns.constraint_object_id = sys.foreign_keys.object_id
INNER JOIN sys.columns ON sys.foreign_key_columns.parent_object_id = sys.columns.object_id AND sys.foreign_key_columns.parent_column_id = sys.columns.column_id
INNER JOIN sys.types ON sys.columns.system_type_id = sys.types.system_type_id
WHERE sys.types.name <> 'sysname'

UNION

SELECT
	OBJECT_NAME(foreign_keys.referenced_object_id) As TabellNamn,
	OBJECT_NAME(foreign_keys.parent_object_id) As OtherTabellNamn,
	sys.columns.name AS KolumnNamn,
	sys.types.name As DataTyp
FROM sys.foreign_keys
INNER JOIN sys.foreign_key_columns ON sys.foreign_key_columns.constraint_object_id = sys.foreign_keys.object_id
INNER JOIN sys.columns ON sys.foreign_key_columns.referenced_object_id = sys.columns.object_id AND sys.foreign_key_columns.referenced_column_id = sys.columns.column_id
INNER JOIN sys.types ON sys.columns.system_type_id = sys.types.system_type_id
WHERE sys.types.name <> 'sysname'

)
SELECT TabellNamn, KolumnNamn, DataTyp FROM CTE
WHERE (TabellNamn = @LeftTableName AND OtherTabellNamn = @RightTableName) OR
	  (TabellNamn = @RightTableName AND OtherTabellNamn = @LeftTableName)

END
go

