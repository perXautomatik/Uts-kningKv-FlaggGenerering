



CREATE VIEW [dbo].[vwTrBvBrandfarligVara]
AS
SELECT	[tbTrBvBrandfarligVara].[recBrandfarligVaraID],
		[tbTrBvBrandfarligVara].[recBrandfarligVaraID] AS intRecnum,
		[tbTrBvBrandfarligVara].[recTillsynsobjektID],
		[tbTrBvBrandfarligVara].[intCisternVolymLiter],
		[tbTrBvBrandfarligVara].[strPlacering],
		[tbTrBvBrandfarligVara].[strCisterntyp],
		[tbTrBvBrandfarligVara].[strSerienummer],
		[tbTrBvBrandfarligVara].[strBeskrivning],
		[tbTrBvBrandfarligVara].[datTillstaandAnmaelan],
		[tbTrBvBrandfarligVara].[strInnehaall],
		[tbTrBvBrandfarligVara].[strRoerledning],
		[tbTrBvBrandfarligVara].[strVattenskyddssomraade],
		[tbTrBvBrandfarligVara].[strHaardgjordYta],
		[tbTrBvBrandfarligVara].[intInvallningVolymLiter],
		[tbTrBvBrandfarligVara].[bolPaafyllnadsskydd],
		[tbTrBvBrandfarligVara].[bolKorrosionsskydd],
		[tbTrBvBrandfarligVara].[intKontrollintervallAar],
		[tbTrBvBrandfarligVara].[datSenasteKontroll],
		[tbTrBvBrandfarligVara].[datNaestaKontroll],
		[tbTrBvBrandfarligVara].[strStatus],
		[tbTrBvBrandfarligVara].[datStatusDatum],
		[tbTrBvBrandfarligVara].strAnteckning,

		[tbVisDeladFastighet].[strFastighetsbeteckning],
		[tbVisDeladFastighet].[strFnrID]
FROM [dbo].[tbTrBvBrandfarligVara]
LEFT OUTER JOIN [dbo].[tbTrBvBrandfarligVaraFastighet]
ON [tbTrBvBrandfarligVaraFastighet].[recBrandfarligVaraID] = [tbTrBvBrandfarligVara].[recBrandfarligVaraID]
AND [tbTrBvBrandfarligVaraFastighet].[bolHuvudfastighet] = 1
LEFT OUTER JOIN [dbo].[tbVisDeladFastighet]
ON [tbVisDeladFastighet].[strFnrID] = [tbTrBvBrandfarligVaraFastighet].[strFnrID]


go

