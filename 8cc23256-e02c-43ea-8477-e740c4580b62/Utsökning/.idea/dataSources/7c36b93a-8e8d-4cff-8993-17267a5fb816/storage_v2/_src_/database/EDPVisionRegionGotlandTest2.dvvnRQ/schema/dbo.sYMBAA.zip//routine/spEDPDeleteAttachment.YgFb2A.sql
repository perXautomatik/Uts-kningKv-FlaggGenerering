/****** Object:  StoredProcedure [dbo].[spEDPDeleteAttachment]    Script Date: 09/28/2006 17:14:07 ******/
CREATE PROCEDURE [dbo].[spEDPDeleteAttachment]
  @intAttachmentID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	delete from tbEDPAttachment where intAttachmentID = @intAttachmentID
END
go

