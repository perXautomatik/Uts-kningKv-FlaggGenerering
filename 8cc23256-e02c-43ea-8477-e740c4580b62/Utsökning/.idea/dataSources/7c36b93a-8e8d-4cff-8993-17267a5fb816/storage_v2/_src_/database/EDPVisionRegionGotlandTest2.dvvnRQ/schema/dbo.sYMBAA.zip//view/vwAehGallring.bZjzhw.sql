CREATE VIEW [dbo].[vwAehGallring]
AS
SELECT
	dbo.tbAehGallring.recGallringID,
	dbo.tbAehGallring.recGallringID as intRecnum,

	dbo.tbAehGallring.datGallringsDatum,
	dbo.tbAehGallring.strMyndighet,
	dbo.tbAehGallring.strHandlingsslag,
	dbo.tbAehGallring.strGallringsbeslut,
	dbo.tbAehGallring.intUserID,
	dbo.tbEDPUser.strSignature

FROM dbo.tbAehGallring
LEFT JOIN dbo.tbEDPUser ON dbo.tbAehGallring.intUserID = dbo.tbEDPUser.intUserID
go

