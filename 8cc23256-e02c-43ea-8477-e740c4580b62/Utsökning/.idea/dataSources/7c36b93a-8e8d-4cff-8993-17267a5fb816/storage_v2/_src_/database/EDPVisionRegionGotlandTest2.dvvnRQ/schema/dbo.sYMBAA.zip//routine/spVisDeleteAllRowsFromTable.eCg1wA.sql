/****** Object:  StoredProcedure [dbo].[spVisDeleteAllRowsFromTable]    Script Date: 04/20/2007 14:46:49 ******/
CREATE PROCEDURE [dbo].[spVisDeleteAllRowsFromTable]
@strTableName varchar(128)
AS
BEGIN
    declare @sql nvarchar(300)
    set @sql = 'DELETE FROM '+@strTableName
    exec sp_executesql @sql
END
go

