

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell16Rivningslov]
AS
SELECT     tbAehPblTaxa2011Tabell16Rivningslov.recTabell16ID, 
           recRivningslovID as 'intRecnum', 
		   recRivningslovID,
		   strYta,
		   strBeskrivning, 
		   recTaxa2011ID,
		   intHF
FROM         dbo.tbAehPblTaxa2011Tabell16Rivningslov
LEFT OUTER JOIN vwAehPblTaxa2011Tabell16 
ON vwAehPblTaxa2011Tabell16.recTabell16ID = tbAehPblTaxa2011Tabell16Rivningslov.recTabell16ID


go

