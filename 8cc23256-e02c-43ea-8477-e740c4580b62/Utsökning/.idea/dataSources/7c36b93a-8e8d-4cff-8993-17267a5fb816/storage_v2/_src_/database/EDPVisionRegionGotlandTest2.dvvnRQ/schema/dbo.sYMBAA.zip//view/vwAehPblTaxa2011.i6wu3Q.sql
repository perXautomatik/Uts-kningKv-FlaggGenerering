



CREATE VIEW [dbo].[vwAehPblTaxa2011]
AS
SELECT        dbo.tbAehPblTaxa2011.recTaxa2011ID, 
				dbo.tbAehPblTaxa2011.recTaxa2011ID AS intRecnum, 
				dbo.tbAehPblTaxa2011.recKommunID, 
                dbo.tbVisKommun.strKommunNamn, 
                dbo.tbAehPblTaxa2011.recAvdelningID, 
                dbo.tbVisAvdelning.strAvdelningNamn,
                dbo.tbVisAvdelning.strAvdelningKod, 
                dbo.tbAehPblTaxa2011.datGiltigFraan, 
                dbo.tbAehPblTaxa2011.strBeskrivning, 
                dbo.tbAehPblTaxa2011.decNFaktor, 
                dbo.tbAehPblTaxa2011.decPbb, 
                dbo.tbAehPblTaxa2011.intTimpris,
                dbo.tbAehPblTaxa2011.bolEjAktuell
                
FROM            dbo.tbAehPblTaxa2011 LEFT OUTER JOIN dbo.tbVisKommun 
				ON dbo.tbAehPblTaxa2011.recKommunID = dbo.tbVisKommun.recKommunID 
				LEFT OUTER JOIN dbo.tbVisAvdelning 
                ON dbo.tbAehPblTaxa2011.recAvdelningID = dbo.tbVisAvdelning.recAvdelningID



go

