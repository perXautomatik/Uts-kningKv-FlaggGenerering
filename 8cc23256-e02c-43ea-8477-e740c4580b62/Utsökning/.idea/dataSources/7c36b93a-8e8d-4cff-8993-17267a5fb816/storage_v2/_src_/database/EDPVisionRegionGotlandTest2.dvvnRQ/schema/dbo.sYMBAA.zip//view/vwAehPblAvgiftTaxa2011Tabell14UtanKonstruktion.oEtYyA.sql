

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell14UtanKonstruktion]
AS
SELECT        recPblAvgiftTaxa2011Tabell14ID
			, recPblAvgiftTaxa2011Tabell14UtanKonstruktionID
			, recPblAvgiftTaxa2011Tabell14UtanKonstruktionID as 'intRecnum'
			, strObjekt
			, strBeskrivning
			, intOF
			, intHF1
			, intHF2
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell14UtanKonstruktion
go

