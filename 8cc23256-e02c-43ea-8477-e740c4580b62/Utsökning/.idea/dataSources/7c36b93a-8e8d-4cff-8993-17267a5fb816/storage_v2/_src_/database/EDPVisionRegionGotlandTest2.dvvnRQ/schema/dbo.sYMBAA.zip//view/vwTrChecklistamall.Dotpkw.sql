



CREATE VIEW [dbo].[vwTrChecklistamall]
AS
SELECT
dbo.tbTrChecklistamall.recChecklistamallID,
dbo.tbTrChecklistamall.recChecklistamallID AS intRecnum,
dbo.tbTrChecklistamall.strNamn,
dbo.tbTrChecklistamall.strBeskrivning,
dbo.tbTrChecklistamall.bolStandardchecklista,
dbo.tbTrChecklistamall.bolEjAktuell,
tbTrChecklistamall.recTillsynsobjektTypID,
tbTrTillsynsobjektsTyp.strTillsynsobjektsTypNamn,
(SELECT TOP (1) recChecklistaVersionID FROM tbTrChecklistamallVersion
    WHERE tbTrChecklistamall.recChecklistamallID = tbTrChecklistamallVersion.recChecklistamallID
    ORDER BY tbTrChecklistamallVersion.strFilversion DESC) as recChecklistaVersionID,
(SELECT TOP (1) strFilversion FROM tbTrChecklistamallVersion
    WHERE tbTrChecklistamall.recChecklistamallID = tbTrChecklistamallVersion.recChecklistamallID
    ORDER BY tbTrChecklistamallVersion.strFilversion DESC) as strFilversion
FROM dbo.tbTrChecklistamall
LEFT OUTER JOIN dbo.tbTrTillsynsobjektsTyp
ON dbo.tbTrTillsynsobjektsTyp.recTillsynsobjektTypID = dbo.tbTrChecklistamall.recTillsynsobjektTypID
go

