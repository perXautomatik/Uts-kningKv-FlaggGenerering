

-- spEDPGetParameterWithValueType START
CREATE PROCEDURE [dbo].[spEDPGetParameterWithValueType] 
	@strParameterName varchar(200)
AS
BEGIN
declare  @strParameterValueDefault varchar(200) 
declare  @strValueTypeName varchar(200) 


	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
SET @strParameterValueDefault = (SELECT strParameterValueDefault from vwEDPParameterValueType
    WHERE strParameterName = @strParameterName)

SET @strValueTypeName = (SELECT strValueTypeName from vwEDPParameterValueType
    WHERE strParameterName = @strParameterName)

select  @strValueTypeName,@strParameterValueDefault

END
go

