
CREATE VIEW [dbo].[vwEDPDocumentTemplate]
AS
SELECT     dbo.tbEDPFileObject.strDescription, dbo.tbEDPFileObject.strFileName, dbo.tbEDPDocumentFormat.strFormat, 
                      dbo.tbEDPDocumentTemplate.strDocumentTemplateName, dbo.tbEDPDocumentTemplate.strCategory, dbo.tbEDPDocumentTemplate.recFileObjectID, 
                      dbo.tbEDPDocumentTemplate.recDocumentTemplateID, dbo.tbEDPDocumentTemplate.recDocumentTemplateID AS intRecNum, 
                      dbo.tbEDPDocumentTemplate.bolDefault, dbo.tbEDPDocumentTemplate.recFormatID, 
                      dbo.tbEDPDocumentTemplate.strDocumentNameFormat, dbo.tbEDPDocumentTemplate.bolPersonuppgift 
FROM         dbo.tbEDPDocumentTemplate INNER JOIN
                      dbo.tbEDPFileObject ON dbo.tbEDPDocumentTemplate.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID INNER JOIN
                      dbo.tbEDPDocumentFormat ON dbo.tbEDPDocumentTemplate.recFormatID = dbo.tbEDPDocumentFormat.recFormatID
go

