CREATE VIEW [dbo].[vwFasTidigareFastBeteckningFoere]
AS
SELECT     recGTIBET, strOTYP, strDATUMLOP, strFNRID, intLOPID, strOMDAT, strAKT, strREGO, strTREGAST, strBLKVSS, strTKN, strENHET, 
                      ISNULL(strTREGAST, '') + ' ' + ISNULL(strBLKVSS, '') + ISNULL(strTKN, '') + ISNULL(strENHET, '') AS strFastighetsbeteckning, 
                      recGTIBET AS intRecnum
FROM         dbo.tbFasGTIBET

go

