CREATE PROCEDURE [dbo].[spEDPGetParameterSubParameterValues]
  @intParameterID as int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

SELECT     intSubParameterID, strSubParameterValue, strValue, intGroupID, strValueTypeName, intSubParameterPriority, strParameterName, 
                      strSubParameterName, strSearchMethodName, intParameterID, strParameterValueLookUpID, strSubParameterValueLookUpID
FROM         vwEDPParameterSubParameterValue
WHERE     (intParameterID = @intParameterID)
ORDER BY intSubParameterPriority, strSubParameterValue, intGroupID
END
go

