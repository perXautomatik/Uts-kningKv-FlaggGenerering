
            CREATE VIEW [dbo].[vwEDPFileStorageLocation]
            AS
            SELECT     dbo.tbEDPFileStorageLocation.recFileStorageLocationID, dbo.tbEDPFileStorageLocation.strFileStorageLocationName, 
                                  dbo.tbEDPFileStorageLocation.bolIsCurrentStorageLocation, CASE WHEN strDataBaseName IS NULL THEN CAST('FS' AS varchar(2)) 
                                  WHEN strDataBaseName IS NOT NULL THEN CAST('DB' AS varchar(2)) ELSE NULL END AS strFileStorageType, 
                                  dbo.tbEDPFileStorageLocation.recFileStorageLocationID AS intRecnum, dbo.tbEDPFileStorageLocationFileStructure.strFileStructureDomain, 
                                  dbo.tbEDPFileStorageLocationFileStructure.strFileStructurePassword, dbo.tbEDPFileStorageLocationFileStructure.strFileStructureUserName, 
                                  dbo.tbEDPFileStorageLocationFileStructure.strFileStructurePath, dbo.tbEDPFileStorageLocationDatabase.strDatabasePassword, 
                                  dbo.tbEDPFileStorageLocationDatabase.strDatabaseUserName, dbo.tbEDPFileStorageLocationDatabase.strDatabaseName, 
                                  dbo.tbEDPFileStorageLocationDatabase.strDatabaseServerName, dbo.tbEDPFileStorageLocationDatabase.bolIntegratedSecurity, 
                                  dbo.tbEDPFileStorageLocationFileStructure.recFileStorageLocationFileStructureID, 
                                  dbo.tbEDPFileStorageLocationDatabase.recFileStorageLocationDatabaseID
            FROM         dbo.tbEDPFileStorageLocation LEFT OUTER JOIN
                                  dbo.tbEDPFileStorageLocationDatabase ON 
                                  dbo.tbEDPFileStorageLocation.recFileStorageLocationID = dbo.tbEDPFileStorageLocationDatabase.recFileStorageLocationID LEFT OUTER JOIN
                                  dbo.tbEDPFileStorageLocationFileStructure ON 
                                  dbo.tbEDPFileStorageLocation.recFileStorageLocationID = dbo.tbEDPFileStorageLocationFileStructure.recFileStorageLocationID
            go

