
CREATE PROCEDURE [dbo].[spVisGetTableInformationSchema]
/* $Date: 2005-10-20 12:22:20+02:00 $ */
/* Givet en tabell, @strTableName, så vill vi hitta alla tabeller som */
/* har relationer som gör att vi ev. inte får lov att ta bort en post */
/* ur tabellen. */
/* Komplettera med att (i kod) för varje rad = tabell kolla om en     */
/* TABLE_NAME har en COLUMN_NAME som är den sökta posten i            */
/* @strTableName.                                                     */
@strTableName varchar(128)
AS

	SELECT sc1.name as COLUMN_NAME, 'FOREIGN KEY' as CONSTRAINT_TYPE, object_name(sf.rkeyid) as REFERENCES_TABLE_NAME, sc2.name as REFERENCES_COLUMN_NAME, object_name(sf.constid) AS CONSTRAINT_NAME
	FROM sysforeignkeys  sf
		INNER JOIN sysreferences sr ON sf.constid=sr.constid
		INNER JOIN syscolumns sc1 ON sf.fkeyid = sc1.id AND sf.fkey = sc1.colid
		INNER JOIN syscolumns sc2 ON sf.rkeyid = sc2.id AND sf.rkey = sc2.colid
	WHERE object_name(sf.fkeyid) = @strTableName
UNION
	SELECT COLUMN_NAME, CONSTRAINT_TYPE, '' as REFERENCES_TABLE_NAME, '' as REFERENCES_COLUMN_NAME, INFORMATION_SCHEMA.KEY_COLUMN_USAGE.CONSTRAINT_NAME
	FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
		INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS ON
		INFORMATION_SCHEMA.TABLE_CONSTRAINTS.CONSTRAINT_NAME = INFORMATION_SCHEMA.KEY_COLUMN_USAGE.CONSTRAINT_NAME
	WHERE INFORMATION_SCHEMA.KEY_COLUMN_USAGE.TABLE_NAME = @strTableName
		AND CONSTRAINT_TYPE = 'PRIMARY KEY'

go

