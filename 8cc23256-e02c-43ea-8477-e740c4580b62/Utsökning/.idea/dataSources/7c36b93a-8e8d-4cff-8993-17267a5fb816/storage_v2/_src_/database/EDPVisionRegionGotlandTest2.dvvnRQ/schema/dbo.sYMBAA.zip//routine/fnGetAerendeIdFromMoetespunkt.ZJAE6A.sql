
            CREATE FUNCTION [dbo].[fnGetAerendeIdFromMoetespunkt] 
            (	
	            @moetespunktId int 
            )
            RETURNS TABLE 
            AS
            RETURN 
            (
	            SELECT tmma.recAerendeID FROM dbo.tbMhMoetespunkt tmm		
		            INNER JOIN	dbo.tbMhMoetespunktAerende tmma ON tmma.recMoetespunktID = tmm.recMoetespunktID
		            WHERE tmm.recMoetespunktID = @moetespunktId
	            UNION	SELECT taah.recAerendeID FROM dbo.tbMhMoetespunkt tmm2
		            INNER JOIN	dbo.tbMhMoetespunktHaendelse tmmh ON tmmh.recMoetespunktID = tmm2.recMoetespunktID	
		            INNER JOIN	dbo.tbAehAerendeHaendelse taah	on tmmh.recHaendelseID = taah.recHaendelseID	
		            WHERE tmm2.recMoetespunktID = @moetespunktId
            )
            go

