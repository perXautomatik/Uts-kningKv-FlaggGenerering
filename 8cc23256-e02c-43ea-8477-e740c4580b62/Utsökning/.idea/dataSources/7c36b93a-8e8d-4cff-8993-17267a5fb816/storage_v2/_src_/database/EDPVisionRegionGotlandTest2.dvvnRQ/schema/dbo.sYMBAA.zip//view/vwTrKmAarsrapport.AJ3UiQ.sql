
CREATE VIEW [dbo].[vwTrKmAarsrapport]
AS
SELECT     
	
	dbo.tbTrKmAarsrapport.recAarsrapportID as intRecnum,

	dbo.tbTrKmAarsrapport.recAarsrapportID, 
	dbo.tbTrKmAarsrapport.recTillsynsobjektID, 
	dbo.tbTrKmAarsrapport.intAvserAar, 
	dbo.tbTrKmAarsrapport.datInkom, 
	dbo.tbTrKmAarsrapport.decInstalleradMaengdHFC, 
	dbo.tbTrKmAarsrapport.decInstalleradMaengdHCFC, 
	dbo.tbTrKmAarsrapport.decInstalleradMaengdCFC, 
	dbo.tbTrKmAarsrapport.decPaafylldMaengdHFC, 
	dbo.tbTrKmAarsrapport.decPaafylldMaengdHCFC, 
	dbo.tbTrKmAarsrapport.decPaafylldMaengdCFC, 
	dbo.tbTrKmAarsrapport.decOmhaandertagenMaengdHFC, 
	dbo.tbTrKmAarsrapport.decOmhaandertagenMaengdHCFC, 
    dbo.tbTrKmAarsrapport.decOmhaandertagenMaengdCFC, 
	dbo.tbTrKmAarsrapport.decFoerbrukadMaengdHFC, 
	dbo.tbTrKmAarsrapport.decFoerbrukadMaengdHCFC, 
    dbo.tbTrKmAarsrapport.decFoerbrukadMaengdCFC, 

	dbo.tbTrTillsynsobjekt.strObjektsNamn

FROM dbo.tbTrKmAarsrapport 

INNER JOIN dbo.tbTrTillsynsobjekt 
ON dbo.tbTrKmAarsrapport.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID

go

