
CREATE VIEW [dbo].[vwTrBranschkod]
AS
SELECT     
	dbo.tbTrBranschkod.recBranschkodID, 
	dbo.tbTrBranschkod.recBranschkodID as intRecnum, 
	dbo.tbTrBranschkod.recTillsynsobjektTypID, 
	dbo.tbTrBranschkod.strBranschkod, 
	dbo.tbTrBranschkod.strProevningsplikt, 
	dbo.tbTrBranschkod.strHuvudrubrik, 
	dbo.tbTrBranschkod.strUnderrubrik, 
	dbo.tbTrBranschkod.strBeskrivning, 
	dbo.tbTrBranschkod.strIEDKod, 

    dbo.tbTrTillsynsobjektsTyp.strTillsynsobjektsTypNamn
    
FROM dbo.tbTrBranschkod
INNER JOIN dbo.tbTrTillsynsobjektsTyp 
	ON dbo.tbTrBranschkod.recTillsynsobjektTypID = dbo.tbTrTillsynsobjektsTyp.recTillsynsobjektTypID
go

