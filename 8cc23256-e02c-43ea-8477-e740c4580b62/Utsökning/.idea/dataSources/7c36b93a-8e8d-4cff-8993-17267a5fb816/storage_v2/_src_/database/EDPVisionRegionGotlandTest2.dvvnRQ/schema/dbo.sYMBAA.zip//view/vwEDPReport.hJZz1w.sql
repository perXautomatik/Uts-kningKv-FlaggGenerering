
            CREATE VIEW [dbo].[vwEDPReport]
            AS
            SELECT
                  dbo.tbEDPReport.intReportID AS intRecnum
                , dbo.tbEDPReport.intReportID
                , dbo.tbEDPReportCategory.strReportCategoryName
                , dbo.tbEDPReportCategory.strDataSourceName
                , dbo.tbEDPReport.strReportName
                , dbo.tbEDPReport.intReportCategory
                , dbo.tbEDPReport.binReport
                , dbo.tbEDPReport.strClassName
                , dbo.tbEDPReport.datSkapad
                , dbo.tbEDPReport.strSkapadAv
                , dbo.tbEDPReport.guidLayoutID
                , dbo.tbEDPReport.datUpphor
            FROM dbo.tbEDPReport
            INNER JOIN dbo.tbEDPReportCategory ON dbo.tbEDPReport.intReportCategory = dbo.tbEDPReportCategory.intReportCategoryID
            go

