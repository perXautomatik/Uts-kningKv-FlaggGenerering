CREATE VIEW [dbo].[vwTrLoLokal]
AS
SELECT     recLokalID, recLokalID as intRecnum, recTillsynsobjektID, intBesöksIntervall, datSenasteBesoek, datNaestaBesoek, intAarsavgift, bolSpecialpris, strRabatt, strAttributKod, decJusteradKontrolltid,
                      strAnmaelningspliktig, strAnvaendsTill, intTillsynsnivå, strBeskrivning, datAnmaelningsdatum, strParagraf, datGodkaennandedatum, intByggnadsAar, strOmgivning,
                      strGrund, strTaktyp, strFasad, strTakmaterial, strGaardsyta, strSolskydd, strKommunaltVatten, strKommunaltAvlopp, strVaaning, intLokalYta, strBaerandekonstruktion,
                      strUppvaermning, strVentilation, strEnergiaatervinning, strGolvbelaeggning, strInredning, intAntalPersonerBehandlingsplatser, strLjudabsorbent, strRadon, strGodkaend,
					  datNaestaBesiktning, datOmBesiktning
FROM         dbo.tbTrLoLokal
go

