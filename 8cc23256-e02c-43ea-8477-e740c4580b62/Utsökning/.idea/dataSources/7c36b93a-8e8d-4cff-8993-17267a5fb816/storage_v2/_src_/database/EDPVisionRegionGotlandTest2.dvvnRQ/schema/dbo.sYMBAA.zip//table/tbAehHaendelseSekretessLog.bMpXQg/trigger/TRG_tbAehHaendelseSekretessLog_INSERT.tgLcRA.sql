
        CREATE TRIGGER TRG_tbAehHaendelseSekretessLog_INSERT ON tbAehHaendelseSekretessLog
        AFTER INSERT
        AS
        BEGIN
        SET NOCOUNT ON;

        DECLARE sekretess_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recHaendelseID FROM INSERTED
        OPEN sekretess_cursor
        DECLARE @recHaendelseID INT
        FETCH NEXT FROM sekretess_cursor INTO @recHaendelseID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehHaendelseUpdateSekretesslog @recHaendelseID

            FETCH NEXT FROM sekretess_cursor INTO @recHaendelseID
        END
        CLOSE sekretess_cursor
        DEALLOCATE sekretess_cursor
        END
        go

