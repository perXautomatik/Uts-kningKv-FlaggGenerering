
CREATE VIEW [dbo].[vwAehByByggAerende]
AS
SELECT tbAehByByggAerende.recByggAerendeID, 
  tbAehByByggAerende.recByggAerendeID AS intRecNum, 
  tbAehByByggAerende.datLagaKraft, 
  tbAehByByggAerende.datKungjort, 
  tbAehByByggAerende.strByggnadstyp, 
  tbAehByByggAerende.strByggaatgaerd,
  tbAehByByggAerende.recAerendeID,
  tbAehByByggSakkunnig.recSakkunnigID,
  vwTrSakkunnig.strVisasSom,
  vwAehAerende.recAvdelningID,  -- Behövs för postbehörigheter
  LovIdentifiering.strHaendelseIdentifiering as strLovBeviljat,
  tbAehByByggAerende.recHaendelseLovID,
  tbAehByByggAerende.recHaendelseStartbeskedID,
  tbAehByByggAerende.recHaendelseSlutbeskedID,

  CASE
    WHEN Lov.strHaendelseStatusLocalizationCode = 'ALLM' Then Lov.datBeslutsDatum
    ELSE NULL
  END AS datLovbeviljatDatum,

  StartIdentifiering.strHaendelseIdentifiering as strStartbesked,

  CASE
    WHEN Startbesked.strHaendelseStatusLocalizationCode = 'ALLM' Then Startbesked.datBeslutsDatum
    ELSE NULL
  END AS datStartbeskedDatum,

  SlutIdentifiering.strHaendelseIdentifiering as strSlutbesked,

  CASE
    WHEN Slutbesked.strHaendelseStatusLocalizationCode = 'ALLM' Then Slutbesked.datBeslutsDatum
    ELSE NULL
  END AS datSlutbeskedDatum,

  tbAehByByggAerende.datSistaDatumFoerBeslut,
  tbAehByByggAerende.datVerkstaellighetsdatum,
  tbAehByByggAerende.datStartDatumTidsfrist,
  tbAehByByggAerende.intTidsfristlaengd,

CASE
    -- Hela veckan ska räknas från första dagen => +1 (Alltså: vecka 0 blir vecka 1)
    WHEN datStartDatumTidsfrist IS NULL THEN NULL
    -- Bara datStartDatumTidsfrist ifyllt, men inte datBeslutsDatum
    WHEN vwAehAerende.datBeslutsDatum IS NULL AND datStartDatumTidsfrist > GETDATE() THEN NULL
    WHEN vwAehAerende.datBeslutsDatum IS NULL THEN (DATEDIFF(day,  CONVERT (date, datStartDatumTidsfrist), CONVERT (date, GETDATE())) / 7) + 1
    -- Både datStartDatumTidsfrist och datBeslutsDatum ifyllda
    WHEN datStartDatumTidsfrist > vwAehAerende.datBeslutsDatum THEN NULL
    ELSE (DATEDIFF(day,  CONVERT (date, datStartDatumTidsfrist), CONVERT (date, vwAehAerende.datBeslutsDatum)) / 7) + 1
 END AS intHandlaeggningsveckorTotalt


FROM tbAehByByggAerende
LEFT JOIN tbAehByByggSakkunnig
  ON tbAehByByggSakkunnig.recByggAerendeID = tbAehByByggAerende.recByggAerendeID
  AND tbAehByByggSakkunnig.bolHuvud = 1
LEFT JOIN vwTrSakkunnig
  ON vwTrSakkunnig.recSakkunnigID = tbAehByByggSakkunnig.recSakkunnigID
LEFT OUTER JOIN vwAehAerende
  ON vwAehAerende.recAerendeID = tbAehByByggAerende.recAerendeID
LEFT OUTER JOIN dbo.vwAehHaendelseidentifiering as LovIdentifiering
  ON LovIdentifiering.recHaendelseID = tbAehByByggAerende.recHaendelseLovID
LEFT OUTER JOIN vwAehHaendelse as Lov
  ON Lov.recHaendelseID = tbAehByByggAerende.recHaendelseLovID
LEFT OUTER JOIN dbo.vwAehHaendelseidentifiering as StartIdentifiering
  ON StartIdentifiering.recHaendelseID = tbAehByByggAerende.recHaendelseStartbeskedID
LEFT OUTER JOIN vwAehHaendelse as Startbesked
  ON Startbesked.recHaendelseID = tbAehByByggAerende.recHaendelseStartbeskedID
LEFT OUTER JOIN dbo.vwAehHaendelseidentifiering as SlutIdentifiering
  ON SlutIdentifiering.recHaendelseID = tbAehByByggAerende.recHaendelseSlutbeskedID
LEFT OUTER JOIN vwAehHaendelse as Slutbesked
  ON Slutbesked.recHaendelseID = tbAehByByggAerende.recHaendelseSlutbeskedID

go

