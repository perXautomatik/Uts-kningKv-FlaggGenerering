
CREATE VIEW [dbo].[vwMhOrgan]
AS
SELECT dbo.tbMhOrgan.recOrganID, 
  dbo.tbMhOrgan.strOrgannamn, dbo.tbMhOrgan.strBeskrivning, dbo.tbMhParagrafnummerSerie.strParagrafnummerSerieNamn,
  dbo.tbMhOrgan.strOrgantyp, dbo.tbMhOrgan.intAntalLedamoeter, dbo.tbMhOrgan.datMandatPeriodFraan, 
  dbo.tbMhOrgan.datMandatPeriodTill, dbo.tbMhOrgan.recParagrafnummerserieID, dbo.tbMhOrgan.bolEjAktuell,
  dbo.tbMhOrgan.strOrganFoerkortning, dbo.tbMhOrgan.intSenasteJusteringsman, dbo.tbMhOrgan.recOrganID AS intRecnum,
  dbo.vwVisHandlaeggareEDPUser.strFullName, dbo.vwVisHandlaeggareEDPUser.intUserID
FROM  dbo.tbMhOrgan 
LEFT OUTER JOIN
                      dbo.tbMhParagrafnummerSerie ON 
                      dbo.tbMhOrgan.recParagrafnummerSerieID = dbo.tbMhParagrafnummerSerie.recParagrafnummerSerieID 
LEFT OUTER JOIN
                      dbo.vwVisHandlaeggareEDPUser ON dbo.vwVisHandlaeggareEDPUser.intUserID = dbo.tbMhOrgan.intUserID

go

