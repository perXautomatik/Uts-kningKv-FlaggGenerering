
CREATE VIEW [dbo].[vwEDPParameter]
AS
SELECT tbEDPParameter.intParameterID AS intRecnum, tbEDPParameter.intParameterID, tbEDPParameter.strParameterName,
  tbEDPParameter.strParameterDisplayName, tbEDPParameter.strParameterDescription, tbEDPParameter.intParameterValueTypeID,
  tbEDPParameter.strParameterValueLookUpID, tbEDPParameterDefaultValue.strParameterDefaultValue AS strParameterValueDefault,
  tbEDPParameter.intParameterTypeID, tbEDPParameter.intParentParameterID, tbEDPParameter.intParameterValueLength,
  tbEDPParameter.intParameterTypeDecimalCount, tbEDPParameter.intParameterTypeFigureCount, tbEDPParameter.bolPasswordMask,
  (SELECT tbParent.strParameterName FROM tbEDPParameter AS tbParent WHERE tbParent.intParameterID = dbo.tbEDPParameter.intParentParameterID) AS strParentParameterName 
FROM  tbEDPParameter LEFT OUTER JOIN tbEDPParameterDefaultValue ON dbo.tbEDPParameter.intParameterID = dbo.tbEDPParameterDefaultValue.intParameterID

go

