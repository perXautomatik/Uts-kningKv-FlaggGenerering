
CREATE FUNCTION [dbo].[FnAehAerendeMoetesDatum]
  (@intAerendeID int)     
  RETURNS DateTime    
AS    

BEGIN  
	DECLARE @ids TABLE( id int )
	DECLARE @moetesDatum AS DateTime

	-- MOETES ID
	INSERT INTO @ids (id)
	SELECT recMoeteID FROM tbMhMoetespunkt WHERE recMoetespunktID IN(
		SELECT recMoetespunktID FROM tbMhMoetespunktAerende 
		WHERE recAerendeID = @intAerendeID
		UNION
		SELECT recMoetespunktID FROM tbMhMoetespunktHaendelse 
		WHERE recHaendelseID IN( SELECT recHaendelseID FROM tbAehAerendeHaendelse 
					 WHERE recAerendeID = @intAerendeID ) 
    	)

	-- Hämta datum för nästa möte om det finns något inplanerat
	SELECT TOP 1 @moetesDatum = datMoetesDatum FROM tbMhMoete 
    	WHERE recMoeteID IN( SELECT id FROM @ids ) 
    	AND datMoetesDatum >= GETDATE() ORDER BY datMoetesDatum ASC
    
    IF (@moetesDatum IS NULL)
		-- Inget nytt möte planerat. Hämta datum för senaste möte.
		SELECT TOP 1 @moetesDatum = datMoetesDatum FROM tbMhMoete 
    	WHERE recMoeteID IN( SELECT id FROM @ids ) 
    	ORDER BY datMoetesDatum DESC

 	RETURN @moetesDatum  
END
go

