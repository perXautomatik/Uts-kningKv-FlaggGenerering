CREATE PROCEDURE [dbo].[spEDPGetAuthorizedByRoleIDSecurityObjectName]
	@intRoleID int,
    @strSecurityObjectName varchar(200)
AS
	SELECT    bitAuthorized, intRoleID, strSecurityObjectName, guidSecurityObjectID
	FROM      vwEDPRoleSecurityObject
	WHERE     (intRoleID = @intRoleID  
               and 
               strSecurityObjectName = @strSecurityObjectName)
	RETURN
go

