

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell18Marklov]
AS
SELECT     
recPblAvgiftTaxa2011Tabell18ID, 
recPblAvgiftTaxa2011Tabell18MarklovID, 
recPblAvgiftTaxa2011Tabell18MarklovID as 'intRecnum', 
strAatgaerd,
strBeskrivning,
decAntalmPBB,
decAvgift


	
FROM dbo.tbAehPblAvgiftTaxa2011Tabell18Marklov



go

