
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell05]
AS
SELECT     
  dbo.tbAehPblAvgiftTaxa2011Tabell05.recPblAvgiftTaxa2011Tabell05ID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell05.recAvgiftID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell05.recPblAvgiftTaxa2011Tabell05ID AS intRecnum, 
  dbo.tbAehPblAvgiftTaxa2011Tabell05.strAvvikandeOFAAtgaerd,
  dbo.tbAehPblAvgiftTaxa2011Tabell05.intOF,
  dbo.tbAehPblAvgiftTaxa2011Tabell05.decAvgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell05.decHF2,
  dbo.tbAehPblAvgiftTaxa2011Tabell05.decOF,
  dbo.tbAehPblAvgiftTaxa2011Tabell05.decmPBB,
  dbo.tbAehPblAvgiftTaxa2011Tabell05.decN,
  dbo.tbAehPblAvgiftTaxa2011Tabell05.decHF2Justering,
  dbo.tbAehPblAvgiftTaxa2011Tabell05.decOFJustering,
  dbo.tbAehPblAvgiftTaxa2011Tabell05.bolDebiterad
FROM dbo.tbAehPblAvgiftTaxa2011Tabell05

go

