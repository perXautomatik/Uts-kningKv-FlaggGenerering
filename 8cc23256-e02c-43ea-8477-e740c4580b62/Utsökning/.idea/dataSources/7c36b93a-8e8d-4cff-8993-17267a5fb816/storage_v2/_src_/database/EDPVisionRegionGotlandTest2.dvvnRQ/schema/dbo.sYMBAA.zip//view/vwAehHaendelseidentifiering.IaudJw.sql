
CREATE VIEW [dbo].[vwAehHaendelseidentifiering] 
AS
 SELECT  tbAehHaendelse.recHaendelseID, 
    CASE
      WHEN (dbo.tbAehAerendeData.strDiarienummer IS NOT NULL) THEN 
		-- Om en händelse är kopplad till ett ärende, visas ärendets diarienummer + händelsens löpnummer som UFIC.		
		dbo.tbAehAerendeData.strDiarienummer + ISNULL(':' + CONVERT(VARCHAR, dbo.tbAehAerendeHaendelse.intLoepnummerHaendelse), '')
     
	  WHEN (dbo.tbAehHaendelse.strTillhoerPostlista IS NOT NULL AND dbo.tbAehHaendelse.strTillhoerPostlista <> '') THEN 
		-- Om händelsen inte är kopplad till ett ärende, men kopplad till en postlista visas det sammanslagna fältet postlista som UFIC.
		dbo.tbAehHaendelse.strTillhoerPostlista
	  
	  ELSE
	   -- Om händelsen varken är kopplad till ett ärende eller en postlista visas Händelsekategorikod, Händelsedatum som UFIC.			
		CONVERT(varchar(10), dbo.tbAehHaendelse.datHaendelseDatum, 120) + ' ' +  dbo.tbAehHaendelseKategori.strHaendelseKategoriKod

      END AS strHaendelseIdentifiering 
  FROM tbAehHaendelse 
  LEFT OUTER JOIN dbo.tbAehHaendelseKategori 
    ON dbo.tbAehHaendelse.recHaendelseKategoriID = dbo.tbAehHaendelseKategori.recHaendelseKategoriID 
  LEFT OUTER JOIN dbo.tbAehAerendeHaendelse 
    ON dbo.tbAehHaendelse.recHaendelseID = dbo.tbAehAerendeHaendelse.recHaendelseID 
  LEFT OUTER JOIN dbo.tbAehAerendeData
    ON dbo.tbAehAerendeHaendelse.recAerendeID = dbo.tbAehAerendeData.recAerendeID



go

