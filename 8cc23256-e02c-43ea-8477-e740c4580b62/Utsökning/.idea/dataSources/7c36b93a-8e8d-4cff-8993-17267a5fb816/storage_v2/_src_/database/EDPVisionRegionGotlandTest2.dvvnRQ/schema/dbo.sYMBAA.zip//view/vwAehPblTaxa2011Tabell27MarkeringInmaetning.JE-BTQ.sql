


CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell27MarkeringInmaetning]
AS
SELECT     tbAehPblTaxa2011Tabell27MarkeringInmaetning.recTabell27ID, 
           recMarkeringInmaetningID as 'intRecnum', 
		   recMarkeringInmaetningID,
		   strObjekt,
		   strBeskrivning,
		   recTaxa2011ID,
		   intMF
FROM         dbo.tbAehPblTaxa2011Tabell27MarkeringInmaetning
LEFT OUTER JOIN vwAehPblTaxa2011Tabell27 
ON vwAehPblTaxa2011Tabell27.recTabell27ID = tbAehPblTaxa2011Tabell27MarkeringInmaetning.recTabell27ID

go

