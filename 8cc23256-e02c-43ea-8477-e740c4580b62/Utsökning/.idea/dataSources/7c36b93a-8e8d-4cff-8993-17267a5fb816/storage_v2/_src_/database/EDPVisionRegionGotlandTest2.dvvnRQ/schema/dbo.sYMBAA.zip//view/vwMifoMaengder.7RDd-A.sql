CREATE VIEW dbo.vwMifoMaengder
AS
SELECT     dbo.tbMifoMaengder.recMaengderID, dbo.tbMifoMaengder.recObjektID, dbo.tbMifoMaengder.strMedium, dbo.tbMifoMaengder.strOmfattning,
                      dbo.tbMifoMaengder.strTyp, dbo.tbMifoObjekt.strObjektNamn, dbo.tbMifoObjekt.strObjektId, dbo.tbMifoMaengder.recMaengderID AS intRecnum,
                      dbo.tbMifoMaengder.strFas, dbo.tbMifoMaengder.strAemnen
FROM         dbo.tbMifoMaengder INNER JOIN
                      dbo.tbMifoObjekt ON dbo.tbMifoMaengder.recObjektID = dbo.tbMifoObjekt.recObjektID
go

