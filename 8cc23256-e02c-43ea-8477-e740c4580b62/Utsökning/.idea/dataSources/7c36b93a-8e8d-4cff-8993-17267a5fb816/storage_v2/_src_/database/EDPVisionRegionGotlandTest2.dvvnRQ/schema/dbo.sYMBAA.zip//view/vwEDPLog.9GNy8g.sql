CREATE VIEW [dbo].[vwEDPLog]
AS
SELECT     dbo.tbEDPLog.strTableName, dbo.tbEDPLog.intIdentity, dbo.tbEDPLogAction.strAction, dbo.tbEDPLog.strOldValue, dbo.tbEDPLog.strNewValue, 
                      dbo.tbEDPLog.datChanged, dbo.tbEDPUser.strUserWindowsAccount AS strUser
FROM         dbo.tbEDPLog INNER JOIN
                      dbo.tbEDPLogAction ON dbo.tbEDPLog.intActionID = dbo.tbEDPLogAction.intActionID INNER JOIN
                      dbo.tbEDPUser ON dbo.tbEDPLog.intUserID = dbo.tbEDPUser.intUserID

go

