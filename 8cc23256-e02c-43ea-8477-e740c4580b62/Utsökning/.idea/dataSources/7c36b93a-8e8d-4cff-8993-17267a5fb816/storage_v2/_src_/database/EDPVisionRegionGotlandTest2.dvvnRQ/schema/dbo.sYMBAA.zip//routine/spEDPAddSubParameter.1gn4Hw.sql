
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spEDPAddSubParameter]
	-- Add the parameters for the stored procedure here
  @strSubParameterName varchar(200),
  @strSubParameterDescription varchar(200),
  @intSubParameterSearchMethodID int,
  @intSubParameterValueTypeID int,
  @strSubParameterValueLookupId varchar(200),
  @intSubParameterValueLength int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
INSERT INTO tbEDPSubParameter (strSubParameterName, 
  strSubParameterDescription,
  intSubParameterSearchMethodID,
  intSubParameterValueTypeID,
  strSubParameterValueLookUpId,
  intSubParameterValueLength)
VALUES (@strSubParameterName, 
  @strSubParameterDescription,
  @intSubParameterSearchMethodID,
  @intSubParameterValueTypeID,
  @strSubParameterValueLookupId,
  @intSubParameterValueLength)
  
END

go

