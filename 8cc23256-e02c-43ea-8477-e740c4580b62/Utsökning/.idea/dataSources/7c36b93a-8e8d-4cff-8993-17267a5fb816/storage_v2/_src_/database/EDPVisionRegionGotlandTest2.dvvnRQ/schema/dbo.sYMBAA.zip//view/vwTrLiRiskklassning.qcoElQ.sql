CREATE VIEW [dbo].[vwTrLiRiskklassning]
AS
SELECT     tbTrLiRiskklassning.*, recTrLiRiskklassningID As 'intRecnum'

FROM         dbo.tbTrLiRiskklassning


go

