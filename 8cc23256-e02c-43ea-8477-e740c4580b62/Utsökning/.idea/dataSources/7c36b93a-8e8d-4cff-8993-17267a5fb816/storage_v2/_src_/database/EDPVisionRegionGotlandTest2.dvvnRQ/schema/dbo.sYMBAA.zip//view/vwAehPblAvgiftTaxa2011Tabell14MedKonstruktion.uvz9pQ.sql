

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell14MedKonstruktion]
AS
SELECT		  recPblAvgiftTaxa2011Tabell14MedKonstruktionID
			, recPblAvgiftTaxa2011Tabell14MedKonstruktionID as 'intRecnum'
			, recPblAvgiftTaxa2011Tabell14ID
			, strObjekt
			, strBeskrivning
			, intHF
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell14MedKonstruktion
go

