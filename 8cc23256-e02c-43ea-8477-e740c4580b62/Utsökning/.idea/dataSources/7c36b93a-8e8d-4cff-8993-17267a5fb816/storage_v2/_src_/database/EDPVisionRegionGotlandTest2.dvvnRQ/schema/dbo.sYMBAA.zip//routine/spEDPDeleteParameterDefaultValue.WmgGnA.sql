CREATE PROCEDURE [dbo].[spEDPDeleteParameterDefaultValue]
	-- Add the parameters for the stored procedure here
	@strParameterName varchar(200)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
  DECLARE @intParameterID int
  SET @intParameterID = (SELECT intParameterID from tbEDPParameter WHERE strParameterName = @strParameterName)

  DELETE tbEDPParameterDefaultValue WHERE intParameterID = @intParameterID
END
go

