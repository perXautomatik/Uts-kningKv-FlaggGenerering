


CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell26DigitalGeografiskInformation]
AS
SELECT	
		
		recPblAvgiftTaxa2011Tabell26ID,
		recPblAvgiftTaxa2011Tabell26ID as 'intRecnum', 
		recPblAvgiftTaxa2011Tb26DigitalGeografiskInformationID ,
		decKF, 
		strInformationstyp, 
		strAatgaerd, 
		strBeskrivning

FROM	dbo.tbAehPblAvgiftTaxa2011Tabell26DigitalGeografiskInformation


go

