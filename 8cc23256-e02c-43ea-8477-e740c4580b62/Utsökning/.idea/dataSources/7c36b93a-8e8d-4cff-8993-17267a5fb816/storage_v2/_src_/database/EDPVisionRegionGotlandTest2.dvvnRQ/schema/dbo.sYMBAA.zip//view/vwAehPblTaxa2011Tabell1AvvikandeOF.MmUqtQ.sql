
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell1AvvikandeOF]
AS
SELECT     recT1AvvikandeID, 
           recT1AvvikandeID as 'intRecnum', 
		   tbAehPblTaxa2011Tabell1AvvikandeOF.recTabell1ID,
		   strAvvikandeAatgaerd, 
		   strBeskrivning,
		   recTaxa2011ID,
		   intOf
FROM         dbo.tbAehPblTaxa2011Tabell1AvvikandeOF
LEFT OUTER JOIN vwAehPblTaxa2011Tabell1
ON vwAehPblTaxa2011Tabell1.recTabell1ID = tbAehPblTaxa2011Tabell1AvvikandeOF.recTabell1ID


go

