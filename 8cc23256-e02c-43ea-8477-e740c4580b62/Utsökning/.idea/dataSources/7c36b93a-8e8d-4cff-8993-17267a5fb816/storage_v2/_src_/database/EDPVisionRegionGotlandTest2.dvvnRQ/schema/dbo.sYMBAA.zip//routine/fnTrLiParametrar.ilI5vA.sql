
            CREATE FUNCTION [dbo].[fnTrLiParametrar] 
            (
              @recTillsynsobjektID INT
            )
            RETURNS NVARCHAR(MAX)
            AS
            BEGIN
              DECLARE @result NVARCHAR(MAX)
  
              SELECT @result = 
                LTRIM ((
                  SELECT strParameter + ', ' FROM tbTrLiDricksvattenParametrar 
                  WHERE tbTrLiDricksvattenParametrar.recTillsynsobjektID = @recTillsynsobjektID
                  FOR XML PATH('')
                )) 

              RETURN LEFT(@result, LEN(@result) - 2)
            END
            go

