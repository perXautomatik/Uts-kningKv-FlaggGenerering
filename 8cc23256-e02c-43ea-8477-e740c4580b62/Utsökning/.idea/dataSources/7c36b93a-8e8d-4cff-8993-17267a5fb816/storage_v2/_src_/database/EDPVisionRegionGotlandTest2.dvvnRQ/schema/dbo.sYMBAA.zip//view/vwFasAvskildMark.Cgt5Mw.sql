CREATE VIEW dbo.vwFasAvskildMark
AS
SELECT     dbo.tbFasFASTAVSK.recFASTAVSK, dbo.tbFasFASTAVSK.strOTYP, dbo.tbFasFASTAVSK.strDATUMLOP, dbo.tbFasFASTAVSK.strFNRID, 
                      dbo.tbFasFASTAVSK.strAVFNRID, dbo.tbFasFASTAVSK.strAVKOD, dbo.tbFasFASTAVSK.recFASTAVSK AS intRecnum, 
                      dbo.vwFasFastighet.strFastighetsbeteckning, dbo.vwFasFastighet.strKOMMUN
FROM         dbo.tbFasFASTAVSK LEFT OUTER JOIN
                      dbo.vwFasFastighet ON dbo.tbFasFASTAVSK.strAVFNRID = dbo.vwFasFastighet.strFNRID
go

