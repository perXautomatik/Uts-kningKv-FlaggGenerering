



CREATE PROCEDURE dbo.spEDPGetObjectIDByObjectName
	(
		@strObjectName varchar(300)
	)
AS
SELECT     intObjectID
FROM         tbEDPObject
WHERE     (strObjectName = @strObjectName)
	RETURN

go

