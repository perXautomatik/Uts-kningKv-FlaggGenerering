CREATE VIEW dbo.vwMmKlassningVaerde
AS
SELECT     dbo.tbMmKlassningvaerde.recKlassningvaerdeID, dbo.tbMmKlassningvaerde.recKlassningID, dbo.tbMmKlassningvaerde.strKlassningvaerde,
                      dbo.tbMmKlassningvaerde.strKlassningvaerdeKommentar, dbo.tbMmKlassning.strKlassningNamn,
                      dbo.tbMmKlassningvaerde.recKlassningvaerdeID AS intRecnum
FROM         dbo.tbMmKlassning RIGHT OUTER JOIN
                      dbo.tbMmKlassningvaerde ON dbo.tbMmKlassning.recKlassningID = dbo.tbMmKlassningvaerde.recKlassningID
go

