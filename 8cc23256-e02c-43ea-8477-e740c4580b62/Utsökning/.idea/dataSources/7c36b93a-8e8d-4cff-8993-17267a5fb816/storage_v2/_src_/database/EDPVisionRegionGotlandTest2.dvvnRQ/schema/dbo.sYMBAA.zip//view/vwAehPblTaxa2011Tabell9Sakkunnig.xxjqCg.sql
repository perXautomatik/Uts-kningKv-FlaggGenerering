

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell9Sakkunnig]
AS
SELECT     tbAehPblTaxa2011Tabell9Sakkunnig.recTabell9ID, 
           recSakkunningID as 'intRecnum', 
		   recSakkunningID,
		   strAatgaerd,
		   strBeskrivning,
		   recTaxa2011ID,
		   intHF
FROM         dbo.tbAehPblTaxa2011Tabell9Sakkunnig
LEFT OUTER JOIN vwAehPblTaxa2011Tabell9
ON vwAehPblTaxa2011Tabell9.recTabell9ID = tbAehPblTaxa2011Tabell9Sakkunnig.recTabell9ID



go

