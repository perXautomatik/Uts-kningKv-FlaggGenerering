CREATE VIEW dbo.vwMmOmraadeHuvudHandlaeggare
AS
SELECT     dbo.tbMmOmraadeUser.recOmraadeUserID, dbo.tbMmOmraadeUser.recOmrID, dbo.tbMmOmraadeUser.intUserID,
                      dbo.tbMmOmraadeUser.bolHuvudhandlaeggare, dbo.vwVisHandlaeggareEDPUser.strSignature
FROM         dbo.tbMmOmraadeUser INNER JOIN
                      dbo.vwVisHandlaeggareEDPUser ON dbo.tbMmOmraadeUser.intUserID = dbo.vwVisHandlaeggareEDPUser.intUserID
WHERE     (dbo.tbMmOmraadeUser.bolHuvudhandlaeggare = 1)
go

