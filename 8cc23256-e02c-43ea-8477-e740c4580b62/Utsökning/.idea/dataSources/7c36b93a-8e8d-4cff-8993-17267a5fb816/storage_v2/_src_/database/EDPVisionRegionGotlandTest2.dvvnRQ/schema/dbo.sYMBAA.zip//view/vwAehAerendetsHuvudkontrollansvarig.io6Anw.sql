
CREATE VIEW [dbo].[vwAehAerendetsHuvudkontrollansvarig]
AS

SELECT DISTINCT
	vwTrSakkunnig.recSakkunnigID,
	vwTrSakkunnig.recSakkunnigID AS intRecnum,
	dbo.tbAehByByggAerende.recAerendeID,
	strCoadress,
	strEfternamn,
	strEpost,
	strFax,
	strFoeretag AS strServiceFöretag,
	strFoernamn,
	strGatuadress,
	strKontaktTyp,
	strLand,
	strMobil,
	strNamn,
	strOrginisationPersonnummer,
	strPostnummer,
	strPostort,
	strSammanslagenAdress,
	strTelefon,
	strTitel,
	strVisasSom,
	dbo.tbTrCertifiering.strCertifieringsnummer,
	dbo.tbTrCertifiering.strBehoerighet,
	dbo.tbTrCertifiering.datCertifieradFraanOchMed,
	dbo.tbTrCertifiering.datCertifieradTillOchMed,
	dbo.tbTrCertifiering.strCertifieradAv
	
FROM vwTrSakkunnig
INNER JOIN dbo.tbAehByByggSakkunnig ON tbAehByByggSakkunnig.recSakkunnigID = vwTrSakkunnig.recSakkunnigID AND tbAehByByggSakkunnig.bolHuvud = 1
INNER JOIN dbo.tbAehByByggAerende ON tbAehByByggAerende.recByggAerendeID = tbAehByByggSakkunnig.recByggAerendeID
LEFT JOIN dbo.tbTrCertifiering ON tbTrCertifiering.recCertifieringID = 
(
	SELECT TOP(1) tbTrCertifiering.recCertifieringID
	FROM tbTrCertifiering
	INNER JOIN tbTrCertifieringSakkunnig ON tbTrCertifiering.recCertifieringID = tbTrCertifieringSakkunnig.recCertifieringID
	WHERE strCertifieringsTyp = 'ByggÄrende'
	AND tbTrCertifieringSakkunnig.recSakkunnigID = vwTrSakkunnig.recSakkunnigID
	ORDER BY tbTrCertifiering.recCertifieringID DESC
)
go

