CREATE VIEW dbo.vwMifoBransch
AS
SELECT     dbo.tbMifoBransch.recBranschID, dbo.tbMifoBransch.recObjektID, dbo.tbMifoBransch.intBranschIdMIFO, dbo.tbMifoBransch.strSNIBranschKod,
                      dbo.tbMifoBransch.strAnteckning, dbo.tbMifoBransch.recBranschID AS intRecnum, dbo.tbMmSNIBransch.strSNIBranschNamn,
                      dbo.tbMifoObjekt.strObjektId, dbo.tbMifoObjekt.strObjektNamn, dbo.vwMifoBranschNamn.strBranschNamn, dbo.tbMmSNIBransch.intAartal
FROM         dbo.tbMifoObjekt RIGHT OUTER JOIN
                      dbo.tbMifoBransch LEFT OUTER JOIN
                      dbo.vwMifoBranschNamn ON dbo.tbMifoBransch.intBranschIdMIFO = dbo.vwMifoBranschNamn.intBranschIdMIFO ON
                      dbo.tbMifoObjekt.recObjektID = dbo.tbMifoBransch.recObjektID LEFT OUTER JOIN
                      dbo.tbMmSNIBransch ON dbo.tbMifoBransch.strSNIBranschKod = dbo.tbMmSNIBransch.strSNIBranschKod
go

