
        CREATE TRIGGER TRG_tbAehAerendeEnstakaKontakt_INSERT_UPDATE_DELETE ON tbAehAerendeEnstakaKontakt
        AFTER INSERT, UPDATE, DELETE
        AS
        BEGIN
        SET NOCOUNT ON;

        DECLARE aerende_kontakt_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recAerendeID FROM INSERTED UNION SELECT recAerendeID FROM DELETED
        OPEN aerende_kontakt_cursor
        DECLARE @recAerendeID INT
        FETCH NEXT FROM aerende_kontakt_cursor INTO @recAerendeID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehAerendeDataUpdateKontakt @recAerendeID

            FETCH NEXT FROM aerende_kontakt_cursor INTO @recAerendeID
        END
        CLOSE aerende_kontakt_cursor
        DEALLOCATE aerende_kontakt_cursor
        END
        go

