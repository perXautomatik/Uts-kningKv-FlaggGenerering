
        CREATE TRIGGER trInsertUpdateTrTillsynsobjektStatusLast ON tbTrTillsynsobjektStatus
        AFTER UPDATE, INSERT
        AS
        BEGIN
        DECLARE @recTillsynsobjektID INT
        DECLARE insert_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recTillsynsobjektID FROM INSERTED
        OPEN insert_cursor
        FETCH NEXT FROM insert_cursor INTO @recTillsynsobjektID
        WHILE (@@fetch_status = 0)
        BEGIN
            UPDATE tbTrTillsynsobjekt SET recLastLogPostID =
            (
                SELECT TOP (1) recTillsynsobjektStatusID
                FROM tbTrTillsynsobjektStatus
                WHERE recTillsynsobjektID = @recTillsynsobjektID
                ORDER BY datDatum DESC, recTillsynsobjektStatusID DESC
            )
            WHERE recTillsynsobjektID = @recTillsynsobjektID

            FETCH NEXT FROM insert_cursor INTO @recTillsynsobjektID
        END
        CLOSE insert_cursor
        DEALLOCATE insert_cursor
        END
        go

