
CREATE VIEW [dbo].[vwAehAerendeTyp]
AS
SELECT tbAehAerendetyp.recAerendetypID as intRecnum, 
	tbAehAerendetyp.recAerendetypID,
	tbAehAerendetyp.strAerendetypKod,
	tbAehAerendetyp.bolEjAktuell,
	tbAehAerendetyp.strAerendeTyp,
	tbAehAerendetyp.bolKomplettAerende,
	tbAehAerendetyp.strAerendekategori,
	tbAehAerendetyp.strPoITKategori
FROM tbAehAerendetyp

go

