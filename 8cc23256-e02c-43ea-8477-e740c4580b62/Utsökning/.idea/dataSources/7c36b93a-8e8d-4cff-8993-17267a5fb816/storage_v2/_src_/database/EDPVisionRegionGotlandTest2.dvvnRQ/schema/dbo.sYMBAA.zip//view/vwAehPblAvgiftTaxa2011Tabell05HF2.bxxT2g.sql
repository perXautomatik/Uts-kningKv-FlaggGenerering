CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell05HF2]
AS
SELECT     recPblAvgiftTaxa2011Tabell05ID, recPblAvgiftTaxa2011Tabell05HF2ID as 'intRecnum', recPblAvgiftTaxa2011Tabell05HF2ID,strAatgaerd,
			strBeskrivning,intHF2
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell05HF2

go

