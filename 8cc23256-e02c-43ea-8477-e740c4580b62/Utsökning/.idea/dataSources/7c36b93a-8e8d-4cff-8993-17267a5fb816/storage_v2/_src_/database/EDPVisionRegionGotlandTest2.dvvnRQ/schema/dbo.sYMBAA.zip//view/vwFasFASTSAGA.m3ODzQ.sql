CREATE VIEW dbo.vwFasFASTSAGA
AS
SELECT     dbo.tbFasFASTSAGA.recFASTSAGA, dbo.tbFasFASTSAGA.strOTYP, dbo.tbFasFASTSAGA.strDATUMLOP, dbo.tbFasFASTSAGA.strFNRID, 
                      dbo.tbFasFASTSAGA.strANDFNRID, dbo.tbFasFASTSAGA.strENHTYP, dbo.tbFasFASTSAGA.recFASTSAGA AS intRecnum, 
                      dbo.vwFasFastighet.strFastighetsbeteckning, dbo.vwFasFastighet.strKOMMUN
FROM         dbo.tbFasFASTSAGA LEFT OUTER JOIN
                      dbo.vwFasFastighet ON dbo.tbFasFASTSAGA.strANDFNRID = dbo.vwFasFastighet.strFNRID
go

