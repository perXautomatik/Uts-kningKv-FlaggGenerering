
CREATE VIEW [dbo].[vwTrCertifiering]
AS
SELECT     recCertifieringID, recCertifieringID as intRecnum, strCertifieringsTyp, strBehoerighet, strCertifieringsnummer, datCertifieradFraanOchMed, datCertifieradTillOchMed, strCertifieradAv
FROM         dbo.tbTrCertifiering
go

