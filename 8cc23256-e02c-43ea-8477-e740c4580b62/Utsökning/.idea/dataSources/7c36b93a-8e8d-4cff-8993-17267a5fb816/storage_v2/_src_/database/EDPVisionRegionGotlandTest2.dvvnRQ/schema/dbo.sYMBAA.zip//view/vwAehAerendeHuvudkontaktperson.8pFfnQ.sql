


CREATE VIEW [dbo].[vwAehAerendeHuvudkontaktperson]
AS

SELECT 
	tbAehAerendeEnstakaKontakt.recAerendeID
	, tbAehAerendeEnstakaKontakt.strRoll
	, vwVisEnstakaKontakt.* 
FROM tbAehAerendeEnstakaKontakt 
INNER JOIN vwVisEnstakaKontakt ON vwVisEnstakaKontakt.recEnstakaKontaktID = tbAehAerendeEnstakaKontakt.recEnstakaKontaktID
WHERE bolHuvudkontakt = 1


go

