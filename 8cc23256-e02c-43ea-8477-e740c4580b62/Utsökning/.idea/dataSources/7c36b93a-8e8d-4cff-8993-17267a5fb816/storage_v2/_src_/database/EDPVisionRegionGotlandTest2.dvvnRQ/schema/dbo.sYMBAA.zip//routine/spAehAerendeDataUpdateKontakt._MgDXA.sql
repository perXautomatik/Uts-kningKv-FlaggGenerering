
CREATE PROCEDURE [dbo].[spAehAerendeDataUpdateKontakt]
  @recAerendeID int
AS
BEGIN
  SET NOCOUNT ON;
  
  UPDATE tbAehAerendeData SET
    recEnstakaKontaktID = dbo.tbVisEnstakaKontakt.recEnstakaKontaktID,
    strVisasSom = dbo.tbVisEnstakaKontakt.strVisasSom,
    strGatuadress = dbo.tbVisEnstakaKontakt.strGatuadress,
    strPostnummer = dbo.tbVisEnstakaKontakt.strPostnummer,
    strPostort = dbo.tbVisEnstakaKontakt.strPostort,

    strRoll = dbo.tbAehAerendeEnstakaKontakt.strRoll,
    recKontaktRollID = dbo.tbVisKontaktRoll.recKontaktRollID,
    recAerendeEnstakaKontaktID = dbo.tbAehAerendeEnstakaKontakt.recAerendeEnstakaKontaktID
  FROM tbAehAerendeData
  LEFT OUTER JOIN dbo.tbAehAerendeEnstakaKontakt
    ON dbo.tbAehAerendeData.recAerendeID = dbo.tbAehAerendeEnstakaKontakt.recAerendeID 
    AND dbo.tbAehAerendeEnstakaKontakt.bolHuvudKontakt = 1 
  LEFT OUTER JOIN dbo.tbVisEnstakaKontakt 
    ON dbo.tbAehAerendeEnstakaKontakt.recEnstakaKontaktID = dbo.tbVisEnstakaKontakt.recEnstakaKontaktID
    LEFT OUTER JOIN dbo.tbVisKontaktRoll
	ON dbo.tbVisKontaktRoll.strRoll = dbo.tbAehAerendeEnstakaKontakt.strRoll
  WHERE tbAehAerendeData.recAerendeID = @recAerendeID
END
go

