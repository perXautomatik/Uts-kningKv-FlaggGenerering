
CREATE VIEW [dbo].[vwAehHaendelse]
AS
WITH haendelsetid AS (
  SELECT tbVisTidpost.recHaendelseID, 
    CAST(SUM(intMinuter)/60 AS VARCHAR) + ':' + RIGHT('0' + CAST(SUM(intMinuter)%60 AS VARCHAR), 2) AS strSummaTidposter
  FROM tbVisTidpost 
  GROUP BY recHaendelseID
),
Gallrad AS (SELECT Max(datDatum) AS datGallrad, recHaendelseID
FROM tbAehHaendelseStatusLog WHERE recHaendelseStatusLogTypID in 
(SELECT recHaendelseStatusLogTypID FROM tbAehHaendelseStatusLogTyp WHERE strHaendelseStatusLogTyp = 'Gallrad')
GROUP BY recHaendelseID
),
Arkiverad as (SELECT Max(datDatum) as datArkiverad, recHaendelseID
FROM tbAehHaendelseStatusLog WHERE recHaendelseStatusLogTypID in 
(SELECT recHaendelseStatusLogTypID FROM tbAehHaendelseStatusLogTyp WHERE strHaendelseStatusLogTyp = 'Arkiverat')
GROUP BY recHaendelseID
)

SELECT dbo.tbAehHaendelse.datHaendelseDatum,
       dbo.tbAehHaendelse.strRubrik, 
       dbo.tbAehHaendelse.strText, 
       dbo.tbAehHaendelse.strRiktning, 
       dbo.tbAehHaendelse.strKommunikationssaett, 
       dbo.tbAehHaendelse.recHaendelseKategoriID,
       dbo.tbAehHaendelse.recLastHaendelseStatusLogID,       
       dbo.tbAehHaendelse.recHaendelseID, 
       dbo.tbAehHaendelse.recHaendelseID AS intRecnum,
       dbo.tbAehHaendelse.recDiarieAarsSerieID,  -- Diarieårsserie för postlista
       dbo.tbAehHaendelse.intLoepnummer,  -- Löpnummer för postlista
       dbo.tbAehHaendelse.intAntalFiler,
	   dbo.tbAehHaendelse.recRemissutskickID,
       -- 53508
       dbo.tbAehHaendelse.recFoervaltningID,
       dbo.tbAehHaendelse.strPublicering,   	   
       dbo.tbAehHaendelse.recEnhetID, 
       dbo.tbAehHaendelse.recAvdelningID,  
       
       dbo.tbVisEnhet.strEnhetNamn,      
       dbo.tbVisEnhet.strEnhetKod,   
       
       dbo.tbVisAvdelning.strAvdelningNamn,
       dbo.tbVisAvdelning.strAvdelningKod,   
       dbo.tbVisFoervaltning.strFoervaltningKod, 
             
       dbo.vwAehHaendelseidentifiering.strHaendelseIdentifiering,       
       dbo.tbMhOrgan.strOrgannamn, 

       dbo.tbAehHaendelseBeslut.strBeslutsNummer, 
       dbo.tbAehHaendelseBeslut.datBeslutsDatum, 
       dbo.tbAehHaendelseBeslut.recOrganID, 
       dbo.tbAehHaendelseBeslut.recHaendelseBeslutID, 
       dbo.tbAehHaendelseBeslut.strBeslutsutfall, 

       dbo.tbAehHaendelseKategori.strHaendelseKategori, 
       dbo.tbAehHaendelseKategori.strHaendelseKategoriKod, 
       dbo.tbAehHaendelseKategori.bolEjAktuell, 
       dbo.tbAehHaendelseKategori.bolBeslut, 
       dbo.tbAehHaendelseKategori.strHaendelseKategoriKommentar, 

       dbo.tbAehHaendelseData.strFastighetsbeteckning, 
       dbo.tbAehHaendelseData.strFnrID,
       dbo.tbAehHaendelseData.recFastighetID,
 
       dbo.tbAehAerendeHaendelse.intLoepnummerHaendelse, 
       dbo.tbAehAerendeHaendelse.recAerendeID,
       dbo.tbAehAerendeHaendelse.bolHuvudbeslut AS bolMainHuvudBeslut, -- Trams men behövs för att kunna särskilja den när man hämtar underliggande data

       dbo.tbAehHaendelseData.strSekretess, 
       dbo.tbAehHaendelseData.strBegraensa, 
       dbo.tbAehHaendelseData.strSekretessMyndighet, 
       dbo.tbAehHaendelseData.datSekretessDatum, 

       dbo.tbAehHaendelseData.recEnstakaKontaktID,
       dbo.tbAehHaendelseData.strGatuadress, 
       dbo.tbAehHaendelseData.strPostnummer, 
       dbo.tbAehHaendelseData.strPostort, 
       dbo.tbAehHaendelseData.strVisasSom,

       dbo.tbAehHaendelseData.strRoll, 
       dbo.tbAehHaendelseData.recKontaktRollID,
       dbo.tbAehHaendelseData.recHaendelseEnstakaKontaktID, 

       dbo.tbAehHaendelseData.strSignature,
       dbo.tbAehHaendelseData.intUserID,

       dbo.tbAehHaendelseData.datDatum, 
       dbo.tbAehHaendelseData.strLogKommentar,

       dbo.tbAehHaendelseData.strHaendelseStatusPresent, 
       dbo.tbAehHaendelseData.strHaendelseStatusLogTyp, 
       dbo.tbAehHaendelseData.strHaendelseStatusLocalizationCode, 

       dbo.tbAehAerendeData.strDiarienummer, 
       dbo.tbAehAerendetyp.strAerendeTyp,   
       dbo.tbAehAerendeData.strFastighetsbeteckning AS strAerendeFastighet,  -- För händelserapport
       dbo.tbAehAerendeData.strAerendeStatusPresent,
	   dbo.tbAehAerendeData.strLocalizationCode AS strAerendeLocalizationCode,
       dbo.tbAehAerende.strSoekbegrepp,  -- För händelserapport
       dbo.tbAehAerendeData.recDiarieSerieID, 
       dbo.tbAehAerendeData.strDiarieSerieKod AS strDiarieserieAerende,
       dbo.tbAehAerendeData.intDiarieAar,
       dbo.tbAehAerende.intDiarienummerLoepNummer, 
       dbo.tbAehAerendeData.intSerieStartVaerde, 
       vwAehDiarieAarsSerie.recDiarieSerieID as recDiarieSeriePostlista,
       vwAehDiarieAarsSerie.strDiarieSerieKod AS strDiarieseriePostlista, 
       vwAehDiarieAarsSerie.intDiarieAar AS intDiarieAarPostlista, 
       dbo.tbAehHaendelse.strTillhoerPostlista,
       dbo.tbAehAerende.strAerendemening,
       dbo.tbAehAerendetyp.strAerendetypKod,
       dbo.tbAehHaendelse.recKommunID,
       dbo.tbVisKommun.strKommunNamn,
       
       dbo.tbVisFoervaltning.strFoervaltningNamn,


	   dbo.tbAehHaendelseBeslut.intArbetsdagar ,
       ISNULL(haendelsetid.strSummaTidposter, '0:00') AS strSummaTidposter,
       dbo.tbAehAerendetyp.strPoITkategori,
       dbo.tbAehHaendelse.recDelprocessID ,
       dbo.tbAehDelprocess.strDelprocesskod ,
       dbo.tbAehDelprocess.strDelprocess,
	   Gallrad.datGallrad,
	   Arkiverad.datArkiverad

FROM dbo.tbAehHaendelse 
LEFT OUTER JOIN dbo.tbAehHaendelseData
  ON dbo.tbAehHaendelseData.recHaendelseID = dbo.tbAehHaendelse.recHaendelseID
LEFT OUTER JOIN dbo.tbAehHaendelseKategori
  ON dbo.tbAehHaendelseKategori.recHaendelseKategoriID = dbo.tbAehHaendelse.recHaendelseKategoriID
LEFT OUTER JOIN dbo.tbAehHaendelseBeslut 
  ON dbo.tbAehHaendelse.recHaendelseID = dbo.tbAehHaendelseBeslut.recHaendelseID 
LEFT OUTER JOIN dbo.tbMhOrgan 
  ON dbo.tbMhOrgan.recOrganID = dbo.tbAehHaendelseBeslut.recOrganID 
LEFT OUTER JOIN dbo.tbAehAerendeHaendelse
  ON dbo.tbAehAerendeHaendelse.recHaendelseID = dbo.tbAehHaendelse.recHaendelseID
LEFT OUTER JOIN dbo.tbAehAerende
  ON dbo.tbAehAerende.recAerendeID = dbo.tbAehAerendeHaendelse.recAerendeID
LEFT OUTER JOIN dbo.tbAehAerendeData
  ON dbo.tbAehAerendeData.recAerendeID = dbo.tbAehAerendeHaendelse.recAerendeID
LEFT OUTER JOIN dbo.tbAehAerendetyp
  ON dbo.tbAehAerendetyp.recAerendetypID = dbo.tbAehAerende.recAerendetypID
 
LEFT OUTER JOIN tbVisKommun
  ON tbVisKommun.recKommunID = tbAehHaendelse.recKommunID
LEFT OUTER JOIN dbo.vwAehHaendelseidentifiering
  ON dbo.vwAehHaendelseidentifiering.recHaendelseID = tbAehHaendelse.recHaendelseID
LEFT OUTER JOIN vwAehDiarieAarsSerie
  ON vwAehDiarieAarsSerie.recDiarieAarsSerieID = tbAehHaendelse.recDiarieAarsSerieID
LEFT OUTER JOIN haendelsetid
  ON haendelsetid.recHaendelseID = tbAehHaendelse.recHaendelseID
LEFT OUTER JOIN tbAehDelprocess
  ON tbAehDelprocess.recDelprocessID = tbAehHaendelse.recDelprocessID	
  
-- 53508
LEFT OUTER JOIN tbVisAvdelning
  ON tbVisAvdelning.recAvdelningID = tbAehHaendelse.recAvdelningID
LEFT OUTER JOIN dbo.tbVisEnhet 
  ON dbo.tbVisEnhet.recEnhetID = tbAehHaendelse.recEnhetID 
LEFT OUTER JOIN tbVisFoervaltning
  ON tbVisFoervaltning.recFoervaltningID = tbAehHaendelse.recFoervaltningID
LEFT OUTER JOIN Gallrad 
  ON Gallrad.recHaendelseID = tbAehHaendelse.recHaendelseID
LEFT OUTER JOIN Arkiverad 
  ON Arkiverad.recHaendelseID = tbAehHaendelse.recHaendelseID
go

