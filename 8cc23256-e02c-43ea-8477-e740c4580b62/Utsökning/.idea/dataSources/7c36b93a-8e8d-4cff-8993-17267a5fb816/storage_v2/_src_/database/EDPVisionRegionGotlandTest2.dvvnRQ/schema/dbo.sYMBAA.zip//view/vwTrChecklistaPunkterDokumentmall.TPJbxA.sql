CREATE VIEW [dbo].[vwTrChecklistaPunkterDokumentmall]
AS
SELECT recChecklistaPunktID, recChecklistaPunktID As intRecnum,
       tbTrChecklistaPunkt.recChecklistamallVersionVaerdenID,
       tbTrChecklistamallVersionPunkt.recChecklistamallVersionVaerdeListaID As intValbaraVardenID,
	   bolEjKontrollerad,
	   CAST(tbOmraade.intNummer AS VARCHAR) + '.' + 
         CAST(tbTrChecklistamallVersionPunkt.intNummer AS VARCHAR) + ' ' +
         tbOmraade.strNamn + ': ' + strAvvikelse AS strAvvikelse, 
       tbOmraade.intNummer,
	   CAST(tbOmraade.intNummer AS VARCHAR) + '.' + 
         CAST(tbTrChecklistamallVersionPunkt.intNummer AS VARCHAR) + ' ' +
         tbOmraade.strNamn + ': ' + strIakttagelse AS strIakttagelse, 
       strVaerde,
       intOrdning, 
       bolPositivt, 
       intVikt, 
       recTillsynsbesoekID,
	   tbTrChecklistamallVersionPunkt.strNamn As strPunktNamn, 
       tbTrChecklistamallVersionPunkt.intNummer As intPunktNummer, 
	   strHjaelpText,
       strRapporteringsPunkt,
       tbOmraade.recChecklistamallVersionOmraadeID,
       tbTrChecklistaPunkt.recChecklistamallVersionPunktID,
	   Convert(nvarchar(5), tbOmraade.intNummer) + '. ' + tbOmraade.strNamn As strOmraadesNamn, 
       tbTrChecklistamallVersion.recChecklistaVersionID,

--Enbart för dokumentmallar
	   CASE 
		 WHEN (strAvvikelse IS NOT NULL ) THEN
		   Convert(nvarchar(5), tbOmraade.intNummer) + 
		   '. ' + CAST(tbTrChecklistamallVersionPunkt.intNummer AS VARCHAR) +
		   ' ' + tbOmraade.strNamn + ': ' + strAvvikelse + CHAR(13) + CHAR(10)
		 ELSE
		   NULL 
		 END AS strOmraadesNamnAvvikelse,

	   CASE 
		 WHEN (strIakttagelse IS NOT NULL) THEN
		   Convert(nvarchar(5), tbOmraade.intNummer) + 
           '. ' + CAST(tbTrChecklistamallVersionPunkt.intNummer AS VARCHAR) +
		   ' ' + tbOmraade.strNamn + ': ' + strIakttagelse + CHAR(13) + CHAR(10)
		 ELSE
		   NULL 
		 END AS strOmraadesNamnIakttagelse,

	   CASE 
         WHEN(strVaerde = 'A') THEN
		   CAST(tbOmraade.intNummer AS VARCHAR) + 
		   '.' + CAST(tbTrChecklistamallVersionPunkt.intNummer AS VARCHAR) +
		   ': ' + tbOmraade.strNamn + CHAR(13) + CHAR(10)
	     ELSE NULL
	     END AS strChecklistaPunkterMedA,

	   CASE 
         WHEN(strVaerde = 'AA') THEN
		   CAST(tbOmraade.intNummer AS VARCHAR) + 
		   '.' + CAST(tbTrChecklistamallVersionPunkt.intNummer AS VARCHAR) +
		   ': ' + tbOmraade.strNamn + CHAR(13) + CHAR(10)
	     ELSE NULL
	     END AS strChecklistaPunkterMedAA,

	   CASE 
         WHEN(strVaerde = 'A' OR strVaerde = 'AA') THEN
		   CAST(tbOmraade.intNummer AS VARCHAR) + 
		   '.' + CAST(tbTrChecklistamallVersionPunkt.intNummer AS VARCHAR) +
		   ': ' + tbOmraade.strNamn + CHAR(13) + CHAR(10)
	     ELSE NULL
	     END AS strChecklistaPunkterMedAellerAA,

	   CASE 
         WHEN(strVaerde = 'EK') THEN
		   CAST(tbOmraade.intNummer AS VARCHAR) + 
		   '.' + CAST(tbTrChecklistamallVersionPunkt.intNummer AS VARCHAR) +
		   ': ' + tbOmraade.strNamn + CHAR(13) + CHAR(10)
	     ELSE NULL
	     END AS strChecklistaPunkterMedEK,

	   CASE 
         WHEN(strVaerde = 'EA') THEN
		   CAST(tbOmraade.intNummer AS VARCHAR) + 
		   '.' + CAST(tbTrChecklistamallVersionPunkt.intNummer AS VARCHAR) +
		   ': ' + tbOmraade.strNamn + CHAR(13) + CHAR(10)
	     ELSE NULL
	     END AS strChecklistaPunkterMedEA,

	   CASE 
         WHEN(strVaerde = 'UA') THEN
		   CAST(tbOmraade.intNummer AS VARCHAR) + 
		   '.' + CAST(tbTrChecklistamallVersionPunkt.intNummer AS VARCHAR) +
		   ': ' + tbOmraade.strNamn + CHAR(13) + CHAR(10)
	     ELSE NULL
	     END AS strChecklistaPunkterMedUA,

	   CASE 
         WHEN(strVaerde = 'Ja') THEN
		   CAST(tbOmraade.intNummer AS VARCHAR) + 
		   '.' + CAST(tbTrChecklistamallVersionPunkt.intNummer AS VARCHAR) +
		   ': ' + tbOmraade.strNamn + CHAR(13) + CHAR(10)
	     ELSE NULL
	     END AS strChecklistaPunkterMedJa,

	   CASE 
         WHEN(strVaerde = 'Nej') THEN
		   CAST(tbOmraade.intNummer AS VARCHAR) + 
		   '.' + CAST(tbTrChecklistamallVersionPunkt.intNummer AS VARCHAR) +
		   ': ' + tbOmraade.strNamn + CHAR(13) + CHAR(10)
	     ELSE NULL
	     END AS strChecklistaPunkterMedNej

FROM dbo.tbTrChecklistaPunkt
LEFT OUTER JOIN dbo.tbTrChecklistamallVersionVaerden 
  ON dbo.tbTrChecklistaPunkt.recChecklistamallVersionVaerdenID = dbo.tbTrChecklistamallVersionVaerden.recChecklistamallVersionVaerdenID
LEFT OUTER JOIN dbo.tbTrChecklistamallVersionPunkt 
  ON dbo.tbTrChecklistaPunkt.recChecklistamallVersionPunktID = dbo.tbTrChecklistamallVersionPunkt.recChecklistamallVersionPunktID
LEFT OUTER JOIN dbo.tbTrChecklistamallVersionOmraade As tbOmraade
  ON dbo.tbTrChecklistamallVersionPunkt.recChecklistamallVersionOmraadeID = tbOmraade.recChecklistamallVersionOmraadeID
LEFT OUTER JOIN dbo.tbTrChecklistamallVersion
  ON dbo.tbTrChecklistamallVersion.recChecklistaVersionID = tbOmraade.recChecklistaVersionID
go

