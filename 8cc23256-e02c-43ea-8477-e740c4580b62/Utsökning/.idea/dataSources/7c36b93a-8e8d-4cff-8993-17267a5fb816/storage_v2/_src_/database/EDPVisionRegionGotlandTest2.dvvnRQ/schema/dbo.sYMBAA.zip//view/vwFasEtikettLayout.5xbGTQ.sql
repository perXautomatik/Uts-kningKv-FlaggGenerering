CREATE VIEW [dbo].[vwFasEtikettLayout]
AS
SELECT     dbo.tbFasADRPL.strGARDSNAMN, dbo.tbFasLAGF.strNAMN, dbo.tbFasLAGF.strFNRID,  
                      dbo.tbFasADRPL.strADROMRADE +' ' + dbo.tbFasADRPL.strADRPLATS as Gatuadress, dbo.tbFasLAGF.recLAGF AS intRecnum, dbo.tbFasADRPL.strPOSTNR +'  '+ dbo.tbFasADRPL.strPOSTORT as Postadress
FROM         dbo.tbFasADRPL INNER JOIN
                      dbo.tbFasLAGF ON dbo.tbFasADRPL.strFNRID = dbo.tbFasLAGF.strFNRID

go

