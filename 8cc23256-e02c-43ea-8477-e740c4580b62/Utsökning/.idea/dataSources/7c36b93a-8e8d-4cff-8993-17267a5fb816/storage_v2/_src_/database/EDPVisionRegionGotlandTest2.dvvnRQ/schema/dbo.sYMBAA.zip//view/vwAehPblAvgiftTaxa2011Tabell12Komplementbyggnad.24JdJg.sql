

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell12Komplementbyggnad]
AS
SELECT    recPblAvgiftTaxa2011Tabell12KomplementbyggnadID
		, recPblAvgiftTaxa2011Tabell12KomplementbyggnadID as 'intRecnum'
		, recPblAvgiftTaxa2011Tabell12ID
		, strObjekt
		, strBeskrivning
		, intOF
		, intHF1
		, intHF2
FROM      dbo.tbAehPblAvgiftTaxa2011Tabell12Komplementbyggnad
go

