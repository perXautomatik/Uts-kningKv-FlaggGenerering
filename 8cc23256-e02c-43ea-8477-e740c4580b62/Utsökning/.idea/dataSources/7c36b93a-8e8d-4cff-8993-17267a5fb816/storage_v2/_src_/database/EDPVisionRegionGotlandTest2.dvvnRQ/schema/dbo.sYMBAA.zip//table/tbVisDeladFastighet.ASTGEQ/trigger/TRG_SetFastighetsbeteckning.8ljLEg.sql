
        CREATE TRIGGER TRG_SetFastighetsbeteckning ON tbVisDeladFastighet
        AFTER INSERT, UPDATE
        AS
        BEGIN

        IF @@ROWCOUNT = 0
        RETURN

            UPDATE tbVisDeladFastighet
            SET tbVisDeladFastighet.strFastighetsbeteckning = ISNULL(strTrakt, '') + ' ' + ISNULL(strBlock, '') + ISNULL(strTkn, '') + ISNULL(LTRIM(STR(intEnhet)), '')
            WHERE  tbVisDeladFastighet.strFnrID IN (SELECT INSERTED.strFnrID FROM INSERTED)

        END
        go

