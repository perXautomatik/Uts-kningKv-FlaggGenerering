

CREATE VIEW [dbo].[vwAehBaBostadsanpassningUtbetalning]
AS
SELECT		dbo.tbAehBaBostadsanpassningUtbetalning.recBostadsanpassningUtbetalningID, 
			dbo.tbAehBaBostadsanpassningUtbetalning.recBostadsanpassningUtbetalningID as intRecnum, 
			dbo.tbAehBaBostadsanpassningUtbetalning.recBostadsanpassningID, 
			dbo.tbAehBaBostadsanpassningUtbetalning.datDatum, 
			dbo.tbAehBaBostadsanpassningUtbetalning.intUserID, 
			dbo.tbAehBaBostadsanpassningUtbetalning.strKommentar,
			dbo.tbAehBaBostadsanpassningUtbetalning.recEnstakaKontaktID,			 
			dbo.tbVisEnstakaKontakt.strVisasSom as strUtbetalatTill, 
			(select SUM(ISNULL(decBelopp,0)) 
            from tbAehBaBostadsanpassningUtbetalningAatgaerd as Atgard
            where Atgard.recBostadsanpassningUtbetalningID = tbAehBaBostadsanpassningUtbetalning.recBostadsanpassningUtbetalningID) as decTotaltBelopp ,
			dbo.tbAehAerendeData.strDiarienummer as strAerendeDiarienummer,
			handlaeggare.strUserFirstname +' ' + handlaeggare.strUserSurname as strHandlaeggare,
			
			STUFF((SELECT ',' + strAatgaerd  
						FROM dbo.tbAehBaBostadsanpassningAatgaerd 
							INNER JOIN dbo.tbAehBaBostadsanpassningUtbetalningAatgaerd
							ON dbo.tbAehBaBostadsanpassningUtbetalningAatgaerd.recBostadsanpassningAatgaerdID = tbAehBaBostadsanpassningAatgaerd.recBostadsanpassningAatgaerdID 
							WHERE dbo.tbAehBaBostadsanpassningUtbetalning.recBostadsanpassningUtbetalningID = dbo.tbAehBaBostadsanpassningUtbetalningAatgaerd.recBostadsanpassningUtbetalningID
							FOR XML PATH('')
					), 1, 1, '') as strAatgaerder,
			handlaeggare.strSignature as handlaeggareSignatur,
			'' as strAatgaerdBelopp		
			
FROM        dbo.tbAehBaBostadsanpassningUtbetalning
			LEFT JOIN dbo.tbAehBaBostadsanpassning 
				ON dbo.tbAehBaBostadsanpassningUtbetalning.recBostadsanpassningID = dbo.tbAehBaBostadsanpassning.recBostadsanpassningID
			LEFT JOIN dbo.tbAehAerendeData
				ON dbo.tbAehBaBostadsanpassning.recAerendeID = dbo.tbAehAerendeData.recAerendeID								
			LEFT OUTER JOIN tbEDPUser as handlaeggare
				ON handlaeggare.intUserID = dbo.tbAehBaBostadsanpassningUtbetalning.intUserID
			LEFT OUTER JOIN tbVisEnstakaKontakt
				ON dbo.tbVisEnstakaKontakt.recEnstakaKontaktID = dbo.tbAehBaBostadsanpassningUtbetalning.recEnstakaKontaktID

go

