



CREATE VIEW [dbo].[vwMhPerson]
AS
SELECT tbMhPerson.recPersonID, 
  tbMhPerson.recPersonID AS intRecnum, 
  tbMhPerson.bolEjAktuell,
  tbMhPerson.strOrgPersNr, 
  tbMhPerson.strFoernamn, 
  tbMhPerson.strEfternamn, 
  LTRIM(ISNULL(RTRIM(strFoernamn) + ' ', '') + RTRIM(LTRIM(strEfternamn))) AS strNamn, 
  tbMhPerson.strTitel, 
  tbMhPerson.strAdress, 
  tbMhPerson.strCoadress, 
  tbMhPerson.strPostnr, 
  tbMhPerson.strPostort, 
  tbMhPerson.strLand,
  tbMhPerson.recPartiID, 
  tbMhParti.strPartifoerkortning, 
  tbMhParti.strPartinamn,
  tbMhPerson.strRestid, 
  tbMhPerson.decResstraecka, 
  tbMhPerson.intInvalsnummer,
  tbMhPerson.strTele, 
  tbMhPerson.strMobil, 
  tbMhPerson.strEmail
FROM tbMhPerson
  LEFT OUTER JOIN [dbo].[tbMhParti]
  ON tbMhParti.recPartiID = tbMhPerson.recPartiID



go

