


CREATE VIEW [dbo].[vwTrAvgiftskod]
AS
SELECT     

	tbTrAvgiftskod.recAvgiftskodID, 
	tbTrAvgiftskod.recAvgiftskodID as intRecnum, 
	tbTrAvgiftskod.strAvgiftskod, 
	tbTrAvgiftskod.intAvgift, 
	tbTrAvgiftskod.strTillsynstid, 
	tbTrAvgiftskod.bolSpecialpris, 
	tbTrAvgiftskod.strProevningsplikt, 
	tbTrAvgiftskod.strHuvudrubrik, 
	tbTrAvgiftskod.strUnderrubrik, 
    tbTrAvgiftskod.strBeskrivning, 
	tbTrAvgiftskod.intAvgiftsklass, 
	tbTrAvgiftskod.bolEjAktuell, 
	tbTrAvgiftskod.recBranschKodID,
    tbTrAvgiftskod.strIedKod,
    tbTrAvgiftskod.strLagrum,
    tbTrAvgiftskod.strStorlek,
	
	tbTrBranschkod.strBranschkod,

	tbTrAvgiftskod.recTillsynsobjektTypID,
	vwVisTjaenst.intPris As 'intAktuellTimAvgift',      
	vwTrTillsynsobjektsTyp.strTillsynsobjektsTypNamn

FROM dbo.tbTrAvgiftskod

LEFT OUTER JOIN dbo.tbTrBranschkod
ON tbTrBranschkod.recBranschkodID = tbTrAvgiftskod.recBranschKodID

LEFT OUTER JOIN dbo.vwTrTillsynsobjektsTyp
ON vwTrTillsynsobjektsTyp.recTillsynsobjektTypID = tbTrAvgiftskod.recTillsynsobjektTypID

LEFT OUTER JOIN dbo.vwVisTjaenst
ON vwVisTjaenst.recTjaenstID = vwTrTillsynsobjektsTyp.recTimavgiftTjaenstID

go

