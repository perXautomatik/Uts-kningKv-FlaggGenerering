

CREATE VIEW [dbo].[vwTrChecklistaRapporteringspunkter]
AS
SELECT		tbPunkt.recChecklistamallVersionPunktID As 'intRecnum',
			Convert(nvarchar(5), tbOmraade.intNummer) + '.' + Convert(nvarchar(5), tbPunkt.intNummer) + ' ' + tbOmraade.strNamn + ' - ' + tbPunkt.strNamn AS 'OmraadePunkt',

			tbPunkt.recChecklistamallVersionPunktID, 
			tbPunkt.strNamn AS 'Punktnamn',
			tbPunkt.intNummer As 'Punktnummer', 
			tbPunkt.strHjaelpText, 
			ISNULL(tbPunkt.strRapporteringsPunkt, '') as strRapporteringsPunkt, 
			
			tbOmraade.recChecklistamallVersionOmraadeID,
			tbOmraade.strNamn AS 'Omraadenamn',
			tbOmraade.intNummer AS 'Omraadenummer',
			
			tbVersion.recChecklistaVersionID,
			tbVersion.strFilversion,
			
			tbChecklista.recChecklistamallID,
			tbChecklista.strNamn AS 'Checklistanamn',
			
			RIGHT('000' + CAST(tbOmraade.intNummer as VARCHAR(2)), 3) + '.' + RIGHT('000' + CAST(tbPunkt.intNummer as VARCHAR(2)), 3) AS sortcolumn

FROM  		tbTrChecklistamallVersionPunkt AS tbPunkt

LEFT  OUTER JOIN tbTrChecklistamallVersionOmraade AS tbOmraade 
      ON  tbOmraade.recChecklistamallVersionOmraadeID = tbPunkt.recChecklistamallVersionOmraadeID 

LEFT  OUTER JOIN tbTrChecklistamallVersion AS tbVersion 
	  	ON  tbVersion.recChecklistaVersionID = tbOmraade.recChecklistaVersionID 

LEFT  OUTER JOIN tbTrChecklistamall AS tbChecklista 
		  ON  tbChecklista.recChecklistaMallID = tbVersion.recChecklistaMallID 
WHERE   tbVersion.recChecklistaVersionID = 
(
	SELECT max(tbVersion.recChecklistaVersionID) AS recChecklistamallVersionPunktID

	FROM tbTrChecklistamallVersionPunkt AS tbPunkt

	LEFT  OUTER JOIN tbTrChecklistamallVersionOmraade AS tbOmraade 
	ON  tbOmraade.recChecklistamallVersionOmraadeID = tbPunkt.recChecklistamallVersionOmraadeID 

	LEFT  OUTER JOIN tbTrChecklistamallVersion AS tbVersion 
	ON  tbVersion.recChecklistaVersionID = tbOmraade.recChecklistaVersionID 

	LEFT  OUTER JOIN tbTrChecklistamall AS tbChecklista 
	ON  tbChecklista.recChecklistaMallID = tbVersion.recChecklistaMallID 

	--GROUP BY tbChecklista.recChecklistamallID
)



go

