

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell11KomplementByggnad]
AS
SELECT     tbAehPblTaxa2011Tabell11Komplementbyggnad.recTabell11ID, 
		   recKomplementID as 'intRecnum',
		   recKomplementID,
		   strObjekt,
		   strBeskrivning,
		   recTaxa2011ID,
		   intOf,
		   intHF1,
		   intHF2
FROM dbo.tbAehPblTaxa2011Tabell11Komplementbyggnad
LEFT OUTER JOIN vwAehPblTaxa2011Tabell11 
ON vwAehPblTaxa2011Tabell11.recTabell11ID = tbAehPblTaxa2011Tabell11Komplementbyggnad.recTabell11ID


go

