CREATE VIEW Clusterd_tbTrEaAvloppsanlaeggning
WITH SCHEMABINDING
AS
SELECT recAvloppsanlaeggningID,
       recTillsynsobjektID,
       strBoendetyp,
       strVatten,
       bolIndraget,
       strAnlaeggningstyp,
       strStatus,
       intByggnadsaar,
       datBeslutsdatum,
       datBesiktningsdatum,
       strNotering,
       strEfterfoeljandereningReningstyp,
       intEfterfoeljandereningYta,
       strEfterfoeljandereningRecipient,
       strBedoemning,
       strInventering,
       datInventeringsdatum,
       intLoepnr,
       strVattenskyddsomraade,
       strPrioritet,
       strEfterpoleringTyp,
       intUnderhaallsintervallMaanad,
       datNaastaService,
       datFoeregaandeService,
       strAvrinningsomraade
from [dbo].tbTrEaAvloppsanlaeggning
go

