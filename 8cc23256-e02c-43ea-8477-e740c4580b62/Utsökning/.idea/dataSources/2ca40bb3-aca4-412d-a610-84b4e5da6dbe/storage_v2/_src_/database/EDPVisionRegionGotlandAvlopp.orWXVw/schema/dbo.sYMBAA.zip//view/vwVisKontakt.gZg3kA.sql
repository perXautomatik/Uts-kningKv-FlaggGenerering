
            CREATE VIEW [dbo].[vwVisKontakt] AS
            SELECT recKontaktID
	            , recKontaktHistorik
	            , datSkapad
	            , recKontaktTypID
	            , strKontaktTyp
	            , bolEjAktuell
	            , strOrgPersNr
	            , strFoernamn
	            , strEfternamn
	            , strNamn
	            , strTitel
	            , strAdress
	            , strCoadress
	            , strPostnr
	            , strPostort
	            , strLand
	            , strSignature
	            , strTele
	            , strMobil
	            , strEmail
	            , intRecnum
	            , intMainTableID
	            , strAnledning
	            , strOrganistion
	            , datDatumBort
	            , intSkapadAv
	            , strAnteckning
            FROM 
            (SELECT * FROM [dbo].[vwVisKontaktHistorik]
                WHERE recKontaktHistorik IN (
                  SELECT TOP 1 recKontaktHistorik FROM [dbo].[tbVisKontaktHistorik]
                  WHERE tbVisKontaktHistorik.intMainTableID = recKontaktID
                  AND datSkapad <= GETDATE()
                  ORDER BY datSkapad DESC)) as tbl
            go

