CREATE Function dbo.usp_FilterByHasArende(@TVP HandelseTableType READONLY)
RETURNS table AS
      return select tv.* from @tvp tv left outer join (select Diarienummer from @TVP 
	  where CC_harAnsok = 1) 
	  has on has.Diarienummer = tv.Diarienummer where has.Diarienummer is null
go

