CREATE VIEW MittVsEdpEjskapadeObjekt AS select DISTINCT
    _ObjektID_,
    _Objektnamn_,
    recTillsynsobjektID,
    strObjektsNamn

from EDPVisionRegionGotlandAvlopp.dbo.tbTrTillsynsobjekt right outer join tempExcel.dbo.Blad1ObjIDObjNamn on _Objektnamn_ = EDPVisionRegionGotlandAvlopp.dbo.tbTrTillsynsobjekt.strObjektsNamn
WHERE recTillsynsobjektID  IS NULL or strObjektsNamn IS NULL
go

