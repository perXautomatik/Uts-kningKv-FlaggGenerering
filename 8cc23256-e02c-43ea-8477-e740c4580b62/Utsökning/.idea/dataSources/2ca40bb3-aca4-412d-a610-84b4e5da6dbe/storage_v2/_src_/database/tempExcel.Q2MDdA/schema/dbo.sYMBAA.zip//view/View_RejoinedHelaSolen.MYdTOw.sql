create view RejoinedHelaSolen as select HelaSolen3._ObjektID_,
       _Objektnamn_,
       _Anteckning_,
       _Inventering_,
       _Inventeringsinformation_Datum_,
       _Inventeringsinformation_Status_,
       _Bedömning_,
       _fliken_Fastigheter_,
       _fliken_FastigheterFNR_,
       _Adress_,
       _Besöksadress_Postnr_,
       _Besöksadress_Ort_,
       _Besöksadress_Huvudfastighet_,
       _FNR_,
       _Fliken_Koordinater_,
       _flik_Avloppsänlaggni_Boendetyp_,
       _flik_Avloppsanläggn_Byggnadsår_,
       _flik_Avloppsa_Besiktningsdatum_,
       _flik_Avloppsanläg_Beslutsdatum_,
       _Vatten_,
       _Recipient_,
       _Anläggningskategori_,
       _besiktningdatum_,
       _beslutsdatum_,
       _Anläggningstyp_,
       _Volym_m3_,
       _Anl_för_EftR_TöInterv_mån_,
       _AnlF_efR_Koordinater_X_o_Y_,
       _PunkttypER_,
       _Anläggning_för_EfterföljRText_,
       _PunkttypAB_,
       _Anläggningskategori_2_,
       _Anläggning_för_S_Anläggningstyp_,
       _Externt_Tjänsteid_,
       _text_,
       _Anläggning_för_Slamav_Volym_m3_,
       _Anläggningskategori_3_,
       _AnlförEfterR_Anläggningstyp_,
       _besiktningdatum_2_,
       _beslutsdatum_2_,
       _Externt_Tjänsteid2_,
       _Volym_m32_,
       _Verksamhetsutövare_Namn_,
       _Verksamhetsutöv_Person_orgnr_,
       _fliken_Ärenden_,
       _Timdebitering_,
       _Fakturamottagare_NAMN_,
       _Fakturamottagare_Faktura_ADRESS_,
       _Fakturamottagare_Faktura_POSTNR_,
       _Fakturamottagare_Faktura_POSTOR_
from HelaSolen3
left outer join Blad1ObjIDObjNamn B1OION on HelaSolen3._ObjektID_ = B1OION._ObjektID_
left outer join BladObjeAnteck BOA on HelaSolen3._ObjektID_ = BOA._ObjektID_
left outer join BladObjeInventer BOI on HelaSolen3._ObjektID_ = BOI._ObjektID_
left outer join BladObjFastigheter BOF on HelaSolen3._ObjektID_ = BOF._ObjektID_
left outer join BladObjHuvudFast BOHF on HelaSolen3._ObjektID_ = BOHF._ObjektID_
left outer join bladObjKoord bOK on HelaSolen3._ObjektID_ = bOK._ObjektID_
left outer join BladObjPåkoppladFastighet BOPF on HelaSolen3._ObjektID_ = BOPF._ObjektID_
left outer join BladObjRening BOR on HelaSolen3._ObjektID_ = BOR._ObjektID_
left outer join BladObjSlamskilj BOS on HelaSolen3._ObjektID_ = BOS._ObjektID_
left outer join BladObjTank BOT on HelaSolen3._ObjektID_ = BOT._ObjektID_
left outer join BladObjVerksamhetsUtövare BOVU on HelaSolen3._ObjektID_ = BOVU._ObjektID_
left outer join BladObjÄrenden BOÄ on HelaSolen3._ObjektID_ = BOÄ._ObjektID_
left outer join BlodObjTimdeb B on HelaSolen3._ObjektID_ = B._ObjektID_
left outer join FakturaMottagare FM on HelaSolen3._ObjektID_ = FM._ObjektID_
go

