create view ServersinScope as
    select * from sys.servers
go

