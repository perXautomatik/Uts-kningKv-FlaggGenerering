CREATE FUNCTION  dbo.usp_SplitReturnOcX(@stringToSplit as varchar(100),@nr as smallint,@delimeeter as character)
RETURNS
 varchar(max)
AS
BEGIN

 DECLARE @name NVARCHAR(255)
 DECLARE @pos INT
 Declare @returnList TABLE ([Name] [nvarchar] (500),[id] [int])
 declare @itterator Int
 set @itterator = 0

 WHILE CHARINDEX(@delimeeter, @stringToSplit) > 0
 BEGIN
  set @pos  = CHARINDEX(@delimeeter, @stringToSplit)
  set @name = SUBSTRING(@stringToSplit, 1, @pos-1)
  set @itterator = @itterator + 1

  INSERT INTO @returnList
  SELECT @name,@pos

  set @stringToSplit = SUBSTRING(@stringToSplit, @pos+1, LEN(@stringToSplit)-@pos)
 END
 
   INSERT INTO @returnList
  SELECT  @stringToSplit,@pos

 set @name =  (select name from (select name, row_number() over (order by id) r from @returnList) q where r = @nr)
 return @name
END
go

