create procedure dbo.fn_xScalarDiaToTableDia(@Diax TT_EndastUnikaArenden READONLY) as
begin
declare @Results table (Diarienummer nvarCHAR(30))

insert into @Results select * from @Diax
select * from @Results
end
go

