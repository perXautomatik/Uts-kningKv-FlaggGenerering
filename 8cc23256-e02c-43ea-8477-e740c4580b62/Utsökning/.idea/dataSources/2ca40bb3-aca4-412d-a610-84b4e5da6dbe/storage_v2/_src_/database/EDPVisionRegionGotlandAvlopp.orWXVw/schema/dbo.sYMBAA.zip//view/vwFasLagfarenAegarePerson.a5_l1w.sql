CREATE VIEW [dbo].[vwFasLagfarenAegarePerson]
AS
SELECT     dbo.tbFasLAGF.recLAGF AS intRecNum, dbo.tbFasLAGF.strOTYP, dbo.tbFasLAGF.strDATUMLOP, dbo.tbFasLAGF.strFNRID, dbo.tbFasLAGF.strDBNRID, 
                      dbo.tbFasLAGF.strFANG, dbo.tbFasLAGF.strFANGDATUM, dbo.tbFasLAGF.strKOPTYP, dbo.tbFasLAGF.strINSKDATUM, dbo.tbFasLAGF.strANDEL, 
                      dbo.tbFasLAGF.strNAMN, dbo.tbFasLAGF.strPERSONNR, dbo.tbFasLAGF.strLAGFANM, dbo.tbFasPERSON.strFAL_CO, 
                      dbo.tbFasPERSON.strFAL_UTADR1, dbo.tbFasPERSON.strFAL_UTADR2, dbo.tbFasPERSON.strFAL_POSTNR, dbo.tbFasPERSON.strFAL_POSTORT, 
                      dbo.tbFasPERSON.strKORTNAMN, dbo.tbFasLAGF.intKOPSUM
FROM         dbo.tbFasLAGF INNER JOIN
                      dbo.tbFasPERSON ON dbo.tbFasLAGF.strPERSONNR = dbo.tbFasPERSON.strPERSONNRID
go

