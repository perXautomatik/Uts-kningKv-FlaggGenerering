create view BestFir as

    with
     re_regrownerinfo as (select RealEstateKey,REFREGDOMESTICOWNER, REFREPREVIOUS,DENOMINATOR,DOCNAME,IDENT,NUMERATOR,OBJECTTYP,REGDOMESTICOWNERID,REGDT from [GISDATA].[sde_geofir_gotland].gng.RE_REGOWNERINFO),
     RE_PERSONORGANISATION as (select ADDRESS1,ADDRESS2,ADDRESSCO,COUNTRY,FOREIGNADDRESS1,FOREIGNADDRESS2,FOREIGNADDRESS3,FOREIGNADDRESS4,MIDDLENAME,POSTCITY,POSTNR,SPECIALADDRESS1,SPECIALADDRESS2,SPECIALADDRESSCO,SPECIALPOSTCITY,SPECIALPOSTNR,FIRSTNAME,LASTNAME,
                                      NAME, OBJECTTYP, PERSONORGANISATIONNR from [GISDATA].[sde_geofir_gotland].gng.RE_PERSONORGANISATION),
     RE_REGPURCHASEREF as (select REALESTATEID, RealEstateKey, REGPURCHASEINFOID from [GISDATA].[sde_geofir_gotland].gng.RE_REGPURCHASEREF),
     RETAXATIONUNIT as (select DataYear,RealEstateKey,BuildingValue,CodeType,CreationType,GroundValue,HasJointTax,TaxIdentity,TaxYear,TotalArea,TotalValue from [GISDATA].[sde_geofir_gotland].gng.RETAXATIONUNIT),
     REREALESTATE as (select fnr realestatekey, beteckning name from [GISDATA].[sde_geofir_gotland].gng.FA_FASTIGHET),
   RE_REGPURCHASEINFO as (select GID,PURCHASESUM,PURCHASETYP from [GISDATA].[sde_geofir_gotland].gng.RE_REGPURCHASEINFO),
     RE_REGTITLEDEED as (select CREATIONDAY,CREATIONTYP,REGDT, NUMERATOR, DENOMINATOR, DOCNAME, IDENT from [GISDATA].[sde_geofir_gotland].gng.RE_REGTITLEDEED),
     RE_REGDOMESTICOWNER as (select FIRSTNAME,LASTNAME,
                                    GID, idnr from [GISDATA].[sde_geofir_gotland].gng.RE_REGDOMESTICOWNER)


select distinct
                e.NAME kir ,g.RealEstateKey,DataYear,
                coalesce(nullif(y.REGDT, g.REGDT), g.REGDT, y.REGDT)                         REGDT,
                REGDOMESTICOWNERID,
                x.NAME,t.FIRSTNAME tFIRSTNAME,x.FIRSTNAME xFIRSTNAME,t.LASTNAME tLASTNAME ,x.LASTNAME xLASTNAME,
                -- c.REALESTATEID,g.REALESTATEID,u.REALESTATEID,--x.UniqueID, ACTIVENAMEFLAG, IDNR,
                PERSONORGANISATIONNR,
                POSTCITY,POSTNR,ADDRESS1,ADDRESS2,ADDRESSCO,COUNTRY,FOREIGNADDRESS1,FOREIGNADDRESS2,FOREIGNADDRESS3,FOREIGNADDRESS4,MIDDLENAME,SPECIALADDRESS1,SPECIALADDRESS2,SPECIALADDRESSCO,SPECIALPOSTCITY,SPECIALPOSTNR,
                coalesce(nullif(y.NUMERATOR, g.NUMERATOR), y.NUMERATOR, g.NUMERATOR)         NUMERATOR,
                coalesce(nullif(y.DENOMINATOR, g.DENOMINATOR), y.DENOMINATOR, g.DENOMINATOR) DENOMINATOR,
                coalesce(nullif(y.DOCNAME, g.DOCNAME), y.DOCNAME, g.DOCNAME)                 DOCNAME,
                g.IDENT,x.OBJECTTYP xOBJECTTYP,g.OBJECTTYP gOBJECTTYP,REGPURCHASEINFOID,
                PURCHASESUM,PURCHASETYP,CREATIONDAY,CREATIONTYP,BuildingValue,CodeType,CreationType,GroundValue,HasJointTax,TaxIdentity,TaxYear,TotalArea,TotalValue
from re_regrownerinfo g left outer join RE_REGDOMESTICOWNER t on
     t.GID = coalesce(g.REGDOMESTICOWNERID, g.REFREGDOMESTICOWNER, g.REFREPREVIOUS)
         left outer join RE_PERSONORGANISATION x on x.PERSONORGANISATIONNR = t.idnr
         left outer join RE_REGPURCHASEREF c on g.RealEstateKey = c.RealEstateKey
         left outer join RETAXATIONUNIT u on g.RealEstateKey = u.RealEstateKey
        left outer join REREALESTATE e ON g.RealEstateKey = e.RealEstateKey
         left outer join RE_REGPURCHASEINFO b on b.GID = c.REGPURCHASEINFOID
         left outer join RE_REGTITLEDEED y on y.IDENT = g.IDENT
where x.NAME is not null
go

