CREATE VIEW dbo.FNRKIRDIARENR_FörUtskick
AS

SELECT        z.Fastighet KIR, x.FNR, z.Diarienummer AS Diarienr
FROM            [tempExcel].dbo.[2019-10-02-förbud_1] z left outer join GISDATA.[sde_geofir_gotland].[gng].Fa_Fastighet x on z.Fastighet = x.beteckning
go

