CREATE function stringComparision(@a as nvarchar(max), @b as nvarchar(max))
    returns bit
as
begin
    return (iif(@a = @b, 1,
                iif(@a is null AND @b is null, 1,
                    iif(@a is null and @b = '', 1,
                        iif(@b is null and @a = '', 1,
                            iif(@a is null and try_cast(@b as int) = 0, 1,
                                iif(@b is null and try_cast(@a as int) = 0, 1,
                                    0)))))))
end
go

