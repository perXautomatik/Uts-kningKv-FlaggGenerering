create function Fn_compareDatatypesOFtwoTables(@TABLE_SCHEMA1 varchar(60),@TABLE_NAME1 varchar(125),@TABLE_SCHEMA2 varchar(60),@TABLE_NAME2 varchar(125))
 returns table as return
select coalesce(zxy.DATA_TYPE,wsa.DATA_TYPE) DATA_TYPE,
       coalesce(zxy.CHARACTER_MAXIMUM_LENGTH,wsa.CHARACTER_MAXIMUM_LENGTH) CHARACTER_MAXIMUM_LENGTH,
       concat(@TABLE_SCHEMA1,'.',@TABLE_NAME1,'.',zxy.COLUMN_NAME) zxyCOLUMN_NAME,
       concat(@TABLE_SCHEMA2,'.',@TABLE_NAME2,'.',wsa.COLUMN_NAME) wsaCOLUMN_NAME,
       (select count(*)-(case when zxy.COLUMN_NAME = wsa.COLUMN_NAME then 1 else 0 end)
        from string_split(concat(zxy.DATA_TYPE,',',wsa.DATA_TYPE,',',zxy.COLUMN_NAME,',',wsa.COLUMN_NAME),',') where value = '') lowerbetter

from
(select DATA_TYPE,COLUMN_NAME,CHARACTER_MAXIMUM_LENGTH from INFORMATION_SCHEMA.COLUMNS xz where TABLE_SCHEMA = @TABLE_SCHEMA1 and TABLE_NAME = @TABLE_NAME1) zxy
full outer join
(select DATA_TYPE,COLUMN_NAME,CHARACTER_MAXIMUM_LENGTH from INFORMATION_SCHEMA.COLUMNS xz where TABLE_SCHEMA = @TABLE_SCHEMA2  and TABLE_NAME = @TABLE_NAME2) wsa
    on wsa.DATA_TYPE = zxy.DATA_TYPE and isnull(wsa.CHARACTER_MAXIMUM_LENGTH,0) = isnull(zxy.CHARACTER_MAXIMUM_LENGTH,0)
go

