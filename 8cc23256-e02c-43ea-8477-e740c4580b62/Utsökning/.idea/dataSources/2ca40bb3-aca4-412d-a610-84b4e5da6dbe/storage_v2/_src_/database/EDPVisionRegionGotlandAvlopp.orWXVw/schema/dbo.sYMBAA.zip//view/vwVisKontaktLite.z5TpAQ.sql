
            CREATE VIEW [dbo].[vwVisKontaktLite] AS
            SELECT
                  recKontaktID
                , strNamn
                , intRecnum
                , strOrgPersNr
                , strAdress
                , strCoadress
                , strPostnr
                , strPostort
            FROM dbo.vwVisKontakt
            go

