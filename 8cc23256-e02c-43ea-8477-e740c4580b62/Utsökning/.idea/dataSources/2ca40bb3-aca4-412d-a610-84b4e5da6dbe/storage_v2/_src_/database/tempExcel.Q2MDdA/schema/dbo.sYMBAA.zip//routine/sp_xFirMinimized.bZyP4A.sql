create function sp_xFirMinimized(@diaKir as HandelseTableType READONLY ) returns table as
return
    with FirRaw as
        (select PERSORGNR, FAL_CO, FAL_UTADR1, FAL_UTADR2, FAL_POSTNR, FAL_POSTORT
        , SAL_CO, SAL_UTADR1, SAL_UTADR2, SAL_POSTNR, SAL_POSTORT
        , UA_UTADR1, UA_UTADR2, UA_UTADR3, UA_UTADR4, UA_LAND,input.fastighet
        from GISDATA.sde_geofir_gotland.gng.FA_lagfart_V2 q inner join sp_xKirToFnr(@DiaKir) input on q.FNR = input.fnr)
    select PERSORGNR,
                                     concat(case when FAL_CO <> '' then concat(FAL_CO, ',') else '' end,
                                            case when FAL_UTADR1 <> '' then concat(FAL_UTADR1, ',') else '' end,
                                            FAL_UTADR2)                        adress,
                                     tempExcel.dbo.udf_xGetNumeric(FAL_POSTNR) postnr,
                                     FAL_POSTORT,fastighet
                              from
                                   (select PERSORGNR, FAL_CO, FAL_UTADR1, FAL_UTADR2, FAL_POSTNR, FAL_POSTORT,fastighet
                         from
                             FirRaw
                         where not (nullif(FAL_co, '') is null ANd nullif(FAL_UTADR1, '') is null and
                                    nullif(FAL_UTADR2, '') is null)
                           AND nullif(FAL_POSTNR, 0) is not null
                           and nullif(FAL_POSTORT, '') is not null
                         union
                         select PERSORGNR, SAL_CO, SAL_UTADR1, SAL_UTADR2, SAL_POSTNR, SAL_POSTORT,fastighet
                         from FirRaw
                         where not (nullif(sal_co, '') is null ANd nullif(sal_UTADR1, '') is null and
                                    nullif(sal_UTADR2, '') is null)
                           AND nullif(sal_POSTNR, 0) is not null
                           and nullif(sal_POSTORT, '') is not null
                         union
                         select PERSORGNR, UA_UTADR1, UA_UTADR2, UA_UTADR3, UA_UTADR4, UA_LAND,fastighet
                         from FirRaw
                         where not (nullif(UA_UTADR1, '') is null ANd nullif(UA_UTADR2, '') is null and
                                    nullif(UA_UTADR3, '') is null)
                           AND nullif(UA_UTADR4, '') is not null
                           and nullif(UA_LAND, '') is not null)
                                   EnAdressTyp
go

