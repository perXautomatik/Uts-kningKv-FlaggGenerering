
CREATE VIEW [dbo].[vwFasPlan]
AS
SELECT tbFasPLAN.recPLAN , tbFasPLAN.strOTYP, tbFasPLAN.strDATUMLOP, tbFasPLANBEROR.strBNKLID, 
  tbFasPLAN.strGRUPP, tbFasPLAN.strLMAKT, tbFasPLAN.strARKPL, tbFasPLAN.strPLNAMN, tbFasPLAN.strPLANFK, 
  tbFasPLAN.strPSTAT, tbFasPLAN.strBDAT, tbFasPLAN.strGDATB, tbFasPLAN.strGDATU, tbFasPLAN.strGTILL, 
  tbFasPLAN.strLDAT, tbFasPLAN.strSAJDAT, tbFasPLAN.strBMYND, tbFasPLAN.intMFLAGGA, dbo.tbFasPLAN.strONK, 
  tbFasPLAN.strPLANANM, dbo.vwFasFastighet.strKOMMUN, tbFasPLAN.strREGDAT, tbFasPLAN.recPLAN AS intRecNum
FROM tbFasPLAN LEFT OUTER JOIN tbFasPLANBEROR 
  ON tbFasPLAN.strBNKLID = tbFasPLANBEROR.strBNKLID 
INNER JOIN vwFasFastighet 
  ON tbFasPLANBEROR.strFNRID = vwFasFastighet.strFNRID
GROUP BY tbFasPLAN.recPLAN, tbFasPLAN.strOTYP, tbFasPLAN.strDATUMLOP, tbFasPLANBEROR.strBNKLID, 
  tbFasPLAN.strGRUPP, tbFasPLAN.strLMAKT, tbFasPLAN.strARKPL, tbFasPLAN.strPLNAMN, tbFasPLAN.strPLANFK, 
  tbFasPLAN.strPSTAT, tbFasPLAN.strBDAT, tbFasPLAN.strGDATB, tbFasPLAN.strGDATU, tbFasPLAN.strGTILL, 
  tbFasPLAN.strLDAT, tbFasPLAN.strSAJDAT, tbFasPLAN.strBMYND, tbFasPLAN.intMFLAGGA, tbFasPLAN.strONK, 
  tbFasPLAN.strPLANANM, vwFasFastighet.strKOMMUN, tbFasPLAN.strREGDAT
HAVING  (tbFasPLANBEROR.strBNKLID IN
  (SELECT strBNKLID FROM tbFasPLAN AS tbFasPLAN_1))
go

