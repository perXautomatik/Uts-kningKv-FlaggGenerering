CREATE VIEW dbo.vwFasSamtaxering
AS
SELECT     dbo.tbFasSAMTAXF.recSAMTAXF, dbo.tbFasSAMTAXF.strOTYP, dbo.tbFasSAMTAXF.strDATUMLOP, dbo.tbFasSAMTAXF.strFNRSAMID, 
                      dbo.tbFasSAMTAXF.strARID, dbo.tbFasSAMTAXF.strID_TAXENHETID, dbo.tbFasSAMTAXF.recSAMTAXF AS intRecnum, dbo.tbFasTAXENH.strFNRID, 
                      dbo.vwFasFastighet.strFastighetsbeteckning, dbo.vwFasFastighet.strKOMMUN
FROM         dbo.tbFasTAXENH LEFT OUTER JOIN
                      dbo.vwFasFastighet ON dbo.tbFasTAXENH.strFNRID = dbo.vwFasFastighet.strFNRID RIGHT OUTER JOIN
                      dbo.tbFasSAMTAXF ON dbo.tbFasTAXENH.strFNRID = dbo.tbFasSAMTAXF.strFNRSAMID AND 
                      dbo.tbFasTAXENH.strARID = dbo.tbFasSAMTAXF.strARID AND dbo.tbFasTAXENH.strID_TAXENHETID = dbo.tbFasSAMTAXF.strID_TAXENHETID
go

