
            CREATE VIEW dbo.vwVisKontaktRelation AS
            SELECT
            tmp.recKontaktRelationID AS intRecnum
            , tmp.intParent
            , tmp.firstname AS strParentFirstname
            , tmp.lastname AS strParentLastname
            , tmp.intParentRole
            , tmp.intChild
            , tmp.typ AS strParentKontaktTyp
            , tmp.typID AS recParentKontaktTypID
            , h2.strFoernamn AS strChildFirstname
            , h2.strEfternamn AS strChildLastname
            , tmp.intChildRole
            , h2.strKontaktTyp AS strChildKontaktTyp
            , h2.recKontaktTypID AS recChildKontaktTypID
            FROM (SELECT
                relation.recKontaktRelationID
                , h1.strFoernamn AS firstname
                , h1.strEfternamn AS lastname
                , h1.strKontaktTyp AS typ
                , h1.recKontaktTypID AS typID
                , relation.intChild
                , relation.intParent
                , relation.intParentRole
                , relation.intChildRole
            FROM dbo.tbVisKontaktRelation AS relation
            INNER JOIN dbo.vwVisKontakt AS h1 ON h1.recKontaktID = relation.intParent) AS tmp
            INNER JOIN dbo.vwVisKontakt AS h2 ON h2.recKontaktID = tmp.intChild
            go

