CREATE FUNCTION dbo.checkThatItsNotBadHadelseNamn(@TVP HandelseTableType READONLY) 
RETURNS Table AS return select tv.* from @tvp tv where CC_badrubrik = 0
go

