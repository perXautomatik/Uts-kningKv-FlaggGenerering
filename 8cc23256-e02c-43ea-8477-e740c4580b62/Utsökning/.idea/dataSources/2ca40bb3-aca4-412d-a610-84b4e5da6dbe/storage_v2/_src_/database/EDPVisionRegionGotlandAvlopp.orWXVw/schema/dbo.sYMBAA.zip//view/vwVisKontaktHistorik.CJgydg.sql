CREATE VIEW [dbo].[vwVisKontaktHistorik]
AS
SELECT tbVisKontakt.recKontaktID, tbVisKontaktHistorik.recKontaktHistorik, tbVisKontaktHistorik.datSkapad, 
  tbVisKontakt.recKontaktTypID, tbVisKontaktTyp.strKontaktTyp, tbVisKontakt.bolEjAktuell, 
  tbVisKontaktHistorik.strOrgPersNr, tbVisKontaktHistorik.strFoernamn, tbVisKontaktHistorik.strEfternamn, tbVisKontaktHistorik.strNamn, 
  tbVisKontaktHistorik.strTitel, tbVisKontaktHistorik.strAdress, tbVisKontaktHistorik.strCoadress, 
  tbVisKontaktHistorik.strPostnr, tbVisKontaktHistorik.strPostort, tbVisKontaktHistorik.strLand, 
  tbVisKontaktHistorik.strSignature, tbVisKontaktHistorik.strTele, 
  tbVisKontaktHistorik.strMobil, tbVisKontaktHistorik.strEmail, 
  tbVisKontakt.recKontaktID AS intRecnum, tbVisKontaktHistorik.intMainTableID, 
  tbVisKontaktHistorik.strAnledning, tbVisKontaktHistorik.strOrganistion, 
  tbVisKontaktHistorik.datDatumBort, tbVisKontaktHistorik.intSkapadAv, tbVisKontaktHistorik.strAnteckning
FROM dbo.tbVisKontakt 
INNER JOIN dbo.tbVisKontaktHistorik 
ON tbVisKontaktHistorik.intMainTableID = tbVisKontakt.recKontaktID 
LEFT OUTER JOIN dbo.tbVisKontaktTyp 
ON tbVisKontakt.recKontaktTypID = tbVisKontaktTyp.recKontaktTypID
go

