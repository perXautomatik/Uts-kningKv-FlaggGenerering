CREATE VIEW Clusterd_tbVisKoordinat
 WITH SCHEMABINDING
AS
 SELECT recKoordinatID,
            decX,
          decY,
        strPunkttyp,
      strAnteckning
FROM [dbo].tbVisKoordinat
WHERE decX IS NOT NULL AND decY IS NOT NULL
go

