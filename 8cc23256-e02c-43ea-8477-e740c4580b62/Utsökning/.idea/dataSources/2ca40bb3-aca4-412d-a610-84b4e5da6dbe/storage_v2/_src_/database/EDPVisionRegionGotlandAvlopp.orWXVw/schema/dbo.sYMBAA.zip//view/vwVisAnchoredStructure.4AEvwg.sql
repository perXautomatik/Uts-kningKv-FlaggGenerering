CREATE VIEW dbo.vwVisAnchoredStructure
AS
SELECT     dbo.tbVisAnchoredStructure.recAnchoredStructureID, dbo.tbVisAnchoredStructure.strStructureName, dbo.tbVisAnchoredStructure.intUserID, 
                      dbo.tbVisAnchoredStructure.strTopFormHeadline, dbo.tbVisAnchoredStructure.strComment, dbo.tbVisAnchoredStructure.strCategory, 
                      dbo.tbVisAnchoredStructure.binStructure, dbo.tbEDPUser.strSignature, dbo.tbVisAnchoredStructure.recAnchoredStructureID AS intRecnum
FROM         dbo.tbVisAnchoredStructure LEFT OUTER JOIN
                      dbo.tbEDPUser ON dbo.tbVisAnchoredStructure.intUserID = dbo.tbEDPUser.intUserID
go

