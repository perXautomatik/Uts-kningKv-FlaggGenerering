CREATE view vwFasFastighetPlocklista
as
select distinct
	F.strFnrid As strFnrId,F.strFastighetsbeteckning As strFastighetsbeteckning, F.strFastighetsbeteckningUtanStjaerna As FastIKarta,
	F.strTrakt as FastTrackt, F.strBlock as FastBlock, F.intEnhet as FastEnhet, F.strStatus as strStatus, F.strKommun as FastKommun,
	F.strNYKO as FastNyckelkodsomrade, F.strTomtratt as FastTomtratt, F.strREGTYP as FastRegtyp, F.strFrajdatum as FastFrajdatum, 
	F.strIrajdatum as FastIrajdatum, F.bolAgarlag as FastAgarlag, F.bolAgarlagUrholk as FastAgarlagUrholk,
	A.strAdromrade As FastGata, A.strAdrplats As FastGatunr, A.strPostnr As FastPostnr, A.strPostort As FastPostort, A.strGardsnamn as FastGardsadress, A.strPopnamn as FastPopularNamn, A.decXKoord as FastXKoordRiket, A.decYKoord as FastYKoordRiket, A.decXKoordL as FastXKoordLokalt, A.decYKoordL as FastYKoordLokalt,
	L.strNamn As LagfAgareNamn, L.strCO as LagfAgareCO, L.strPersonnr As LagfAgarePersonnr,L.strANDEL As LagfAgareAndel, 
	LagfAgareAdress = case when L.strAdress is null and L.strAdress1 is null and L.strPostnr is null and L.strPostort is null Then L.strUA_UTADR1 ELSE L.strAdress END,
	LagfAgareAdress1 = case when L.strAdress is null and L.strAdress1 is null and L.strPostnr is null and L.strPostort is null Then L.strUA_UTADR2 ELSE L.strAdress1 END,
	LagfAgarePostnr = case when L.strAdress is null and L.strAdress1 is null and L.strPostnr is null and L.strPostort is null Then L.strUA_UTADR3 ELSE L.strPostnr END,
	LagfAgarePostOrt = case when L.strAdress is null and L.strAdress1 is null and L.strPostnr is null and L.strPostort is null Then L.strUA_UTADR4 ELSE L.strPostOrt END,
	L.strKommun as LagfAgareKommun, L.strInskDatum as LagfAgareInskDatum, L.intKopsum as LagfAgareKopsum, L.strKopTyp as LagfAgareKopTyp, 
	L.strLand as LagfAgareLand, L.strFangdatum as LagfAgareFangdatum, L.strFang as LagfAgareFang,
	T.strOrgkortnamn as TaxAgareNamn, T.strCO as TagAgareCO, T.strPersonnr As TaxAgarePersnr, T.strAdress as TaxAgareAdress, T.strAdress1 as TaxAgareAdress1, T.strKommun as TaxAgareKommun, T.strPostnr as TaxAgarePostnr, T.strPostort as TaxAgarePostort, --T.strLand as TaxAgareLand,
	T.intTaljand as TaxAgareTaljand, T.intNamnand as TaxAgareNamnand, T.strArId as TaxAgareArId, T.strAgTyp as TaxAgareAgTyp, T.strID_TAXENHETID as TaxAgareEnhetId,
	U.strFnrid As UrsprFnrid, U.strUrsprungsbeteckning as UrsprFastBet, U.strOmdat as UrsprOmregDatum, U.strRegisterOmraadeKommun as UrsprKommunRegisteromr, U.strInfoTabell as UrsprInfoTabell,
	D.strFnrid As DelFastFnrid,
	DE.strFastighetsbeteckning As DelFastBet,
	DE.strTrakt as DelFastTrackt, DE.strBlock as DelFastBlock, DE.intEnhet as DelFastEnhet, DE.strStatus as DelFastStatus, DE.strKommun as DelFastKommun,
	DE.strNYKO as DelFastNyckelkodsomrade, DE.strTomtratt as DelFastTomtratt, DE.strREGTYP as DelFastRegtyp, DE.strFrajdatum as DelFastFrajdatum, 
	DE.strIrajdatum as DelFastIrajdatum,
	DL.strNamn As DelFastLafgAgareNamn, DL.strCO as DelFastLagfAgareCO, DL.strPersonnr As DelFastLagfAgarePersonnr,DL.strANDEL As DelFastLagfAgareAndel, 
	DelFastLagfAdress = case when DL.strAdress is null and DL.strAdress1 is null and DL.strPostnr is null and DL.strPostort is null Then DL.strUA_UTADR1 ELSE DL.strAdress END,
	DelFastLagfAdress1 = case when DL.strAdress is null and DL.strAdress1 is null and DL.strPostnr is null and DL.strPostort is null Then DL.strUA_UTADR2 ELSE DL.strAdress1 END,
	DelFastLagfPostnr = case when DL.strAdress is null and DL.strAdress1 is null and DL.strPostnr is null and DL.strPostort is null Then DL.strUA_UTADR3 ELSE DL.strPostnr END,
	DelFastLagfPostOrt = case when DL.strAdress is null and DL.strAdress1 is null and DL.strPostnr is null and DL.strPostort is null Then DL.strUA_UTADR4 ELSE DL.strPostOrt END,
	DL.strKommun as DelFastLagfAgareKommun, DL.strInskDatum as DelFastLagfAgareInskDatum, DL.intKopsum as DelFastLagfAgareKopsum, DL.strKopTyp as DelFastLagfAgareKopTyp,
	DL.strLand as DelFastLagfLand, DL.strFangdatum as DelFastLagfFangdatum
from vwFasFastighet As F
left outer join vwFasAdress A on A.strFnrid = F.strFnrid
left outer join tbFasLagfarenAegare_Adress L on L.strFnrid = F.strFnrid
left outer join vwFasTaxpersaTaxpersPersonOrg T on T.strFnrid = F.strFnrid
left outer join vwFasUrsprung U on U.strFnrid = F.strFnrid
left outer join tbFasSagaFast D on D.strFnrId = F.strFnrid
left outer join tbFasDelaegandeEnhet DE on DE.strFnrid = D.strDelFnrid
left outer join tbFasLagfarenAegare_Adress DL on DL.strFnrId = DE.strDelFnrid
go

