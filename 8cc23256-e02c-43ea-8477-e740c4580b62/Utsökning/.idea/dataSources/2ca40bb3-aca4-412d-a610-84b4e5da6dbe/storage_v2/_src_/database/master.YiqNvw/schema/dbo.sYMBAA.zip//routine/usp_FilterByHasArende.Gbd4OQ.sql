CREATE Function dbo.usp_FilterByHasArende(@TVP HandelseTableType READONLY)
RETURNS table AS
      return select tv.* from @tvp tv inner join (select Diarienummer from @TVP where  Riktning = 'inkommande' AND (Rubrik like N'Ansökan%' OR Rubrik like N'ansökan%' OR Rubrik like N'Anmälan%' OR Rubrik like N'anmälan%' OR Rubrik like N'Utförandeintyg%' OR Rubrik like N'utförandeintyg%')) has on has.Diarienummer = tv.Diarienummer
go

