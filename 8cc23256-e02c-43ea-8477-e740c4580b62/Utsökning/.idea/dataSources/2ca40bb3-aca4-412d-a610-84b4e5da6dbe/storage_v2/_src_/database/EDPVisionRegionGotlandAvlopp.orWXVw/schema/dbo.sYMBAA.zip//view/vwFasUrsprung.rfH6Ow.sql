CREATE VIEW [dbo].[vwFasUrsprung]
AS
SELECT     dbo.tbFasURSPRUNG.recURSPRUNG, dbo.tbFasURSPRUNG.strOTYP, dbo.tbFasURSPRUNG.strDATUMLOP, dbo.tbFasURSPRUNG.strFNRID, 
                      dbo.tbFasURSPRUNG.strUFNRID, dbo.tbFasURSPRUNG.strUKOD, dbo.tbFasURSPRUNG.recURSPRUNG AS intRecnum, 
                      dbo.vwFasTidigareFastighetsBeteckningar_Union.strOMDAT, dbo.vwFasTidigareFastighetsBeteckningar_Union.strRegisterOmraadeKommun, 
                      dbo.vwFasTidigareFastighetsBeteckningar_Union.strTrakt, dbo.vwFasTidigareFastighetsBeteckningar_Union.strBlock, 
                      dbo.vwFasTidigareFastighetsBeteckningar_Union.strTKN, dbo.vwFasTidigareFastighetsBeteckningar_Union.strENHET, 
                      dbo.vwFasTidigareFastighetsBeteckningar_Union.strUrsprungsbeteckning, dbo.vwFasTidigareFastighetsBeteckningar_Union.strInfoTabell
FROM         dbo.tbFasURSPRUNG LEFT OUTER JOIN
                      dbo.vwFasTidigareFastighetsBeteckningar_Union ON dbo.tbFasURSPRUNG.strUFNRID = dbo.vwFasTidigareFastighetsBeteckningar_Union.strUFnrID

go

