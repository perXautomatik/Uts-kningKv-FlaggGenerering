create view
    databasesinScope as
    select * from sys.databases
go

