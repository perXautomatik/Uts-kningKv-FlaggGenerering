create view CompareAdressOfOutputWithFir as
    with aPrint as (select fastighet,namn,adress,diarienummer,PERSORGNR from tempExcel.dbo.[AAA to print]),
    firA as (select fir.name,fir.REGDT,fir.ADDRESS1,fir.ADDRESS2,fir.kir,fir.NUMERATOR,fir.DENOMINATOR,cast((cast(fir.NUMERATOR as float) / cast(fir.DENOMINATOR as float)) as float) andel from tempExcel.dbo.BestFir fir inner join (select fastighet from aPrint group by fastighet) x on fir.kir = x.fastighet),
    za as (select andel,name,REGDT,ADDRESS1,ADDRESS2,kir,row_number() over (partition by kir order by REGDT,andel) prio from firA),
    RunningTotalAndel as (select andel,prio,name,REGDT,ADDRESS1,ADDRESS2,kir,SUM(andel) OVER (PARTITION BY kir ORDER BY prio) AS runningAndelTotal from za),
    Fir as (select andel,prio,name,REGDT,ADDRESS1,ADDRESS2,kir,runningAndelTotal from RunningTotalAndel where runningAndelTotal <= 1),
    aaatoPrint as (select fastighet,namn,adress ,row_number() over (partition by z.diarienummer,z.PERSORGNR order by z.diarienummer) prio from aPrint z)
select z.fastighet,z.namn "Utskick har gått till:",z.adress till,x.name "Lagfaren ägare",x.andel,cast(x.REGDT as date)            dataÅR,coalesce(x.ADDRESS1, x.ADDRESS2) adress
    from aaatoPrint z right outer join Fir x on z.fastighet = x.kir and z.prio = x.prio
go

