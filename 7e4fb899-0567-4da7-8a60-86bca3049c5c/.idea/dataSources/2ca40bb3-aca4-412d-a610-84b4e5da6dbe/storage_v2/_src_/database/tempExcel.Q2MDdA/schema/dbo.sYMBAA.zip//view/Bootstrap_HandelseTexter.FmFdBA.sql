CREATE VIEW dbo.HändelseTexter
AS
SELECT        [Ärendets huvudfastighet], Diarienummer, Rubrik, Händelsedatum, Riktning, Text
FROM            dbo.HändelserFörbud12020
go

