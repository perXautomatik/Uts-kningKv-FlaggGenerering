CREATE VIEW dbo.FastighetEllerÄrendeToExclude
AS
SELECT        KIR AS 'Fastighet', Status AS 'Diarienr'
FROM            dbo.[LänsTingsrättens-List]
go

