create view HänÄrendeKontakter as

select Diarienummer,
       Huvudkontakt,
       Postnummer,
       Postort,
       Gatuadress
from ÄrendeKontakter group by Diarienummer, Huvudkontakt, Postnummer, Postort, Gatuadress
go

