create view ÄrendensSenasteKonaktMedH as
select senasteÄrende.Diarienummer,
       Händelsedatum,
       Namn                                                            HändelseNamn,
       senasteHändelseKontakt.Gatuadress                               HändelseGatuadress,
       senasteHändelseKontakt.Postnummer                               HändelsePostNummer,
       Ort                                                             HändelseOrt,
       (case
            when Namn <> senasteÄrende.Huvudkontakt
                then senasteÄrende.Huvudkontakt end)                   ÄrendeHuvudkontakt,
       (case
            when Namn <> senasteÄrende.Huvudkontakt
                then senasteÄrende.Postnummer end)                     ÄrendePostnummer,
       (case when Namn <> senasteÄrende.Huvudkontakt then Postort end) ÄrendePostort,
       (case
            when Namn <> senasteÄrende.Huvudkontakt
                then senasteÄrende.Gatuadress end)                     ÄrendeGatuadress
from (select senasteÄrende.*, id
      from (select Diarienummer,
                   max(Huvudkontakt) Huvudkontakt,
                   max(Postnummer)   Postnummer,
                   max(Postort)      Postort,
                   max(Gatuadress)   Gatuadress
            from ÄrendeKontakter
            group by ÄrendeKontakter.Diarienummer) senasteÄrende
               left outer join (select Diarienummer, max(id) id
                                from (select händelseIndex.Diarienummer,
                                             max(Händelsedatum)                               Händelsedatum,
                                             Namn,
                                             Gatuadress,
                                             Postnummer,
                                             Ort,
                                             Row_number() over ( order by max(Händelsedatum)) id
                                      from (
                                               select Diarienummer,
                                                      Löpnummer,
                                                      Händelsedatum
                                               from HändelseKontakter
                                               group by Diarienummer, Händelsedatum, Löpnummer
                                           ) händelseIndex
                                               join (select max(Händelsedatum) hd,
                                                            Diarienummer,
                                                            Namn,
                                                            Gatuadress,
                                                            Postnummer,
                                                            Ort
                                                     from HändelseKontakter
                                                     where namn <> ''
                                                       AND Gatuadress <> ''
                                                       AND Postnummer <> ''
                                                     group by Namn,
                                                              Diarienummer,
                                                              Gatuadress,
                                                              Postnummer, Ort) senastHändelse
                                                    on händelseIndex.Diarienummer = senastHändelse.Diarienummer and
                                                       senastHändelse.hd = händelseIndex.Händelsedatum
                                      group by Namn,
                                               Gatuadress,
                                               Postnummer,
                                               Ort, händelseIndex.Diarienummer
                                     ) senasteHändelseKontakt
                                group by Diarienummer) diaHIndex
                               on diaHIndex.Diarienummer = senasteÄrende.Diarienummer) senasteÄrende
         left outer join (select händelseIndex.Diarienummer,
                                 max(Händelsedatum)                               Händelsedatum,
                                 Namn,
                                 Gatuadress,
                                 Postnummer,
                                 Ort,
                                 Row_number() over ( order by max(Händelsedatum)) id
                          from (
                                   select Diarienummer,
                                          Löpnummer,
                                          Händelsedatum
                                   from HändelseKontakter
                                   group by Diarienummer, Händelsedatum, Löpnummer
                               ) händelseIndex
                                   join (select max(Händelsedatum) hd,
                                                Diarienummer,
                                                Namn,
                                                Gatuadress,
                                                Postnummer,
                                                Ort
                                         from HändelseKontakter
                                         where namn <> ''
                                           AND Gatuadress <> ''
                                           AND Postnummer <> ''
                                         group by Namn,
                                                  Diarienummer,
                                                  Gatuadress,
                                                  Postnummer, Ort) senastHändelse
                                        on händelseIndex.Diarienummer = senastHändelse.Diarienummer and
                                           senastHändelse.hd = händelseIndex.Händelsedatum
                          group by Namn,
                                   Gatuadress,
                                   Postnummer,
                                   Ort, händelseIndex.Diarienummer
) senasteHändelseKontakt on senasteÄrende.id = senasteHändelseKontakt.id
go

