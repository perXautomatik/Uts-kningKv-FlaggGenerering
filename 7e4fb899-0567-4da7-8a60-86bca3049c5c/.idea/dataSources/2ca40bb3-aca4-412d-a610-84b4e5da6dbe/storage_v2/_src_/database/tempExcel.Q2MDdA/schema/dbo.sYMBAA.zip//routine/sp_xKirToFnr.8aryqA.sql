Create Function dbo.KirToFnr(@TVP HandelseTableType READONLY)
Returns Table as
	return
		select z.*,x.fnr from @TVP z join
			[gisdata].[sde_geofir_gotland].[gng].Fa_Fastighet x on z.fastighet = x.beteckning
go

