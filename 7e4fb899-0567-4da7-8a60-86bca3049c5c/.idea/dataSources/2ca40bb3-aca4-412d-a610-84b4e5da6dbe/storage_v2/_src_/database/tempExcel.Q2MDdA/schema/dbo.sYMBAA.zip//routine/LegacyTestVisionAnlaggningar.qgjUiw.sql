Create function LegacyTestVisionAnlaggningar() RETURNS TABLE
AS RETURN
    with VisionÄrenden as (SELECT EDPVisionRegionGotlandAvlopp.dbo.tbAehAerende.intDiarienummerLoepNummer,
                              EDPVisionRegionGotlandAvlopp.dbo.tbAehAerendeData.strDiarienummer,
                              EDPVisionRegionGotlandAvlopp.dbo.tbAehAerende.strSoekbegrepp
                       FROM EDPVisionRegionGotlandAvlopp.dbo.tbAehAerende
                                LEFT OUTER JOIN EDPVisionRegionGotlandAvlopp.dbo.tbAehAerendeData
                                                ON EDPVisionRegionGotlandAvlopp.dbo.tbAehAerendeData.recAerendeID = EDPVisionRegionGotlandAvlopp.dbo.tbAehAerende.recAerendeID
                                LEFT OUTER JOIN EDPVisionRegionGotlandAvlopp.dbo.tbAehProjekt
                                                ON EDPVisionRegionGotlandAvlopp.dbo.tbAehAerende.recProjektID = EDPVisionRegionGotlandAvlopp.dbo.tbAehProjekt.recProjektID
                                LEFT OUTER JOIN EDPVisionRegionGotlandAvlopp.dbo.tbAehHaendelseBeslut ON EDPVisionRegionGotlandAvlopp.dbo.tbAehAerende.recLastHaendelseBeslutID =
                                                                            EDPVisionRegionGotlandAvlopp.dbo.tbAehHaendelseBeslut.recHaendelseBeslutID
                                LEFT OUTER JOIN EDPVisionRegionGotlandAvlopp.dbo.tbAehAerendetyp ON EDPVisionRegionGotlandAvlopp.dbo.tbAehAerende.recAerendetypID =
                                                                       EDPVisionRegionGotlandAvlopp.dbo.tbAehAerendetyp.recAerendetypID
                                LEFT OUTER JOIN EDPVisionRegionGotlandAvlopp.dbo.tbVisEnhet
                                                ON EDPVisionRegionGotlandAvlopp.dbo.tbAehAerende.recEnhetID = EDPVisionRegionGotlandAvlopp.dbo.tbVisEnhet.recEnhetID
                                LEFT OUTER JOIN EDPVisionRegionGotlandAvlopp.dbo.tbVisFoervaltning ON EDPVisionRegionGotlandAvlopp.dbo.tbAehAerende.recFoervaltningID =
                                                                         EDPVisionRegionGotlandAvlopp.dbo.tbVisFoervaltning.recFoervaltningID
                                LEFT OUTER JOIN EDPVisionRegionGotlandAvlopp.dbo.tbVisAvdelning
                                                ON EDPVisionRegionGotlandAvlopp.dbo.tbAehAerende.recAvdelningID = EDPVisionRegionGotlandAvlopp.dbo.tbVisAvdelning.recAvdelningID
                                LEFT OUTER JOIN EDPVisionRegionGotlandAvlopp.dbo.tbVisEnstakaKontakt AS fakturamottagarekontakt
                                                ON fakturamottagarekontakt.recEnstakaKontaktID =
                                                   (SELECT recEnstakaKontaktID
                                                    FROM EDPVisionRegionGotlandAvlopp.dbo.tbVisEnstakafakturamottagare
                                                    WHERE recEnstakaFakturamottagareID = tbAehAerende.recEnstakaFakturamottagareID)
                                LEFT OUTER JOIN EDPVisionRegionGotlandAvlopp.dbo.tbVisKommun
                                                ON EDPVisionRegionGotlandAvlopp.dbo.tbVisKommun.recKommunID = EDPVisionRegionGotlandAvlopp.dbo.tbAehAerende.recKommunID
                                LEFT OUTER JOIN EDPVisionRegionGotlandAvlopp.dbo.tbEDPUser
                                                ON EDPVisionRegionGotlandAvlopp.dbo.tbEDPUser.intUserID = EDPVisionRegionGotlandAvlopp.dbo.tbAehAerendeData.intUserID
                                LEFT OUTER JOIN EDPVisionRegionGotlandAvlopp.dbo.vwAehAerendeTotaltid
                                                ON EDPVisionRegionGotlandAvlopp.dbo.vwAehAerendeTotaltid.recAerendeID = tbAehAerende.recAerendeID
                                LEFT OUTER JOIN EDPVisionRegionGotlandAvlopp.dbo.tbVisExternTjaenst ON EDPVisionRegionGotlandAvlopp.dbo.tbVisExternTjaenst.recExternTjaenstID =
                                                                          tbAehAerende.recExternTjaenstID
                                LEFT OUTER JOIN EDPVisionRegionGotlandAvlopp.dbo.tbAehHaendelse ON EDPVisionRegionGotlandAvlopp.dbo.tbAehHaendelse.recHaendelseID =
                                                                      tbAehHaendelseBeslut.recHaendelseID)

   , toCorrect as (select tempExcel.[dbo].up_xSplitStringByDelim(x.fliken_Ärenden, 2, '-') year,
                          tempExcel.[dbo].up_xSplitStringByDelim(x.fliken_Ärenden, 3, '-') nr
                   from (select fliken_Ärenden from dbo.sol19_4Kol group by fliken_Ärenden) x
                            left outer join dbo.sol19_ÄrendenrAttJoina
                                            on fliken_Ärenden = sol19_ÄrendenrAttJoina.Diarienummer
                   where Diarienummer is null
                     and fliken_Ärenden <> '0'
                     AND fliken_Ärenden <> 'anteckning')
   , corrected as (select max(strDiarienummer) strDiarienummer, strSoekbegrepp
                   from (select *
                         from toCorrect
                        ) z
                            cross apply VisionÄrenden q
                   where q.intDiarienummerLoepNummer = z.nr
                     AND q.strDiarienummer like '%' + cast(z.year as varchar(4)) + '%'
                     AND strSoekbegrepp <> ''
                   group by z.year, Z.nr, strSoekbegrepp)
   , firstInsert as (select Diarienummer fliken_ärenden, ObjektID
                     from dbo.sol19_ÄrendenrAttJoina
                              join dbo.sol19_4Kol s194K on sol19_ÄrendenrAttJoina.fnr = s194K.FNR)
   , forgotten as (select ty.*, qw.fnr
                   from (select * from corrected) ty
                            left outer join [GISDATA].sde_geofir_gotland.gng.FA_TIDIGAREBETECKNING qw
                                            on ty.strSoekbegrepp = qw.beteckning
                   where qw.fnr is not null)

   , toInsert as (
    select *
    from firstInsert
    union
    select strDiarienummer fliken_ärenden, ObjektID
    from forgotten
             join dbo.sol19_4Kol s194K on forgotten.fnr = s194K.FNR
    where forgotten.fnr is not null)

select distinct 'Anteckning'   anläggningskategori,
                'Anteckning'   Anläggningstyp,
                fliken_ärenden Anläggning_för_EfterföljRText,
                toInsert.ObjektID
from toInsert
         left outer join VisionÄrenden on toInsert.fliken_ärenden = VisionÄrenden.strDiarienummer
where strSoekbegrepp is null
go

