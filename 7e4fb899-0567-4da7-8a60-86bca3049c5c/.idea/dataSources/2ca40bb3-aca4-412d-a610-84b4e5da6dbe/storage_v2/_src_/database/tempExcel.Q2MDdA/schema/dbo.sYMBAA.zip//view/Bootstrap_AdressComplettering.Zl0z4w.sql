CREATE view [dbo].[AdressComplettering] AS
select POSTORT,
       POSTNUMMER,
       ADRESS,
       NAMN,
       arndenr
from tempExcel.dbo.MY_TABLE
go

