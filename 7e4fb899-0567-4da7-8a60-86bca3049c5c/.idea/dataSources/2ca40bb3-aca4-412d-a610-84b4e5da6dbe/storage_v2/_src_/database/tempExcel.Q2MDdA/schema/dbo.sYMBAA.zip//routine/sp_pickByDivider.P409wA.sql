create function sp_pickByDivider(@input as nvarchar(max),@delimeter as nvarchar(5),@theNumber as integer) returns table as
    return
        select REVERSE(PARSENAME(REPLACE(REVERSE(@input), @delimeter, '.'), @theNumber)) as returns
go

