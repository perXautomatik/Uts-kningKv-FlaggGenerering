--CAST(CASE WHEN isnull([ANDEL],'') = '' THEN '1/1' ELSE [ANDEL] END AS varchar) as Händelsedatum,
CREATE FUNCTION dbo.FnrToAdress(@inputFnr KontaktUpgTableType READONLY) RETURNS 
   table as
   return
 	    with
		lagf1              AS (SELECT z.FNR, 	z.KORTNAMN NAMN, z.INSKDATUM, z.andel,PERSORGNR, z.FAL_CO, z.FAL_UTADR1, z.FAL_UTADR2, z.FAL_POSTNR, z.FAL_POSTORT, z.SAL_CO, z.SAL_UTADR1, z.SAL_UTADR2, z.SAL_POSTNR, z.SAL_POSTORT, z.UA_UTADR1, z.UA_UTADR2, z.UA_UTADR3, z.UA_UTADR4, z.UA_LAND FROM[GISDATA].SDE_GEOFIR_GOTLAND.gng.FA_LAGFART_V2 z inner join @INPUTFNR ip on ip.FNR = z.fnr )
    ,           FalFlaToVect       AS (SELECT FNR,	NAMN,INSKDATUM,andel,PERSORGNR, FAL_CO, FAL_UTADR1, FAL_UTADR2, FAL_POSTNR, FAL_POSTORT FROM lagf1 UNION SELECT
           				      FNR, 	NAMN,INSKDATUM, ANDEL, PERSORGNR, SAL_CO, SAL_UTADR1, SAL_UTADR2, SAL_POSTNR, SAL_POSTORT FROM lagf1 UNION SELECT
           				      FNR, 	NAMN,INSKDATUM, ANDEL, PERSORGNR, UA_UTADR1, UA_UTADR2, UA_UTADR3, UA_UTADR4, UA_LAND FROM lagf1)
    ,           Fal_Columns        as (SELECT FNR,	NAMN,INSKDATUM,ANDEL,PERSORGNR, FAL_CO, FAL_UTADR1, FAL_UTADR2, FAL_POSTNR, FAL_POSTORT FROM FalFlaToVect WHERE coalesce(FAL_CO, FAL_UTADR1, FAL_UTADR2, FAL_POSTNR, FAL_POSTORT) IS NOT NULL)
    ,           Taxer1             as (select q.FNR,	KORTNAMN NAMN, q.PERSORGNR, q.ANDEL, q.FAL_CO, q.FAL_UTADR1, q.FAL_UTADR2, q.FAL_POSTNR, q.FAL_POSTORT, q.SAL_CO, q.SAL_UTADR1, q.SAL_UTADR2, q.SAL_POSTNR, q.SAL_POSTORT, q.UA_UTADR1, q.UA_UTADR2, q.UA_UTADR3, q.UA_UTADR4, q.UA_LAND FROM[GISDATA]. sde_geofir_gotland.gng.FA_TAXERINGAGARE_V2 q inner join @INPUTFNR x on x.FNR = q.fnr )
    ,           TaxFlaToVect       as (select FNR, PERSORGNR, ANDEL, NAMN, FAL_CO, FAL_UTADR1, FAL_UTADR2, FAL_POSTNR, FAL_POSTORT from Taxer1 union select FNR, PERSORGNR, ANDEL, NAMN, SAL_CO, SAL_UTADR1, SAL_UTADR2, SAL_POSTNR, SAL_POSTORT from Taxer1 union select FNR, PERSORGNR, ANDEL, NAMN, UA_UTADR1, UA_UTADR2, UA_UTADR3, UA_UTADR4, UA_LAND from Taxer1)
    ,           Tax_columns	   as (select FNR, PERSORGNR, ANDEL, NAMN, nullif(FAL_CO, '')  FAL_CO, nullif(FAL_UTADR1, '') FAL_UTADR1, nullif(FAL_UTADR2, '') FAL_UTADR2, nullif(FAL_POSTNR, '') FAL_POSTNR, nullif(FAL_POSTORT, '') FAL_POSTORT from TaxFlaToVect WHERE coalesce(nullif(FAL_CO, ''), nullif(FAL_UTADR1, ''), nullif(FAL_UTADR2, ''), nullif(FAL_POSTNR, ''), nullif(FAL_POSTORT, '')) IS NOT NULL)

 	       ,combined as (select FNR, PERSORGNR, andel, Namn, INSKDATUM,FAL_CO, FAL_UTADR1, FAL_UTADR2, FAL_POSTNR, FAL_POSTORT
 	       from Fal_Columns union select FNR, PERSORGNR, ANDEL, NAMN, (select top 1 Händelsedatum from @INPUTFNR), 	FAL_CO, FAL_UTADR1, FAL_UTADR2, FAL_POSTNR, FAL_POSTORT
 	       from Tax_columns)
    ,andelad as (select case when  charindex('/', ANDEL, 1) > 0 then try_cast(left(ANDEL, charindex('/', ANDEL, 1) - 1) as float) / try_cast(right(ANDEL, len(ANDEL) - charindex('/', ANDEL, 1)) as float)end as ANDEL, FNR, PERSORGNR, NAMN, INSKDATUM, FAL_CO, FAL_UTADR1, FAL_UTADR2, FAL_POSTNR, FAL_POSTORT from COMBINED)
    ,grouped as (select FNR, PERSORGNR, min(ANDEL) AndelMin, NAMN, min(INSKDATUM) InsksDatMin, FAL_CO, FAL_UTADR1, FAL_UTADR2, FAL_POSTNR, FAL_POSTORT from ANDELAD GROUP BY FNR, PERSORGNR, NAMN, FAL_CO, FAL_UTADR1, FAL_UTADR2, FAL_POSTNR, FAL_POSTORT)

    ,medFastighetsAgare as (
    select FNR, PERSORGNR, format(ANDELMIN,'0.00') ANDELMIN, NAMN,
	  nullif(INSKSDATMIN,(select top 1 Händelsedatum from @INPUTFNR)) INSKSDATMIN,
	   ltrim(CONCAT( case when FAL_POSTNR is null then fal_co else  nullif('c/o '+FAL_CO+', ','c/o , ') end, FAL_UTADR1+' ', FAL_UTADR2 + ', ',FAL_POSTNR,' ' +FAL_POSTORt)) ADRESS,
	    fal_postort postort,fal_postnr postnr,
	   case when INSKSDATMIN = (select top 1 Händelsedatum from @INPUTFNR) then 'FA_TAXERINGAGARE' else 'FA_LAGFART' end as source
    from GROUPED
    UNION
    select REALESTATEKEY, PERSONORGANISATIONNR ,
	 format(case when charindex('/', SHAREPART, 1) > 0 then try_cast(left(SHAREPART, charindex('/', SHAREPART, 1) - 1) as float) / try_cast(right(SHAREPART, len(SHAREPART) - charindex('/', SHAREPART, 1)) as float)end,'0.00') ANDEL
	 , Name NAMN, regdt
	 ,Address,
	   null postort,null postnr,
	     'info_CurrentOwner'
    from
   [GISDATA]. sde_geofir_gotland.gng.info_CurrentOwner --sde_geofir_gotland.gng.FASTIGHETSÄGARE
    where REALESTATEKEY in (select fnr from @INPUTFNR)and Address is not null
    ),
   		fardig as (
    select FNR, PERSORGNR, min(ANDELMIN) andel,
	    NAMN
	      , format(nullif(min(INSKSDATMIN), (select top 1 Händelsedatum from @INPUTFNR)), 'yyyy MMdd')                                             INSKDATUM
	      , replace(replace(replace(ADRESS,'  ',' '), isnull(' ' + max(POSTNR), ''), ''), isnull(', ' + max(POSTORT), ''), '') ADRESS
	      , max(POSTORT)                                                                                     POSTORT
	      , max(POSTNR)                                                                                      POSTNR
	      ,
	   case when  max(POSTORT) is null
		then 'info_currentOwner'
	       else case when  min(INSKSDATMIN) is null then 'FA_TAXERINGAGARE' else 'FA_LAGFART' end end
	       as source

    from medFastighetsAgare GROUP BY FNR, PERSORGNR, NAMN, ADRESS)
    select * from FARDIG
GO

