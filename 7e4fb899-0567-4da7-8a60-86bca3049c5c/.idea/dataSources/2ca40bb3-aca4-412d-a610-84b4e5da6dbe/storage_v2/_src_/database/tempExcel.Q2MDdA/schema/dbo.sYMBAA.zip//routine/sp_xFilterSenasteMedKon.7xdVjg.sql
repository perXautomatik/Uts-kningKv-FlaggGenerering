CREATE FUNCTION dbo.senastKontaktMedHandelsetext(@input HandelseTableType READONLY) RETURNS table AS
return
	select * from (SELECT *,row_number() over (partition by diarienummer order by cast(cast(datum as datetime) as int)*(CASE WHEN tz.TEXT IS NOT NULL THEN 1000 ELSE 1 END)  desc) CC_priorit from @input tz ) q where CC_priorit = 1
go

