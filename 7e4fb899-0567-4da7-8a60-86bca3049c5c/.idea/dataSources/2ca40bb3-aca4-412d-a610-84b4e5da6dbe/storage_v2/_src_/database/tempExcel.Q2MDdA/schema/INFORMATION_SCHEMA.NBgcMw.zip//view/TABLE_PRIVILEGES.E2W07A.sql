CREATE VIEW INFORMATION_SCHEMA.TABLE_PRIVILEGES
AS
SELECT	
	USER_NAME(p.grantor_principal_id)	AS GRANTOR,
	USER_NAME(p.grantee_principal_id)	AS GRANTEE,
	DB_NAME()						AS TABLE_CATALOG,
	SCHEMA_NAME(o.schema_id)			AS TABLE_SCHEMA,
	o.name							AS TABLE_NAME,
	convert(varchar(10), CASE p.type
		WHEN 'RF' THEN 'REFERENCES'
		WHEN 'SL' THEN 'SELECT'
		WHEN 'IN' THEN 'INSERT'
		WHEN 'DL' THEN 'DELETE'
		WHEN 'UP' THEN 'UPDATE'
		END)						AS PRIVILEGE_TYPE,
	convert(varchar(3), CASE p.state
		WHEN 'G' THEN 'NO'
		WHEN 'W' THEN 'YES'
		END)						AS IS_GRANTABLE
FROM
	sys.objects o,
	sys.database_permissions p
WHERE
	o.type IN ('U', 'V')
	AND p.class = 1
	AND p.major_id = o.object_id
	AND p.minor_id = 0	-- all columns
 	AND p.type IN ('RF','IN','SL','UP','DL')
 	AND p.state IN ('W','G')
	AND (p.grantee_principal_id = 0
		OR p.grantee_principal_id = DATABASE_PRINCIPAL_ID()
		OR p.grantor_principal_id = DATABASE_PRINCIPAL_ID())
go

