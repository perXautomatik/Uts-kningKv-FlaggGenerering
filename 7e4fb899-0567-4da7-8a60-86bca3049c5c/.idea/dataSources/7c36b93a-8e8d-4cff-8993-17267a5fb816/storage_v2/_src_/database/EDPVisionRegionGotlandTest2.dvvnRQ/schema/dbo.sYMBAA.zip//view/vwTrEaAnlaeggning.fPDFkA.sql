

CREATE VIEW [dbo].[vwTrEaAnlaeggning]
AS
SELECT
	dbo.tbTrEaAnlaeggning.recAnlaeggningID,
	dbo.tbTrEaAnlaeggning.recAnlaeggningID as intRecnum,
	dbo.tbTrEaAnlaeggning.recAvloppsanlaeggningID,
	dbo.tbTrEaAnlaeggning.recAnlaeggningskategoriID,
    dbo.tbTrEaAnlaeggning.recAnlaeggningstypID,
	dbo.tbTrEaAnlaeggning.strCertifieringstyp,
	dbo.tbTrEaAnlaeggning.decVolym,
	dbo.tbTrEaAnlaeggning.datBeslutsdatum,
    dbo.tbTrEaAnlaeggning.datBesiktningsdatum,
	dbo.tbTrEaAnlaeggning.intToemningsintervall,
	dbo.tbTrEaAnlaeggning.datToemningsdispensFrOM,
    dbo.tbTrEaAnlaeggning.datToemningsdispensTOM,
	dbo.tbTrEaAnlaeggning.intExterntTjaenstID,
	dbo.tbTrEaAnlaeggning.strToaletttyp,
	dbo.tbTrEaAnlaeggning.strText,
	dbo.tbTrEaAnlaeggning.datStatusDatum,
	dbo.tbTrEaAnlaeggning.strStatus,


    dbo.tbTrTillsynsobjekt.recTillsynsobjektID,
	dbo.tbTrTillsynsobjekt.strObjektsNamn,

	dbo.tbTrEaAnlaeggningstyp.strAnlaeggningstyp,

    dbo.tbTrEaAnlaeggningskategori.strAnlaeggningskategori


FROM dbo.tbTrEaAnlaeggning

LEFT OUTER JOIN dbo.tbTrEaAnlaeggningskategori
	ON dbo.tbTrEaAnlaeggning.recAnlaeggningskategoriID = dbo.tbTrEaAnlaeggningskategori.recAnlaeggningskategoriID

INNER JOIN dbo.tbTrEaAvloppsanlaeggning
	ON dbo.tbTrEaAnlaeggning.recAvloppsanlaeggningID = dbo.tbTrEaAvloppsanlaeggning.recAvloppsanlaeggningID

INNER JOIN dbo.tbTrTillsynsobjekt
	ON dbo.tbTrEaAvloppsanlaeggning.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID

LEFT OUTER JOIN dbo.tbTrEaAnlaeggningstyp
	ON dbo.tbTrEaAnlaeggning.recAnlaeggningstypID = dbo.tbTrEaAnlaeggningstyp.recAnlaeggningstypID
go

