
CREATE TRIGGER TRG_SetintAntalFiler_tbAehHaendelse ON tbAehHaendelseFileObject
AFTER INSERT, DELETE
AS
BEGIN
  IF @@ROWCOUNT = 0
    RETURN

  UPDATE tbAehHaendelse
    SET tbAehHaendelse.intAntalFiler = (SELECT COUNT(recHaendelseFileObjectID)
                                                FROM tbAehHaendelseFileObject
                                                WHERE recHaendelseID = tbAehHaendelse.recHaendelseID)
    WHERE  tbAehHaendelse.recHaendelseID IN (SELECT recHaendelseID FROM INSERTED UNION ALL SELECT recHaendelseID FROM DELETED)
END
go

