
        CREATE TRIGGER TRG_tbAehHaendelse_UPDATE ON
        tbAehHaendelse
        AFTER UPDATE
        AS
        BEGIN
        SET NOCOUNT ON;

        DECLARE @recHaendelseID INT

        --- Uppdatera postlista
        DECLARE haendelse_cursor CURSOR FAST_FORWARD
        FOR
        SELECT INSERTED.recHaendelseID, INSERTED.recDiarieAarsSerieID FROM INSERTED
        INNER JOIN DELETED
            ON INSERTED.recHaendelseID = DELETED.recHaendelseID
            AND ISNULL(INSERTED.recDiarieAarsSerieID, -1) <> ISNULL(DELETED.recDiarieAarsSerieID, -1)
        OPEN haendelse_cursor
        DECLARE @recDiarieAarsSerieID INT
        FETCH NEXT FROM haendelse_cursor INTO @recHaendelseID, @recDiarieAarsSerieID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehHaendelseUpdatePostlista @recHaendelseID, @recDiarieAarsSerieID

            FETCH NEXT FROM haendelse_cursor INTO @recHaendelseID, @recDiarieAarsSerieID
        END
        CLOSE haendelse_cursor
        DEALLOCATE haendelse_cursor
        END
        go

