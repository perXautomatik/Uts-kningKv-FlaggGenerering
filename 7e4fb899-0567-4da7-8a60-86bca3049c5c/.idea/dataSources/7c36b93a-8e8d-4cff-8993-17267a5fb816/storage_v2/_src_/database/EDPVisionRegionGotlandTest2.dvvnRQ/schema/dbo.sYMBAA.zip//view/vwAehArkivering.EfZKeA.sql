
CREATE VIEW [dbo].[vwAehArkivering]
AS
SELECT 
	  tbAehArkivering.recArkiveringID
	, tbAehArkivering.recArkiveringID As intRecNum
	, tbAehArkivering.datDatum
	, tbAehArkivering.strKommentar
	, tbAehArkivering.recInstaellningID    
    , tbAehArkivering.recInstallningsID
	, CASE WHEN tbAehComprimaArkiveraInstaellning.strRubrik IS NULL THEN 
	  tbAehFGSInstallning.strRubrik
	  ELSE tbAehComprimaArkiveraInstaellning.strRubrik 
	  END as strRubrik	
      FROM tbAehArkivering
      LEFT OUTER JOIN tbAehComprimaArkiveraInstaellning ON tbAehComprimaArkiveraInstaellning.recInstaellningID = tbAehArkivering.recInstaellningID
      LEFT OUTER JOIN tbAehFGSInstallning ON tbAehFGSInstallning.recInstallningsID = tbAehArkivering.recInstallningsID
go

