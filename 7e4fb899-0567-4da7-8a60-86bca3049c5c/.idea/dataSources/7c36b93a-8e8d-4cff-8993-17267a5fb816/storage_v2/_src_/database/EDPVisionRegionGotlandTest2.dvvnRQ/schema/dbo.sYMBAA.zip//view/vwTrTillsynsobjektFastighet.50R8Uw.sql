CREATE VIEW [dbo].[vwTrTillsynsobjektFastighet]
AS
SELECT 
	dbo.vwVisDeladFastighet.strFnrID, 
	dbo.vwVisDeladFastighet.strFastighetsbeteckning,
	dbo.vwVisDeladFastighet.recFastighet,

	dbo.tbTrTillsynsobjektFastighet.bolHuvudfastighet, 
	dbo.tbTrTillsynsobjektFastighet.recTrTillsynsobjektFastighetID AS intRecnum,
	dbo.tbTrTillsynsobjektFastighet.recTillsynsobjektID,
	dbo.tbTrTillsynsobjektFastighet.recTrTillsynsobjektFastighetID

FROM dbo.tbTrTillsynsobjektFastighet 
LEFT OUTER JOIN dbo.vwVisDeladFastighet 
ON tbTrTillsynsobjektFastighet.strFnrID = dbo.vwVisDeladFastighet.strFnrID
go

