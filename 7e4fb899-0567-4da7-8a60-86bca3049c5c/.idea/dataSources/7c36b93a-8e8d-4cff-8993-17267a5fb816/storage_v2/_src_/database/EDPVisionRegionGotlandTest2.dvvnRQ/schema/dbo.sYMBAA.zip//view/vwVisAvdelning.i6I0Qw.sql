

CREATE VIEW [dbo].[vwVisAvdelning]
AS
SELECT  dbo.tbVisAvdelning.recFoervaltningID,
		dbo.tbVisAvdelning.recAvdelningID,
		dbo.tbVisAvdelning.recDiarieSerieID,
		dbo.tbVisAvdelning.strAvdelningKod,
		dbo.tbVisAvdelning.strAvdelningNamn,
		dbo.tbVisAvdelning.bolEjAktuell,
		dbo.tbVisAvdelning.recAvdelningID AS intRecnum,

		dbo.tbVisFoervaltning.strFoervaltningKod,
        dbo.tbVisFoervaltning.strFoervaltningNamn,

		dbo.tbAehDiarieSerie.strDiarieSerieKod



FROM	dbo.tbVisAvdelning

LEFT OUTER JOIN	dbo.tbVisFoervaltning ON dbo.tbVisAvdelning.recFoervaltningID = dbo.tbVisFoervaltning.recFoervaltningID
LEFT OUTER JOIN	dbo.tbAehDiarieSerie ON dbo.tbVisAvdelning.recDiarieSerieID = dbo.tbAehDiarieSerie.recDiarieSerieID
go

