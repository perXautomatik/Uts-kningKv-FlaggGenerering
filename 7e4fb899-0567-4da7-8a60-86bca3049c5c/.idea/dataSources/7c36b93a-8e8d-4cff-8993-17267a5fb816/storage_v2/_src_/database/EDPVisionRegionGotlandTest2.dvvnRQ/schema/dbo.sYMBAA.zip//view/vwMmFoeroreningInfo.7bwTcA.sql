CREATE VIEW dbo.vwMmFoeroreningInfo
AS
SELECT     dbo.tbMmFoeroreningInfo.recFoeroreningInfoID, dbo.tbMmFoeroreningInfo.recFoeroreningID, dbo.tbMmFoeroreningInfo.recFasID,
                      dbo.tbMmFoeroreningInfo.decVolym, dbo.tbMmFoeroreningInfo.decYta, dbo.tbMmFoeroreningInfo.decFraanDjup, dbo.tbMmFoeroreningInfo.decTillDjup,
                      dbo.tbMmFas.intOrdningsNr, dbo.tbMmFas.strFasNamn, dbo.tbMmBedoemningVaerde.strBedoemningVaerde,
                      dbo.tbMmBedoemningVaerde.strBedoemningVaerdeFoerklaring, dbo.tbMmFoeroreningInfo.recFoeroreningInfoID AS intRecnum,
                      dbo.tbMmFoeroreningInfo.strEnhetVolym, dbo.tbMmBedoemningVaerde.intBedoemningVaerdeFaergARGB,
                      dbo.tbMmFoeroreningInfo.guidBedoemningVaerdeID
FROM         dbo.tbMmFoeroreningInfo LEFT OUTER JOIN
                      dbo.tbMmBedoemningVaerde ON
                      dbo.tbMmFoeroreningInfo.guidBedoemningVaerdeID = dbo.tbMmBedoemningVaerde.guidBedoemningVaerdeID LEFT OUTER JOIN
                      dbo.tbMmFas ON dbo.tbMmFoeroreningInfo.recFasID = dbo.tbMmFas.recFasID
go

