CREATE VIEW [dbo].[vwTrTillsynsobjektHaendelse]
AS
--- Specialvy för att hämta de tillsynsobjekt som är kopplade till en händelse
--- För dokumentmallar (och lite historisk barlast)
SELECT recTillsynsobjektID, recHaendelseID  
  FROM tbTrTillsynsobjektHaendelse

go

