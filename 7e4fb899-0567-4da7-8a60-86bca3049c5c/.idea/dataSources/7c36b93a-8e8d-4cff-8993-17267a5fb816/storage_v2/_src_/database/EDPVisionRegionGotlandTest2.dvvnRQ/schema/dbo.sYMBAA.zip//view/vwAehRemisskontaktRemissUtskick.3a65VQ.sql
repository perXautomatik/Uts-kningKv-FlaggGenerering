

CREATE VIEW [dbo].[vwAehRemisskontaktRemissUtskick]
AS
SELECT     dbo.tbAehRemisskontaktRemissUtskick.recRemisskontaktRemissUtskickID, 
           dbo.tbAehRemisskontaktRemissUtskick.recRemisskontaktRemissUtskickID as intRecNum,
           dbo.tbAehRemisskontaktRemissUtskick.recRemisskontaktID, 
           dbo.tbAehRemisskontaktRemissUtskick.recRemissutskickID, 
           dbo.tbAehRemisskontaktRemissUtskick.datYttrandedatum, 
           dbo.tbAehRemisskontaktRemissUtskick.strYttrande, 
           dbo.tbAehRemisskontaktRemissUtskick.datKommuniceringsDatum, 
           dbo.tbAehRemisskontaktRemissUtskick.datKommuniceringMottagen, 
           dbo.tbAehRemisskontaktRemissUtskick.strKommunicering, 
           dbo.tbAehRemisskontakt.strRemisskontaktRoll, 
           dbo.tbVisEnstakaKontakt.strVisasSom, 
           dbo.tbVisEnstakaFastighet.strFastighetsbeteckning
FROM         dbo.tbAehRemisskontaktRemissUtskick 
INNER JOIN   dbo.tbAehRemisskontakt 
ON dbo.tbAehRemisskontaktRemissUtskick.recRemisskontaktID = dbo.tbAehRemisskontakt.recRemisskontaktID 
LEFT OUTER JOIN dbo.tbVisEnstakaKontakt 
ON dbo.tbAehRemisskontakt.recEnstakaKontaktID = dbo.tbVisEnstakaKontakt.recEnstakaKontaktID 
LEFT OUTER JOIN dbo.tbVisEnstakaFastighet 
ON dbo.tbAehRemisskontakt.recEnstakaFastighetID = dbo.tbVisEnstakaFastighet.recFastighetID



go

