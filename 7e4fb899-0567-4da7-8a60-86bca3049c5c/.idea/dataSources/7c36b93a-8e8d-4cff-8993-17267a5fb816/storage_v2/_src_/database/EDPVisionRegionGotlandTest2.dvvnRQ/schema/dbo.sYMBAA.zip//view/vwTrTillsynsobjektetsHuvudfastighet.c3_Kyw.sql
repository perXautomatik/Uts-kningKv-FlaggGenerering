
CREATE VIEW [dbo].[vwTrTillsynsobjektetsHuvudfastighet]
AS
SELECT tbTrTillsynsobjektFastighet.recTillsynsobjektID,
  tbTrTillsynsobjektFastighet.recTrTillsynsobjektFastighetID,
  tbTrTillsynsobjektFastighet.strFnrID,
  vwVisDeladFastighet.strTrakt,
  vwVisDeladFastighet.strBlock,
  vwVisDeladFastighet.strTkn,
  vwVisDeladFastighet.intEnhet,
  vwVisDeladFastighet.strFastighetsbeteckning,
  vwVisDeladFastighet.strAdress,
  vwVisDeladFastighet.strPostnr,
  vwVisDeladFastighet.strPostort,
  vwVisDeladFastighet.strKommunNamn  

FROM tbTrTillsynsobjektFastighet
INNER JOIN vwVisDeladFastighet
  ON vwVisDeladFastighet.strFnrID = tbTrTillsynsobjektFastighet.strFnrID
WHERE tbTrTillsynsobjektFastighet.bolHuvudfastighet = 1
go

