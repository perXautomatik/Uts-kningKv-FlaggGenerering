

CREATE VIEW [dbo].[vwTrTillsynsbesoek]
AS
SELECT dbo.tbTrTillsynsbesoek.recTillsynsbesoekID,
       dbo.tbTrTillsynsbesoek.recTillsynsbesoekID AS intRecnum,
       dbo.tbTrTillsynsbesoek.strUppfoeljning,
       dbo.tbTrTillsynsbesoek.strGenerellNotering,
       dbo.tbTrTillsynsbesoek.strAnmaelningstyp,
       dbo.tbTrTillsynsbesoek.strResultat,
       dbo.tbTrTillsynsbesoek.strBesoekstyp,
       dbo.tbTrTillsynsbesoek.strOrsak,
       dbo.tbTrTillsynsbesoek.strSyfte,
       dbo.tbTrTillsynsbesoek.strInspektionstyp,
       dbo.tbTrTillsynsbesoek.recChecklistaVersionID,
       dbo.tbTrTillsynsbesoek.recChecklistamallID,
       dbo.tbTrTillsynsbesoek.datDatum,
       dbo.tbTrTillsynsbesoek.recHaendelseID,
       dbo.tbTrTillsynsbesoek.recAerendeID,
       dbo.tbTrTillsynsbesoek.recTillsynsobjektID,
       dbo.tbEDPUser.intUserID,
       dbo.tbEDPUser.strUserSurName,
       dbo.tbEDPUser.strUserFirstname,
       dbo.tbEDPUser.strSignature AS strHuvudHandlaeggareSignatur,
       dbo.tbEDPUser.strUserFirstname + ' '+ dbo.tbEDPUser.strUserSurName AS strHuvudHandlaeggareNamn,
       dbo.tbTrTillsynsobjekt.strObjektsNamn,
       dbo.tbAehAerendeData.strDiarienummer,
       dbo.vwAehHaendelseidentifiering.strHaendelseIdentifiering,
       dbo.tbTrChecklistamall.strNamn,
       dbo.tbTrChecklistamallVersion.strFilversion,
       dbo.tbTrTillsynsbesoek.strRapporteringsid,
       dbo.tbVisEnstakaKontakt.recEnstakaKontaktID,
       dbo.tbVisEnstakaKontakt.strVisasSom,
       dbo.tbTrVerksamhet.strVerksamhetNamn,
       dbo.tbTrTillsynsbesoekEnstakakontakt.strRoll
FROM dbo.tbTrTillsynsbesoek
LEFT OUTER JOIN tbTrTillsynsbesoekUser
  ON dbo.tbTrTillsynsbesoekUser.recTillsynsbesoekID = dbo.tbTrTillsynsbesoek.recTillsynsbesoekID
  AND dbo.tbTrTillsynsbesoekUser.bolHuvudhandlaeggare = 1
LEFT OUTER JOIN dbo.tbEDPUser 
  ON dbo.tbEDPUser.intUserID = dbo.tbTrTillsynsbesoekUser.intUserID
LEFT OUTER JOIN tbTrTillsynsbesoekEnstakakontakt 
  ON dbo.tbTrTillsynsbesoekEnstakakontakt.recTillsynsbesoekID = dbo.tbTrTillsynsbesoek.recTillsynsbesoekID
  AND dbo.tbTrTillsynsbesoekEnstakakontakt.bolHuvudkontakt = 1
LEFT OUTER JOIN dbo.tbVisEnstakaKontakt
  ON dbo.tbVisEnstakaKontakt.recEnstakaKontaktID = dbo.tbTrTillsynsbesoekEnstakakontakt.recEnstakaKontaktID
LEFT OUTER JOIN dbo.tbTrChecklistamall
  ON dbo.tbTrChecklistamall.recChecklistamallID = dbo.tbTrTillsynsbesoek.recChecklistamallID
LEFT OUTER JOIN dbo.tbTrChecklistamallVersion
  ON dbo.tbTrTillsynsbesoek.recChecklistaVersionID = dbo.tbTrChecklistamallVersion.recChecklistaVersionID
LEFT OUTER JOIN dbo.tbTrTillsynsobjekt
 ON dbo.tbTrTillsynsobjekt.recTillsynsobjektID = dbo.tbTrTillsynsbesoek.recTillsynsobjektID
LEFT OUTER JOIN dbo.tbAehAerendeData
  ON dbo.tbTrTillsynsbesoek.recAerendeID = dbo.tbAehAerendeData.recAerendeID
LEFT OUTER JOIN dbo.tbTrVerksamhet
  ON dbo.tbTrVerksamhet.recVerksamhetID = tbTrTillsynsobjekt.recVerksamhetID
LEFT OUTER JOIN dbo.vwAehHaendelseidentifiering
  ON dbo.vwAehHaendelseidentifiering.recHaendelseID = tbTrTillsynsbesoek.recHaendelseID


go

