
CREATE VIEW [dbo].[vwVisEnstakaKontaktGrid]
AS
WITH kommunikationSaett AS (
    SELECT recEnstakaKontaktID, strKommunikationsaettTyp + ' - ' + strVaerde AS kommunikationssaett
    FROM tbVisEnstakaKontaktKommunikationssaett
	LEFT OUTER JOIN tbVisKommunikationssaett
	  ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
)
,
kommunikationsSaettSammanslagen AS (SELECT recEnstakaKontaktID, 
 (SELECT  kommunikationssaett + ', '
  FROM kommunikationSaett
  WHERE kommunikationSaett.recEnstakaKontaktID = tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID
  FOR XML PATH('')) AS strKommunikationssaett 
FROM tbVisEnstakaKontaktKommunikationssaett
GROUP BY recEnstakaKontaktID
)

SELECT tbVisEnstakaKontakt.recEnstakaKontaktID, strVisasSom, strOrginisationPersonnummer,
  strSammanslagenAdress, tbVisEnstakaKontakt.recEnstakaKontaktID AS intRecnum,
  LEFT(strKommunikationssaett, LEN(strKommunikationssaett) - 1) AS strKommunikationssaett
FROM tbVisEnstakaKontakt 
LEFT OUTER JOIN kommunikationsSaettSammanslagen 
  ON tbVisEnstakaKontakt.recEnstakaKontaktID = kommunikationsSaettSammanslagen.recEnstakaKontaktID

go

