
        CREATE TRIGGER TRG_tbAehHaendelse_INSERT ON tbAehHaendelse
        AFTER INSERT
        AS
        BEGIN
        SET NOCOUNT ON;

        --- Skapa ny(a) post(er) i tbAehHaendelseData ---
        INSERT INTO tbAehHaendelseData (recHaendelseID)
        SELECT recHaendelseID FROM INSERTED

        DECLARE @recDiarieAarsSerieID INT
        DECLARE @recHaendelseID INT

        --- Uppdatera  postlista och tbAehHaendelseData
        DECLARE haendelse_postlista_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recHaendelseID, recDiarieAarsSerieID FROM INSERTED
        OPEN haendelse_postlista_cursor
        FETCH NEXT FROM haendelse_postlista_cursor INTO @recHaendelseID, @recDiarieAarsSerieID
        WHILE (@@fetch_status = 0)
        BEGIN
            IF (@recDiarieAarsSerieID IS NOT NULL)
            BEGIN
            EXEC spAehHaendelseUpdatePostlista @recHaendelseID, @recDiarieAarsSerieID
            END

            EXEC spAehHaendelseUpdateStatuslog @recHaendelseID
            EXEC spAehHaendelseUpdateSekretesslog @recHaendelseID
            EXEC spAehHaendelseUpdateHuvudHandlaeggare @recHaendelseID
            EXEC spAehHaendelseUpdateKontakt @recHaendelseID
            EXEC spAehHaendelseUpdateFastighet  @recHaendelseID

            FETCH NEXT FROM haendelse_postlista_cursor INTO @recHaendelseID, @recDiarieAarsSerieID
        END
        CLOSE haendelse_postlista_cursor
        DEALLOCATE haendelse_postlista_cursor
        END
        go

