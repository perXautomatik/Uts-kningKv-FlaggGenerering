CREATE VIEW [dbo].[vwEDPFileVersion]
AS
SELECT     dbo.tbEDPFileVersion.recFileVersionID, dbo.tbEDPFileVersion.recFileObjectID, dbo.tbEDPFileVersion.recFileStorageLocationID, 
                      dbo.tbEDPFileVersion.intFileVersion, dbo.tbEDPFileVersion.strFileType, dbo.tbEDPFileVersion.intFileVersionStorageSubDirectoryPath, 
                      dbo.tbEDPFileVersion.datFileVersionDate, dbo.tbEDPFileVersion.lngFileSize, dbo.tbEDPFileVersion.strFileVersionComment, 
                      dbo.tbEDPFileVersion.intUserID, dbo.tbEDPUser.strSignature,

					CASE
						WHEN Signering.recFileVersionSignatureID IS NOT NULL
							THEN CAST(1 AS BIT)
						ELSE
							CAST(0 AS BIT)
					END AS bolSignature

FROM         dbo.tbEDPFileVersion LEFT OUTER JOIN
                      dbo.tbEDPUser ON dbo.tbEDPFileVersion.intUserID = dbo.tbEDPUser.intUserID
            LEFT JOIN 
			(SELECT * FROM tbVisFileVersionSignature AS S WHERE recFileVersionSignatureID in 
				(SELECT MAX(recFileVersionSignatureID) FROM tbVisFileVersionSignature GROUP BY recFileVersionID)) as Signering
			ON Signering.recFileVersionID = dbo.tbEDPFileVersion.recFileVersionID

go

