CREATE PROCEDURE [dbo].[spEDPDeleteRoleSecurityObject]
	-- Add the parameters for the stored procedure here
  @intRoleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
DELETE FROM tbEDPRoleSecurityObject 
WHERE intRoleID = @intRoleID

END
go

