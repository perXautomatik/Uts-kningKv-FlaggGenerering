

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell19]
AS
SELECT     

dbo.tbAehPblTaxa2011Tabell19.recTabell19ID, 
dbo.tbAehPblTaxa2011Tabell19.recTaxa2011ID, 
dbo.tbAehPblTaxa2011Tabell19.recTabell19ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell19.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell19.recFakturatextID,
dbo.tbAehPblTaxa2011Tabell19.strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell19

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell19.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell19.recTjaenstID



go

