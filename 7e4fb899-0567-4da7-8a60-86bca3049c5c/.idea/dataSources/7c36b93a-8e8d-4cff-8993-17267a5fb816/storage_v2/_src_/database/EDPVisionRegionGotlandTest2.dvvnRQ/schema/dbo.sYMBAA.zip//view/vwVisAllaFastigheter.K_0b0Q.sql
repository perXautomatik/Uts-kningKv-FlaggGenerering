CREATE VIEW dbo.vwVisAllaFastigheter AS
WITH AllaFastigheter AS (
	SELECT strFastighetsbeteckning, strKommunNamn FROM dbo.vwVisEnstakaFastighet
	UNION
	SELECT strFastighetsbeteckning, strKommunNamn FROM dbo.vwVisDeladFastighet
)
SELECT DISTINCT ROW_NUMBER() OVER(ORDER BY strFastighetsbeteckning) AS intRecNum, strFastighetsbeteckning, strKommunNamn FROM AllaFastigheter
go

