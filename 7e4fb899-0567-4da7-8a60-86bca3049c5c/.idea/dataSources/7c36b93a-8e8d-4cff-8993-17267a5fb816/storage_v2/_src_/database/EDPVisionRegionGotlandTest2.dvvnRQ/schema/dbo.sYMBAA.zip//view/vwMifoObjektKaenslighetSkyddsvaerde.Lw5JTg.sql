CREATE VIEW dbo.vwMifoObjektKaenslighetSkyddsvaerde
AS
SELECT     dbo.tbMifoKaenslighetSkyddsvaerde.recKaenslighetSkyddsvaerdeID, dbo.tbMifoKaenslighetSkyddsvaerde.recObjektID,
                      dbo.tbMifoKaenslighetSkyddsvaerde.strMedium, dbo.tbMifoKaenslighetSkyddsvaerde.strKaenslighetSkyddsvaerde,
                      dbo.tbMifoKaenslighetSkyddsvaerde.strKellerS, dbo.tbMifoObjekt.strObjektId, dbo.tbMifoObjekt.strObjektNamn,
                      dbo.tbMifoKaenslighetSkyddsvaerde.recKaenslighetSkyddsvaerdeID AS intRecnum
FROM         dbo.tbMifoObjekt RIGHT OUTER JOIN
                      dbo.tbMifoKaenslighetSkyddsvaerde ON dbo.tbMifoObjekt.recObjektID = dbo.tbMifoKaenslighetSkyddsvaerde.recObjektID
go

