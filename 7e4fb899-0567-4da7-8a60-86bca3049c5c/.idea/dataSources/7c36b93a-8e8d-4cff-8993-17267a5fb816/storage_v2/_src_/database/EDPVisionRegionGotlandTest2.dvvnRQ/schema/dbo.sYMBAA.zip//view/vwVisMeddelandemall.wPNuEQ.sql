
CREATE VIEW [dbo].[vwVisMeddelandemall]
AS
SELECT 
  recMeddelandemallID,
  recMeddelandemallID AS intRecnum,
	strMallnamn,
	strTjaenst,
	strRegistreringshaendelse,
	strTjaensteaktivitet,
	strRubrik,
	strText,
	tbVisMeddelandemall.bolEjAktuell,
	bolRegistreraFoervalt,
	strETjaenstnamn,
    tbVisMeddelandemall.recDelprocessID,
	strDelprocesskod,
    tbVisMeddelandemall.recHaendelseKategoriID,
	strHaendelseKategori, 
    strHaendelseKategoriKod,
    bolSkapaHaendelse
FROM dbo.tbVisMeddelandemall
LEFT OUTER JOIN tbAehDelprocess on tbAehDelprocess.recDelprocessID = tbVisMeddelandemall.recDelprocessID
LEFT OUTER JOIN tbAehHaendelseKategori on tbAehHaendelseKategori.recHaendelseKategoriID = tbVisMeddelandemall.recHaendelseKategoriID



go

