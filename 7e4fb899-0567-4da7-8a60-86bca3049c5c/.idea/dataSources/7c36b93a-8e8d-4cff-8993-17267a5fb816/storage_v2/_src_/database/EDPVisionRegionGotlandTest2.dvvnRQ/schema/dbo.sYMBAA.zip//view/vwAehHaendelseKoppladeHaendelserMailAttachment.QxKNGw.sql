
CREATE VIEW vwAehHaendelseKoppladeHaendelserMailAttachment AS
SELECT DISTINCT * FROM (
SELECT tbAehHaendelse.recHaendelseID, coalesce(tbAehHaendelseFileObject.recFileObjectID, -1) 'recFileObjectID'
FROM tbAehHaendelse
LEFT JOIN tbAehHaendelseFileObject ON tbAehHaendelseFileObject.recHaendelseID = tbAehHaendelse.recHaendelseID
UNION ALL
SELECT tbAehHaendelseHaendelse.recKoppladHaendelseID, coalesce(tbAehHaendelseFileObject.recFileObjectID, -1) 'recFileObjectID'
FROM tbAehHaendelseHaendelse
LEFT JOIN tbAehHaendelseFileObject on tbAehHaendelseFileObject.recHaendelseID = tbAehHaendelseHaendelse.recHaendelseID
UNION ALL
SELECT tbAehHaendelseHaendelse.recHaendelseID, coalesce(tbAehHaendelseFileObject.recFileObjectID, -1) 'recFileObjectID'
FROM tbAehHaendelseHaendelse
LEFT JOIN tbAehHaendelseFileObject ON tbAehHaendelseFileObject.recHaendelseID = tbAehHaendelseHaendelse.recKoppladHaendelseID
) AS T
go

