


CREATE VIEW [dbo].[vwVisComprimaSoekIndex]
AS
SELECT recIndexID, recIndexID As intRecNum, recInstaellningID, intIndex, strNamn, strSoekfaelt,
       bolVisaIGrid, intKolumnBredd
	
FROM tbVisComprimaSoekIndex



go

