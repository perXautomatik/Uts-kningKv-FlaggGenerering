CREATE VIEW [dbo].[vwTrLiProvtagningsParameter]
            AS SELECT
            P.*, L.strRapporteringsID, L.recTillsynsobjektID, P.recProvtagningsParameterId as intRecnum
            FROM tbTrLiProvtagningsParameter as P
            LEFT JOIN tbTrLiLivsmedel as L ON L.recLivsmedelID = P.recLivsmedelID

go

