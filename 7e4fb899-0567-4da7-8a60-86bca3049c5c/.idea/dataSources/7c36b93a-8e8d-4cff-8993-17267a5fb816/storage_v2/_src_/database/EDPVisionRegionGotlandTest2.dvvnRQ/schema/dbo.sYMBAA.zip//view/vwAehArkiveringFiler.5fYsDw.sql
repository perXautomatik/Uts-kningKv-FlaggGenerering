


CREATE VIEW [dbo].[vwAehArkiveringFiler]
AS
SELECT 
	  recArkiveringFilID
	, recArkiveringFilID As intRecNum
	, recArkiveringID
	, intArkivID
	, recHaendelseID
	, strHaendelseIdentifiering
	, strHaendelseKategori
	, recFileObjectID
	, strFilNamn
	, strFilbeskrivning
FROM tbAehArkiveringFiler
go

