
CREATE VIEW [dbo].[vwAehRemissutskick]
AS
SELECT dbo.tbAehRemissutskick.recRemissutskickID, 
		   dbo.tbAehRemissutskick.recRemissutskickID as intRecNum, 
		   dbo.tbAehRemissutskick.strRubrik, 
		   dbo.tbAehRemissutskick.datUtskicksdatum, 
		   dbo.tbAehRemissutskick.datSvarsdatum, 
		   dbo.tbAehRemissutskick.recAerendeID, 
		   dbo.tbAehAerendeData.strDiarienummer as strAerendeDiarienummer, 
		   dbo.tbAehAerende.strPublicering as strAerendePublicering
FROM dbo.tbAehRemissutskick 
LEFT OUTER JOIN dbo.tbAehAerendeData
  ON dbo.tbAehRemissutskick.recAerendeID = dbo.tbAehAerendeData.recAerendeID
LEFT OUTER JOIN dbo.tbAehAerende
  ON dbo.tbAehRemissutskick.recAerendeID = dbo.tbAehAerende.recAerendeID
go

