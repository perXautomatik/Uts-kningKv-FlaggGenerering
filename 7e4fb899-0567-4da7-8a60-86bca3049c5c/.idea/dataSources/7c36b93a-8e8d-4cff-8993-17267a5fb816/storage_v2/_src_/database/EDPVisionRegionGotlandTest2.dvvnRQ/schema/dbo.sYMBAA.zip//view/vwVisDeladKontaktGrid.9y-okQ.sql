
CREATE VIEW [dbo].[vwVisDeladKontaktGrid]
AS

WITH kommunikationSaett AS (
    SELECT recDeladKontaktID, strKommunikationsaettTyp + ' - ' + strVaerde AS kommunikationssaett
    FROM tbVisDeladKontaktKommunikationssaett
	LEFT OUTER JOIN tbVisKommunikationssaett
	  ON tbVisDeladKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
)
,
kommunikationsSaettSammanslagen AS (SELECT recDeladKontaktID, 
 (SELECT kommunikationssaett + ', '
  FROM kommunikationSaett
  WHERE kommunikationSaett.recDeladKontaktID = tbVisDeladKontaktKommunikationssaett.recDeladKontaktID
  FOR XML PATH('')) AS strKommunikationssaett 
FROM tbVisDeladKontaktKommunikationssaett
GROUP BY recDeladKontaktID
)

SELECT tbVisDeladKontakt.recDeladKontaktID, strVisasSom, strPostnummer, strGatuadress, strPostort, 
  strOrginisationPersonnummer, strSammanslagenAdress, strCoadress, tbVisDeladKontakt.recDeladKontaktID AS intRecnum,
  LEFT(strKommunikationssaett, LEN(strKommunikationssaett) - 1) AS strKommunikationssaett
FROM tbVisDeladKontakt 
LEFT OUTER JOIN kommunikationsSaettSammanslagen 
  ON tbVisDeladKontakt.recDeladKontaktID = kommunikationsSaettSammanslagen.recDeladKontaktID

go

