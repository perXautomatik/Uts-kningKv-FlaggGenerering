
CREATE VIEW [dbo].[vwVisInkorg]
AS
SELECT		dbo.tbVisInkorg.recInkorgID, 
			dbo.tbVisInkorg.strName, 
			dbo.tbVisInkorg.recFileNameTemplateID, 
			dbo.tbVisInkorg.recInkorgTypeID, 
            dbo.tbVisInkorgType.strName AS strInkorgTypeName, 
            dbo.tbVisFileNameTemplate.strName AS strFileNameTemplateName,
            dbo.tbVisFileNameTemplate.strTemplate, 
            dbo.tbVisInkorg.xmlSettings, 
            dbo.tbVisInkorg.recInkorgID AS intRecnum,
            dbo.tbVisInkorg.strScanFolder,
            dbo.tbVisInkorg.strPapperskorgFolder,
            dbo.tbVisInkorg.strTestScanFolder,
            dbo.tbVisInkorg.strTestPapperskorgFolder
            
FROM		dbo.tbVisInkorg 

INNER JOIN	dbo.tbVisInkorgType ON 
				dbo.tbVisInkorg.recInkorgTypeID = dbo.tbVisInkorgType.recInkorgTypeID 
INNER JOIN	dbo.tbVisFileNameTemplate ON 
				dbo.tbVisInkorg.recFileNameTemplateID = dbo.tbVisFileNameTemplate.recFileNameTemplateID



go

