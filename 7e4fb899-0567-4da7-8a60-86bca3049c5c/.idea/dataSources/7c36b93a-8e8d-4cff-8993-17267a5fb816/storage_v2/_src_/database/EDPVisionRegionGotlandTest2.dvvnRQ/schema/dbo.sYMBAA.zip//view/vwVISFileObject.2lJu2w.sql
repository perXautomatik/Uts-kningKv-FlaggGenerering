

CREATE VIEW [dbo].[vwVISFileObject]
AS
WITH

FilVy 
AS (
SELECT DISTINCT 
	dbo.tbEDPFileObject.recFileObjectID,
	dbo.tbEDPFileObject.strDescription, 
	dbo.tbEDPFileObject.strFileName,
    dbo.tbEDPFileObject.strHandlingstyp,
	FileLocked.recFileObjectLockedID, 
	FileLocked.strCheckedOutFileName, 
	FileLocked.datCheckOutDateTime, 
	FileLocked.intUserID, 
	EdpUser.strSignature,	
	FileVersion.strFiletype,  			
	dbo.tbEDPFileObject.recFileObjectID AS intRecnum,
	FileVersion.intFileVersion AS intMaxFileVersion,
	FileVersion.datFileVersionDate AS datLastFileVersionDate,
	dbo.tbEDPFileObject.bolWriteProtected,
	dbo.tbEDPFileObject.bolKanInnehaallaPersonuppgifter, 
	FileVersion.lngFileSize,
    Signering.strSignatureType as strSigneringsTyp,
	
	CASE 
		WHEN FileLocked.datCheckOutDateTime IS NOT NULL 
			THEN CAST(1 AS BIT) 
		ELSE
			CAST(0 AS BIT)
    END AS bolCheckedOut,

	CASE 
		WHEN DocumentTemplate.recFileObjectID IS NOT NULL 
			THEN CAST(1 AS BIT) 
		WHEN MailTemplate.recFileObjectID IS NOT NULL 
			THEN CAST(1 AS BIT) 
		ELSE 
			CAST(0 AS BIT)
	END AS isTemp,
	
	CASE 
		WHEN datCheckOutDateTime IS NOT NULL 
			THEN 'Utcheckad'
		WHEN datCheckOutDateTime IS NULL 
			THEN ''
    END AS strStatus,
	
	CASE 
		WHEN Arkivering.recFileObjectID IS NULL 
			THEN CAST(0 AS BIT)
		ELSE 
			CAST(1 AS BIT)
	END AS bolArkiverad
	
FROM dbo.tbEDPFileObject
	
	OUTER APPLY (SELECT TOP 1 * FROM  tbEDPFileVersion WHERE dbo.tbEDPFileObject.recFileObjectID = dbo.tbEDPFileVersion.recFileObjectID
		AND  (dbo.tbEDPFileVersion.recFileVersionID = 
		  (SELECT TOP 1 recFileVersionID FROM tbEDPFileVersion
			WHERE tbEDPFileVersion.recFileObjectID = tbEDPFileObject.recFileObjectID
			ORDER BY recFileVersionID DESC) OR EXISTS (SELECT COUNT(recFileVersionID) FROM tbEDPFileVersion
			WHERE tbEDPFileVersion.recFileObjectID = tbEDPFileObject.recFileObjectID
			HAVING COUNT(recFileVersionID) = 0))) as FileVersion

	OUTER APPLY (SELECT recFileObjectLockedID, strCheckedOutFileName, datCheckOutDateTime, intUserID FROM dbo.tbEDPFileObjectLocked WHERE  dbo.tbEDPFileObjectLocked.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID) FileLocked 
	OUTER APPLY (SELECT intUserID, strSignature FROM dbo.tbEDPUser WHERE dbo.tbEDPUser.intUserID = FileLocked.intUserID) EdpUser  
	OUTER APPLY (SELECT recFileObjectID FROM dbo.tbEDPDocumentTemplate WHERE tbEDPDocumentTemplate.recFileObjectID = tbEDPFileObject.recFileObjectID) DocumentTemplate  
	OUTER APPLY (SELECT recFileObjectID FROM dbo.tbEDPMailTemplate WHERE dbo.tbEDPMailTemplate.recFileObjectID = tbEDPFileObject.recFileObjectID) MailTemplate  
	OUTER APPLY (SELECT * FROM dbo.tbVisFilmall WHERE dbo.tbVisFilmall.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID) Filmall  
	OUTER APPLY (SELECT recFileObjectID FROM dbo.tbAehArkiveringFiler WHERE dbo.tbAehArkiveringFiler.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID) Arkivering  
	OUTER APPLY (SELECT TOP 1 strSignatureType FROM tbVisFileVersionSignature WHERE recFileVersionID = FileVersion.recFileVersionID ORDER BY tbVisFileVersionSignature.recFileVersionSignatureID DESC) Signering
  
WHERE 
	NOT EXISTS (SELECT recFileObjectID FROM dbo.tbVisFilmall WHERE dbo.tbVisFilmall.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID) AND 
	NOT EXISTS (SELECT recFileObjectID FROM dbo.tbEDPDocumentTemplate WHERE dbo.tbEDPDocumentTemplate.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID) AND 
	NOT EXISTS (SELECT recFileObjectID FROM dbo.tbEDPMailTemplate WHERE dbo.tbEDPMailTemplate.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID)
)

SELECT 
	Filvy.recFileObjectID,
	Filvy.strDescription, 
	Filvy.strFileName,
    FilVy.strHandlingstyp,
	Filvy.recFileObjectLockedID, 
	Filvy.strCheckedOutFileName, 
	Filvy.datCheckOutDateTime, 
	Filvy.intUserID, 
	Filvy.strSignature,	
	Filvy.strFiletype,  			
	Filvy.intRecnum,
	Filvy.intMaxFileVersion,
	Filvy.datLastFileVersionDate,
	Filvy.bolWriteProtected,
	Filvy.bolKanInnehaallaPersonuppgifter, 
	Filvy.lngFileSize,
	Filvy.strSigneringsTyp,
	Filvy.bolCheckedOut,
	Filvy.strStatus,
	Filvy.bolArkiverad, 
	Filvy.strStatus + ', ' + Filvy.strSignature + ', ' + convert(varchar(10), Filvy.datCheckOutDateTime, 20)  AS strUtcheckningStatus,
	CASE 
		WHEN FilVy.isTemp = 1
			THEN 
				CAST(1 AS BIT) 
		ELSE
			CASE 
				WHEN FilVy.recFileObjectID IS NOT NULL	
				THEN 
					CAST(1 AS BIT) 
				ELSE 
					CAST(0 AS BIT)  
			END
    END AS isTemplate
FROM FilVy


go

