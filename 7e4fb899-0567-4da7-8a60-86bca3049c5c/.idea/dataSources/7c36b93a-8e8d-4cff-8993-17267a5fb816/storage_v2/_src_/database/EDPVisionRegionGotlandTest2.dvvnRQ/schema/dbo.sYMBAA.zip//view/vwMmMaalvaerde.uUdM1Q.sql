CREATE VIEW dbo.vwMmMaalvaerde
AS
SELECT     dbo.tbMmMaalvaerde.recMaalvaerdeID, dbo.tbMmMaalvaerde.recFoeroreningAemneID, dbo.tbMmMaalvaerde.decMaalvaerde,
                      dbo.tbMmMaalvaerde.strEnhet, dbo.tbMmMaalvaerde.decFraanDjup, dbo.tbMmMaalvaerde.decTillDjup, dbo.tbMmMaalvaerde.strKommentar,
                      dbo.tbMmFoeroreningAemne.recFoeroreningID, dbo.tbMmFoerorening.recMediumID, dbo.tbMmFoerorening.strFoeroreningNamn,
                      dbo.tbMmAemne.strAemneNamn, dbo.tbMmMedium.strMediumNamn, dbo.tbMmMaalvaerde.recMaalvaerdeID AS intRecnum,
                      dbo.tbMmOmraade.strOmrNamn, dbo.tbMmFoerorening.recOmrID, dbo.tbMmFoeroreningAemne.guidAemneID
FROM         dbo.tbMmOmraade RIGHT OUTER JOIN
                      dbo.tbMmFoerorening ON dbo.tbMmOmraade.recOmrID = dbo.tbMmFoerorening.recOmrID LEFT OUTER JOIN
                      dbo.tbMmMedium ON dbo.tbMmFoerorening.recMediumID = dbo.tbMmMedium.recMediumID RIGHT OUTER JOIN
                      dbo.tbMmAemne RIGHT OUTER JOIN
                      dbo.tbMmFoeroreningAemne ON dbo.tbMmAemne.guidAemneID = dbo.tbMmFoeroreningAemne.guidAemneID ON
                      dbo.tbMmFoerorening.recFoeroreningID = dbo.tbMmFoeroreningAemne.recFoeroreningID RIGHT OUTER JOIN
                      dbo.tbMmMaalvaerde ON dbo.tbMmFoeroreningAemne.recFoeroreningAemneID = dbo.tbMmMaalvaerde.recFoeroreningAemneID
go

