
CREATE PROCEDURE [dbo].[spAehAerendeDataUpdateFastighet]
  @recAerendeID int
AS
BEGIN
  SET NOCOUNT ON;
  
  UPDATE tbAehAerendeData SET
    strFastighetsbeteckning = dbo.tbVisEnstakaFastighet.strFastighetsbeteckning,
    strFnrID = dbo.tbVisEnstakaFastighet.strFnrID,
    guidFastighetUuid = dbo.tbVisEnstakaFastighet.guidUuid,
    recFastighetID = dbo.tbVisEnstakaFastighet.recFastighetID
  FROM tbAehAerendeData
  LEFT OUTER JOIN dbo.tbAehAerendeEnstakaFastighet
    ON dbo.tbAehAerendeData.recAerendeID = dbo.tbAehAerendeEnstakaFastighet.recAerendeID 
    AND dbo.tbAehAerendeEnstakaFastighet.bolHuvudfastighet = 1
  LEFT OUTER JOIN dbo.tbVisEnstakaFastighet
    ON dbo.tbAehAerendeEnstakaFastighet.recFastighetID = dbo.tbVisEnstakaFastighet.recFastighetID
  WHERE tbAehAerendeData.recAerendeID = @recAerendeID

  UPDATE tbAehAerende SET
    recKommunID = tbVisEnstakaFastighet.recKommunID
  FROM tbAehAerende
  LEFT OUTER JOIN dbo.tbAehAerendeEnstakaFastighet
    ON dbo.tbAehAerende.recAerendeID = dbo.tbAehAerendeEnstakaFastighet.recAerendeID 
    AND dbo.tbAehAerendeEnstakaFastighet.bolHuvudfastighet = 1
  LEFT OUTER JOIN dbo.tbVisEnstakaFastighet
    ON dbo.tbAehAerendeEnstakaFastighet.recFastighetID = dbo.tbVisEnstakaFastighet.recFastighetID
  WHERE tbAehAerende.recAerendeID = @recAerendeID

END
go

