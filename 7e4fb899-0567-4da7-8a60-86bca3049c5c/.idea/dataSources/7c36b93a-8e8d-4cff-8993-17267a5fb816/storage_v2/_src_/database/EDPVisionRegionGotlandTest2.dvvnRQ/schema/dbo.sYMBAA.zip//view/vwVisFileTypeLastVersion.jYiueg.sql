CREATE VIEW dbo.vwVisFileTypeLastVersion
AS
SELECT     dbo.vwEDPFileObject.recFileObjectID, dbo.vwEDPFileObject.intMaxFileVersion, dbo.vwEDPFileObject.strFileName, dbo.vwEDPFileVersion.strFileType,
                      dbo.vwEDPFileObject.recFileObjectID AS intRecnum
FROM         dbo.vwEDPFileObject LEFT OUTER JOIN
                      dbo.vwEDPFileVersion ON dbo.vwEDPFileObject.intMaxFileVersion = dbo.vwEDPFileVersion.intFileVersion AND
                      dbo.vwEDPFileObject.recFileObjectID = dbo.vwEDPFileVersion.recFileObjectID
go

