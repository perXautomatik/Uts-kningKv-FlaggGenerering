
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell04]
AS
SELECT     
  dbo.tbAehPblAvgiftTaxa2011Tabell04.recPblAvgiftTaxa2011Tabell04ID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell04.recAvgiftID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell04.recPblAvgiftTaxa2011Tabell04ID AS intRecnum, 
  dbo.tbAehPblAvgiftTaxa2011Tabell04.strAvvikandeOFAAtgaerd,
  dbo.tbAehPblAvgiftTaxa2011Tabell04.intOF,
  dbo.tbAehPblAvgiftTaxa2011Tabell04.bolTidsersaettning,
  dbo.tbAehPblAvgiftTaxa2011Tabell04.bolHandlaeggningsfaktor,
  dbo.tbAehPblAvgiftTaxa2011Tabell04.decAvgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell04.decHF1,
  dbo.tbAehPblAvgiftTaxa2011Tabell04.decOF,
  dbo.tbAehPblAvgiftTaxa2011Tabell04.decmPBB,
  dbo.tbAehPblAvgiftTaxa2011Tabell04.decN,
  dbo.tbAehPblAvgiftTaxa2011Tabell04.decHF1Justering,
  dbo.tbAehPblAvgiftTaxa2011Tabell04.decOFJustering,
  dbo.tbAehPblAvgiftTaxa2011Tabell04.bolDebiterad
FROM dbo.tbAehPblAvgiftTaxa2011Tabell04

go

