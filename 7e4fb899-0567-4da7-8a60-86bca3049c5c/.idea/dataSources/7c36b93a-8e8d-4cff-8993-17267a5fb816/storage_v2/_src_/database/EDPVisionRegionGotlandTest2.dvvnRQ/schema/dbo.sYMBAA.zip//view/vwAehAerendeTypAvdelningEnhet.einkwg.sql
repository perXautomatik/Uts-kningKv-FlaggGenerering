
CREATE VIEW [dbo].[vwAehAerendeTypAvdelningEnhet]
AS SELECT tbAehAerendetyp.recAerendetypID as intRecnum, 
    tbAehAerendetyp.recAerendetypID,
	tbAehAerendetyp.strAerendetypKod,
	tbAehAerendetyp.bolEjAktuell,
	tbAehAerendetyp.strAerendeTyp,
	tbAehAerendetyp.bolKomplettAerende,
	tbAehAerendetyp.strAerendekategori,
	tbAehAerendetyp.strPoITKategori,
	(SELECT CONVERT(NVARCHAR, recAvdelningID) + ', ' 
        FROM tbAehAerendetypAvdelning
        WHERE tbAehAerendetypAvdelning.recAerendetypID = tbAehAerendetyp.recAerendetypID
        FOR XML PATH('')) AS recAvdelningID,
	(SELECT CONVERT(NVARCHAR, recEnhetID) + ', ' 
        FROM tbAehAerendetypEnhet
        WHERE tbAehAerendetypEnhet.recAerendetypID = tbAehAerendetyp.recAerendetypID
        FOR XML PATH('')) AS recEnhetID
    FROM tbAehAerendetyp

go

