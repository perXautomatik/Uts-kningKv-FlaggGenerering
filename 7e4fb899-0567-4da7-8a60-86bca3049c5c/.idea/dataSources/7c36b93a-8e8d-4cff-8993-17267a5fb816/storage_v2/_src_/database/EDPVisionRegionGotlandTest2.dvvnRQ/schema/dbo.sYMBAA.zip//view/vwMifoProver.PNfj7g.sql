CREATE VIEW dbo.vwMifoProver
AS
SELECT     dbo.tbMifoProver.recProverID, dbo.tbMifoProver.recObjektID, dbo.tbMifoProver.strMedium, dbo.tbMifoProver.strJaemfoerelse,
                      dbo.tbMifoProver.strAntalProver, dbo.tbMifoProver.strReferenser, dbo.tbMifoProver.strBeskrivning, dbo.tbMifoObjekt.strObjektId,
                      dbo.tbMifoObjekt.strObjektNamn, dbo.tbMifoProver.recProverID AS intRecnum, dbo.tbMifoProver.strFas
FROM         dbo.tbMifoObjekt INNER JOIN
                      dbo.tbMifoProver ON dbo.tbMifoObjekt.recObjektID = dbo.tbMifoProver.recObjektID
go

