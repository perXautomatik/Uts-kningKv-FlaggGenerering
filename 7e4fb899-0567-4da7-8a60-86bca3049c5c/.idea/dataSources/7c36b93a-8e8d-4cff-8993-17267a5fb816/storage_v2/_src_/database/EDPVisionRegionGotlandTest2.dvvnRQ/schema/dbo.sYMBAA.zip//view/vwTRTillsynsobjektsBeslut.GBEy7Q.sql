CREATE VIEW vwTRTillsynsobjektsBeslut
AS
--- Fuskvy för att kunna skapa GridID, data hämtas inifrån programmet
SELECT '' AS strDiarienummer,
       '' AS strHaendelsekategori,
     NULL AS datBeslutsDatum,
       '' AS strBeslutsNummer,
       '' AS strBeslutsutfall,
       '' AS strRubrik,
       '' AS strHuvudhandlaeggare,
        0 AS intAntalFiler
go

