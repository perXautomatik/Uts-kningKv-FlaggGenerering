

CREATE VIEW [dbo].[vwTrKmAggregat]
AS
SELECT        dbo.tbTrKmAggregat.recAggregatID AS intRecnum, dbo.tbTrKmAggregat.recAggregatID, dbo.tbTrKmAggregat.recTillsynsobjektID, dbo.tbTrKmAggregat.datStatusDatum, dbo.tbTrKmAggregat.strStatus,
                         dbo.tbTrKmAggregat.strAnteckning, dbo.tbTrKmAggregat.strAggregatBeteckning, dbo.tbTrKmAggregat.strAnvaendingsSaett, dbo.tbTrKmAggregat.decInstalleradMaengd, dbo.tbTrKmAggregat.strKoeldmedieTyp,
                         dbo.tbTrKmAggregat.intKontrollIntervall, dbo.tbTrKmAggregat.datNaestaKontroll, dbo.tbTrKmAggregat.datSenasteKontroll, dbo.tbTrKmAggregat.bolLaeckageSystem, dbo.tbTrKmAggregat.bolHermetisktSystem,
                         dbo.tbTrKmAggregat.decCO2e, dbo.tbTrTillsynsobjekt.strObjektsNamn, dbo.tbVisDeladFastighet.strFastighetsbeteckning AS strHuvudFastighet, dbo.tbVisDeladFastighet.strFnrID, dbo.tbTrKmAggregat.recKoeldmediumID,
                         dbo.tbTrKmKoeldMedium.strRNummer as strKoeldmedium
FROM            dbo.tbTrKmAggregat INNER JOIN
                         dbo.tbTrTillsynsobjekt ON dbo.tbTrKmAggregat.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID LEFT OUTER JOIN
                         dbo.tbTrKmKoeldMedium ON dbo.tbTrKmAggregat.recKoeldmediumID = dbo.tbTrKmKoeldMedium.recKoeldmediumID LEFT OUTER JOIN
                         dbo.tbTrKmAggregatFastighet ON dbo.tbTrKmAggregatFastighet.recAggregatID = dbo.tbTrKmAggregat.recAggregatID AND dbo.tbTrKmAggregatFastighet.bolHuvudfastighet = 1 LEFT OUTER JOIN
                         dbo.tbVisDeladFastighet ON dbo.tbVisDeladFastighet.strFnrID = dbo.tbTrKmAggregatFastighet.strFnrID
go

