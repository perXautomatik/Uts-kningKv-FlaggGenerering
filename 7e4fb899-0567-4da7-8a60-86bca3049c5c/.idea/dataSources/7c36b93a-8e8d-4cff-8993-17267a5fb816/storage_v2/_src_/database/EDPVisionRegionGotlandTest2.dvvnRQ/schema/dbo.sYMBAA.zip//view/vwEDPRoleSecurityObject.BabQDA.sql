CREATE VIEW dbo.vwEDPRoleSecurityObject
AS
SELECT tbEDPRoleSecurityObject.intRoleID, tbEDPRole.strRoleName,
  tbEDPSecurityObject.strSecurityObjectName, tbEDPRoleSecurityObject.guidSecurityObjectID,
  tbEDPRoleSecurityObject.bitAuthorized, tbEDPRoleSecurityObject.intRoleID AS intRecnum,
  tbEDPRoleSecurityObject.intRoleSecurityObjectID
FROM tbEDPRoleSecurityObject INNER JOIN tbEDPSecurityObject
  ON tbEDPRoleSecurityObject.guidSecurityObjectID = tbEDPSecurityObject.guidSecurityObjectID
  INNER JOIN tbEDPRole
    ON tbEDPRole.intRoleID = tbEDPRoleSecurityObject.intRoleID
go

