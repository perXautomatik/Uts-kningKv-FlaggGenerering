CREATE VIEW dbo.vwAehDiarieAarsSerie
AS
SELECT     dbo.tbAehDiarieAarsSerie.recDiarieAarsSerieID, dbo.tbAehDiarieAarsSerie.recDiarieSerieID, dbo.tbAehDiarieAarsSerie.intDiarieAar,
                      dbo.tbAehDiarieAarsSerie.intSerieStartVaerde, dbo.tbAehDiarieAarsSerie.bolEjAktuell, dbo.tbAehDiarieSerie.strDiarieSerieKod,
                      dbo.tbAehDiarieAarsSerie.recDiarieAarsSerieID AS intRecnum, tbl.intMaxLoepNummer
FROM         dbo.tbAehDiarieAarsSerie LEFT OUTER JOIN
                      dbo.tbAehDiarieSerie ON dbo.tbAehDiarieAarsSerie.recDiarieSerieID = dbo.tbAehDiarieSerie.recDiarieSerieID LEFT OUTER JOIN
                          (SELECT     MAX(intDiarienummerLoepNummer) AS intMaxLoepNummer, recDiarieAarsSerieID
                            FROM          dbo.tbAehAerende
                            GROUP BY recDiarieAarsSerieID) AS tbl ON dbo.tbAehDiarieAarsSerie.recDiarieAarsSerieID = tbl.recDiarieAarsSerieID
go

