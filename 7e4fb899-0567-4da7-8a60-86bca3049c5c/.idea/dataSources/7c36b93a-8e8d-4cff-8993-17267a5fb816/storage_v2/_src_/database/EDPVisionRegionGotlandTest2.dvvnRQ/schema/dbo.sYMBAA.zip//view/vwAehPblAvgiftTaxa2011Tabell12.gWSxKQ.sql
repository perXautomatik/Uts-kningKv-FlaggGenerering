
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell12]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell12.recPblAvgiftTaxa2011Tabell12ID,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.recPblAvgiftTaxa2011Tabell12ID AS intRecnum,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.bolHuvudByggnad,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.bolKomplementbyggnad,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.bolTidsersaettning,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.bolHandlaeggningsfaktor,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.bolHaemtaHF1,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.bolHaemtaHf2,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.decAvgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.decOF,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.decHF1,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.decHF2,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.decmPBB,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.decN,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.decOFJustering,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.decHF1Justering,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.decHF2Justering,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.recAvgiftID,
  dbo.tbAehPblAvgiftTaxa2011Tabell12.bolDebiterad
FROM  dbo.tbAehPblAvgiftTaxa2011Tabell12

go

