CREATE VIEW dbo.vwMmRiktvaerdeEget
AS
SELECT     dbo.tbMmRiktvaerdeEget.recRiktvaerdeEgetID, dbo.tbMmRiktvaerdeEget.strMarkanvaendning, dbo.tbMmRiktvaerdeEget.strMarktaethet,
                      dbo.tbMmRiktvaerdeEget.intOrganiskHalt, dbo.tbMmRiktvaerdeEget.intLerhalt, dbo.tbMmAemne.strAemneKemBeteckning, dbo.tbMmAemne.bolEditOk,
                      dbo.tbMmRiktvaerdeEget.recRiktvaerdeEgetID AS intRecnum, dbo.tbMmRiktvaerdeEget.strKommentar, dbo.tbMmRiktvaerdeEget.decFraanDjup,
                      dbo.tbMmRiktvaerdeEget.decTillDjup, dbo.tbMmRiktvaerdetyp.strRiktvaerdetypNamn, dbo.tbMmAemne.strAemneNamn,
                      dbo.tbMmRiktvaerdeEget.intAartal, dbo.tbMmRiktvaerdeEget.strMatris, dbo.tbMmRiktvaerdeEget.decVaerde, dbo.tbMmRiktvaerdeEget.strEnhet,
                      dbo.tbMmRiktvaerdeEget.guidAemneID, dbo.tbMmRiktvaerdeEget.guidRiktvaerdetypID
FROM         dbo.tbMmRiktvaerdeEget LEFT OUTER JOIN
                      dbo.tbMmRiktvaerdetyp ON dbo.tbMmRiktvaerdeEget.guidRiktvaerdetypID = dbo.tbMmRiktvaerdetyp.guidRiktvaerdetypID LEFT OUTER JOIN
                      dbo.tbMmAemne ON dbo.tbMmRiktvaerdeEget.guidAemneID = dbo.tbMmAemne.guidAemneID
go

