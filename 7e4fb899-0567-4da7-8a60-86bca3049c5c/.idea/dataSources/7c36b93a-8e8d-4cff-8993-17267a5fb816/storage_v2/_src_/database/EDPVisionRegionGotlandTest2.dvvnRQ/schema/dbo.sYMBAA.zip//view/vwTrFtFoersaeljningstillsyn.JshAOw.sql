

CREATE VIEW [dbo].[vwTrFtFoersaeljningstillsyn]
AS
SELECT        recFoersaeljningstillsynID
			,recFoersaeljningstillsynID as intRecnum
			, strVerksamhetsinrikting
			,recTillsynsobjektID
FROM            dbo.tbTrFtFoersaeljningstillsyn
go

