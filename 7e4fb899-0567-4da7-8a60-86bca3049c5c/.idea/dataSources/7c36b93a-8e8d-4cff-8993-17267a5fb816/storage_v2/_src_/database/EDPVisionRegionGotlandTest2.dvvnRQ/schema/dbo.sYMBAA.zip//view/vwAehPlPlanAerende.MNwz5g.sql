
CREATE VIEW [dbo].[vwAehPlPlanAerende]
AS
SELECT tbAehPlPlanAerende.recPlanAerendeID, 
  tbAehPlPlanAerende.recPlanAerendeID AS intRecnum,
  tbAehPlPlanAerende.recAerendeID,
  tbAehPlPlanAerende.strPlanNamn,
  tbAehPlPlanAerende.strAktbeteckning,
  tbAehPlPlanAerende.strPlantyp,
  tbAehPlPlanAerende.strLittera,
  tbAehPlPlanAerende.datLagakraft,
  tbAehAerende.recAvdelningID  -- Behövs för postbehörigheter
FROM dbo.tbAehPlPlanAerende
LEFT OUTER JOIN	tbAehAerende
  ON tbAehAerende.recAerendeID = tbAehPlPlanAerende.recAerendeID

go

