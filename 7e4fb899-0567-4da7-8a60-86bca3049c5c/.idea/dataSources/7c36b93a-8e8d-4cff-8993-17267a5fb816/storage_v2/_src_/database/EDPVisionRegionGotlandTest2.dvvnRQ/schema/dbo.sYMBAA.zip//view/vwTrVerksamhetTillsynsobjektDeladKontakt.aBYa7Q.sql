
CREATE VIEW [dbo].[vwTrVerksamhetTillsynsobjektDeladKontakt]
AS
SELECT 
		dbo.tbTrTillsynsobjektDeladKontakt.recTillsynsobjektDeladKontaktID as intRecnum,
		dbo.tbTrTillsynsobjektDeladKontakt.recTillsynsobjektDeladKontaktID,
        dbo.vwVisDeladKontaktGrid.recDeladKontaktID,          
        dbo.vwVisDeladKontaktGrid.strVisasSom,
        dbo.vwVisDeladKontaktGrid.strSammanslagenAdress,
        dbo.vwVisDeladKontaktGrid.strOrginisationPersonnummer,
		dbo.vwVisDeladKontaktGrid.strKommunikationssaett,
                  
        dbo.tbTrTillsynsobjektDeladKontakt.strRoll,
          
        dbo.tbTrTillsynsobjekt.recTillsynsobjektID,          
        dbo.tbTrTillsynsobjekt.strObjektsNamn,
        dbo.tbTrTillsynsobjekt.recVerksamhetID,
          
        dbo.tbTrTillsynsobjektsTyp.strTillsynsobjektsTypNamn
    
FROM    dbo.tbTrTillsynsobjektDeladKontakt

LEFT OUTER JOIN dbo.vwVisDeladKontaktGrid
ON      dbo.tbTrTillsynsobjektDeladKontakt.recDeladKontaktID = dbo.vwVisDeladKontaktGrid.recDeladKontaktID

LEFT OUTER JOIN dbo.tbTrTillsynsobjekt
ON      dbo.tbTrTillsynsobjektDeladKontakt.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID

LEFT OUTER JOIN dbo.tbTrTillsynsobjektsTyp
ON      dbo.tbTrTillsynsobjekt.recTillsynsobjektTypID = dbo.tbTrTillsynsobjektsTyp.recTillsynsobjektTypID


go

