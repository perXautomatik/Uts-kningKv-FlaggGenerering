

CREATE VIEW [dbo].[vwTrLiMyndighetsuppgifterPerAar2010]
AS
SELECT  	tbTrLiMyndighetsuppgifterPerAar2010.recMyndighetsuppgifterPerAar2010ID, 
			tbTrLiMyndighetsuppgifterPerAar2010.recMyndighetsuppgifterPerAar2010ID AS intRecNum,
			tbTrLiMyndighetsuppgifterPerAar2010.recMyndighetsuppgifterID, 
			tbTrLiMyndighetsuppgifterPerAar2010.intTimtaxaPlaneradKontroll, 
			tbTrLiMyndighetsuppgifterPerAar2010.intAntalRegistreringar, 
			tbTrLiMyndighetsuppgifterPerAar2010.intAntalGodkaennande, 
			tbTrLiMyndighetsuppgifterPerAar2010.intAvgiftRegistreringar, 
			tbTrLiMyndighetsuppgifterPerAar2010.intAvgifterGodkaennande, 
			tbTrLiMyndighetsuppgifterPerAar2010.intExtraKontrollavgifter, 
			tbTrLiMyndighetsuppgifterPerAar2010.intBudgeteradKostnad, 
			tbTrLiMyndighetsuppgifterPerAar2010.intAarligaKontrollavgifter, 
			tbTrLiMyndighetsuppgifterPerAar2010.decResursbehovAdminstoedDricksvatten, 
			tbTrLiMyndighetsuppgifterPerAar2010.decResursbehovDricksvattenkontroll, 
			tbTrLiMyndighetsuppgifterPerAar2010.decAarsarbetskrafterDricksvattenkontroll, 
			tbTrLiMyndighetsuppgifterPerAar2010.intPersonerDricksvattenkontroll, 
			tbTrLiMyndighetsuppgifterPerAar2010.decResursbehovAdminstoedLivsmedel, 
			tbTrLiMyndighetsuppgifterPerAar2010.decResursbehovLivsmedelskontroll, 
			tbTrLiMyndighetsuppgifterPerAar2010.decAarsarbetskrafterAdminstoedLivsmedel, 
			tbTrLiMyndighetsuppgifterPerAar2010.decAarsarbetskrafterLivsmedelskontroll, 
			tbTrLiMyndighetsuppgifterPerAar2010.intPersonerLivsmedelskontroll, 
			tbTrLiMyndighetsuppgifterPerAar2010.strRiskklassning, 
			tbTrLiMyndighetsuppgifterPerAar2010.intAar, 
			tbTrLiMyndighetsuppgifterPerAar2010.intTimtaxaExtraOffentligKontroll, 
			tbTrLiMyndighetsuppgifterPerAar2010.decAarsarbetskrafterAdminstoedDricksvatten, 
			tbTrLiMyndighetsuppgifter.strMyndighetskod, 
			tbTrLiMyndighetsuppgifter.strMyndighetsnamn,
            tbTrLiMyndighetsuppgifter.strEpost, 
            tbVisLaen.strLaensNamn,
            tbTrLiMyndighetsuppgifter.strMyndighetstyp
FROM		tbTrLiMyndighetsuppgifterPerAar2010 
INNER JOIN	tbTrLiMyndighetsuppgifter 
ON			tbTrLiMyndighetsuppgifter.recMyndighetsuppgifterID = tbTrLiMyndighetsuppgifterPerAar2010.recMyndighetsuppgifterID
LEFT JOIN	tbVisLaen ON tbVisLaen.recLaenID = tbTrLiMyndighetsuppgifter.recLaenID


go

