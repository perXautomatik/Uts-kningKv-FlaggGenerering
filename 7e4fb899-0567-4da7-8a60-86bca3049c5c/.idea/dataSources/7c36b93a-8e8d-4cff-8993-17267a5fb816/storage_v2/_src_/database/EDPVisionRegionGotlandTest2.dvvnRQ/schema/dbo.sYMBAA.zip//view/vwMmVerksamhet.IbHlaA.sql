CREATE VIEW dbo.vwMmVerksamhet
AS
SELECT     dbo.tbMmBransch.strBranschNamn, dbo.tbMmBransch.intBranschIdMIFO, dbo.tbMmBransch.intBranschRiskklass,
                      dbo.tbMmVerksamhet.recVerksamhetID AS intRecnum, dbo.tbMmVerksamhet.recVerksamhetID, dbo.tbMmVerksamhet.recOmrID,
                      dbo.tbMmVerksamhet.recBranschID, dbo.tbMmVerksamhet.strUtoevare, dbo.tbMmVerksamhet.datStartdatum, dbo.tbMmVerksamhet.datSlutdatum,
                      dbo.tbMmVerksamhet.strVerksamhetGatuadress, dbo.tbMmVerksamhet.strVerksamhetFastbeteckning,
                      dbo.tbMmVerksamhet.strVerksamhetBeskrivning, dbo.tbMmVerksamhet.strVerksamhet, dbo.vwMmOmraade.strOmraadeKod,
                      dbo.vwMmOmraade.strOmrNamn, dbo.tbMmVerksamhet.bolAnsvarig, dbo.tbMmBransch.strBranschBeskrivning
FROM         dbo.tbMmVerksamhet INNER JOIN
                      dbo.vwMmOmraade ON dbo.tbMmVerksamhet.recOmrID = dbo.vwMmOmraade.recOmrID LEFT OUTER JOIN
                      dbo.tbMmBransch ON dbo.tbMmVerksamhet.recBranschID = dbo.tbMmBransch.recBranschID
go

