
CREATE VIEW [dbo].[vwAehHaendelseLookup]
AS

SELECT
       dbo.tbAehHaendelse.recHaendelseID intRecnum,
       dbo.tbAehHaendelse.recHaendelseID,
       dbo.tbAehHaendelse.strRubrik, 
	   dbo.vwAehHaendelseidentifiering.strHaendelseIdentifiering,       
       dbo.tbAehHaendelseKategori.strHaendelseKategori, 
	   dbo.tbAehHaendelseData.strSignature
FROM dbo.tbAehHaendelse 
LEFT OUTER JOIN dbo.tbAehHaendelseData
  ON dbo.tbAehHaendelseData.recHaendelseID = dbo.tbAehHaendelse.recHaendelseID
LEFT OUTER JOIN dbo.tbAehHaendelseKategori
  ON dbo.tbAehHaendelseKategori.recHaendelseKategoriID = dbo.tbAehHaendelse.recHaendelseKategoriID
LEFT OUTER JOIN dbo.tbAehAerendeHaendelse
  ON dbo.tbAehAerendeHaendelse.recHaendelseID = dbo.tbAehHaendelse.recHaendelseID
LEFT OUTER JOIN dbo.vwAehHaendelseidentifiering
  ON dbo.vwAehHaendelseidentifiering.recHaendelseID = tbAehHaendelse.recHaendelseID
go

