/****** Object:  View [dbo].[vwEDPRoleUser]    Script Date: 11/09/2006 15:23:49 ******/
CREATE VIEW [dbo].[vwEDPRoleUser]
AS
SELECT     dbo.tbEDPRole.strRoleName, dbo.tbEDPRoleUser.intRoleID, dbo.tbEDPRoleUser.intUserID, dbo.tbEDPRoleUser.intPriority, 
                      dbo.tbEDPRoleUser.intRecnum
FROM         dbo.tbEDPRole INNER JOIN
                      dbo.tbEDPRoleUser ON dbo.tbEDPRole.intRoleID = dbo.tbEDPRoleUser.intRoleID
go

