
CREATE PROCEDURE [dbo].[spAehAerendeDataUpdateSekretesslog]
  @recAerendeID int
AS
BEGIN
  SET NOCOUNT ON;

  UPDATE dbo.tbAehAerendeData SET recLastAerendeSekretessLogID = 
    ( SELECT TOP (1) recAerendeSekretessLogID FROM tbAehAerendeSekretessLog
      WHERE recAerendeID = @recAerendeID
      ORDER BY datDatum DESC
    )
  WHERE recAerendeID = @recAerendeID
  
  UPDATE tbAehAerendeData SET
    strSekretess = dbo.tbAehAerendeSekretessLog.strRekommendation,
    strBegraensa = dbo.tbAehAerendeSekretessLog.strBegraensa,
    strSekretessMyndighet = dbo.tbAehAerendeSekretessLog.strMyndighet,
    datSekretessDatum = dbo.tbAehAerendeSekretessLog.datDatum
	
  FROM tbAehAerendeData
  LEFT OUTER JOIN tbAehAerendeSekretessLog 
    ON tbAehAerendeSekretessLog.recAerendeSekretessLogID = dbo.tbAehAerendeData.recLastAerendeSekretessLogID 
  WHERE tbAehAerendeData.recAerendeID = @recAerendeID
  
  UPDATE tbAehAerende SET
    strPublicering = CASE WHEN dbo.tbAehAerendeSekretessLog.strMyndighet IS NULL THEN 'Visa med personskydd' ELSE 'Visa inte' END
  FROM tbAehAerende
  INNER JOIN tbAehAerendeData
    ON tbAehAerendeData.recAerendeID = tbAehAerende.recAerendeID
  LEFT OUTER JOIN tbAehAerendeSekretessLog 
    ON tbAehAerendeSekretessLog.recAerendeSekretessLogID = dbo.tbAehAerendeData.recLastAerendeSekretessLogID 
  WHERE tbAehAerende.recAerendeID = @recAerendeID
END
go

