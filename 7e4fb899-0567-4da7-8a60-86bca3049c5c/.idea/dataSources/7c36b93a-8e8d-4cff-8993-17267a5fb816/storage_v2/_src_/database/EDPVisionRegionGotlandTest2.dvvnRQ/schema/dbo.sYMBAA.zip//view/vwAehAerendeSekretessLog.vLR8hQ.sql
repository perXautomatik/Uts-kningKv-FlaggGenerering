CREATE VIEW [dbo].[vwAehAerendeSekretessLog]
AS
SELECT     dbo.tbAehAerendeSekretessLog.recAerendeSekretessLogID, dbo.tbAehAerendeSekretessLog.recAerendeID, dbo.tbAehAerendeSekretessLog.intUserID,
                      dbo.tbAehAerendeSekretessLog.datDatum, dbo.tbEDPUser.strSignature, dbo.tbAehAerendeSekretessLog.recAerendeSekretessLogID AS intRecnum,
                      dbo.tbAehAerendeSekretessLog.strKommentar, dbo.tbAehAerendeSekretessLog.strMyndighet, dbo.tbAehAerendeSekretessLog.strRekommendation,
                      dbo.tbAehAerendeSekretessLog.strBegraensa
FROM         dbo.tbAehAerendeSekretessLog INNER JOIN
                      dbo.tbEDPUser ON dbo.tbAehAerendeSekretessLog.intUserID = dbo.tbEDPUser.intUserID
go

