
            -- Hämta datum för den äldsta kopplingen för denna person
            -- måste uppdateras efter hand som nya koplingstabeller tillkommer.
            CREATE FUNCTION [dbo].[FnMhPersonTidigasteKopplingsdatum]
              (@recPersonID AS INT)
              RETURNS DATETIME
            AS
            BEGIN
              DECLARE @dat AS DATETIME;
              WITH Personer AS
              (
                -- Kopplingstabell: tbMhMoetePerson 
                SELECT datKopplingsDatum AS dat FROM tbMhMoetePerson 
                WHERE datKopplingsDatum IS NOT NULL AND recPersonID = @recPersonID 

                -- Nästa kopplingstabell
                -- UNION
                -- SELECT datKopplingsDatum AS dat FROM tbMhMoetePerson 
                -- WHERE datKopplingsDatum IS NOT NULL AND recPersonID = @recPersonID 
              )
              SELECT TOP 1 @dat = datSkapad FROM tbMhPersonHistorik
              WHERE datSkapad <= (SELECT MIN(dat) FROM Personer)
              ORDER BY datSkapad DESC

              RETURN @dat
            END
            go

