

CREATE VIEW [dbo].[vwTrPcbByggnad]
AS
SELECT dbo.tbTrPcbByggnad.recPcbByggnadID, dbo.tbTrPcbByggnad.recPcbByggnadID AS intRecnum,
  dbo.tbTrPcbByggnad.recTillsynsobjektID, dbo.tbTrTillsynsobjekt.strObjektsNamn, dbo.tbTrPcbByggnad.strByggnad,
  dbo.tbTrPcbByggnad.strByggnadsID, dbo.tbTrPcbByggnad.strByggnadsadress, dbo.tbTrPcbByggnad.strAnteckningBeskrivning,
  dbo.tbTrPcbByggnad.strByggnadsTyp, dbo.tbTrPcbByggnad.intTillbyggnadsAar, dbo.tbTrPcbByggnad.intNybyggnadsAar,
  dbo.tbTrPcbByggnad.decInventeradFoglaengdOever500, dbo.tbTrPcbByggnad.decInventeradFoglaengdOever50Under500,
  dbo.tbTrPcbByggnad.decInventeradFoglaengdUnder500, dbo.tbTrPcbByggnad.decInventeradPCBmaengdIFog,
  dbo.tbTrPcbByggnad.decSaneradFoglaengdOever500, dbo.tbTrPcbByggnad.decSaneradFoglaengdOever50Under500,
  dbo.tbTrPcbByggnad.decSaneradFoglaengdUnder500, dbo.tbTrPcbByggnad.decSaneradPCBmaengdIFog,
  dbo.tbTrPcbByggnad.decDoldaFogarOever500, dbo.tbTrPcbByggnad.decDoldaFogarOever50Under500,
  dbo.tbTrPcbByggnad.strDoldaFogar, dbo.tbTrPcbByggnad.bolInventeradeIsolerrutor,
  dbo.tbTrPcbByggnad.bolInventeradeKondensatorer, dbo.tbTrPcbByggnad.bolInventeradeGolvmassor,
  dbo.tbTrPcbByggnad.intAntalInventeradeRutor, dbo.tbTrPcbByggnad.intAntalInventeradeKondensatorer,
  dbo.tbTrPcbByggnad.intInventeradGolvyta, dbo.tbTrPcbByggnad.bolSaneradeIsolerrutor,
  dbo.tbTrPcbByggnad.bolSaneradeKondensatorer, dbo.tbTrPcbByggnad.bolSaneradeGolvmassor,
  dbo.tbTrPcbByggnad.intAntalSaneradeRutor, dbo.tbTrPcbByggnad.intAntalSaneradeKondensatorer,
  dbo.tbTrPcbByggnad.intSaneradGolvyta, dbo.tbTrPcbByggnad.bolUtanfoer1956till1973,
  dbo.tbTrPcbByggnad.strByggnadsstatus
FROM dbo.tbTrPcbByggnad
INNER JOIN dbo.tbTrTillsynsobjekt
  ON dbo.tbTrPcbByggnad.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID
go

