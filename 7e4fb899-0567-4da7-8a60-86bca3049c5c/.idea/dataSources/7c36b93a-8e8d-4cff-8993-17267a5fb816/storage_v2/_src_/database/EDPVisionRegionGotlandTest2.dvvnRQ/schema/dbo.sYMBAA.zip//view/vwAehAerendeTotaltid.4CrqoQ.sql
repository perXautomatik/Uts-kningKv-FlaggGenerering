CREATE VIEW [dbo].[vwAehAerendeTotaltid] AS

WITH CTE AS (
SELECT recAerendeID, intMinuter
FROM tbVisTidpost
WHERE recAerendeID IS NOT NULL

UNION ALL

SELECT tbVisTidpost.recAerendeID, intMinuter
FROM tbVisTidpost
INNER JOIN tbAehAerendeHaendelse
	ON tbAehAerendeHaendelse.recHaendelseID = tbVisTidpost.recHaendelseID
INNER JOIN dbo.tbAehAerende
	ON tbAehAerende.recAerendeID = tbAehAerendeHaendelse.recAerendeID
WHERE tbVisTidpost.recAerendeID IS NULL
)

SELECT recAerendeID, CAST(SUM(intMinuter)/60 AS VARCHAR) + ':' + RIGHT('0' + CAST(SUM(intMinuter)%60 AS VARCHAR), 2) AS strSummaTidposter
FROM CTE
GROUP BY recAerendeID
go

