
CREATE VIEW [dbo].[vwVisEnstakaFastighet]
AS
WITH FastighetsAdress AS (
  SELECT recFastighetID, MIN(recEnstakaFastighetAdressID) AS ID
  FROM dbo.tbVisEnstakaFastighetAdress
  GROUP BY recFastighetID
)
SELECT 
	dbo.tbVisEnstakaFastighet.strFnrID, 
	dbo.tbVisEnstakaFastighet.strTrakt, 
	dbo.tbVisEnstakaFastighet.strBlock, 
	dbo.tbVisEnstakaFastighet.strTkn, 
	dbo.tbVisEnstakaFastighet.intEnhet, 
	dbo.tbVisEnstakaFastighet.recFastighetID, 
	dbo.tbVisEnstakaFastighet.strFastighetsbeteckning,
	dbo.tbVisEnstakaFastighet.recFastighetID AS intRecnum,
    dbo.tbVisEnstakaFastighet.guidUuid,
	
	dbo.tbVisKommun.strKommunNamn, 
	dbo.tbVisEnstakaFastighet.recKommunID,	
	
	dbo.tbVisEnstakaFastighetAdress.strAdress,
	dbo.tbVisEnstakaFastighetAdress.strPostnr,
	dbo.tbVisEnstakaFastighetAdress.strPostort
	
FROM dbo.tbVisEnstakaFastighet

LEFT OUTER JOIN dbo.tbVisKommun
	ON dbo.tbVisKommun.recKommunID = dbo.tbVisEnstakaFastighet.recKommunID
	
LEFT OUTER JOIN dbo.tbVisEnstakaFastighetAdress
	ON dbo.tbVisEnstakaFastighetAdress.recEnstakaFastighetAdressID = 
	(SELECT ID FROM FastighetsAdress WHERE recFastighetID = dbo.tbVisEnstakaFastighet.recFastighetID)

go

