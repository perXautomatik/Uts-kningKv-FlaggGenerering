

CREATE VIEW [dbo].[vwTrMtTaekt]
AS
SELECT		
	dbo.tbTrMtTaekt.recTaektID, 			
	dbo.tbTrMtTaekt.recTaektID AS intRecnum, 
	dbo.tbTrMtTaekt.bolTaektobjekt, 
	dbo.tbTrMtTaekt.intAreal, 
	dbo.tbTrMtTaekt.intTillstaandMaengd, 
	dbo.tbTrMtTaekt.intMaxAarligtUttag, 
	dbo.tbTrMtTaekt.datTillstaandTill, 
	dbo.tbTrMtTaekt.bitKrossverk, 
	dbo.tbTrMtTaekt.bitSorterverk,
	dbo.tbTrMtTaekt.recTillsynsobjektID,
	
	   (REPLACE( (SELECT strTyp + ', ' 
    FROM tbTrMtTaektTaektTyp
    WHERE tbTrMtTaektTaektTyp.recTaektID = tbTrMtTaekt.recTaektID
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS Täkttyp,
	
	CASE 
		WHEN (SELECT TOP(1) strHuvudflik FROM tbTrTillsynsobjektHuvudflik WHERE recTillsynsobjektID  = tbTrMtTaekt.recTillsynsobjektID ORDER BY recTillsynsobjektHuvudflikID ASC) = 'TrMtTäkt' THEN 
			CAST(1 as bit)
		ELSE 
			CAST(0 as bit)
	END AS bolHuvudflik
      
FROM dbo.tbTrMtTaekt



go

