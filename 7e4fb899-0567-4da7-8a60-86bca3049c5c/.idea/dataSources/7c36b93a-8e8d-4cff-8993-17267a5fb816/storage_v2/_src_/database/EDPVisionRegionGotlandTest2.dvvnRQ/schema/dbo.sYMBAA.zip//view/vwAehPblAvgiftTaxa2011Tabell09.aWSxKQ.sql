
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell09]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell09.recAehPblAvgiftTaxa2011Tabell09ID,
  dbo.tbAehPblAvgiftTaxa2011Tabell09.recAehPblAvgiftTaxa2011Tabell09ID AS intRecnum,
  dbo.tbAehPblAvgiftTaxa2011Tabell09.bolDebiterad,
  dbo.tbAehPblAvgiftTaxa2011Tabell09.decAvgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell09.intHF,
  dbo.tbAehPblAvgiftTaxa2011Tabell09.decmPBB,
  dbo.tbAehPblAvgiftTaxa2011Tabell09.decN,
  dbo.tbAehPblAvgiftTaxa2011Tabell09.recAvgiftID
FROM dbo.tbAehPblAvgiftTaxa2011Tabell09

go

