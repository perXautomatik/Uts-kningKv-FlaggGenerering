
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell11]
AS
SELECT     

recTabell11ID, 
recTaxa2011ID, 
recTabell11ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell11.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell11.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell11

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell11.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell11.recTjaenstID


go

