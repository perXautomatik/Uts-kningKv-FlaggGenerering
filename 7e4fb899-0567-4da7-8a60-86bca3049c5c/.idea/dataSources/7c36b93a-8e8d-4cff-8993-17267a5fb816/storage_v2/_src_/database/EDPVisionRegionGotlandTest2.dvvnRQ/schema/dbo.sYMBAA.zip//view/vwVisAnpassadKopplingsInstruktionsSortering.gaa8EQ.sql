

CREATE VIEW [dbo].[vwVisAnpassadKopplingsInstruktionsSortering]
AS
SELECT      recSorteringId AS intRecnum,     
            recSorteringId, 
            recAnpassadKopplingId, 
            strFaelt, 
            strVaerde,
			intOrdning
FROM        dbo.tbVisAnpassadKopplingsInstruktionsSortering


go

