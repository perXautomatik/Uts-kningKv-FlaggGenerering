

CREATE VIEW [dbo].[vwTrVpVaermepumpTillsatsaemne]
AS
SELECT

	dbo.tbVisCombo.strComboVaerde,
	dbo.tbTrVpVaermapumpTillsatsaemne.recVaermepumpID,
	dbo.tbTrVpVaermapumpTillsatsaemne.recVaermepumpTillsattsAemneID As intRecnum,
	dbo.tbTrVpVaermapumpTillsatsaemne.recComboID,
	dbo.tbTrVpVaermapumpTillsatsaemne.recVaermepumpTillsattsAemneID,
	dbo.tbTrVpVaermapumpTillsatsaemne.intProcentSats
FROM         dbo.tbTrVpVaermapumpTillsatsaemne


LEFT OUTER JOIN
dbo.tbVisCombo
ON dbo.tbTrVpVaermapumpTillsatsaemne.recComboID = dbo.tbVisCombo.recComboID



go

