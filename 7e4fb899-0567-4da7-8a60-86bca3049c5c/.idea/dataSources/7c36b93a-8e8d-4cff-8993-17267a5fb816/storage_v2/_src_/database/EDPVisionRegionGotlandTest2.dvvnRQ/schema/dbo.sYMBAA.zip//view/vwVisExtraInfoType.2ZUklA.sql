CREATE VIEW [dbo].[vwVisExtraInfoType]
AS
SELECT dbo.tbVisExtraInfoType.recExtraInfoTypeID, dbo.tbVisExtraInfoType.recExtraInfoTypeFormatID,
  dbo.tbVisExtraInfoType.strTypeName, dbo.tbVisExtraInfoType.bolAllowMultiple,
  dbo.tbVisExtraInfoType.intMaxlength, dbo.tbVisExtraInfoType.intMinlength,
  dbo.tbVisExtraInfoType.intIntegercount, dbo.tbVisExtraInfoType.intDecimalcount,
  dbo.tbVisExtraInfoType.bolAutomaticLookUpValidation, dbo.tbVisExtraInfoTypeFormat.strExtraInfoTypeFormat,
  dbo.tbVisExtraInfoType.recExtraInfoTypeID AS intRecnum, dbo.tbVisExtraInfoType.bolEjAktuell
FROM dbo.tbVisExtraInfoType
LEFT OUTER JOIN dbo.tbVisExtraInfoTypeFormat
ON dbo.tbVisExtraInfoType.recExtraInfoTypeFormatID = dbo.tbVisExtraInfoTypeFormat.recExtraInfoTypeFormatID
go

