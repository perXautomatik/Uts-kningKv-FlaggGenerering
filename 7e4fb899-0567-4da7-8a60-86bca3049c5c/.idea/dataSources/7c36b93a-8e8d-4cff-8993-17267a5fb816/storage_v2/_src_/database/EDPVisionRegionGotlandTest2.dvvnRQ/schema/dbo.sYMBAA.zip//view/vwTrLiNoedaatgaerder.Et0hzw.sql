


CREATE VIEW [dbo].[vwTrLiNoedaatgaerder]
AS
SELECT recNoedaatgaerderID, 
			recNoedaatgaerderID as intRecnum,
			tbTrLiNoedaatgaerder.strRapporteringsID, 
			datDatum, 
			intAntalBeroerda, 
			intAntalDygn, 
			strAatgaerd, 
			strOrsak, 
			strAnledning,
			strAnledningOmraade,
			strOevrigt,
			dbo.tbTrLiNoedaatgaerder.recLivsmedelID,
			dbo.tbTrTillsynsobjekt.recTillsynsobjektID,
			dbo.tbTrTillsynsobjekt.strObjektsNamn,
			dbo.tbTrVerksamhet.strVerksamhetNamn
FROM  dbo.tbTrLiNoedaatgaerder
LEFT OUTER JOIN dbo.tbTrLiLivsmedel
  ON dbo.tbTrLiLivsmedel.recLivsmedelID = dbo.tbTrLiNoedAatgaerder.recLivsmedelID
LEFT OUTER JOIN dbo.tbTrTillsynsobjekt
  ON dbo.tbTrLiLivsmedel.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID
LEFT OUTER JOIN dbo.tbTrVerksamhet
  ON dbo.tbTrVerksamhet.recVerksamhetID = dbo.tbTrTillsynsobjekt.recVerksamhetID


go

