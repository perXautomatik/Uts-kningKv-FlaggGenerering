

CREATE VIEW [dbo].[vwVisKommun]
AS
SELECT		dbo.tbVisKommun.recKommunID,
			dbo.tbVisKommun.recKommunID AS intRecnum,
			dbo.tbVisKommun.recLaenID,
			dbo.tbVisKommun.strKommunNamn,
			dbo.tbVisKommun.strKommunKod,
			dbo.tbVisKommun.bolEjAktuell,
			dbo.tbVisLaen.strLaensNamn,
			dbo.tbVisLaen.strLaensKod,
			dbo.tbVisLaen.strLaensBokstav
FROM		dbo.tbVisKommun
LEFT OUTER JOIN
			dbo.tbVisLaen ON dbo.tbVisKommun.recLaenID = dbo.tbVisLaen.recLaenID
go

