CREATE VIEW [dbo].[vwMmUndersoekning]
AS
SELECT     dbo.tbMmUndersoekning.recUndersoekningID, dbo.tbMmUndersoekning.recFasID, dbo.tbMmUndersoekning.intUndersoekningsNr,
                      dbo.tbMmUndersoekning.strDiarienummer, dbo.tbMmUndersoekning.strRegkod, dbo.tbMmUndersoekning.strUndersoekningsNamn,
                      dbo.tbMmUndersoekning.datUndersoekningsDatum, dbo.tbMmUndersoekning.strUndersoekningsId, dbo.tbMmUndersoekning.strFoerfattare,
                      dbo.tbMmUndersoekning.strUndersoekningstyp, dbo.tbMmUndersoekning.strBestaellare, dbo.tbMmUndersoekning.strArkivplats,
                      dbo.tbMmUndersoekning.strSammanfattning, dbo.tbMmFas.intOrdningsNr, dbo.tbMmFas.strFasNamn,
                      dbo.tbMmUndersoekning.strRegkod + '-' + LTRIM(STR(dbo.tbMmUndersoekning.intUndersoekningsNr)) AS strUndersoekningsKod,
                      dbo.tbMmUndersoekning.recUndersoekningID AS intRecnum
FROM         dbo.tbMmUndersoekning LEFT OUTER JOIN
                      dbo.tbMmFas ON dbo.tbMmUndersoekning.recFasID = dbo.tbMmFas.recFasID
go

