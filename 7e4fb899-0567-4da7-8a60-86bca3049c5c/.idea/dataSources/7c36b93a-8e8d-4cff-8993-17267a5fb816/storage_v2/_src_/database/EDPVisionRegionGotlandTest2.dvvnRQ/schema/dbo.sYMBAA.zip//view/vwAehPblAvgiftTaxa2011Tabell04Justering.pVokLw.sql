
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell04Justering]
AS
SELECT     recPblAvgiftTaxa2011Tabell04ID, recPblAvgiftTaxa2011Tabell04JusteringID as 'intRecnum', recPblAvgiftTaxa2011Tabell04JusteringID, strAatgaerd,
			strBeskrivning,decOF, decHF1
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell04Justering
go

