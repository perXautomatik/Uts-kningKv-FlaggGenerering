
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
Create PROCEDURE [dbo].[spEDPGetSubParameters]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
SELECT     intSubParameterID, strSubParameterName, strSubParameterDescription, intSubParameterSearchMethodID, strSubParameterValueLookUpID, 
                      intSubParameterValueTypeID, intSubParameterValueLength
FROM         tbEDPSubParameter

END

go

