

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
create PROCEDURE [dbo].[spEDPDeleteParameterbyParameterID]
	-- Add the parameters for the stored procedure here
  @intParameterID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
DELETE FROM tbEDPParameter 
WHERE intParameterID = @intParameterID

END

go

