
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell23]
AS
SELECT 
	dbo.tbAehPblAvgiftTaxa2011Tabell23.recPblAvgiftTaxa2011Tabell23ID, 
	dbo.tbAehPblAvgiftTaxa2011Tabell23.recPblAvgiftTaxa2011Tabell23ID AS intRecnum,
	dbo.tbAehPblAvgiftTaxa2011Tabell23.decAvgift, 
	dbo.tbAehPblAvgiftTaxa2011Tabell23.intNKF, 
	dbo.tbAehPblAvgiftTaxa2011Tabell23.decmPBB, 
	dbo.tbAehPblAvgiftTaxa2011Tabell23.decN, 
	dbo.tbAehPblAvgiftTaxa2011Tabell23.recAvgiftID,
	dbo.tbAehPblAvgiftTaxa2011Tabell23.bolDebiterad
FROM dbo.tbAehPblAvgiftTaxa2011Tabell23

go

