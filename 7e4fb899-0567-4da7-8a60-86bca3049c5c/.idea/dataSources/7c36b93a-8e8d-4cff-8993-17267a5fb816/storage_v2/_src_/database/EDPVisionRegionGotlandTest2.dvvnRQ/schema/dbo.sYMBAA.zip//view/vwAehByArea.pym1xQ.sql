

CREATE VIEW [dbo].[vwAehByArea]
AS
SELECT recAreaID, 
  recAreaID AS intRecNum,
  decArea, 
  strAreatyp, 
  strByggnadAnlaeggning, 
  recByggAerendeID,
  recPlanAerendeID
FROM tbAehByArea

go

