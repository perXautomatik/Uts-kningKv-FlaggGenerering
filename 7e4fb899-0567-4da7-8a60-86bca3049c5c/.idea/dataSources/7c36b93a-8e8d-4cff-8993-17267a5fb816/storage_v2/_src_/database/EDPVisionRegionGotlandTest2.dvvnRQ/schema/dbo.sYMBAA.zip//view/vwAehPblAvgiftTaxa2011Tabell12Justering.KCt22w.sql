

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell12Justering]
AS
SELECT     recPblAvgiftTaxa2011Tabell12JusteringID,
		   recPblAvgiftTaxa2011Tabell12JusteringID as 'intRecnum',
		   recPblAvgiftTaxa2011Tabell12ID,
		   strAatgaerd,
		   strBeskrivning,
		   decOF,
		   decHF1,
		   decHF2
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell12Justering
go

