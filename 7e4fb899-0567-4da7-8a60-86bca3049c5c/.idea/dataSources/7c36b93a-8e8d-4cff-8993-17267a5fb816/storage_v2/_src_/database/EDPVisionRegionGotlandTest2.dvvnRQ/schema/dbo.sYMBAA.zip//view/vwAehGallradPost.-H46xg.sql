CREATE VIEW [dbo].[vwAehGallradPost]
AS
SELECT     recGallradPostID,recGallradPostID as intRecnum, recGallringID, intPostID, strUfic, strGallringsSaett, strTabellNamn
FROM         dbo.tbAehGallradPost
go

