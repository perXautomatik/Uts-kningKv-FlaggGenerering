

CREATE VIEW [dbo].[vwVisFakturaText]
AS

SELECT  recFakturatextID,
		recFakturatextID AS intRecnum,
		strFakturatextkod,
		strFoerklaring,
		strFakturatext,
		bolEjAktuell,
		bolStandard
FROM	dbo.tbVisFakturatext
go

