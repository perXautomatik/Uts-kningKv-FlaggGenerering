
CREATE VIEW [dbo].[vwVisMallKontaktGrid]

As
WITH kommunikationSaett AS (
    SELECT recMallKontaktID, strKommunikationsaettTyp + ' - ' + strVaerde AS kommunikationssaett
    FROM tbVisMallKontaktKommunikationssaett
	LEFT OUTER JOIN tbVisKommunikationssaett
	  ON tbVisMallKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
)
,
kommunikationsSaettSammanslagen AS (SELECT recMallKontaktID, 
 (SELECT kommunikationssaett + ', '
  FROM kommunikationSaett
  WHERE kommunikationSaett.recMallKontaktID = tbVisMallKontaktKommunikationssaett.recMallKontaktID
  FOR XML PATH('')) AS strKommunikationssaett 
FROM tbVisMallKontaktKommunikationssaett
GROUP BY recMallKontaktID
)

SELECT tbVisMallKontakt.recMallKontaktID, strVisasSom, strPostnummer, strGatuadress, strCoadress, strPostort, 
  strOrginisationPersonnummer, strSammanslagenAdress, recAdressbokID, tbVisMallKontakt.recMallKontaktID AS intRecnum,
  LEFT(strKommunikationssaett, LEN(strKommunikationssaett) - 1) AS strKommunikationssaett
FROM tbVisMallKontakt 
LEFT OUTER JOIN kommunikationsSaettSammanslagen 
  ON tbVisMallKontakt.recMallKontaktID = kommunikationsSaettSammanslagen.recMallKontaktID

go

