CREATE VIEW dbo.vwMmTillsats
AS
SELECT     dbo.tbMmTillsats.recTillsatsID, dbo.tbMmTillsats.strTillsatsNamn, dbo.tbMmTillsats.decMaengd, dbo.tbMmTillsats.strEnhetMaengd,
                      dbo.tbMmTillsats.decKoncentration, dbo.tbMmTillsats.strEnhetKoncentration, dbo.tbMmSanering.strProjektNamn,
                      dbo.tbMmTillsats.recTillsatsID AS intRecnum, dbo.tbMmTillsats.recInSituOnSiteID, dbo.tbMmInSituOnSite.strInSituOnSiteNamn,
                      dbo.vwMmOmraade.strOmrNamn, dbo.tbMmSanering.strProjektID, dbo.vwMmOmraade.strOmraadeKod, dbo.tbMmSanering.recOmrID,
                      dbo.tbMmInSituOnSite.recSaneringID
FROM         dbo.tbMmTillsats LEFT OUTER JOIN
                      dbo.tbMmInSituOnSite INNER JOIN
                      dbo.tbMmSanering ON dbo.tbMmInSituOnSite.recSaneringID = dbo.tbMmSanering.recSaneringID INNER JOIN
                      dbo.vwMmOmraade ON dbo.tbMmSanering.recOmrID = dbo.vwMmOmraade.recOmrID ON
                      dbo.tbMmTillsats.recInSituOnSiteID = dbo.tbMmInSituOnSite.recInSituOnSiteID
go

