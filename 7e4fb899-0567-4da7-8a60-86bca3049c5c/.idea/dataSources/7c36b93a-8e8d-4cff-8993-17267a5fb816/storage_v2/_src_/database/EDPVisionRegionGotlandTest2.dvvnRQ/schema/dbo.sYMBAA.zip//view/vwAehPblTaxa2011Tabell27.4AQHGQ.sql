
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell27]
AS
SELECT     

recTabell27ID, 
recTaxa2011ID, 
recTabell27ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell27.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell27.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell27

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell27.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell27.recTjaenstID


go

