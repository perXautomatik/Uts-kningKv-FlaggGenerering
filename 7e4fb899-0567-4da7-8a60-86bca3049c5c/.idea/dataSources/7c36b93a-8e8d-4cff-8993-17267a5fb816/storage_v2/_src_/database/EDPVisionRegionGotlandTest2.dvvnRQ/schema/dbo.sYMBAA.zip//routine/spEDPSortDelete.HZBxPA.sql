

CREATE PROCEDURE dbo.spEDPSortDelete
		@strFormName varchar(100)
AS

DELETE FROM tbEDPSortControlColumn
WHERE     (strFormName = @strFormName)

DELETE FROM tbEDPSortColumn WHERE intColumnID NOT IN (SELECT intColumnID FROM tbEDPSortOrderSortColumn)

RETURN


go

