CREATE VIEW [dbo].[vwAehHaendelseStatusLog]
AS
SELECT     dbo.tbAehHaendelseStatusLog.recHaendelseStatusLogID, dbo.tbAehHaendelseStatusLog.recHaendelseStatusLogTypID, 
                      dbo.tbAehHaendelseStatusLog.recHaendelseID, dbo.tbAehHaendelseStatusLog.intUserID, dbo.tbAehHaendelseStatusLog.datDatum, 
                      dbo.tbAehHaendelseStatusLogTyp.strHaendelseStatusLogTyp, dbo.tbAehHaendelseStatusLogTyp.strLocalizationCode, dbo.tbEDPUser.strSignature, 
                      dbo.tbAehHaendelseStatusLog.recHaendelseStatusLogID AS intRecnum, dbo.tbAehHaendelseStatusLogTyp.strHaendelseStatusPresent, 
                      dbo.tbAehHaendelseStatusLog.strKommentar
FROM         dbo.tbAehHaendelseStatusLog INNER JOIN
                      dbo.tbAehHaendelseStatusLogTyp ON 
                      dbo.tbAehHaendelseStatusLog.recHaendelseStatusLogTypID = dbo.tbAehHaendelseStatusLogTyp.recHaendelseStatusLogTypID INNER JOIN
                      dbo.tbEDPUser ON dbo.tbAehHaendelseStatusLog.intUserID = dbo.tbEDPUser.intUserID

go

