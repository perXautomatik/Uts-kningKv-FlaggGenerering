
CREATE VIEW [dbo].[vwTrSkSkyddsrumPaaObjekt]
AS
SELECT     dbo.tbTrSkSkyddsrumPaaObjekt.recSkyddsrumPaaObjektID,
           dbo.tbTrSkSkyddsrumPaaObjekt.recSkyddsrumPaaObjektID AS intRecNum, 
		   dbo.tbTrSkSkyddsrumPaaObjekt.recTillsynsobjektID, 
           dbo.tbTrSkSkyddsrumPaaObjekt.strSkyddsrumsnummer, 
           dbo.tbTrSkSkyddsrumPaaObjekt.strLokalID, 
           dbo.tbTrSkSkyddsrumPaaObjekt.strHemskyddsomraade, 
           dbo.tbTrSkSkyddsrumPaaObjekt.strNyckelkod, 
           dbo.tbTrSkSkyddsrumPaaObjekt.strFoersamlingskod, 
           dbo.tbTrSkSkyddsrumPaaObjekt.strBestaemmelse, 
           dbo.tbTrSkSkyddsrumPaaObjekt.strLuftrenaretyp, 
           dbo.tbTrSkSkyddsrumPaaObjekt.intBruksarea, 
           dbo.tbTrSkSkyddsrumPaaObjekt.intNettoarea, 
           dbo.tbTrSkSkyddsrumPaaObjekt.intPlatsantal, 
           dbo.tbTrSkSkyddsrumPaaObjekt.strKartnummer, 
           dbo.tbTrSkSkyddsrumPaaObjekt.intHoejdOeverUnder, 
           dbo.tbTrSkSkyddsrumPaaObjekt.intFilter, 
           dbo.tbTrSkSkyddsrumPaaObjekt.strSkyddsnivaa, 
           dbo.tbTrSkSkyddsrumPaaObjekt.intAntalvaaningar, 
           dbo.tbTrSkSkyddsrumPaaObjekt.intAntaldoerrar, 
           dbo.tbTrSkSkyddsrumPaaObjekt.intAntaloeppningar, 
           dbo.tbTrSkSkyddsrumPaaObjekt.datBygglovsdatum, 
           dbo.tbTrSkSkyddsrumPaaObjekt.datAvregistreringsdatum, 
           dbo.tbTrSkSkyddsrumPaaObjekt.datGodkännandedatum, 
           dbo.tbTrSkSkyddsrumPaaObjekt.strAnteckning, 
           dbo.tbTrSkSkyddsrumPaaObjekt.intBesiktningsintervall, 
           dbo.tbTrSkSkyddsrumPaaObjekt.datFoeregaaendebesiktning, 
           dbo.tbTrSkSkyddsrumPaaObjekt.datOmbesiktning, 
           dbo.tbTrSkSkyddsrumPaaObjekt.datNaestabesiktning, 
           dbo.tbTrSkSkyddsrumPaaObjekt.strBesiktninggodkaend, 
           dbo.tbTrSkSkyddsrumPaaObjekt.recSakkunnigID, 
           dbo.tbVisDeladFastighet.strFnrID, 
           dbo.tbVisDeladFastighet.strFastighetsbeteckning, 
           dbo.tbTrTillsynsobjekt.strObjektsNamn, 
           dbo.tbVisEnstakaKontakt.strVisasSom as strSakkunnigVisasSom
FROM         dbo.tbTrSkSkyddsrumPaaObjekt 
			LEFT OUTER JOIN	 dbo.tbTrSkSkyddsrumPaaObjektFastighet 
			ON dbo.tbTrSkSkyddsrumPaaObjekt.recSkyddsrumPaaObjektID = dbo.tbTrSkSkyddsrumPaaObjektFastighet.recSkyddsrumPaaObjektID 
			AND	tbTrSkSkyddsrumPaaObjektFastighet.bolHuvudfastighet = 1
            LEFT OUTER JOIN	 dbo.tbVisDeladFastighet 
            ON dbo.tbTrSkSkyddsrumPaaObjektFastighet.strFnrID = dbo.tbVisDeladFastighet.strFnrID 
            LEFT OUTER JOIN	 dbo.tbTrTillsynsobjekt 
            ON dbo.tbTrSkSkyddsrumPaaObjekt.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID 
            LEFT OUTER JOIN	 dbo.tbTrSakkunnig 
            ON dbo.tbTrSkSkyddsrumPaaObjekt.recSakkunnigID = dbo.tbTrSakkunnig.recSakkunnigID 
            LEFT OUTER JOIN	 dbo.tbVisEnstakaKontakt 
            ON dbo.tbTrSakkunnig.recEnstakaKontaktID = dbo.tbVisEnstakaKontakt.recEnstakaKontaktID
go

