
        CREATE TRIGGER TRG_tbAehAerendeUser_INSERT_UPDATE_DELETE ON tbAehAerendeUser
        AFTER INSERT, UPDATE, DELETE
        AS
        BEGIN
        SET NOCOUNT ON;

        --- Det är bara om ändringen berör en huvudhandläggare som vi behöver uppdatera ärendet
        DECLARE aerende_user_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recAerendeID FROM INSERTED WHERE bolHuvudhandlaeggare = 1 UNION SELECT recAerendeID FROM DELETED WHERE bolHuvudhandlaeggare = 1
        OPEN aerende_user_cursor
        DECLARE @recAerendeID INT
        FETCH NEXT FROM aerende_user_cursor INTO @recAerendeID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehAerendeDataUpdateHuvudhandlaeggare @recAerendeID

            FETCH NEXT FROM aerende_user_cursor INTO @recAerendeID
        END
        CLOSE aerende_user_cursor
        DEALLOCATE aerende_user_cursor
        END
        go

