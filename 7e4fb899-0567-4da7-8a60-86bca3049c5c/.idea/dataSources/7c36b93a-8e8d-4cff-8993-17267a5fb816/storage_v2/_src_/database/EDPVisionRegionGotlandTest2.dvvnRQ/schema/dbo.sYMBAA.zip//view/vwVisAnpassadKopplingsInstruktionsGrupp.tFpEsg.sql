
CREATE VIEW [dbo].[vwVisAnpassadKopplingsInstruktionsGrupp]
AS
SELECT      recAnpassadKopplingId AS intRecnum,      
            recAnpassadKopplingId,
            strNamn,
            strKategori,
            strGrupp,
            strFoerkortning,
            strBeskrivning,
            bolStandardMallkategori
FROM        dbo.tbVisAnpassadKopplingsInstruktionsGrupp



go

