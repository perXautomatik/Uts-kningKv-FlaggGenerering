

CREATE VIEW [dbo].[vwAehComprimaArkiveraIndex]
AS
SELECT 
	  recIndexID
	, recIndexID As intRecNum
	, decIndex
	, strNamn
	, strKoppling
	, decKolumnBredd
	, recInstaellningID
FROM tbAehComprimaArkiveraIndex
go

