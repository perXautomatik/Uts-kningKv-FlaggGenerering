
CREATE VIEW [dbo].[vwVisExternTjaenst]
AS
SELECT
			recExternTjaenstID AS intRecnum,
			recExternTjaenstID, 
			strExternTjaenst,
			strETjaenstNamn,
			xmlExterntID
FROM
			dbo.tbVisExternTjaenst

go

