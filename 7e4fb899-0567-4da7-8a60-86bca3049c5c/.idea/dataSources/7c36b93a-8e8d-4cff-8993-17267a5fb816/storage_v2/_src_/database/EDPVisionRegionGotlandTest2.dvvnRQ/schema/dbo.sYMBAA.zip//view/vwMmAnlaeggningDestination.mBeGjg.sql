CREATE VIEW dbo.vwMmAnlaeggningDestination
AS
SELECT     ROW_NUMBER() OVER (ORDER BY strType, strNamn) AS intRecnum, strNamn, strType, strAdress, strOrt
FROM         (SELECT     strAnlaeggningNamn AS strNamn, 'Anläggning' AS strType, strAdress, strOrt
                       FROM          dbo.tbMmAnlaeggning
                       UNION ALL
                       SELECT     strDestinationNamn AS strNamn, 'Annan destination' AS strType, '' AS strAdress, '' AS strOrt
                       FROM         dbo.tbMmDestination) AS tbltemp
go

