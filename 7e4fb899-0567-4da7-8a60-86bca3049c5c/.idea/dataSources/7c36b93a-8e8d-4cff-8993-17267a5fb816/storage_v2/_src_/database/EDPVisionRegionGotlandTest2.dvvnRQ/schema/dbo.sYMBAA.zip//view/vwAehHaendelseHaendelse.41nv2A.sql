
CREATE VIEW vwAehHaendelseHaendelse AS
WITH Relation AS(
    SELECT
        recHaendelseID AS recHaendelseID,
        recKoppladHaendelseID AS recKoppladHaendelseID,
        recKoppladHaendelseID AS intRecnum
    FROM tbAehHaendelseHaendelse
    UNION
    SELECT
        reckoppladhaendelseid AS recHaendelseID,
        recHaendelseID AS recKoppladHaendelseID,
        recHaendelseID AS intRecnum
    FROM tbAehHaendelseHaendelse
)
SELECT
    Relation.*,
    vwAehHaendelse.strRubrik,
    vwAehHaendelse.strDiarienummer,
    vwAehHaendelse.strHaendelseKategoriKod,
    vwAehHaendelse.strHaendelseKategori,
    vwAehHaendelse.strHaendelseStatusLocalizationCode,
    vwAehHaendelse.strHaendelseStatusLogTyp,
    vwAehHaendelse.strAerendemening,
    vwAehHaendelse.strFastighetsbeteckning AS 'strHaendelseFastighetsbeteckning',
    vwAehHaendelse.datHaendelseDatum,
    vwAehHaendelse.strAerendeStatusPresent,
    vwAehHaendelse.strAvdelningNamn,
    vwAehHaendelse.strAvdelningKod,
    vwAehHaendelse.strRiktning,
    vwAehAerende.strFastighetsbeteckning AS 'strAerendeFastighetsbeteckning'
FROM Relation
INNER JOIN
    vwAehHaendelse ON Relation.intRecnum = vwAehHaendelse.recHaendelseID
INNER JOIN
    vwAehAerende ON vwAehHaendelse.recAerendeID = vwAehAerende.recAerendeID
go

