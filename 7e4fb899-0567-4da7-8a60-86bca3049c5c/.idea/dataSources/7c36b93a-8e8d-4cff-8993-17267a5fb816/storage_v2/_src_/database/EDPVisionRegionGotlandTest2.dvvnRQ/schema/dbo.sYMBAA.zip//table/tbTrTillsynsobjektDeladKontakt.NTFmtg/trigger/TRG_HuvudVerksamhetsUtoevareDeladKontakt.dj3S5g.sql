CREATE TRIGGER [dbo].[TRG_HuvudVerksamhetsUtoevareDeladKontakt] ON [dbo].[tbTrTillsynsobjektDeladKontakt]
                                                            AFTER INSERT, UPDATE
                                                            AS
                                                            BEGIN
			                                                    SET NOCOUNT ON;
			                                                    DECLARE @recTillsynsobjektID INT
			                                                    DECLARE @recTillsynsobjektDeladKontaktID INT

			                                                    DECLARE @bolHuvudkontaktperson BIT	
			                                                    DECLARE @bolHuvudverksamhetsutoevare BIT
		                                                    
			                                                    SELECT @recTillsynsobjektID	= recTillsynsobjektID FROM INSERTED
			                                                    SELECT @recTillsynsobjektDeladKontaktID = recTillsynsobjektDeladKontaktID FROM INSERTED

			                                                    SELECT @bolHuvudkontaktperson = bolHuvudkontaktperson FROM INSERTED
			                                                    SELECT @bolHuvudverksamhetsutoevare = bolHuvudverksamhetsutoevare FROM INSERTED

			                                                    IF (UPDATE(bolHuvudkontaktperson) AND @bolHuvudkontaktperson = 1)
			                                                    BEGIN
				                                                    UPDATE tbTrTillsynsobjektDeladKontakt
				                                                    SET	bolHuvudkontaktperson = 0
				                                                    WHERE recTillsynsobjektID = @recTillsynsobjektID 
					                                                    AND bolHuvudkontaktperson = 1 
					                                                    AND recTillsynsobjektDeladKontaktID <> @recTillsynsobjektDeladKontaktID	
			                                                    END

			                                                    IF (UPDATE(bolHuvudverksamhetsutoevare) AND @bolHuvudverksamhetsutoevare = 1)
			                                                    BEGIN
				                                                    UPDATE tbTrTillsynsobjektDeladKontakt
				                                                    SET	bolHuvudverksamhetsutoevare = 0
				                                                    WHERE recTillsynsobjektID = @recTillsynsobjektID 
					                                                    AND bolHuvudverksamhetsutoevare = 1 
					                                                    AND recTillsynsobjektDeladKontaktID <> @recTillsynsobjektDeladKontaktID	
			                                                    END
                                                            END
go

