CREATE VIEW [dbo].[vwEDPMailTemplate]
AS
SELECT     dbo.tbEDPFileObject.strDescription, dbo.tbEDPFileObject.strFileName, dbo.tbEDPMailFormat.strFormat, dbo.tbEDPMailPriority.strPriority, 
                      dbo.tbEDPMailTemplate.strMailTemplateName, dbo.tbEDPMailTemplate.strTo, dbo.tbEDPMailTemplate.strCopyTo, 
                      dbo.tbEDPMailTemplate.strSecretCopyTo, dbo.tbEDPMailTemplate.strAttachement, dbo.tbEDPMailTemplate.strFrom, 
                      dbo.tbEDPMailTemplate.strReplyTo, dbo.tbEDPMailTemplate.bDeliverReceipt, dbo.tbEDPMailTemplate.strSubject, 
                      dbo.tbEDPMailTemplate.bReadReceipt, dbo.tbEDPMailTemplate.strCategory, dbo.tbEDPMailTemplate.recFileObjectID, 
                      dbo.tbEDPMailTemplate.recMailTemplateID, dbo.tbEDPMailTemplate.recMailTemplateID AS intRecNum, dbo.tbEDPMailTemplate.bolDefault, 
                      dbo.tbEDPMailTemplate.recFormatID, dbo.tbEDPMailTemplate.recPriorityID, dbo.tbEDPMailTemplate.bolLagraInEpost,
					  dbo.tbEDPMailTemplate.bolKonverteraTillPDF_A, dbo.tbEDPMailTemplate.strHandlingstyp, dbo.tbEDPMailTemplate.strFilnamnsmall
FROM         dbo.tbEDPMailTemplate INNER JOIN
                      dbo.tbEDPFileObject ON dbo.tbEDPMailTemplate.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID INNER JOIN
                      dbo.tbEDPMailFormat ON dbo.tbEDPMailTemplate.recFormatID = dbo.tbEDPMailFormat.recFormatID INNER JOIN
                      dbo.tbEDPMailPriority ON dbo.tbEDPMailTemplate.recPriorityID = dbo.tbEDPMailPriority.recPriorityID
go

