CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell04HF1]
AS         
SELECT     recPblAvgiftTaxa2011Tabell04ID, recPblAvgiftTaxa2011Tabell04HF1ID as 'intRecnum', recPblAvgiftTaxa2011Tabell04HF1ID,strAatgaerd,
			strBeskrivning,intHF1
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell04HF1
go

