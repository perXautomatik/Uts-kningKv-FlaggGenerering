CREATE VIEW dbo.vwMmExSitu
AS
SELECT     dbo.tbMmExSitu.recExSituID, dbo.tbMmExSitu.recSaneringID, dbo.tbMmExSitu.strMaterial, dbo.tbMmExSitu.bolVatten, dbo.tbMmExSitu.strMetodtyp,
                      dbo.tbMmExSitu.strMetodnamn, dbo.tbMmExSitu.strDestination, dbo.tbMmExSitu.strDestinationstyp, dbo.tbMmExSitu.strAatgaerdstyp,
                      dbo.tbMmSanering.strProjektNamn, dbo.tbMmSanering.strProjektID, dbo.tbMmExSitu.recExSituID AS intRecnum, dbo.vwMmOmraade.strOmraadeKod,
                      dbo.vwMmOmraade.strOmrNamn, dbo.tbMmExSitu.strAvfallskod, dbo.tbMmExSitu.strBeskrivning, dbo.tbMmSanering.recOmrID,
                      dbo.tbMmExSitu.decVikt, dbo.tbMmExSitu.decVolym
FROM         dbo.tbMmSanering INNER JOIN
                      dbo.vwMmOmraade ON dbo.tbMmSanering.recOmrID = dbo.vwMmOmraade.recOmrID RIGHT OUTER JOIN
                      dbo.tbMmExSitu ON dbo.tbMmSanering.recSaneringID = dbo.tbMmExSitu.recSaneringID
go

