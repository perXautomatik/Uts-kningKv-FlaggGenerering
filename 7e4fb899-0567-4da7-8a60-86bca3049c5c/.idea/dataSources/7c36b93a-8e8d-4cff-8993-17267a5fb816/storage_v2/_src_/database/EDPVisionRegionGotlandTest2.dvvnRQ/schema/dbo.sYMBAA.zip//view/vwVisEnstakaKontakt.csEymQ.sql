
  CREATE VIEW [dbo].[vwVisEnstakaKontakt]
AS

WITH KontaktKommunikationssaett AS (
SELECT recEnstakaKontaktID , 
   
    (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Telefon' AND recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
       WHERE  dbo.tbVisEnstakaKontakt.recEnstakaKontaktID = dbo.tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strTelefon,

    (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Mobil' AND recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
       WHERE  dbo.tbVisEnstakaKontakt.recEnstakaKontaktID = dbo.tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strMobil	,

    (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Fax' AND recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
       WHERE  dbo.tbVisEnstakaKontakt.recEnstakaKontaktID = dbo.tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strFax,	

    (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'E-post' AND recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
       WHERE  dbo.tbVisEnstakaKontakt.recEnstakaKontaktID = dbo.tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strEpost	


FROM tbVisEnstakaKontakt
)



SELECT  tbVisEnstakaKontakt.recEnstakaKontaktID , 
		tbVisEnstakaKontakt.recEnstakaKontaktID as intrecnum,  
		strFoernamn , 
		strEfternamn, 
		strFoeretag, 
		strOrginisationPersonnummer, 
		strTitel, 
		strKontaktTyp , 
		strGatuadress, 
		strCoadress, 
		strPostnummer, 
		strPostort, 
		strLand, 
		strVisasSom, 
		strSammanslagenAdress,
		KontaktKommunikationssaett.strTelefon,
		KontaktKommunikationssaett.strMobil,
		KontaktKommunikationssaett.strFax,
		KontaktKommunikationssaett.strEpost

FROM            dbo.tbVisEnstakaKontakt

LEFT OUTER JOIN KontaktKommunikationssaett
  ON KontaktKommunikationssaett.recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID
  go

