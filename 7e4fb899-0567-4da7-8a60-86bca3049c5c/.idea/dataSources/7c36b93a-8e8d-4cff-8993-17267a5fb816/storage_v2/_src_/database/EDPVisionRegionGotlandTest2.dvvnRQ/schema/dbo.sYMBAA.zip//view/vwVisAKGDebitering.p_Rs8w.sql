 CREATE VIEW [dbo].[vwVisAKGDebitering]
                AS
                SELECT
                  decAntal,
                  recDebiteringID,
                  intFakturaNr,
                  strGenereradFakturatext,
                  strFoerklaring,
                  strFakturatextkod,
                  strFritext,
                  strKontoStraeng,
                  decMomsKr,
                  decMomsProcent,
                  decPris,
                  decRabattProcent,
                  decSumma,
                  strTjaenstKod,
                  strTjaenst,
                  decTotal,
                  datUtfoerandeFraan,
                  datUtfoerandeTill
                FROM   dbo.vwVisDebitering
 go

