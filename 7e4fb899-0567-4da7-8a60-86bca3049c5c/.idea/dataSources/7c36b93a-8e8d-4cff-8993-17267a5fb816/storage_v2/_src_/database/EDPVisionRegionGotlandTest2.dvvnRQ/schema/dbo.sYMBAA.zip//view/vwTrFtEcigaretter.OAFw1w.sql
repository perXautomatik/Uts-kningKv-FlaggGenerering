

CREATE VIEW [dbo].[vwTrFtEcigaretter]
AS
SELECT
  recEcigaretterID,
  recEcigaretterID AS intRecnum,
  recTillsynsobjektID,
  bolEcigarettobjekt,
  datAnmaelningsdatum,
  datFoersaeljningsstart,
  datFoersaeljningUpphoert,
  CASE 
				WHEN (SELECT TOP(1) strHuvudflik FROM tbTrTillsynsobjektHuvudflik 
						WHERE recTillsynsobjektID  = dbo.tbTrFtEcigaretter.recTillsynsobjektID 
						ORDER BY recTillsynsobjektHuvudflikID ASC) = 'TREcigarett' THEN 
					CAST(1 as bit)
				ELSE 
					CAST(0 as bit)
			END AS bolHuvudflik			
FROM [dbo].[tbTrFtEcigaretter]
go

