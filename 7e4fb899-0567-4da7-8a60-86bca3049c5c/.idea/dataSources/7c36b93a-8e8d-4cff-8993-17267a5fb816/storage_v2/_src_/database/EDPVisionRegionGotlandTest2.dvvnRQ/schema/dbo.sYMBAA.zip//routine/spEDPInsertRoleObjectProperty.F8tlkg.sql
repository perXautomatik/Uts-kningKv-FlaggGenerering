CREATE PROCEDURE [dbo].[spEDPInsertRoleObjectProperty] 
  (
  @strObjectName NVARCHAR(150),
  @strRoleName VARCHAR(50),
  @strPropertyTemplateName NVARCHAR(50), 
  @strPropertyValue NVARCHAR(200),
  @bolChangedByUser BIT
  )
AS
  DECLARE @intObjectID INT
  DECLARE @intRoleID INT
  DECLARE @intPropertyTemplateID INT
  
  SELECT @intObjectID = (SELECT intObjectID FROM tbEDPObject WHERE strObjectName = @strObjectName)
  SELECT @intRoleID = (SELECT intRoleID FROM tbEDPRole WHERE strRoleName = @strRoleName)
  SELECT @intPropertyTemplateID = (SELECT intPropertyTemplateID FROM tbEDPPropertyTemplate WHERE strPropertyTemplateName = @strPropertyTemplateName)
           
  IF (@intObjectID > 0 AND @intRoleID > 0 AND @intPropertyTemplateID > 0)
  BEGIN
    INSERT INTO tbEDPRoleObjectProperty(intRoleID, intObjectID, intPropertyTemplateID, strPropertyValue, bolChangedByUser) 
		VALUES (@intRoleID, @intObjectID ,@intPropertyTemplateID, @strPropertyValue, @bolChangedByUser)
  END

  RETURN @@ROWCOUNT
go

