

CREATE VIEW [dbo].[vwVisAnpassadKopplingsInstruktionsFilter]
AS
SELECT      recFilterId AS intRecnum,       
            recFilterId,
            recAnpassadKopplingId, 
            strFaelt, 
            strVaerde
FROM        dbo.tbVisAnpassadKopplingsInstruktionsFilter


go

