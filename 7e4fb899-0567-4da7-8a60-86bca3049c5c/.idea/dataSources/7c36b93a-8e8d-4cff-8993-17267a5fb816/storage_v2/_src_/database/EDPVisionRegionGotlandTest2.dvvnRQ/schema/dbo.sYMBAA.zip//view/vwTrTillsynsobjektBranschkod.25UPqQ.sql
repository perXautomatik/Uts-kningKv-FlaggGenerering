
CREATE VIEW [dbo].[vwTrTillsynsobjektBranschkod]
AS
SELECT tbTrTillsynsobjektBranschkod.recTillsynsobjektBranschkodID
  , tbTrTillsynsobjektBranschkod.recTillsynsobjektBranschkodID AS intRecnum
  , tbTrTillsynsobjektBranschkod.recTillsynsobjektID
  , tbTrTillsynsobjektBranschkod.recBranschkodID
  , tbTrTillsynsobjektBranschkod.bolHuvudBranschkod
  , tbTrBranschkod.strBranschkod
  , tbTrBranschkod.strUnderrubrik
  , tbTrBranschkod.strHuvudrubrik
  , tbTrBranschkod.strBeskrivning
  , tbTrTillsynsobjekt.strObjektsNamn
  , tbTrVerksamhet.strVerksamhetNamn
FROM tbTrTillsynsobjektBranschkod
INNER JOIN tbTrBranschkod
    ON tbTrBranschkod.recBranschkodID = tbTrTillsynsobjektBranschkod.recBranschkodID
INNER JOIN tbTrTillsynsobjekt
    ON tbTrTillsynsobjektBranschkod.recTillsynsobjektID = tbTrTillsynsobjekt.recTillsynsobjektID
INNER JOIN tbTrVerksamhet
    ON tbTrTillsynsobjekt.recVerksamhetID = tbTrVerksamhet.recVerksamhetID
go

