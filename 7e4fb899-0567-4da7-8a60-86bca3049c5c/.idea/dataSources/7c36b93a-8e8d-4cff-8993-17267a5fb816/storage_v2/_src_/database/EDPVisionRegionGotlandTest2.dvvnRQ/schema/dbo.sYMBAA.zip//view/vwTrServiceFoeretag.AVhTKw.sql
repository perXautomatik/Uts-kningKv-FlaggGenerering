

CREATE VIEW [dbo].[vwTrServiceFoeretag]
AS
WITH KontaktKommunikationssaett AS (
SELECT recEnstakaKontaktID,

    (REPLACE( (SELECT strVaerde + ', '
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Telefon' AND tbVisKommunikationssaett.recKommunikationssaettID IN
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett
       WHERE  dbo.tbTrServiceFoeretag.recEnstakaKontaktID = dbo.tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID)
    FOR XML PATH('')) + '...', ', ...','')
  ) AS strTelefon,

   (REPLACE( (SELECT strVaerde + ', '
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Mobil' AND tbVisKommunikationssaett.recKommunikationssaettID IN
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett
       WHERE  dbo.tbTrServiceFoeretag.recEnstakaKontaktID = dbo.tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID)
    FOR XML PATH('')) + '...', ', ...','')
  ) AS strMobil	,

   (REPLACE( (SELECT strVaerde + ', '
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Fax' AND tbVisKommunikationssaett.recKommunikationssaettID IN
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett
       WHERE  dbo.tbTrServiceFoeretag.recEnstakaKontaktID = dbo.tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID)
    FOR XML PATH('')) + '...', ', ...','')
  ) AS strFax,

   (REPLACE( (SELECT strVaerde + ', '
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'E-post' AND tbVisKommunikationssaett.recKommunikationssaettID IN
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett
       WHERE  dbo.tbTrServiceFoeretag.recEnstakaKontaktID = dbo.tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID)
    FOR XML PATH('')) + '...', ', ...','')
  ) AS strEpost


FROM tbTrServiceFoeretag
)


SELECT
		dbo.tbTrServiceFoeretag.recServiceFoeretagID,
		dbo.tbTrServiceFoeretag.recServiceFoeretagID AS intRecnum,
		dbo.tbTrServiceFoeretag.strAnteckning,
		dbo.tbTrServiceFoeretag.bolEjAktuell,
        dbo.tbTrServiceFoeretag.recEnstakaKontaktID,
        dbo.tbVisEnstakaKontakt.strFoeretag,
		dbo.tbVisEnstakaKontakt.strOrginisationPersonnummer,
        dbo.tbVisEnstakaKontakt.strKontaktTyp,
        dbo.tbVisEnstakaKontakt.strGatuadress,
		dbo.tbVisEnstakaKontakt.strCoadress,
		dbo.tbVisEnstakaKontakt.strPostnummer,
        dbo.tbVisEnstakaKontakt.strPostort,
        dbo.tbVisEnstakaKontakt.strLand,
        dbo.tbVisEnstakaKontakt.strFoernamn,
		dbo.tbVisEnstakaKontakt.strEfternamn,
		dbo.tbVisEnstakaKontakt.strTitel,
		dbo.tbVisEnstakaKontakt.strVisasSom,
			strTelefon,
			strMobil,
			strFax,
			strEpost,

		STUFF ((SELECT DISTINCT ',' + strCertifieringsTyp
				FROM tbTrCertifiering
				--ORDER BY ',' + strCertifieringsTyp
				FOR XML PATH('')
				), 1, 1, '') as strCertifieringar,


		STUFF((
					SELECT		',  ' + ISNULL(strCertifieringsTyp, '') + ' / ' + ISNULL(strCertifieringsnummer, '')  + ' / ' + ISNULL(CONVERT(varchar(10), datCertifieradTillOchMed, 20), '')
					FROM		tbTrCertifiering
						INNER JOIN dbo.tbTrCertifieringServiceFoeretag
								ON dbo.tbTrCertifieringServiceFoeretag.recCertifieringID = tbTrCertifiering.recCertifieringID
						WHERE tbTrCertifieringServiceFoeretag.recServiceFoeretagID = tbTrServiceFoeretag.recServiceFoeretagID
					ORDER BY strCertifieringsTyp
					for xml path('')
				)
				,1,3,''
			) AS strCertifieringsDataCSV,

		dbo.tbVisEnstakaKontakt.strSammanslagenAdress,
		STUFF ((SELECT DISTINCT ', ' + strKommunikationsaettTyp + ': ' + strVaerde
				FROM tbVisKommunikationssaett
				WHERE recKommunikationssaettID IN (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett WHERE recEnstakaKontaktID = dbo.tbTrServiceFoeretag.recEnstakaKontaktID )
				FOR XML PATH('')
				), 1, 2, '') as strKommunikation

FROM    dbo.tbTrServiceFoeretag
INNER JOIN
        dbo.tbVisEnstakaKontakt ON
        dbo.tbTrServiceFoeretag.recEnstakaKontaktID = dbo.tbVisEnstakaKontakt.recEnstakaKontaktID

LEFT OUTER JOIN KontaktKommunikationssaett
  ON KontaktKommunikationssaett.recEnstakaKontaktID = tbTrServiceFoeretag.recEnstakaKontaktID
go

