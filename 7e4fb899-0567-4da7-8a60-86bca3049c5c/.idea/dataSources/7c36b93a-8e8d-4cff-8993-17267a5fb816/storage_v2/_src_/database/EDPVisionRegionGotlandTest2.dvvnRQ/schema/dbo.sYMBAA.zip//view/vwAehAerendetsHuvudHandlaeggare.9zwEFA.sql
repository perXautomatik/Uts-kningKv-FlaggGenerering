CREATE VIEW vwAehAerendetsHuvudHandlaeggare
AS
SELECT tbAehAerendeUser.recAerendeUserID,
  tbAehAerendeUser.recAerendeID,
  tbAehAerendeUser.intUserID,
  vwVisHandlaeggareEDPUser.intRecnum,
  vwVisHandlaeggareEDPUser.strUserWindowsAccount,
  vwVisHandlaeggareEDPUser.strSignature,
  vwVisHandlaeggareEDPUser.strUserSurName,
  vwVisHandlaeggareEDPUser.strUserFirstName,
  vwVisHandlaeggareEDPUser.strFullName,
  vwVisHandlaeggareEDPUser.strEmail,
  vwVisHandlaeggareEDPUser.strTelephone,
  vwVisHandlaeggareEDPUser.strTelephone2,
  vwVisHandlaeggareEDPUser.strBefattning

FROM tbAehAerendeUser
LEFT OUTER JOIN vwVisHandlaeggareEDPUser
ON vwVisHandlaeggareEDPUser.intUserID = tbAehAerendeUser.intUserID
WHERE tbAehAerendeUser.bolHuvudhandlaeggare = 1
go

