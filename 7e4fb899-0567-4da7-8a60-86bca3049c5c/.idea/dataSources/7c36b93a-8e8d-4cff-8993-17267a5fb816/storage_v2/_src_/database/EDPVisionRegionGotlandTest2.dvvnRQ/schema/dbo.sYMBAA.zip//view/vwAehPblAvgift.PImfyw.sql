
CREATE VIEW [dbo].[vwAehPblAvgift]
AS
SELECT  dbo.tbAehPblAvgift.recAvgiftID, 
  dbo.tbAehPblAvgift.recAvgiftID AS intRecnum, 
	dbo.tbAehPblAvgift.recAerendeID, 
	dbo.tbAehAerendeData.strDiarienummer as strAerendeDiarienummer, 
  dbo.tbAehPblAvgift.recByggAerendeID, 
	dbo.tbAehPblAvgift.recPlanAerendeID, 
	dbo.tbAehPblAvgift.datDatum, 
	dbo.tbAehPblAvgift.strRubrik, 
	dbo.tbAehPblAvgift.recTaxa2011ID, 
  dbo.tbAehPblTaxa2011.strBeskrivning AS strTaxemodell, 
	dbo.tbAehPblAvgift.decSumma
FROM dbo.tbAehPblAvgift 
LEFT OUTER JOIN dbo.tbAehAerendeData 
  ON dbo.tbAehPblAvgift.recAerendeID = dbo.tbAehAerendeData.recAerendeID 
LEFT OUTER JOIN dbo.tbAehPblTaxa2011 
  ON dbo.tbAehPblAvgift.recTaxa2011ID = dbo.tbAehPblTaxa2011.recTaxa2011ID

go

