

CREATE PROCEDURE dbo.spEDPSortOrderSortColumnInsert
	(
		@intOrderID int,
		@intColumnID int,
		@intAppearanceOrder int
	)
AS

INSERT INTO tbEDPSortOrderSortColumn
                      (intOrderID, intColumnID, intAppearanceOrder)
VALUES     (@intOrderID, @intColumnID, @intAppearanceOrder)

RETURN


go

