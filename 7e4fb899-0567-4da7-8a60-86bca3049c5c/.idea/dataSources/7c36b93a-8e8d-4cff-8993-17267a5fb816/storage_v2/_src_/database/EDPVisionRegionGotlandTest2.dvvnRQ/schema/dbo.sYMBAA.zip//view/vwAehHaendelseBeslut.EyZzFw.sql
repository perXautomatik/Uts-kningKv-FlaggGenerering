
            CREATE VIEW [dbo].[vwAehHaendelseBeslut]
            AS SELECT
            tbAehHaendelseBeslut.recHaendelseBeslutID as intRecnum,
            tbAehHaendelseBeslut.*,
            tbMhOrgan.strOrgannamn,
            tbAehDelegationskod.strDelegationskod,
            tbAehDelegationskod.strDelegationsNamn,
            tbAehAerendeHaendelse.bolHuvudbeslut AS bolMainHuvudBeslut
            FROM tbAehHaendelseBeslut
            INNER JOIN tbAehAerendeHaendelse ON tbAehAerendeHaendelse.recHaendelseID = tbAehHaendelseBeslut.recHaendelseID
            LEFT OUTER JOIN tbAehDelegationskod ON tbAehDelegationskod.recDelegationskodID = tbAehHaendelseBeslut.recDelegationskodID
            LEFT OUTER JOIN tbMhOrgan ON tbMhOrgan.recOrganID = tbAehHaendelseBeslut.recOrganID

            go

