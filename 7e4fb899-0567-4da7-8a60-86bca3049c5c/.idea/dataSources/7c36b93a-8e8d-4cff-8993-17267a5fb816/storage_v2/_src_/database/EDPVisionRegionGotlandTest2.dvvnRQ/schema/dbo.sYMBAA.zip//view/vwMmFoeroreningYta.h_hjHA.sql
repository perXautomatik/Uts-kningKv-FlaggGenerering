
CREATE VIEW dbo.vwMmFoeroreningYta
AS
SELECT
dbo.tbMmFoeroreningYta.recFoeroreningYtaId AS intRecnum,
dbo.tbMmFoerorening.recFoeroreningID,
dbo.tbMmFoerorening.recOmrID,
dbo.tbMmFoerorening.recMediumID,
dbo.tbMmFoerorening.strRegKod + '-' + LTRIM(STR(dbo.tbMmFoerorening.intFoeroreningNr)) AS strFoeroreningKod,
dbo.tbMmFoerorening.strRegKod,
dbo.tbMmFoerorening.intFoeroreningNr,
dbo.tbMmFoerorening.strKaenslighet,
dbo.tbMmFoerorening.intProvantal,
dbo.tbMmFoerorening.intProvpunkter,
dbo.tbMmFoerorening.strBeskrivning,
dbo.tbMmMedium.strMediumNamn,
dbo.vwMmOmraade.strOmraadeKod,
dbo.vwMmOmraade.strOmrNamn,
dbo.tbMmFoerorening.strFoeroreningNamn,
dbo.tbMmMedium.strLocalizationCode,
dbo.tbVisYta.geomYta
FROM
dbo.tbMmFoeroreningYta
INNER JOIN dbo.tbMmFoerorening ON dbo.tbMmFoeroreningYta.recFoeroreningId = dbo.tbMmFoerorening.recFoeroreningID
LEFT OUTER JOIN dbo.tbVisYta ON dbo.tbMmFoeroreningYta.recYtaId = dbo.tbVisYta.recYtaId
LEFT OUTER JOIN dbo.vwMmOmraade ON dbo.tbMmFoerorening.recOmrID = dbo.vwMmOmraade.recOmrID
LEFT OUTER JOIN dbo.tbMmMedium ON dbo.tbMmFoerorening.recMediumID = dbo.tbMmMedium.recMediumID
go

