CREATE VIEW [dbo].[vwTrVerksamhetTillsynsobjektHaendelse]
AS
SELECT
					dbo.tbTrTillsynsobjekt.recVerksamhetID,
					dbo.tbAehHaendelse.recHaendelseID as intRecnum,
					dbo.tbAehHaendelse.recHaendelseID,
					dbo.tbAehHaendelse.datHaendelseDatum,
					dbo.tbAehHaendelse.strKommunikationssaett,
					dbo.tbAehHaendelse.strRiktning,
					dbo.tbAehHaendelse.strRubrik,
					dbo.tbAehHaendelse.strText,
					dbo.tbAehHaendelseData.intUserID,
					dbo.tbAehAerende.recAvdelningID,
					
					dbo.tbAehHaendelseKategori.strHaendelseKategori,
					
					dbo.tbAehHaendelseSekretessLog.strRekommendation AS strSekretess, 
					dbo.tbAehHaendelseSekretessLog.strBegraensa, 
					dbo.tbAehHaendelseSekretessLog.strMyndighet AS strSekretessMyndighet, 
					dbo.tbAehHaendelseSekretessLog.datDatum AS datSekretessDatum, 

					dbo.tbAehAerendeHaendelse.recAerendeID,

					MAX(dbo.tbTrTillsynsobjekt.recTillsynsobjektID) AS recTillsynsobjektID,
					
                    (SELECT strObjektsNamn FROM dbo.tbTrTillsynsobjekt Tillsynsobjekt 
                       WHERE Tillsynsobjekt.recTillsynsobjektID = MAX(dbo.tbTrTillsynsobjekt.recTillsynsobjektID)) 
                     AS strObjektsNamn,
			
                    (SELECT strTillsynsobjektsTypNamn FROM dbo.tbTrTillsynsobjektsTyp 
                       WHERE dbo.tbTrTillsynsobjektsTyp.recTillsynsobjektTypID = 
                       (SELECT recTillsynsobjektTypID FROM dbo.tbTrTillsynsobjekt Tillsynsobjekt 
                          WHERE Tillsynsobjekt.recTillsynsobjektID = MAX(dbo.tbTrTillsynsobjekt.recTillsynsobjektID))) 
                     AS strTillsynsobjektsTypNamn
					
		
FROM tbTrTillsynsobjekt

LEFT OUTER JOIN		dbo.tbTrTillsynsobjektsTyp
ON					dbo.tbTrTillsynsobjekt.recTillsynsobjektTypID = dbo.tbTrTillsynsobjektsTyp.recTillsynsobjektTypID

LEFT OUTER JOIN
					(
					 SELECT 
										dbo.tbTrTillsynsobjektHaendelse.recHaendelseID, 
										dbo.tbTrTillsynsobjektHaendelse.recTillsynsobjektID as recTillsynsobjektID
							
					 FROM 				dbo.tbTrTillsynsobjektHaendelse

					 UNION

					 SELECT 			dbo.tbAehAerendeHaendelse.recHaendelseID,
										dbo.tbTrTillsynsobjektAerende.recTillsynsobjektID as recTillsynsobjektID
										
					 FROM 				dbo.tbAehAerendeHaendelse

					 LEFT OUTER JOIN	dbo.tbTrTillsynsobjektAerende
					 ON					dbo.tbAehAerendeHaendelse.recAerendeID = dbo.tbTrTillsynsobjektAerende.recAerendeID

					) AS connectedHaendelser
ON 					connectedHaendelser.recTillsynsobjektID = tbTrTillsynsobjekt.recTillsynsobjektID

INNER JOIN 			dbo.tbAehHaendelse
ON					connectedHaendelser.recHaendelseID = dbo.tbAehHaendelse.recHaendelseID

LEFT OUTER JOIN dbo.tbAehHaendelseData
ON dbo.tbAehHaendelseData.recHaendelseID = connectedHaendelser.recHaendelseID

LEFT OUTER JOIN 	dbo.tbAehHaendelseKategori
ON					dbo.tbAehHaendelse.recHaendelseKategoriID = dbo.tbAehHaendelseKategori.recHaendelseKategoriID

LEFT OUTER JOIN tbAehHaendelseSekretessLog 
		ON tbAehHaendelseSekretessLog.recHaendelseSekretessLogID = dbo.tbAehHaendelse.recLastHaendelseSekretessLogID

LEFT OUTER JOIN dbo.tbAehAerendeHaendelse 
		ON dbo.tbAehHaendelse.recHaendelseID = dbo.tbAehAerendeHaendelse.recHaendelseID 

LEFT OUTER JOIN dbo.tbAehAerende
		ON dbo.tbAehAerende.recAerendeID = dbo.tbAehAerendeHaendelse.recAerendeID 

GROUP BY 
					dbo.tbAehHaendelse.recHaendelseID,
					dbo.tbAehHaendelse.datHaendelseDatum,
					dbo.tbAehHaendelse.strKommunikationssaett,
					dbo.tbAehHaendelse.strRiktning,
					dbo.tbAehHaendelse.strRubrik,
					dbo.tbAehHaendelse.strText,
					dbo.tbAehHaendelseData.intUserID,
					dbo.tbAehAerende.recAvdelningID,
					
					dbo.tbAehHaendelseKategori.strHaendelseKategori,
					
					dbo.tbAehHaendelseSekretessLog.strRekommendation, 
					dbo.tbAehHaendelseSekretessLog.strBegraensa, 
					dbo.tbAehHaendelseSekretessLog.strMyndighet, 
					dbo.tbAehHaendelseSekretessLog.datDatum, 

					dbo.tbAehAerendeHaendelse.recAerendeID,
                    dbo.tbTrTillsynsobjekt.recVerksamhetID


go

