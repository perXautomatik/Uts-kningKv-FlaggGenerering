
            CREATE FUNCTION [dbo].[fnVisMallKontaktKommunikationssaett] 
            (
              @recMallKontaktID INT
            )
            RETURNS NVARCHAR(MAX)
            AS
            BEGIN
              DECLARE @result NVARCHAR(MAX)
  
               SELECT @result = 
                LTRIM ((
                  SELECT strKommunikationsaettTyp + ' - ' + strVaerde + ', ' FROM tbVisKommunikationssaett
                  INNER JOIN  tbVisMallKontaktKommunikationssaett
                    ON tbVisKommunikationssaett.recKommunikationssaettID = tbVisMallKontaktKommunikationssaett.recKommunikationssaettID
                  WHERE tbVisMallKontaktKommunikationssaett.recMallKontaktID = @recMallKontaktID
                  FOR XML PATH('')
                )) 

              RETURN LEFT(@result, LEN(@result) - 1)
            END
            go

