

CREATE VIEW [dbo].[vwVisAdressbokRegister]
AS
SELECT	recTillsynsobjektTypID as intRecnum,		
strTillsynsobjektsTypNamn

FROM			dbo.tbTrTillsynsobjektsTyp
UNION SELECT	-1, 'Ärende'
UNION SELECT	-2, 'Händelse'
UNION SELECT	-3, 'Uppgift'
--UNION SELECT	-4, 'Debitering'
--UNION SELECT	-5, 'Tillsynsobjekt'
UNION SELECT	-6, 'Tillsynsbesök'
UNION SELECT	-7, 'Remisskontakt'
UNION SELECT	-8, 'Bostadsanpassningsutbetalning'


go

