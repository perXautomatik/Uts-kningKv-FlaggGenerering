

CREATE VIEW [dbo].[vwTrMtUtslaepp]
AS
SELECT    
		recUtsläppID,
		recUtsläppID As intRecnum,
		recTillsynsobjektID,
		tbTrMtUtslaepp.recEnhetID,
		strEnhet,
		datFrånOchMed,
		datTillOchMed,
		strMottagare,
		decMängd,
		strNotering,
		strAemne

FROM    dbo.tbTrMtUtslaepp 
INNER JOIN
	dbo.tbVisMaetEnhet 
	ON dbo.tbVisMaetEnhet.recEnhetID = dbo.tbTrMtUtslaepp.recEnhetID



go

