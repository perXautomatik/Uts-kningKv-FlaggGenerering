CREATE VIEW [dbo].[vwTrVerksamhetTillsynsobjektAerende]
AS
SELECT DISTINCT
					
					dbo.tbTrTillsynsobjektAerende.recTillsynsobjektAerendeID as intRecnum,
					dbo.tbTrTillsynsobjektAerende.recTillsynsobjektAerendeID,

					dbo.tbTrTillsynsobjektsTyp.strTillsynsobjektsTypNamn,

					dbo.tbTrTillsynsobjekt.recTillsynsobjektID,
					dbo.tbTrTillsynsobjekt.strObjektsNamn,
					dbo.tbTrTillsynsobjekt.recVerksamhetID,

					dbo.vwAehAerende.recAerendeID,
					dbo.vwAehAerende.strDiarienummer,
					dbo.vwAehAerende.strSoekbegrepp,
					dbo.vwAehAerende.strAerendemening,
					dbo.vwAehAerende.datInkomDatum,
					dbo.vwAehAerende.strSignature,		
					dbo.vwAehAerende.intUserID,
					dbo.vwAehAerende.recAvdelningID,

					dbo.vwAehAerende.strSekretess,
					dbo.vwAehAerende.strBegraensa,
					dbo.vwAehAerende.strSekretessMyndighet,
					dbo.vwAehAerende.datSekretessDatum,
												
					dbo.tbAehAerendetyp.strAerendeTyp,
					
					dbo.tbVisEnstakaFastighet.strFastighetsbeteckning,
					
					dbo.tbAehAerendeStatusLogTyp.strAerendeStatusPresent					
					
FROM				dbo.tbTrTillsynsobjektAerende

LEFT OUTER JOIN 	dbo.vwAehAerende
ON					dbo.tbTrTillsynsobjektAerende.recAerendeID = dbo.vwAehAerende.recAerendeID

LEFT OUTER JOIN		dbo.tbAehAerendetyp
ON					dbo.vwAehAerende.recAerendetypID = dbo.tbAehAerendetyp.recAerendetypID

LEFT OUTER JOIN		dbo.tbAehAerendeEnstakaFastighet
ON					dbo.tbAehAerendeEnstakaFastighet.recAerendeId = dbo.tbTrTillsynsobjektAerende.recAerendeId
AND					dbo.tbAehAerendeEnstakaFastighet.bolHuvudfastighet = 1

LEFT OUTER JOIN		dbo.tbVisEnstakaFastighet
ON					dbo.tbVisEnstakaFastighet.recFastighetID = dbo.tbAehAerendeEnstakaFastighet.recFastighetID

LEFT OUTER JOIN		dbo.tbAehAerendeStatusLog
ON					dbo.vwAehAerende.recLastAerendeStatusLogID = dbo.tbAehAerendeStatusLog.recAerendeStatusLogID

LEFT OUTER JOIN		dbo.tbAehAerendeStatusLogTyp
ON					dbo.tbAehAerendeStatusLog.recAerendeStatusLogTypID = dbo.tbAehAerendeStatusLogTyp.recAerendeStatusLogTypID

LEFT OUTER JOIN		dbo.tbTrTillsynsobjekt
ON					dbo.tbTrTillsynsobjektAerende.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID

LEFT OUTER JOIN		dbo.tbTrTillsynsobjektsTyp
ON					dbo.tbTrTillsynsobjekt.recTillsynsobjektTypID = dbo.tbTrTillsynsobjektsTyp.recTillsynsobjektTypID
go

