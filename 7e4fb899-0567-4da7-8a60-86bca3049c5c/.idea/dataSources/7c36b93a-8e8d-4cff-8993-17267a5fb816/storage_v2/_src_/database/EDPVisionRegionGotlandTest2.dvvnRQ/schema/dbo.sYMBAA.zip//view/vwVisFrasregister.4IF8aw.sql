



CREATE VIEW [dbo].[vwVisFrasregister]
AS

SELECT	recFrasregisterID,
		recFrasregisterID as intRecnum,
		strFraskod, 
		strText
FROM    dbo.tbVisFrasregister



go

