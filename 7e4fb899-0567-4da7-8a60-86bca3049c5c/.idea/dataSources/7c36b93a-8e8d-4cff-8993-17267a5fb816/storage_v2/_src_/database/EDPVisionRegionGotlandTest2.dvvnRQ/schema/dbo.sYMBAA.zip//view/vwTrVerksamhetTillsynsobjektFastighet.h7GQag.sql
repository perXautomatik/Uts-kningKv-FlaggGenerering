CREATE VIEW [dbo].[vwTrVerksamhetTillsynsobjektFastighet]
AS
SELECT
					dbo.tbVisDeladFastighet.recFastighet as intRecnum,
					dbo.tbVisDeladFastighet.recFastighet,
					dbo.tbVisDeladFastighet.strFnrID,
					dbo.tbVisDeladFastighet.strFastighetsbeteckning,
					
					dbo.tbVisDeladFastighetAdress.strAdress,
					dbo.tbVisDeladFastighetAdress.strPostnr,
					dbo.tbVisDeladFastighetAdress.strPostort,
					
					dbo.tbTrTillsynsobjekt.recTillsynsobjektID,					
					dbo.tbTrTillsynsobjekt.strObjektsNamn,
					dbo.tbTrTillsynsobjekt.recVerksamhetID,
					
					dbo.tbTrTillsynsobjektsTyp.strTillsynsobjektsTypNamn
					
		
FROM				dbo.tbTrTillsynsobjektFastighet

LEFT OUTER JOIN 	dbo.tbVisDeladFastighet
ON					dbo.tbTrTillsynsobjektFastighet.strFnrID = dbo.tbVisDeladFastighet.strFnrID

LEFT OUTER JOIN		dbo.tbVisDeladFastighetAdress
ON					dbo.tbVisDeladFastighet.strFnrID = 
						(
						 SELECT TOP 1 dbo.tbVisDeladFastighetAdress.strFnrID
						 FROM dbo.tbVisDeladFastighetAdress
						 WHERE dbo.tbVisDeladFastighetAdress.strFnrID = dbo.tbVisDeladFastighet.strFnrID
						)

LEFT OUTER JOIN		dbo.tbTrTillsynsobjekt
ON					dbo.tbTrTillsynsobjektFastighet.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID

LEFT OUTER JOIN		dbo.tbTrTillsynsobjektsTyp
ON					dbo.tbTrTillsynsobjekt.recTillsynsobjektTypID = dbo.tbTrTillsynsobjektsTyp.recTillsynsobjektTypID

go

