


CREATE VIEW [dbo].[vwVisFrasregisterRegisterData]
AS
SELECT     recTillsynsobjektTypID AS intRecnum, strTillsynsobjektsTypNamn
FROM         dbo.tbTrTillsynsobjektsTyp
UNION
SELECT     - 1, 'Ärende'
UNION
SELECT     - 2, 'Händelse'
UNION
SELECT     - 3, 'Uppgift'
UNION
SELECT     - 4, 'Debitering'
UNION
SELECT     - 5, 'Tillsynsobjekt'
UNION
SELECT     - 6, 'Tillsynsbesök - Orsak'
UNION
SELECT     - 7, 'Tillsynsbesök - Generell notering'
UNION
SELECT     - 8, 'Tillsynsbesök - Uppföljning'
UNION
SELECT     - 9, 'PBL-Taxa 2011'
UNION
SELECT     - 10, 'PBL-Avgift'
UNION
SELECT     - 11, 'Bostadsanpassningsutbetalning'
UNION
SELECT     - 12, 'Bostadsanpassningsåtgärd'
go

