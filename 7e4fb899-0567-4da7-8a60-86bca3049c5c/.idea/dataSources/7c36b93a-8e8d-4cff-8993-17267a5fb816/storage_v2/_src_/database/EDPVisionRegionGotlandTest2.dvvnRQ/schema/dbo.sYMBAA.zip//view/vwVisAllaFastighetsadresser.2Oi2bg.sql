CREATE VIEW dbo.vwVisAllaFastighetsadresser AS
WITH AllaFastighetersAdresser AS (
	SELECT vwVisEnstakaFastighetAdress.strAdress, vwVisEnstakaFastighet.strFastighetsbeteckning, vwVisEnstakaFastighet.strKommunNamn FROM dbo.vwVisEnstakaFastighetAdress LEFT JOIN vwVisEnstakaFastighet ON vwVisEnstakaFastighet.recFastighetID = vwVisEnstakaFastighetAdress.recFastighetID
	UNION
	SELECT vwVisDeladFastighetAdress.strAdress, vwVisDeladFastighet.strFastighetsbeteckning, vwVisDeladFastighet.strKommunNamn FROM dbo.vwVisDeladFastighetAdress LEFT JOIN dbo.vwVisDeladFastighet ON vwVisDeladFastighet.strFnrID = vwVisDeladFastighetAdress.strFnrID
)
SELECT DISTINCT ROW_NUMBER() OVER(ORDER BY strAdress) AS intRecNum, strAdress, strFastighetsbeteckning, strKommunNamn FROM AllaFastighetersAdresser
go

