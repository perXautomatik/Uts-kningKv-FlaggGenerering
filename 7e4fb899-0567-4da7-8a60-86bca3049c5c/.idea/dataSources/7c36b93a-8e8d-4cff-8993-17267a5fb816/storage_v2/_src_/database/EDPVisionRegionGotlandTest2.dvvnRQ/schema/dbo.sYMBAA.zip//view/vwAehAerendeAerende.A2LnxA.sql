CREATE VIEW [dbo].[vwAehAerendeAerende]
            AS
            WITH Relation as(
            SELECT
            -- Kopplade utan riktning eller före

            recAerendeID,
            CASE WHEN bolRiktat = 1 THEN 'Före' ELSE 'Kopplad' END AS strRelation,
            recKoppladAerendeID AS recAerendeIDRelaterad,
            recKoppladAerendeID as intRecnum,
            dbo.tbAehAerendeAerende.strKommentar
            FROM dbo.tbAehAerendeAerende
            UNION SELECT
            -- Lägg till dem som är kopplade efter

            recKoppladAerendeID AS recAerendeID,
            CASE WHEN bolRiktat = 1 THEN 'Efter' ELSE 'Kopplad' END AS strRelation,
            recAerendeID AS recAerendeIDRelaterad,
            recAerendeID AS intRecnum,
            dbo.tbAehAerendeAerende.strKommentar

            FROM dbo.tbAehAerendeAerende)
            SELECT Relation.*,
            tbAehAerendeData.strDiarienummer,
            tbAehAerende.datInkomDatum,
            tbAehAerendeData.strAerendeStatusPresent,
            tbAehAerendetyp.strAerendeTyp,
            tbAehAerende.strAerendemening,
            tbAehHaendelseBeslut.datBeslutsDatum
            FROM Relation
            INNER JOIN dbo.tbAehAerende ON Relation.intRecnum = tbAehAerende.recAerendeID
            INNER JOIN dbo.tbAehAerendeData ON Relation.intRecnum = tbAehAerendeData.recAerendeID
            INNER JOIN dbo.tbAehAerendetyp ON tbAehAerende.recAerendetypID = tbAehAerendetyp.recAerendetypID
            LEFT OUTER JOIN dbo.tbAehHaendelseBeslut ON tbAehAerende.recLastHaendelseBeslutID = tbAehHaendelseBeslut.recHaendelseBeslutID
go

