
CREATE PROCEDURE [dbo].[spEDPGetSubParameterSearchMethodName]
	(
		@strSubParameterName varchar(200)
	)
AS
SELECT     tbEDPSearchMethod.strSearchMethodName
FROM         tbEDPSubParameter INNER JOIN
                      tbEDPSearchMethod ON tbEDPSubParameter.intSubParameterSearchMethodID = tbEDPSearchMethod.intSearchMethodID
WHERE     (tbEDPSubParameter.strSubParameterName = @strSubParameterName)
	RETURN

go

