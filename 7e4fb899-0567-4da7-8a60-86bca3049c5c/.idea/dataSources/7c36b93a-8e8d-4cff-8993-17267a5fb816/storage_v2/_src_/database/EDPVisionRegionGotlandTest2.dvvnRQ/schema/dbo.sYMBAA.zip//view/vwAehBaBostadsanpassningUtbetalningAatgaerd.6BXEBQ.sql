

CREATE VIEW [dbo].[vwAehBaBostadsanpassningUtbetalningAatgaerd]
AS
SELECT		dbo.tbAehBaBostadsanpassningUtbetalningAatgaerd.recBostadsanpassningUtbetalningAatgaerdID,
			dbo.tbAehBaBostadsanpassningUtbetalningAatgaerd.recBostadsanpassningUtbetalningAatgaerdID as intRecnum, 
			dbo.tbAehBaBostadsanpassningUtbetalningAatgaerd.recBostadsanpassningUtbetalningID, 
			dbo.tbAehBaBostadsanpassningUtbetalningAatgaerd.recBostadsanpassningAatgaerdID, 
			dbo.tbAehBaBostadsanpassningUtbetalningAatgaerd.decBelopp,
			strAatgaerd
FROM        dbo.tbAehBaBostadsanpassningUtbetalningAatgaerd
			LEFT JOIN tbAehBaBostadsanpassningAatgaerd ON
			dbo.tbAehBaBostadsanpassningUtbetalningAatgaerd.recBostadsanpassningAatgaerdID = tbAehBaBostadsanpassningAatgaerd.recBostadsanpassningAatgaerdID


go

