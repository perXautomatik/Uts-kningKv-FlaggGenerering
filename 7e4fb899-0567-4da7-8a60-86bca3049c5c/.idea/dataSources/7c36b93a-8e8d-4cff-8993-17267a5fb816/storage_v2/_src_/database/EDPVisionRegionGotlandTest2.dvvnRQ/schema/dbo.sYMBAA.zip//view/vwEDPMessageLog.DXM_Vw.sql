/****** Object:  View [dbo].[vwEDPMessageLog]    Script Date: 10/04/2006 11:27:39 ******/
CREATE VIEW [dbo].[vwEDPMessageLog]
AS
SELECT     dbo.tbEDPMessageLog.intMessageLogID AS intRecnum, dbo.tbEDPMessageLog.intMessageLogID, dbo.tbEDPMessageLog.strMessage, 
                      dbo.tbEDPMessageType.strMessageTypeName, dbo.tbEDPMessageLog.datSkapad, dbo.tbEDPMessageLog.strSkapadAv
FROM         dbo.tbEDPMessageLog INNER JOIN
                      dbo.tbEDPMessageType ON dbo.tbEDPMessageLog.intMessageTypeID = dbo.tbEDPMessageType.intMessageTypeID

go

