

CREATE VIEW [dbo].[vwTrVeVentilationsaggregat]
AS

SELECT		tbTrVeVentilationsaggregat.recVentilationsaggregatID, 
			tbTrVeVentilationsaggregat.recVentilationsaggregatID AS intRecNum,
			tbTrVeVentilationsaggregat.recTillsynsobjektID, 
			tbTrVeVentilationsaggregat.strStatus, 
			tbTrVeVentilationsaggregat.datStatusDatum, 
			tbTrVeVentilationsaggregat.strAggregat,
			tbTrVeVentilationsaggregat.strVentilationstyp, 
			tbTrVeVentilationsaggregat.strByggnad, 
			tbTrVeVentilationsaggregat.strVerksamhetstyp, 
			tbTrVeVentilationsaggregat.strBetjaenar, 
			tbTrVeVentilationsaggregat.strEnergiaatervinning, 
			tbTrVeVentilationsaggregat.decTilluft, 
			tbTrVeVentilationsaggregat.decFraanluft, 
			tbTrVeVentilationsaggregat.intByggnadsaar, 
			tbTrVeVentilationsaggregat.intBygglov, 
			tbTrVeVentilationsaggregat.intOmbyggnadsaar, 
			tbTrVeVentilationsaggregat.intLokaler, 
			tbTrVeVentilationsaggregat.intLaegenheter,
			tbTrVeVentilationsaggregat.decYta, 
			tbTrVeVentilationsaggregat.intVaaning, 
			tbTrVeVentilationsaggregat.strNorm, 
			tbTrVeVentilationsaggregat.strAnteckning, 
			tbTrVeVentilationsaggregat.intBesiktningsintervall, 
			tbTrVeVentilationsaggregat.datFoeregaaendeBesiktning,
			tbTrVeVentilationsaggregat.datOmbesiktning, 
			tbTrVeVentilationsaggregat.datNaestaBesiktning,
			tbTrVeVentilationsaggregat.strByggnadstyp,
			tbTrVeVentilationsaggregat.strOmgivning,
			
			tbTrTillsynsobjekt.strObjektsNamn,
			tbTrTillsynsobjekt.recTillsynsobjektTypID,
			
			tbVisDeladFastighet.strFnrID,
			tbVisDeladFastighet.strFastighetsbeteckning

FROM		tbTrVeVentilationsaggregat

LEFT JOIN	tbTrTillsynsobjekt 
		ON	tbTrTillsynsobjekt.recTillsynsobjektID = tbTrVeVentilationsaggregat.recTillsynsobjektID
		
LEFT JOIN	tbTrVeVentilationsaggregatFastighet 
		ON	tbTrVeVentilationsaggregatFastighet.recVentilationsaggregatID = tbTrVeVentilationsaggregat.recVentilationsaggregatID 
		AND	tbTrVeVentilationsaggregatFastighet.bolHuvudfastighet = 1
		
LEFT JOIN	tbVisDeladFastighet
		ON	tbVisDeladFastighet.strFnrID = tbTrVeVentilationsaggregatFastighet.strFnrID



go

