
CREATE PROCEDURE [dbo].[spEDPGetMenuItemsByParentID] 
		@intMenuItemID integer
AS
SELECT     tbEDPMenuItem.*
FROM         tbEDPMenuItem INNER JOIN
tbEDPMenuItem tbEDPMenuItem_1 ON tbEDPMenuItem.intParentID = tbEDPMenuItem_1.intMenuItemID
WHERE     (tbEDPMenuItem_1.intMenuItemID = @intMenuItemID)
order by tbEDPMenuItem.intitemorder
RETURN
go

