

CREATE VIEW [dbo].[vwEDPFileUnmanagedFiles]
AS
SELECT    recUnmanagedfileID
		, recUnmanagedfileID as intRecnum
		, strFullFilePath
		, recHaendelseID
		, recMoeteID
		, recMoetespunktID
		, strFileName
		, intUserID
		, datDatum
		, recFilMallID
		, bolMassbrev
        , recHandlingsTypId

FROM    dbo.tbEDPFileUnmanagedFiles
go

