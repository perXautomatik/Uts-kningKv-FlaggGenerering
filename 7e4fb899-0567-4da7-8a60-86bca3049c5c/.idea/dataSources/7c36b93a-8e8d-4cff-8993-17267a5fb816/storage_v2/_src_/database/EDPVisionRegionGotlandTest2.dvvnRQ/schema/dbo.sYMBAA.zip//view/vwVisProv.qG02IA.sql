

CREATE VIEW [dbo].[vwVisProv]
AS
SELECT
	dbo.tbVisProv.recProvID AS intRecnum, 
	dbo.tbVisProv.*,
	dbo.tbVisKommun.strKommunNamn,
	dbo.tbTrTillsynsobjekt.strObjektsNamn,
	dbo.tbMmOmraade.strRegKod + '-' + dbo.tbMmOmraade.strOmrNr + '-' + dbo.tbMmOmraade.strLopNr AS strOmraadeKod,
	dbo.tbMmOmraade.strOmrNamn
FROM dbo.tbVisProv
LEFT JOIN dbo.tbVisKommun 
	ON dbo.tbVisProv.recKommunID = dbo.tbVisKommun.recKommunID
LEFT JOIN dbo.tbTrTillsynsobjekt
	ON dbo.tbVisProv.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID
LEFT JOIN dbo.tbMmOmraade
	ON dbo.tbVisProv.recOmrID = dbo.tbMmOmraade.recOmrID

go

