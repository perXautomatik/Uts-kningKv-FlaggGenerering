

CREATE VIEW [dbo].[vwAehBaBostadsanpassningAatgaerd]
AS
SELECT		dbo.tbAehBaBostadsanpassningAatgaerd.recBostadsanpassningAatgaerdID, 
			dbo.tbAehBaBostadsanpassningAatgaerd.recBostadsanpassningAatgaerdID as intRecnum, 
			dbo.tbAehBaBostadsanpassningAatgaerd.recBostadsanpassningID, 
			dbo.tbAehBaBostadsanpassningAatgaerd.strAatgaerd, 
			dbo.tbAehBaBostadsanpassningAatgaerd.strBeskrivning, 
			dbo.tbAehBaBostadsanpassningAatgaerd.strBeslutsutfall, 
			dbo.tbAehBaBostadsanpassningAatgaerd.decBeslutatBelopp, 
			dbo.tbAehBaBostadsanpassningAatgaerd.datDatum, 
			dbo.tbAehBaBostadsanpassningAatgaerd.recHaendelseID, 
			dbo.tbAehAerendeData.strDiarienummer as strAerendeDiarienummer,
			dbo.vwAehHaendelseidentifiering.strHaendelseIdentifiering,
			dbo.tbAehAerendeData.recAerendeID,
			
			(select SUM(ISNULL(decBelopp,0)) 
            from tbAehBaBostadsanpassningUtbetalningAatgaerd as tb 
            where tb.recBostadsanpassningAatgaerdID = tbAehBaBostadsanpassningAatgaerd.recBostadsanpassningAatgaerdID) as decTotaltUtbetalt ,
            
            ( decBeslutatBelopp - ISNULL((select SUM(ISNULL(decBelopp,0)) 
            from tbAehBaBostadsanpassningUtbetalningAatgaerd as tb 
            where tb.recBostadsanpassningAatgaerdID = tbAehBaBostadsanpassningAatgaerd.recBostadsanpassningAatgaerdID), 0))  as decKvarAttBetalaUt
			
	                      
            
FROM        dbo.tbAehBaBostadsanpassningAatgaerd
		LEFT JOIN	dbo.tbAehBaBostadsanpassning 
			ON dbo.tbAehBaBostadsanpassningAatgaerd.recBostadsanpassningID = dbo.tbAehBaBostadsanpassning.recBostadsanpassningID
		LEFT JOIN	dbo.tbAehAerendeData
			ON dbo.tbAehBaBostadsanpassning.recAerendeID = dbo.tbAehAerendeData.recAerendeID
		LEFT OUTER JOIN dbo.vwAehHaendelseidentifiering
		  ON dbo.vwAehHaendelseidentifiering.recHaendelseID = tbAehBaBostadsanpassningAatgaerd.recHaendelseID


go

