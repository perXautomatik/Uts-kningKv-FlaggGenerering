

CREATE VIEW [dbo].[vwTrRnMaetning]
AS
SELECT
	dbo.tbTrRnMaetning.recMaetningID,
  dbo.tbTrRnMaetning.recMaetningID AS intRecnum,
	dbo.tbTrRnMaetning.recByggnadsID,
	dbo.tbTrRnMaetning.strMaetAdress,
	dbo.tbTrRnMaetning.strOrt,
	dbo.tbTrRnMaetning.strLaegenhetsNr,
	dbo.tbTrRnMaetning.strAnnatLaegenhetsNr,
	dbo.tbTrRnMaetning.datStartDatum,
	dbo.tbTrRnMaetning.datStoppDatum,
	dbo.tbTrRnMaetning.strMaettid,
	dbo.tbTrRnMaetning.strMaetMetod,
	dbo.tbTrRnMaetning.strMaetAnsvarig,
	dbo.tbTrRnMaetning.strMaetIdentitet,
	dbo.tbTrRnMaetning.strMvTecken,
	dbo.tbTrRnMaetning.intAarsMedelvaerde,
	dbo.tbTrRnMaetning.strSystemFel,
	dbo.tbTrRnMaetning.strEnhet,
	dbo.tbTrRnMaetning.strLaboratorium,
	dbo.tbTrRnMaetning.strOevrigt,
	dbo.tbTrRnMaetning.strVariation,
	dbo.tbTrRnMaetning.recTillsynsobjektID,
	dbo.tbTrRnMaetning.strTillfaelligtFel,
	
	dbo.tbTrTillsynsobjektFastighet.strFnrID,
	dbo.tbVisDeladFastighet.strFastighetsbeteckning,
	tbTrRnMaetningEnstakaKontakt.recEnstakaKontaktID AS recEnstakaKontaktID,
	dbo.tbVisEnstakaKontakt.strVisasSom as strHuvudKontaktNamn,
	tbTrTillsynsobjekt.strObjektsNamn, 
	tbtrTillsynsobjekt.recTillsynsobjektTypID, 
	tbTrRnByggnad.strByggnad

FROM dbo.tbTrRnMaetning
LEFT OUTER JOIN tbTrRnByggnad
  ON tbTrRnByggnad.recByggnadsID = tbTrRnMaetning.recBYggnadsID
LEFT OUTER JOIN tbTrTillsynsobjektFastighet  
  ON tbTrTillsynsobjektFastighet.recTillsynsobjektID = tbTrRnMaetning.recTillsynsobjektID
  AND tbTrTillsynsobjektFastighet.bolHuvudfastighet = 1
LEFT OUTER JOIN dbo.tbVisDeladFastighet
  ON tbVisDeladFastighet.strFnrID = tbTrTillsynsobjektFastighet.strFnrID
LEFT OUTER JOIN dbo.tbTrRnMaetningEnstakaKontakt
  ON dbo.tbTrRnMaetningEnstakaKontakt.recMaetningID = dbo.tbTrRnMaetning.recMaetningID 
  AND dbo.tbTrRnMaetningEnstakaKontakt.bolHuvudkontakt = 1
LEFT OUTER JOIN dbo.tbVisEnstakaKontakt 
  ON dbo.tbVisEnstakaKontakt.recEnstakaKontaktID = dbo.tbTrRnMaetningEnstakaKontakt.recEnstakaKontaktID
LEFT OUTER JOIN tbTrTillsynsobjekt
  ON tbTrTillsynsobjekt.recTillsynsobjektID = tbTrRnMaetning.recTillsynsobjektID

go

