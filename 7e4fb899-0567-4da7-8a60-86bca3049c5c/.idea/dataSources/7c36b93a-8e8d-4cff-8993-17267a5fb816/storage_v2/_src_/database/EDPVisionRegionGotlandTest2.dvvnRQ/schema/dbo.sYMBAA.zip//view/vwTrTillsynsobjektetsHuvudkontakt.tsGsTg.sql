
CREATE VIEW [dbo].[vwTrTillsynsobjektetsHuvudkontakt]
AS
SELECT
  tbTrTillsynsobjektDeladKontakt.recTillsynsObjektDeladKontaktID,
  tbTrTillsynsobjektDeladKontakt.recTillsynsobjektID,
  tbTrTillsynsobjektDeladKontakt.recTillsynsobjektID AS intRecnum,
  tbTrTillsynsobjektDeladKontakt.strRoll,
  tbVisDeladKontakt.*,
  LTRIM(tbVisDeladKontakt.strFoernamn + ' ' + tbVisDeladKontakt.strEfternamn) AS strNamn, 
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisDeladKontaktKommunikationssaett
      ON tbVisDeladKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recDeladKontaktID = tbVisDeladKontakt.recdeladKontaktID 
      AND strKommunikationsaettTyp = 'E-Post'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisDeladKontakt
    WHERE recDeladKontaktID = tbTrTillsynsobjektDeladKontakt.recDeladKontaktID) AS strEpost,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisDeladKontaktKommunikationssaett
      ON tbVisDeladKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recDeladKontaktID = tbVisDeladKontakt.recdeladKontaktID 
      AND strKommunikationsaettTyp = 'Fax'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisDeladKontakt
    WHERE recDeladKontaktID = tbTrTillsynsobjektDeladKontakt.recDeladKontaktID) AS strFax,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisDeladKontaktKommunikationssaett
      ON tbVisDeladKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recDeladKontaktID = tbVisDeladKontakt.recdeladKontaktID 
      AND strKommunikationsaettTyp = 'Telefon'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisDeladKontakt
    WHERE recDeladKontaktID = tbTrTillsynsobjektDeladKontakt.recDeladKontaktID) AS strTelefon,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisDeladKontaktKommunikationssaett
      ON tbVisDeladKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recDeladKontaktID = tbVisDeladKontakt.recdeladKontaktID 
      AND strKommunikationsaettTyp = 'Mobil'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisDeladKontakt
    WHERE recDeladKontaktID = tbTrTillsynsobjektDeladKontakt.recDeladKontaktID) AS strMobil 
FROM tbTrTillsynsobjektDeladKontakt
LEFT OUTER JOIN tbVisDeladKontakt
ON tbVisDeladKontakt.recDeladKontaktID = tbTrTillsynsobjektDeladKontakt.recDeladKontaktID
WHERE tbTrTillsynsobjektDeladKontakt.bolHuvudkontaktperson = 1
AND strRoll = 'Kontaktperson'
go

