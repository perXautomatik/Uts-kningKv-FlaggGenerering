
            CREATE VIEW [dbo].[vwEDPNote]
            AS
            SELECT tbEDPNote.strTableName, tbEDPNote.intFrameworkID, tbEDPNote.intUserID, 
              tbEDPNote.datLastSaved, tbEDPNote.strCaption, tbEDPNote.strText, 
              tbEDPNote.intRecnum, tbEDPNote.datSkapad, tbEDPNote.strSkapadAv, 
              ISNULL(LastSavedUser.strUserFirstname + ' ', '') + LastSavedUser.strUserSurName AS UserName,
              LastSavedUser.strSignature AS strSignature, CreatedUser.strSignature AS CreatedSignature,
              ISNULL(CreatedUser.strUserFirstname + ' ', '') + CreatedUser.strUserSurName AS CreatedUserName,
              datNoteDate
            FROM tbEDPNote 
            INNER JOIN tbEDPUser AS CreatedUser ON tbEDPNote.intSkapadAv = CreatedUser.intUserID
            LEFT JOIN tbEDPUser AS LastSavedUser ON tbEDPNote.intUserID = LastSavedUser.intUserID
            go

