

CREATE VIEW [dbo].[vwAehAerendetsHuvudfastighet]
AS
SELECT tbAehAerendeEnstakaFastighet.recAerendeID,
  tbAehAerendeEnstakaFastighet.recAerendeEnstakaFastighetID,
  tbAehAerendeEnstakaFastighet.recFastighetID,
  vwVisEnstakaFastighet.strFnrID,
  vwVisEnstakaFastighet.strTrakt,
  vwVisEnstakaFastighet.strBlock,
  vwVisEnstakaFastighet.strTkn,
  vwVisEnstakaFastighet.intEnhet,
  vwVisEnstakaFastighet.strFastighetsbeteckning,
  vwVisEnstakaFastighet.strAdress,
  vwVisEnstakaFastighet.strPostnr,
  vwVisEnstakaFastighet.strPostort,
  vwVisEnstakaFastighet.strKommunNamn

FROM tbAehAerendeEnstakaFastighet
INNER JOIN vwVisEnstakaFastighet
  ON vwVisEnstakaFastighet.recFastighetID = tbAehAerendeEnstakaFastighet.recFastighetID
WHERE tbAehAerendeEnstakaFastighet.bolHuvudfastighet = 1

go

