
CREATE PROCEDURE [dbo].[spEDPGetMenuRootItems] AS
select * from tbEDPMenuItem where intParentID is NULL
order by intitemorder
return
go

