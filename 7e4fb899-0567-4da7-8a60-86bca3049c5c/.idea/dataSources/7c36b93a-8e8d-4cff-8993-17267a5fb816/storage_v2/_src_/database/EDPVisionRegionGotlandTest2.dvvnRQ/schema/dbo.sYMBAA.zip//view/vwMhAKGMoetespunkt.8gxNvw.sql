
            CREATE VIEW vwMhAKGMoetespunkt AS
            SELECT DISTINCT tbMhMoetespunkt.recMoetespunktID
                , tbMhMoetespunkt.intParagrafnummer
                , tbMhMoetespunkt.intOrdningsnummer
                , tbMhMoetespunkt.strMoetespunktRubrik
                , tbMhMoetespunkt.recMoeteID
                , tbMhMoetespunkt.strBeslut
                , tbMhMoetespunkt.strDelges
                , tbMhMoetespunkt.recMoetespunktID AS intRecnum
                , tbMhUtfall.guidUtfall
                , tbMhUtfall.recUtfallID
                , tbMhUtfall.strUtfall
                , u.strSignature
                , u.recHandlaeggareID, u.strFullName
                , u.strUserSurName, u.strUserFirstname
                , tbMhMoetespunkt.bolParagrafKraevs
                , vwMhMoete.strMoete
                , vwMhMoete.strOrgannamn
                , vwMhMoete.recOrganID
                , vwMhMoete.datMoetesDatum
                , vwMhMoete.strStarttid
                , tbMhMoetespunkt.strBeslutstextFoerslag
                , tbMhMoetespunkt.strAnteckning
                , tbMhMoetespunkt.intAntalFiler 
            FROM tbMhMoetespunkt 
            LEFT OUTER JOIN vwMhMoete 
              ON tbMhMoetespunkt.recMoeteID = vwMhMoete.recMoeteID 
            LEFT OUTER JOIN tbMhUtfall 
              ON tbMhMoetespunkt.recUtfallID = tbMhUtfall.recUtfallID 
            LEFT OUTER JOIN vwVisHandlaeggareEDPUser AS u 
              ON tbMhMoetespunkt.recHandlaeggareID = u.recHandlaeggareID
            go

