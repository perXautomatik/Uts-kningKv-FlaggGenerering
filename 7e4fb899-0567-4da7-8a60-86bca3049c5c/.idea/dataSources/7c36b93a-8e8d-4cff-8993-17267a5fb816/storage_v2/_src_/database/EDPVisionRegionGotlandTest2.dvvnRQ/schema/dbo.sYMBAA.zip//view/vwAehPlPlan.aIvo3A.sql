
CREATE VIEW [dbo].[vwAehPlPlan]
AS
SELECT
  recPlanID,
  recPlanID AS intRecnum,
	strAktbeteckning,
  strAktbeteckningLmm,
	strPlannamn,
  strPlanbeskrivning,
	strPlantyp,
	intUserIDUppraettadAv,
	[datUppraettad],
	[dbo].[tbEDPUser].[strSignature],
	[dbo].[tbEDPUser].[intUserID]
FROM [dbo].[tbAehPlPlan]
LEFT OUTER JOIN [dbo].[tbEDPUser]
  ON [dbo].[tbEDPUser].[intUserID] = [dbo].[tbAehPlPlan].[intUserIDUppraettadAv]
go

