
CREATE VIEW [dbo].[vwVisEnstakaFastighetAdress]
AS
SELECT     
	dbo.tbVisEnstakaFastighetAdress.recEnstakaFastighetAdressID, 
	dbo.tbVisEnstakaFastighetAdress.strAdress, 
    dbo.tbVisEnstakaFastighetAdress.strPostort, 
    dbo.tbVisEnstakaFastighetAdress.recFastighetID, 
    dbo.tbVisEnstakaFastighetAdress.recEnstakaFastighetAdressID AS intRecnum, 
    dbo.tbVisEnstakaFastighetAdress.strPostnr, 
    
    dbo.tbVisEnstakaFastighet.strFnrID,
    dbo.tbVisEnstakaFastighet.strBlock, 
	dbo.tbVisEnstakaFastighet.strTkn, 
	dbo.tbVisEnstakaFastighet.intEnhet, 
    dbo.tbVisEnstakaFastighet.strTrakt,
    dbo.tbVisEnstakaFastighet.strFastighetsbeteckning
        
FROM dbo.tbVisEnstakaFastighet 

RIGHT OUTER JOIN dbo.tbVisEnstakaFastighetAdress 
	ON dbo.tbVisEnstakaFastighet.recFastighetID = dbo.tbVisEnstakaFastighetAdress.recFastighetID

go

