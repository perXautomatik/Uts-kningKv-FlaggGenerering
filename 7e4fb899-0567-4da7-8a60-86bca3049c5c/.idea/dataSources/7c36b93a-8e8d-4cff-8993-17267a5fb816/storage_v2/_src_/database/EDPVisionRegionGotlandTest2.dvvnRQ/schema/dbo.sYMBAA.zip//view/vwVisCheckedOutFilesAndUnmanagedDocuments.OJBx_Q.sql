
CREATE VIEW [dbo].[vwVisCheckedOutFilesAndUnmanagedDocuments]
AS
	SELECT 'Utcheckad' AS strStatus
	,(
		SELECT REVERSE(SUBSTRING(REVERSE(dbo.vwEDPFileObject.strCheckedOutFileName), 0, CHARINDEX('\', REVERSE(dbo.vwEDPFileObject.strCheckedOutFileName))))
		) AS strFileName
	,dbo.vwEDPFileObject.strCheckedOutFileName AS strFilePath
	,dbo.vwEDPFileObject.recFileObjectID AS recID
	,NULL AS recHaendelseID
	,NULL AS recMoetespunktID
	,NULL AS recMoeteID
	,dbo.vwEDPFileObject.datCheckOutDateTime AS datLastFileVersionDate
	,dbo.tbEDPUser.intUserID
	,dbo.tbEDPUser.strSignature
    ,NULL AS bolMassbrev
FROM dbo.vwEDPFileObject
INNER JOIN dbo.tbEDPUser ON dbo.vwEDPFileObject.intUserID = dbo.tbEDPUser.intUserID
WHERE dbo.vwEDPFileObject.bolCheckedOut = 1 AND dbo.vwEDPFileObject.recFileObjectID NOT IN (SELECT recFileObjectID FROM tbVisFilmall WHERE recFileObjectID IS NOT NULL)

UNION ALL

SELECT 'Ej inlagrad' AS strStatus
	,dbo.tbEDPFileUnmanagedFiles.strFileName
	,dbo.tbEDPFileUnmanagedFiles.strFullFilePath AS strFilePath
	,dbo.tbEDPFileUnmanagedFiles.recUnmanagedfileID AS recID
	,dbo.tbEDPFileUnmanagedFiles.recHaendelseID
	,dbo.tbEDPFileUnmanagedFiles.recMoetespunktID
	,dbo.tbEDPFileUnmanagedFiles.recMoeteID
	,dbo.tbEDPFileUnmanagedFiles.datDatum AS datLastFileVersionDate
	,tbEDPUser.intUserID
	,tbEDPUser.strSignature
    ,dbo.tbEDPFileUnmanagedFiles.bolMassbrev
FROM dbo.tbEDPFileUnmanagedFiles
INNER JOIN dbo.tbEDPUser ON dbo.tbEDPFileUnmanagedFiles.intUserID = dbo.tbEDPUser.intUserID
WHERE dbo.tbEDPFileUnmanagedFiles.recFilmallID IS NULL



go

