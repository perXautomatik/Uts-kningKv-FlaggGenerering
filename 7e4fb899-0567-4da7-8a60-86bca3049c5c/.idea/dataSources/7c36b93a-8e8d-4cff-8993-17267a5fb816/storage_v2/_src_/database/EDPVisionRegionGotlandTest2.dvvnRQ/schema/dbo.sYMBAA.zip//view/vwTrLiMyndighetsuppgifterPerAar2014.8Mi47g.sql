


-- 20 kolumner

CREATE VIEW [dbo].[vwTrLiMyndighetsuppgifterPerAar2014]
AS
SELECT  	tbTrLiMyndighetsuppgifterPerAar2014.recMyndighetsuppgifterPerAar2014ID AS intRecNum,
			tbTrLiMyndighetsuppgifterPerAar2014.recMyndighetsuppgifterPerAar2014ID,
			tbTrLiMyndighetsuppgifterPerAar2014.recMyndighetsuppgifterID,
			tbTrLiMyndighetsuppgifterPerAar2014.intAar,
			tbTrLiMyndighetsuppgifterPerAar2014.intLivAvgiftGodkaennande,
			tbTrLiMyndighetsuppgifterPerAar2014.intTimtaxaExtraOffentligKontroll,
			tbTrLiMyndighetsuppgifterPerAar2014.intTimtaxaPlaneradKontroll,
			tbTrLiMyndighetsuppgifterPerAar2014.strLaboratorium,
			tbTrLiMyndighetsuppgifterPerAar2014.strProvtagning,
			tbTrLiMyndighetsuppgifterPerAar2014.strRiskklassning,
			tbTrLiMyndighetsuppgifterPerAar2014.intLivAarligKontrollavgift,
			tbTrLiMyndighetsuppgifterPerAar2014.intLivAvgiftExtraOffentligKontroll,
			tbTrLiMyndighetsuppgifterPerAar2014.intLivAvgiftRegistrering,
			tbTrLiMyndighetsuppgifterPerAar2014.decLivAntalAarsArbetskrafter,
			tbTrLiMyndighetsuppgifterPerAar2014.decLivResursbehov,
			tbTrLiMyndighetsuppgifterPerAar2014.intDrickAarligKontrollavgift,
			tbTrLiMyndighetsuppgifterPerAar2014.intDrickAvgiftExtraOffentligKontroll,
			tbTrLiMyndighetsuppgifterPerAar2014.intDrickAvgiftRegistrering,
			tbTrLiMyndighetsuppgifterPerAar2014.decDrickAntalAarsArbetskrafter,
			tbTrLiMyndighetsuppgifterPerAar2014.decDrickResursbehov,
			tbTrLiMyndighetsuppgifter.strMyndighetskod, 
			tbTrLiMyndighetsuppgifter.strMyndighetsnamn,
            tbTrLiMyndighetsuppgifter.strEpost, 
            tbVisLaen.strLaensNamn,
            tbTrLiMyndighetsuppgifter.strMyndighetstyp

FROM		tbTrLiMyndighetsuppgifterPerAar2014 
INNER JOIN	tbTrLiMyndighetsuppgifter 
ON			tbTrLiMyndighetsuppgifter.recMyndighetsuppgifterID = tbTrLiMyndighetsuppgifterPerAar2014.recMyndighetsuppgifterID
LEFT JOIN	tbVisLaen ON tbVisLaen.recLaenID = tbTrLiMyndighetsuppgifter.recLaenID



go

