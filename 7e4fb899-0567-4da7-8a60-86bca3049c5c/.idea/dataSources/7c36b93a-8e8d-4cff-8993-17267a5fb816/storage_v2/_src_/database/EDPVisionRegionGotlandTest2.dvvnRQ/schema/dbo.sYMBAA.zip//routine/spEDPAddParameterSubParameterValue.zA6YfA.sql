



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
Create PROCEDURE [dbo].[spEDPAddParameterSubParameterValue]
	-- Add the parameters for the stored procedure here
	@intParameterID int,
	@intSubParameterID int,
	@strSubParameterValue varchar(200),
	@strValue varchar(200),
	@intGroupID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
INSERT INTO tbEDPParameterSubParameterValue(
	intParameterID,
	intSubParameterID,
	strSubParameterValue,
  strValue,
  intGroupID)
VALUES (
	@intParameterID,
	@intSubParameterID,
	@strSubParameterValue,
  @strValue,
  @intGroupID)
END

go

