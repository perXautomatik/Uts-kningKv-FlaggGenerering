
       CREATE TRIGGER TRG_tbAehDiarieSerie_UPDATE
       ON tbAehDiarieSerie
       AFTER UPDATE
       AS
       BEGIN
       SET NOCOUNT ON;

       DECLARE @strDiarieSerieKod AS VARCHAR(6),
       @recDiarieAarsSerieId AS INTEGER,
       @recDiarieSerieID AS INTEGER,
       @recAerendeID AS INTEGER,
       @recHaendelseID AS INTEGER,
       @i AS INTEGER,
       @RecordCount AS INTEGER;
       DECLARE @Aerenden TABLE(
	       rowID INTEGER IDENTITY(1, 1), 
	       recAerendeID INTEGER,
		   recDiarieSerieID INTEGER
       )
       DECLARE @Haendelser TABLE(
	       rowID INTEGER IDENTITY(1, 1), 
	       recHaendelseID INTEGER,
		   recDiarieAarsSerieID INTEGER
       )
       DECLARE @DiarieSerier TABLE(
           rowID INTEGER IDENTITY(1,1),
           recDiarieSerieID INTEGER,
           strDiarieSerieKod VARCHAR(6)
       )
       IF NOT UPDATE(strDiarieSerieKod) RETURN;

       INSERT INTO @DiarieSerier
       SELECT inserted.recDiarieSerieID, inserted.strDiarieSerieKod FROM inserted; 

       INSERT INTO @Aerenden
       SELECT recAerendeID, recDiarieSerieID FROM tbAehAerendeData
       WHERE tbAehAerendeData.recDiarieSerieID IN (SELECT recDiarieSerieID FROM @DiarieSerier)

       SET @RecordCount = @@ROWCOUNT
       SET @i = 1
       WHILE (@i <= @RecordCount)
       BEGIN
	     SELECT @recAerendeID = recAerendeID, @recDiarieSerieID = recDiarieSerieID FROM @Aerenden WHERE rowID = @i;
         SELECT @strDiarieSerieKod = strDiarieSerieKod FROM @DiarieSerier WHERE recDiarieSerieID = @recDiarieSerieID

         UPDATE tbAehAerendeData
         SET strDiarieSerieKod = @strDiarieSerieKod
         WHERE tbAehAerendeData.recAerendeID = @recAerendeID
	
         UPDATE tbAehAerende
         SET strDiarienummerSerie = @strDiarieSerieKod
         WHERE tbAehAerende.recAerendeID = @recAerendeID

         SET @i = @i + 1
       END

       INSERT INTO @Haendelser 
       -- Hämta diarieseriekoden från postlistafältet, dvs. De första x tecknen där x = längden på den föregående diariekoden
       -- jämför sedan denna sträng med värdet som ändrats för att kontrollera om vi ska uppdatera händelsens postlista
       SELECT recHaendelseID, recDiarieAarsSerieID FROM vwAehHaendelse WHERE REPLACE(LEFT(strTillhoerPostlista, CHARINDEX('-', strTillhoerPostlista)), '-', '') IN 
	   (SELECT strDiarieSerieKod FROM deleted)

       SET @RecordCount = @@ROWCOUNT
       SET @i = 1
	       WHILE (@i <= @RecordCount)
	       BEGIN
	        SELECT @recHaendelseID = recHaendelseID, @recDiarieAarsSerieId = recDiarieAarsSerieID from @Haendelser WHERE rowID = @i

	        EXECUTE spAehHaendelseUpdatePostlista @recHaendelseID, @recDiarieAarsSerieId
	        SET @i = @i + 1
	       END
       END
       go

