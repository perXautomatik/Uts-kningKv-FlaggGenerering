
CREATE VIEW [dbo].[vwVisMeddelande]
AS
SELECT    recMeddelandeID
		, recMeddelandeID as intRecnum
		, tbVisMeddelande.recAerendeid
		, tbVisMeddelande.recHaendelseID
		, tbVisMeddelande.datDatum
		, strMall
		, strKommunikationstjaenst
		, tbVisMeddelande.strRubrik
		, strMeddelandetext
		, bolSkickad
		, tbAehAerendeData.strDiarienummer
		, vwAehHaendelse.strHaendelseIdentifiering
FROM dbo.tbVisMeddelande

LEFT OUTER JOIN tbAehAerendeData
  ON tbAehAerendeData.recAerendeID = tbVisMeddelande.recAerendeID
LEFT OUTER JOIN vwAehHaendelse
  ON vwAehHaendelse.recHaendelseID = tbVisMeddelande.recHaendelseID
go

