
CREATE PROC dbo.SPEDPGetIdentityColumnName
@inTableName varchar(100),
@outColumnName varchar(100) output
as
/* Denna sp returnerar namnet på identitykolumnen i tabellen med inskickat namn
   Av Arvid Dellien, 2005-11-28, EDP Consult AB 
   tillägg: kolla om det är en tabell, om inte är det en vy och då antar vi att kolumnen heter intRecnum */
if exists(SELECT * from sysobjects where name = @inTablename and xtype = 'U')
begin
  set @outColumnName = (select name from syscolumns where id = OBJECT_ID(@inTableName)
  and COLUMNPROPERTY( OBJECT_ID(@inTableName),name,'IsIdentity') = 1)
end
else
begin
  set @outColumnName = ('intRecnum')
end
  return
go

