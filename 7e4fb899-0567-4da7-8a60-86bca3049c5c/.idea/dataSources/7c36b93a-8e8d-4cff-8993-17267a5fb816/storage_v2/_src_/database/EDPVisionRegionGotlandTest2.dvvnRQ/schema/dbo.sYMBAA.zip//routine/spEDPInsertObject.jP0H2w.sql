
CREATE PROCEDURE [dbo].[spEDPInsertObject] 
   (
   @strObjectName varchar(150),
   @strParentObjectName varchar(150) = null,
   @strObjectDescription varchar(150) = null, 
   @strObjectTypeName varchar(50),
   @intSortOrder int = null
   )
AS
  SET NOCOUNT ON 

  declare @intParentObjectID int
  declare @intObjectTypeID int

  IF (@strParentObjectName IS NOT NULL)
  BEGIN
   SELECT @intParentObjectID = (SELECT intObjectID from tbEDPObject where strObjectName = @strParentObjectName)
  END
           
  IF (@intParentObjectID <> 0)
  BEGIN
    IF (@strParentObjectName IS NOT NULL)
    BEGIN
      SELECT @intObjectTypeID = (SELECT intObjectTypeID from tbEDPObjectType where strObjectTypeName = @strObjectTypeName)
      IF (@intObjectTypeID <> 0)
      BEGIN
        insert into tbEDPObject(strObjectName, intParentObjectID, strObjectDescription, intObjectTypeID, intSortOrder) values(@strObjectName, @intParentObjectID, @strObjectDescription, @intObjectTypeID, @intSortOrder)
      END
    END
  END

  RETURN Scope_Identity()
go

