

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell10Hissar]
AS
SELECT        
	recAehPblAvgiftTaxa2011Tb10HissarID,
	recAehPblAvgiftTaxa2011Tb10HissarID as 'intRecnum',
	intHF, 
	strBeskrivning, 
	strAatgaerd, 
	recPblAvgiftTaxa2011Tabell10ID
FROM
    dbo.tbAehPblAvgiftTaxa2011Tabell10Hissar


go

