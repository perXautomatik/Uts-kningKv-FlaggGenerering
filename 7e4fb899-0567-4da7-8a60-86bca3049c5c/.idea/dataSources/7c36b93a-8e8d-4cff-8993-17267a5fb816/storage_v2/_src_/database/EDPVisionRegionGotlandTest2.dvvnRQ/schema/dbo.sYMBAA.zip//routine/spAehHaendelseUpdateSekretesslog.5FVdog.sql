CREATE PROCEDURE [dbo].[spAehHaendelseUpdateSekretesslog]
  @recHaendelseID int
AS
BEGIN
  SET NOCOUNT ON;

  UPDATE dbo.tbAehHaendelse SET recLastHaendelseSekretessLogID = 
    ( SELECT TOP (1) recHaendelseSekretessLogID FROM tbAehHaendelseSekretessLog
      WHERE recHaendelseID = @recHaendelseID
      ORDER BY datDatum DESC
    )
  WHERE recHaendelseID = @recHaendelseID
 
  UPDATE dbo.tbAehHaendelseData SET
    strSekretess = dbo.tbAehHaendelseSekretessLog.strRekommendation, 
    strBegraensa = dbo.tbAehHaendelseSekretessLog.strBegraensa, 
    strSekretessMyndighet = dbo.tbAehHaendelseSekretessLog.strMyndighet, 
    datSekretessDatum = dbo.tbAehHaendelseSekretessLog.datDatum 
  FROM dbo.tbAehHaendelseData
  LEFT OUTER JOIN dbo.tbAehHaendelse
    ON dbo.tbAehHaendelse.recHaendelseID = dbo.tbAehHaendelseData.recHaendelseID 
  LEFT OUTER JOIN dbo.tbAehHaendelseSekretessLog 
    ON dbo.tbAehHaendelseSekretessLog.recHaendelseSekretessLogID = dbo.tbAehHaendelse.recLastHaendelseSekretessLogID 
  WHERE dbo.tbAehHaendelseData.recHaendelseID = @recHaendelseID
END
go

