


CREATE VIEW [dbo].[vwAehHaendelseStatusLogTyp]
AS
SELECT     recHaendelseStatusLogTypID, strHaendelseStatusLogTyp, strHaendelseStatusPresent, strLocalizationCode, bolVisas
FROM         dbo.tbAehHaendelseStatusLogTyp
WHERE     (strLocalizationCode = N'ALLM') OR
                      (strLocalizationCode = N'UB') OR
                      (strLocalizationCode = N'NOT')


go

