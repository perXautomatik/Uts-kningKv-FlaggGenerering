
        CREATE TRIGGER TRG_SetDiarienummer ON tbAehAerende
        AFTER INSERT, UPDATE
        AS
        BEGIN

        IF @@ROWCOUNT = 0
        RETURN

            UPDATE tbAehAerendeData
        SET tbAehAerendeData.strDiarienummer =
        (SELECT TOP 1 strDiarienummerSerie FROM tbAehAerende WHERE recAerendeID = tbAehAerendeData.recAerendeID) + '-' +
        CAST((SELECT TOP 1 vwAehDiarieAarsSerie.intDiarieAar FROM vwAehDiarieAarsSerie WHERE vwAehDiarieAarsSerie.recDiarieAarsSerieID = (SELECT TOP 1 recDiarieAarsSerieID FROM tbAehAerende WHERE recAerendeID = tbAehAerendeData.recAerendeID)) AS varchar(4))
        + '-' + CAST((SELECT TOP 1 intDiarienummerLoepNummer FROM tbAehAerende WHERE recAerendeID = tbAehAerendeData.recAerendeID) AS varchar(6))
            WHERE  tbAehAerendeData.recAerendeID IN (SELECT INSERTED.recAerendeID FROM  INSERTED)

        END
        go

