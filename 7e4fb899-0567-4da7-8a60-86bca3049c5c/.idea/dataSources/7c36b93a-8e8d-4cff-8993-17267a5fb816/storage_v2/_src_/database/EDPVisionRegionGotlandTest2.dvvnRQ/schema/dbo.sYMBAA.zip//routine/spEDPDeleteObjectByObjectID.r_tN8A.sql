
CREATE PROCEDURE dbo.spEDPDeleteObjectByObjectID 
	(
	@intObjectID int
	)
AS
  DELETE FROM tbEDPObject WHERE intObjectID = @intObjectID
	RETURN @@ROWCOUNT

go

