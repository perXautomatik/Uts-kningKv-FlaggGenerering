

CREATE VIEW [dbo].[vwVisDeladFastighetLagfarenAegare]
AS
SELECT     
	dbo.tbVisDeladFastighetLagfarenAegare.recFastighetLagfarenAegareID, 
    dbo.tbVisDeladFastighetLagfarenAegare.recFastighetLagfarenAegareID AS intRecnum, 

    dbo.tbVisDeladFastighetLagfarenAegare.strFnrID, 

	dbo.tbVisDeladFastighetLagfarenAegare.strNamn, 
    dbo.tbVisDeladFastighetLagfarenAegare.strPnr, 
    dbo.tbVisDeladFastighetLagfarenAegare.strCO, 
	dbo.tbVisDeladFastighetLagfarenAegare.strAdress, 
    dbo.tbVisDeladFastighetLagfarenAegare.strAdress2, 
    dbo.tbVisDeladFastighetLagfarenAegare.strPostnr, 
	dbo.tbVisDeladFastighetLagfarenAegare.strOrt, 
    dbo.tbVisDeladFastighetLagfarenAegare.strLand, 
    dbo.tbVisDeladFastighetLagfarenAegare.strFaang, 
	dbo.tbVisDeladFastighetLagfarenAegare.strAndel, 
    dbo.tbVisDeladFastighetLagfarenAegare.strKommun, 
    
    dbo.tbVisDeladFastighet.strBlock, 
	dbo.tbVisDeladFastighet.strTkn, 
	dbo.tbVisDeladFastighet.intEnhet, 
    dbo.tbVisDeladFastighet.strTrakt,
    dbo.tbVisDeladFastighet.strFastighetsbeteckning
        
FROM dbo.tbVisDeladFastighetLagfarenAegare
LEFT OUTER JOIN  dbo.tbVisDeladFastighet 
	ON dbo.tbVisDeladFastighet.strFnrID = dbo.tbVisDeladFastighetLagfarenAegare.strFnrID

go

