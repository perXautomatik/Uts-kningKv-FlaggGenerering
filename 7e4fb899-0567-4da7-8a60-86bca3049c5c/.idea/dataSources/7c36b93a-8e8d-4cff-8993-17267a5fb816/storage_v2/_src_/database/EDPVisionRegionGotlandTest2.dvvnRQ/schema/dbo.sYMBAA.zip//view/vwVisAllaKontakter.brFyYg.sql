CREATE VIEW dbo.vwVisAllaKontakter AS
WITH AllaKontakter AS (
	SELECT strVisasSom FROM dbo.tbVisEnstakaKontakt
	UNION
	SELECT strVisasSom FROM dbo.tbVisDeladKontakt
)
SELECT DISTINCT ROW_NUMBER() OVER(ORDER BY strVisasSom) AS intRecNum, strVisasSom FROM AllaKontakter
go

