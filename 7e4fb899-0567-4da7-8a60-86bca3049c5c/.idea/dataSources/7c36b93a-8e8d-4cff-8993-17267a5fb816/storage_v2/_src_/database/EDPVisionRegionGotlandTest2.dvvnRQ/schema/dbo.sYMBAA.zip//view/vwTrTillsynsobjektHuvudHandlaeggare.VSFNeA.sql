CREATE VIEW [dbo].[vwTrTillsynsobjektHuvudHandlaeggare]
AS
SELECT tbTrTillsynsobjektUser.recTrTillsynsobjektUserID,
  tbTrTillsynsobjektUser.recTillsynsobjektID,
  tbTrTillsynsobjektUser.intUserID,
  vwVisHandlaeggareEDPUser.intRecnum,
  vwVisHandlaeggareEDPUser.strUserWindowsAccount,
  vwVisHandlaeggareEDPUser.strSignature,
  vwVisHandlaeggareEDPUser.strUserSurName,
  vwVisHandlaeggareEDPUser.strUserFirstName,
  vwVisHandlaeggareEDPUser.strFullName,
  vwVisHandlaeggareEDPUser.strEmail,
  vwVisHandlaeggareEDPUser.strTelephone,
  vwVisHandlaeggareEDPUser.strTelephone2,
  vwVisHandlaeggareEDPUser.strBefattning

FROM tbTrTillsynsobjektUser 
LEFT OUTER JOIN vwVisHandlaeggareEDPUser
ON vwVisHandlaeggareEDPUser.intUserID = tbTrTillsynsobjektUser.intUserID
WHERE tbTrTillsynsobjektUser.bolHuvudhandlaeggare = 1
go

