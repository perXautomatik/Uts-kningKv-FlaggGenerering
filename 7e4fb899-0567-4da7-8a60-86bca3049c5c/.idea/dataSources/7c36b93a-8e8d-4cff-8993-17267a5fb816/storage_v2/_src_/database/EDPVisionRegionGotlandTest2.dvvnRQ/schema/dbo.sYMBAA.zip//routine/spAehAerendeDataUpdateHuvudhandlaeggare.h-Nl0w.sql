
CREATE PROCEDURE [dbo].[spAehAerendeDataUpdateHuvudhandlaeggare]
  @recAerendeID int
AS
BEGIN
  SET NOCOUNT ON;
  
  UPDATE tbAehAerendeData SET
    strSignature = dbo.tbEDPUser.strSignature,
    intUserID = dbo.tbEDPUser.intUserID
  FROM tbAehAerendeData
  LEFT OUTER JOIN tbAehAerendeUser
    ON tbAehAerendeUser.recAerendeID = tbAehAerendeData.recAerendeID
    AND tbAehAerendeUser.bolHuvudhandlaeggare = 1
  LEFT OUTER JOIN dbo.tbEDPUser 
    ON dbo.tbAehAerendeUser.intUserID = dbo.tbEDPUser.intUserID
  WHERE tbAehAerendeData.recAerendeID = @recAerendeID
END
go

