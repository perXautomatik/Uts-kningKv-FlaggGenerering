

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spEDPGetParameterSubParameterValue] 
  @strParameterName varchar(200)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
select intSubParameterID,
  strSubParameterName,
  strSubParameterValue,
  strValue,
  intGroupID,
  strValueTypeName,
  intSubParameterPriority,
  strSearchMethodName
from vwEDPParameterSubParameterValue 
where strParameterName = @strParameterName
END

go

