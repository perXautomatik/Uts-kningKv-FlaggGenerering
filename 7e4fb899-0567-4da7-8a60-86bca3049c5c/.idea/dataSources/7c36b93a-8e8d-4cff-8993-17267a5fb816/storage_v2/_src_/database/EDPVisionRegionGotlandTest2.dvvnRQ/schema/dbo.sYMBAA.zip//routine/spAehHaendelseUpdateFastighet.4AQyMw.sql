
CREATE PROCEDURE [dbo].[spAehHaendelseUpdateFastighet]
  @recHaendelseID int
AS
BEGIN
  SET NOCOUNT ON;

  UPDATE dbo.tbAehHaendelseData SET
    strFastighetsbeteckning = dbo.tbVisEnstakaFastighet.strFastighetsbeteckning, 
    strFnrID = dbo.tbVisEnstakaFastighet.strFnrID,
    guidFastighetUuid = dbo.tbVisEnstakaFastighet.guidUuid,
    recFastighetID = dbo.tbVisEnstakaFastighet.recFastighetID
  FROM dbo.tbAehHaendelseData
  LEFT OUTER JOIN dbo.tbAehHaendelseEnstakaFastighet
     ON dbo.tbAehHaendelseEnstakaFastighet.recHaendelseID = dbo.tbAehHaendelseData.recHaendelseID 
     AND dbo.tbAehHaendelseEnstakaFastighet.bolHuvudfastighet = 1
  LEFT OUTER JOIN dbo.tbVisEnstakaFastighet 
     ON dbo.tbAehHaendelseEnstakaFastighet.recFastighetID = dbo.tbVisEnstakaFastighet.recFastighetID 
  WHERE dbo.tbAehHaendelseData.recHaendelseID = @recHaendelseID

  IF EXISTS(SELECT tbAehHaendelseEnstakaFastighet.recFastighetID FROM dbo.tbAehHaendelseEnstakaFastighet
		LEFT OUTER JOIN tbAehHaendelse
			ON dbo.tbAehHaendelseEnstakaFastighet.recHaendelseID = dbo.tbAehHaendelse.recHaendelseID 
			AND dbo.tbAehHaendelseEnstakaFastighet.bolHuvudfastighet = 1
		LEFT OUTER JOIN dbo.tbVisEnstakaFastighet 
			ON dbo.tbAehHaendelseEnstakaFastighet.recFastighetID = dbo.tbVisEnstakaFastighet.recFastighetID 
		WHERE dbo.tbAehHaendelse.recHaendelseID = @recHaendelseID)
  BEGIN
      UPDATE dbo.tbAehHaendelse SET
      recKommunID = tbVisEnstakaFastighet.recKommunID
      FROM tbAehHaendelse
      LEFT OUTER JOIN dbo.tbAehHaendelseEnstakaFastighet
         ON dbo.tbAehHaendelseEnstakaFastighet.recHaendelseID = dbo.tbAehHaendelse.recHaendelseID 
         AND dbo.tbAehHaendelseEnstakaFastighet.bolHuvudfastighet = 1
      LEFT OUTER JOIN dbo.tbVisEnstakaFastighet 
         ON dbo.tbAehHaendelseEnstakaFastighet.recFastighetID = dbo.tbVisEnstakaFastighet.recFastighetID 
      WHERE dbo.tbAehHaendelse.recHaendelseID = @recHaendelseID

  END
END
go

