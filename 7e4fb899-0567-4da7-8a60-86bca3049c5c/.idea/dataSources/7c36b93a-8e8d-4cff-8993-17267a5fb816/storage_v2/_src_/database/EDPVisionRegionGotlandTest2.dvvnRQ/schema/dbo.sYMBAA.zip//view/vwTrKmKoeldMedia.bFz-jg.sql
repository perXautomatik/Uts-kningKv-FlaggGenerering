
CREATE VIEW [dbo].[vwTrKmKoeldMedia]
AS
SELECT DISTINCT dbo.tbTrKmAggregat.recTillsynsobjektID AS intRecnum,
                             (SELECT        SUM(decInstalleradMaengd) AS Expr1
                               FROM            dbo.tbTrKmAggregat AS tbAggregat
                               WHERE        (strKoeldmedieTyp = 'HFC') AND (strStatus = 'i bruk') AND (recTillsynsobjektID = dbo.tbTrKmAggregat.recTillsynsobjektID)) AS decHFC,
                             (SELECT        SUM(decInstalleradMaengd) AS Expr1
                               FROM            dbo.tbTrKmAggregat AS tbAggregat
                               WHERE        (strKoeldmedieTyp = 'HCFC') AND (strStatus = 'i bruk') AND (recTillsynsobjektID = dbo.tbTrKmAggregat.recTillsynsobjektID)) AS decHCFC,
                             (SELECT        SUM(decInstalleradMaengd) AS Expr1
                               FROM            dbo.tbTrKmAggregat AS tbAggregat
                               WHERE        (strKoeldmedieTyp = 'CFC') AND (strStatus = 'i bruk') AND (recTillsynsobjektID = dbo.tbTrKmAggregat.recTillsynsobjektID)) AS decCFC,
                             (SELECT        SUM(decInstalleradMaengd) AS Expr1
                               FROM            dbo.tbTrKmAggregat AS tbAggregat
                               WHERE        (strStatus = 'i bruk') AND (recTillsynsobjektID = dbo.tbTrKmAggregat.recTillsynsobjektID)) AS decTotalt,
                             (SELECT        SUM(decInstalleradMaengd) AS Expr1
                               FROM            dbo.tbTrKmAggregat AS tbAggregat
                               WHERE        (strStatus = 'i bruk') AND (decInstalleradMaengd >= 3) AND (bolHermetisktSystem = 0) AND 
                                                         (recTillsynsobjektID = dbo.tbTrKmAggregat.recTillsynsobjektID) OR
                                                         (strStatus = 'i bruk') AND (decInstalleradMaengd >= 6) AND (bolHermetisktSystem = 1) AND 
                                                         (recTillsynsobjektID = dbo.tbTrKmAggregat.recTillsynsobjektID)) AS decTotaltInstalleradMaengd2016,
                             (SELECT        SUM(decCO2e) AS Expr1
                               FROM            dbo.tbTrKmAggregat AS tbAggregat
                               WHERE        (strStatus = 'i bruk') AND (intKontrollIntervall > 0) AND (recTillsynsobjektID = dbo.tbTrKmAggregat.recTillsynsobjektID)) AS decTotaltCO2e,
                             (SELECT        SUM(decInstalleradMaengd) AS Expr1
                               FROM            dbo.tbTrKmAggregat AS tbAggregat
                               WHERE        (strStatus = 'i bruk') AND (intKontrollIntervall > 0) AND (recTillsynsobjektID = dbo.tbTrKmAggregat.recTillsynsobjektID)) 
                         AS decTotaltInstalleradMaengd2017,
                             (SELECT        MIN(intKontrollIntervall) AS Expr1
                               FROM            dbo.tbTrKmAggregat AS tbAggregat
                               WHERE        (recTillsynsobjektID = dbo.tbTrKmAggregat.recTillsynsobjektID) AND (strStatus = 'I bruk')) AS intKontrollIntervall, 
                         dbo.tbTrTillsynsobjekt.recTillsynsobjektID, dbo.tbTrTillsynsobjekt.recTillsynsobjektID AS recKoeldmediaID
FROM            dbo.tbTrKmAggregat LEFT OUTER JOIN
                         dbo.tbTrTillsynsobjekt ON dbo.tbTrKmAggregat.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID

go

