
CREATE VIEW [dbo].[vwVisAnalysresultat]
AS
SELECT
	recAnalysresultatID as intRecnum, 
	dbo.tbVisAnalysresultat.*,
	dbo.tbVisProv.intProvAar
FROM
	dbo.tbVisAnalysresultat
INNER JOIN dbo.tbVisProv ON dbo.tbVisProv.recProvID = dbo.tbVisAnalysresultat.recProvID

go

