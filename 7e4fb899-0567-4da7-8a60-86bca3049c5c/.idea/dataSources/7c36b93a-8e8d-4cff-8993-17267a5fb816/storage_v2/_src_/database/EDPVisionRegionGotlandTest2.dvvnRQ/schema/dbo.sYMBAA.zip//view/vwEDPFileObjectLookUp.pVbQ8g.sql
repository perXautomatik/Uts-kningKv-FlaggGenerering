
CREATE VIEW [dbo].[vwEDPFileObjectLookUp]
AS
WITH FileVersion AS (
  SELECT recFileObjectID, MAX(recFileVersionID) AS recFileVersionID
  FROM tbEDPFileVersion
  GROUP BY recFileObjectID)
SELECT DISTINCT tbEDPFileObject.recFileObjectID, 
  tbEDPFileObject.recFileObjectID AS intRecnum, 
  tbEDPFileObject.strDescription, 
  tbEDPFileObject.strFileName, 
  tbEDPFileVersion.strFileType, 
  CASE 
    WHEN tbEDPMailTemplate.recFileObjectID IS NOT NULL 
      THEN CAST(1 AS BIT) 
    WHEN tbEDPDocumentTemplate.recFileObjectID IS NOT NULL 
      THEN CAST(1 AS BIT) 
    WHEN tbVisFilmall.recFileObjectID IS NOT NULL 
      THEN CAST(1 AS BIT) 
    ELSE 
      CAST(0 AS BIT) 
    END AS isTemplate, 
  tbEDPFileObject.strFileName + '.' + tbEDPFileVersion.strFileType AS strFileNameWithType

FROM dbo.tbEDPFileObject
INNER JOIN FileVersion 
  ON FileVersion.recFileObjectID = tbEDPFileObject.recFileObjectID
INNER JOIN tbEDPFileVersion 
  ON tbEDPFileVersion.recFileVersionID = FileVersion.recFileVersionID
LEFT JOIN tbEDPDocumentTemplate 
  ON tbEDPDocumentTemplate.recFileObjectID = tbEDPFileObject.recFileObjectID
LEFT JOIN tbEDPMailTemplate 
  ON tbEDPMailTemplate.recFileObjectID = tbEDPFileObject.recFileObjectID
LEFT JOIN tbVisFilmall 
  ON tbVisFilmall.recFileObjectID = tbEDPFileObject.recFileObjectID
WHERE tbEDPFileObject.recFileObjectID NOT IN
  (SELECT recFileObjectID FROM dbo.tbMifoObjektFileObject)
go

