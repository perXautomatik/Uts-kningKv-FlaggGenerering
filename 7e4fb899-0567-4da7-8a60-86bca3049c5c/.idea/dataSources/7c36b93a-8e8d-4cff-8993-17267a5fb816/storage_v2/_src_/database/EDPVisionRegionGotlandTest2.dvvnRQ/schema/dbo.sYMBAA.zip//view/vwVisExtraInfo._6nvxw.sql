CREATE VIEW dbo.vwVisExtraInfo
AS
SELECT     dbo.tbVisExtraInfo.recExtraInfoID, dbo.tbVisExtraInfo.strValue, dbo.tbVisExtraInfo.recExtraInfoTypeID, dbo.tbVisExtraInfoType.strTypeName,
                      dbo.tbVisExtraInfo.recExtraInfoID AS intRecnum
FROM         dbo.tbVisExtraInfo INNER JOIN
                      dbo.tbVisExtraInfoType ON dbo.tbVisExtraInfo.recExtraInfoTypeID = dbo.tbVisExtraInfoType.recExtraInfoTypeID
go

