CREATE VIEW dbo.vwMmVerksamhetSNIBransch
AS
SELECT     dbo.tbMmVerksamhetSNIBransch.recVerksamhetSNIBranschID, dbo.tbMmVerksamhetSNIBransch.recSNIBranschID,
                      dbo.tbMmVerksamhetSNIBransch.recVerksamhetID, dbo.tbMmSNIBransch.strSNIBranschNamn, dbo.tbMmSNIBransch.strSNIBranschKod,
                      dbo.tbMmVerksamhetSNIBransch.recVerksamhetSNIBranschID AS intRecnum, dbo.tbMmSNIBransch.intAartal
FROM         dbo.tbMmSNIBransch RIGHT OUTER JOIN
                      dbo.tbMmVerksamhetSNIBransch ON dbo.tbMmSNIBransch.recSNIBranschID = dbo.tbMmVerksamhetSNIBransch.recSNIBranschID
go

