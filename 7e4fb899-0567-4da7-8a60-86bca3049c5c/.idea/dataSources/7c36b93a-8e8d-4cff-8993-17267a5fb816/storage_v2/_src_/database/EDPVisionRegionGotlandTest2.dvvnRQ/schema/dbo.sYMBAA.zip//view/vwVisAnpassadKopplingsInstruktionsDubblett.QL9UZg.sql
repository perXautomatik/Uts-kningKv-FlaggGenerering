

CREATE VIEW [dbo].[vwVisAnpassadKopplingsInstruktionsDubblett]
AS
SELECT      recDubblettId AS intRecnum,
            recDubblettId, 
            recAnpassadKopplingId, 
            strFaelt
FROM        dbo.tbVisAnpassadKopplingsInstruktionsDubblett


go

