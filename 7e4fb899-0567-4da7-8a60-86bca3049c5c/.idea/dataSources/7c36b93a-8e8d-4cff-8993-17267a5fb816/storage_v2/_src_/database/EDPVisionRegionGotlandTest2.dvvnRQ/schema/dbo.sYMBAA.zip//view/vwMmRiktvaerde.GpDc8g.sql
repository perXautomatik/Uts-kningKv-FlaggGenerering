CREATE VIEW dbo.vwMmRiktvaerde
AS
SELECT     dbo.tbMmRiktvaerde.recRiktvaerdeID, dbo.tbMmRiktvaerde.recFoeroreningAemneID, dbo.tbMmRiktvaerdetyp.recRiktvaerdetyp,
                      dbo.tbMmRiktvaerde.strMarkanvaendning, dbo.tbMmRiktvaerde.strMatris, dbo.tbMmRiktvaerde.strMarktaethet, dbo.tbMmRiktvaerde.intOrganiskHalt,
                      dbo.tbMmRiktvaerde.intLerhalt, dbo.tbMmRiktvaerde.intAartal, dbo.tbMmFoeroreningAemne.recFoeroreningID, dbo.tbMmAemne.strAemneNamn,
                      dbo.tbMmRiktvaerdetyp.strRiktvaerdetypNamn, dbo.tbMmFoerorening.strFoeroreningNamn, dbo.tbMmFoerorening.recMediumID,
                      dbo.tbMmMedium.strMediumNamn, dbo.tbMmRiktvaerde.recRiktvaerdeID AS intRecnum, dbo.tbMmRiktvaerde.strKommentar,
                      dbo.tbMmRiktvaerde.decFraanDjup, dbo.tbMmRiktvaerde.decTillDjup, dbo.tbMmRiktvaerde.strReferensAemne, dbo.tbMmOmraade.strOmrNamn,
                      dbo.tbMmFoerorening.recOmrID, dbo.tbMmRiktvaerde.decVaerde, dbo.tbMmRiktvaerde.strEnhet, dbo.tbMmRiktvaerde.guidRiktvaerdetypID,
                      dbo.tbMmFoeroreningAemne.guidAemneID, dbo.tbMmRiktvaerdetyp.strLocalizationCode
FROM         dbo.tbMmRiktvaerde LEFT OUTER JOIN
                      dbo.tbMmRiktvaerdetyp ON dbo.tbMmRiktvaerde.guidRiktvaerdetypID = dbo.tbMmRiktvaerdetyp.guidRiktvaerdetypID LEFT OUTER JOIN
                      dbo.tbMmAemne RIGHT OUTER JOIN
                      dbo.tbMmOmraade INNER JOIN
                      dbo.tbMmFoerorening INNER JOIN
                      dbo.tbMmMedium ON dbo.tbMmFoerorening.recMediumID = dbo.tbMmMedium.recMediumID ON
                      dbo.tbMmOmraade.recOmrID = dbo.tbMmFoerorening.recOmrID RIGHT OUTER JOIN
                      dbo.tbMmFoeroreningAemne ON dbo.tbMmFoerorening.recFoeroreningID = dbo.tbMmFoeroreningAemne.recFoeroreningID ON
                      dbo.tbMmAemne.guidAemneID = dbo.tbMmFoeroreningAemne.guidAemneID ON
                      dbo.tbMmRiktvaerde.recFoeroreningAemneID = dbo.tbMmFoeroreningAemne.recFoeroreningAemneID
go

