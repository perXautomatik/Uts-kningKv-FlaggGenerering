
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell6Justering]
AS
SELECT     tbAehPblTaxa2011Tabell6Justering.recTabell6ID, 
           recJusteringID as 'intRecnum',
		   recJusteringID,
		   strAatgaerd,
		   strBeskrivning,
		   decOF,
		   decHF, 
		   decHF1, 
		   recTaxa2011ID,
		   decHF2
FROM         dbo.tbAehPblTaxa2011Tabell6Justering
LEFT OUTER JOIN vwAehPblTaxa2011Tabell6
ON vwAehPblTaxa2011Tabell6.recTabell6ID = tbAehPblTaxa2011Tabell6Justering.recTabell6ID

go

