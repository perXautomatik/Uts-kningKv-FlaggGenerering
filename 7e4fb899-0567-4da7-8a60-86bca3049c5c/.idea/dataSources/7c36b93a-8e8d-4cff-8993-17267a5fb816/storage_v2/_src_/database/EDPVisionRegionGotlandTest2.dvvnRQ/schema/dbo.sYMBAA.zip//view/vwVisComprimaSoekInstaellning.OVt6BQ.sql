

CREATE VIEW [dbo].[vwVisComprimaSoekInstaellning]
AS
SELECT recInstaellningID, recInstaellningID As intRecNum, strRubrik, intNivaa, strCertifikat, strURLSoek,
       strURLVisa, strUser, strPassword
	
FROM tbVisComprimaSoekInstaellning



go

