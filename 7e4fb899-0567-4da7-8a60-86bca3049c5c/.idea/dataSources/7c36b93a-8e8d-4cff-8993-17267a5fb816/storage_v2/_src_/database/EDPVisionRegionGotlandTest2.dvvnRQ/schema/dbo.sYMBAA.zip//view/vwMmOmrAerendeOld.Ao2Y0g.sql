CREATE VIEW dbo.vwMmOmrAerendeOld
AS
SELECT     dbo.tbMmOmrAerendeOld.recOmrAerendeOldID, dbo.tbMmOmrAerendeOld.intDiarieAAr, dbo.tbMmOmrAerendeOld.recOmrID,
                      dbo.tbMmOmrAerendeOld.strDiarieNummer, dbo.vwMmOmraade.strOmraadeKod, dbo.vwMmOmraade.strOmrNamn,
                      dbo.tbMmOmrAerendeOld.recOmrAerendeOldID AS intRecnum
FROM         dbo.vwMmOmraade RIGHT OUTER JOIN
                      dbo.tbMmOmrAerendeOld ON dbo.vwMmOmraade.recOmrID = dbo.tbMmOmrAerendeOld.recOmrID
go

