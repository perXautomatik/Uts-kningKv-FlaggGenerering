
        CREATE TRIGGER TRG_tbAehAerendeStatusLog_INSERT_UPDATE_DELETE ON tbAehAerendeStatusLog
        AFTER INSERT, UPDATE, DELETE
        AS
        BEGIN
        SET NOCOUNT ON;

        DECLARE @recAerendeID INT
        -- Uppdatera datInkomDatum om ändringen gäller en status inkom -- 
        DECLARE aerende_aerendestatus_cursor CURSOR FAST_FORWARD
        FOR
        SELECT INSERTED.recAerendeID, INSERTED.datDatum FROM INSERTED
        INNER JOIN tbAehAerendeStatusLogTyp
            ON tbAehAerendeStatusLogTyp.recAerendeStatusLogTypID = INSERTED.recAerendeStatusLogTypID
            AND tbAehAerendeStatusLogTyp.strLocalizationCode = 'inkom'
        INNER JOIN tbAehAerende
            ON tbAehAerende.recAerendeID = INSERTED.recAerendeID
        OPEN aerende_aerendestatus_cursor
        DECLARE @datInkomDatum DATETIME
        FETCH NEXT FROM aerende_aerendestatus_cursor INTO @recAerendeID, @datInkomDatum
        WHILE (@@fetch_status = 0)
        BEGIN
            UPDATE tbAehAerende SET datInkomDatum = @datInkomDatum WHERE recAerendeID = @recAerendeID

            FETCH NEXT FROM aerende_aerendestatus_cursor INTO @recAerendeID, @datInkomDatum
        END
        CLOSE aerende_aerendestatus_cursor
        DEALLOCATE aerende_aerendestatus_cursor

        -- Uppdatera statusloginformation på ärendet --
        DECLARE aerende_aerendestatus_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recAerendeID FROM INSERTED UNION SELECT recAerendeID FROM DELETED
        OPEN aerende_aerendestatus_cursor
        FETCH NEXT FROM aerende_aerendestatus_cursor INTO @recAerendeID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehAerendeDataUpdateStatuslog @recAerendeID

            FETCH NEXT FROM aerende_aerendestatus_cursor INTO @recAerendeID
        END
        CLOSE aerende_aerendestatus_cursor
        DEALLOCATE aerende_aerendestatus_cursor
        END
        go

