create view vwAehHaendelseFaeltLookUp as
select 'Lov beviljat' as strRubrik
union all
select 'Slutbesked' as strRubrik
union all
select 'Startbesked' as strRubrik
go

