
        CREATE TRIGGER HuvudKontaktUppgift ON tbVisUppgiftEnstakaKontakt
        AFTER INSERT
        AS
        BEGIN
        -- SET NOCOUNT ON; added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        DECLARE insert_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recUppgiftID FROM INSERTED
        OPEN insert_cursor
        DECLARE @recUppgiftID as INT
        FETCH NEXT FROM insert_cursor INTO @recUppgiftID
        WHILE (@@fetch_status = 0)
        BEGIN
            IF (SELECT COUNT(recUppgiftEnstakaKontaktID) FROM tbVisUppgiftEnstakaKontakt WHERE recUppgiftID = @recUppgiftID) = 1
            UPDATE tbVisUppgiftEnstakaKontakt SET bolHuvudkontakt = 1 WHERE recUppgiftID = @recUppgiftID

            FETCH NEXT FROM insert_cursor INTO @recUppgiftID
        END
        CLOSE insert_cursor
        DEALLOCATE insert_cursor
        END
        go

