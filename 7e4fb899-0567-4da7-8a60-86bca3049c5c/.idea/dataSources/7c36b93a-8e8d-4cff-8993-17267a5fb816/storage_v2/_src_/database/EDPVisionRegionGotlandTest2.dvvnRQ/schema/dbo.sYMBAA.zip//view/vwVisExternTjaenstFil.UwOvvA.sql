

CREATE VIEW [dbo].[vwVisExternTjaenstFil]
AS
SELECT
			recExternTjaenstFileID AS intRecnum, 
			recExternTjaenstFileID, 
			bolKopplad, 
			strFilnamn, 
			recFileObjectID, 
			recExternTjaenstID
FROM
			dbo.tbVisExternTjaenstFil


go

