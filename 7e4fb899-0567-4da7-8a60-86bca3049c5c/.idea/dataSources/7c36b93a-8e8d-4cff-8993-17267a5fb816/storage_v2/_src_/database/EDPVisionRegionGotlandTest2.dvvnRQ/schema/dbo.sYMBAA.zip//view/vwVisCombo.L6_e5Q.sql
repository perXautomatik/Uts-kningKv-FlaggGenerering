CREATE VIEW dbo.vwVisCombo
AS
SELECT     dbo.tbVisCombo.recComboID, dbo.tbVisCombogrupp.recCombogruppID, dbo.tbVisCombogrupp.strGruppnamn, dbo.tbVisCombo.strComboVaerde,
                      dbo.tbVisCombo.recComboID AS intRecnum
FROM         dbo.tbVisCombo INNER JOIN
                      dbo.tbVisCombogrupp ON dbo.tbVisCombo.recCombogruppID = dbo.tbVisCombogrupp.recCombogruppID
go

