

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell21OevrigaAerenden]
AS
SELECT     tbAehPblTaxa2011Tabell21OevrigaAerenden.recTabell21ID, 
           recOevrigaAerendenID as 'intRecnum', 
		   recOevrigaAerendenID,
		   strAerendetyp,
		   strBeskrivning,
		   recTaxa2011ID,
		   intHF
FROM         dbo.tbAehPblTaxa2011Tabell21OevrigaAerenden
LEFT OUTER JOIN vwAehPblTaxa2011Tabell21 
ON vwAehPblTaxa2011Tabell21.recTabell21ID = tbAehPblTaxa2011Tabell21OevrigaAerenden.recTabell21ID


go

