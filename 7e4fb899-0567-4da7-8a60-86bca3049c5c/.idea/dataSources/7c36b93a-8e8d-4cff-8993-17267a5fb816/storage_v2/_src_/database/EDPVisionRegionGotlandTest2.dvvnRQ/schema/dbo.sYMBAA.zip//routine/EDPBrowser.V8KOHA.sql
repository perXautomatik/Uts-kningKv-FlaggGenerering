
create proc [dbo].[EDPBrowser]
@inTableName varchar(100),
@inPageSize int,
@inRecnum int,
@inRowNumber int,
@inOrderByColumns varchar(4000),
@inSelectcolumn varchar(4000),
@inAfterFrom varchar(4000), --allt efter from utom order by-satsen
@inBolForward bit,
@inIncludeFirstRow bit
as
/*  antingen skickas rownumber eller recnum in
    om recnum räknar vi ut rownumber innan bläddringen
    om rownumber så bara kör vi

     vi kollar row_number för recnum enligt gällande sortering
      måste använda cursor för att kolla att row_number är samma
      förslag: ska vara valbart om man vill använda detta
*/

declare @controlRecnum int
declare @newRownumber int
declare @identityColumnName varchar(100)
declare @str nvarchar(4000)

exec SPEDPGetIdentityColumnName @inTableName, @outColumnName = @identityColumnName output
print '@identityColumnName: ' + @identityColumnName

if (@inRecnum is not null and (@inRowNumber <> -1 or @inRowNumber is null)) --så måste vi räkna ut row_number
begin
  /* därefter måste vi skapa en cursor som tar reda på row_number */
  set @str = ('declare tblnames cursor fast_forward for select ' + @inTableName + '.' + @identityColumnName + ', row_number() over (order by ' + @inOrderByColumns + ') from ' + @inAfterFrom + ' ORDER BY ' + @inOrderByColumns)
  print @str
  exec (@str)
  open tblnames
  fetch next from tblnames into @controlRecnum, @newRownumber
  while (@@fetch_status = 0)
    begin
      if (@controlRecnum = @inRecnum)
      begin
        print 'recnum hat hittats'
		GOTO RowNumberFound  -- inte snyggt med GOTO men här har prestanda prioritet
        set @newRownumber = (@newRownumber +1)

      end
      fetch next from tblnames into @controlRecnum, @newRownumber
    end
  RowNumberFound:  --naturligtvis stänger vi cursorn så vi inte äter så mkt minne
  close tblnames
  deallocate tblnames
end

if (@inRowNumber = -1) -- rownumber -1 är specialarvarianten då vi går bakifrån, då blir rownumber antalet poster som finns totalt i tabellen + 1
begin
  --här måste vi på något sätt räkna ut högsta rownumbret i tabellen (=antal poster)
  set @str = ('select @outCount = count(*) from ' + @inAfterFrom)  --man kan inte lösa beräkningen av antalet poster på annat sätt än dynamisk sql och
  print @str							   --sp_executesql-anrop, för att få ut ett parametervärde ifrån dynamisk sql
  exec sp_executesql @str, N'@outCount int output',@outCount = @newRowNumber output
  print cast(@newRowNumber as varchar(5))
  set @inPageSize = (@inPageSize)
  set @newRownumber = (@newRownumber + 1)
end
else
begin
  if (@inRowNumber is not null)
  begin
    print 'rowNumber sätts till vad som skickats in'
    set @newRowNumber = (@inRowNumber)
  end
end

-- sist byggs en dynamisk sql-sats som hämtar ut hela pagen
set @str = ('WITH OurPage AS
(SELECT ' + @inSelectcolumn + ', row_number() over (order by ' + @inOrderByColumns + ') AS EDPFrameworkRowNr, ' + @inTableName + '.' +
@identityColumnName + ' as EDPFrameworkID FROM ' + @inAfterFrom + ') SELECT TOP ' + cast(@inPageSize as varchar(5)) + ' *
FROM OurPage WHERE EDPFrameworkRowNr ')

if (@inIncludeFirstRow <> 0)
begin
  if (@inBolForward <> 0)
  begin
    set @newRownumber = (@newRownumber - 1)
  end
  else
  begin
    set @newRownumber = (@newRownumber + 1)
  end
end

print '@str: ' + @str
print '@newRownumber: ' + cast(@newRownumber as varchar(10))
if (@inBolForward <> 0)
begin
  set @str = (@str + '> ' + cast(@newRownumber as varchar(10)) + ' and EDPFrameworkRowNr <=' + cast((@newRownumber + @inPageSize) as varchar(10)))
end
else
begin
  set @str = (@str + '< ' + cast(@newRownumber as varchar(10)) + ' and EDPFrameworkRowNr >=' + cast((@newRownumber - @inPageSize) as varchar(10)))
end
print '@str: ' + @str
exec (@str) --sist sker själva hämtningen av data
go

