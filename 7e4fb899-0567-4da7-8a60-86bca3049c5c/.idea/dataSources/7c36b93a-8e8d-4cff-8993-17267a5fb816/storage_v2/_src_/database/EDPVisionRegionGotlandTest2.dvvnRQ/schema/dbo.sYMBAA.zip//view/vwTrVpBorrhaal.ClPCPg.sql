CREATE VIEW dbo.vwTrVpBorrhaal
AS
SELECT     tbTrVpBorrhaal.recBorrHaalID, tbTrVpBorrhaal.strBeteckning, tbTrVpBorrhaal.intDjup, tbTrVpBorrhaal.strRiktning, tbTrVpBorrhaal.strKommentar, tbTrVpBorrhaal.intX,
                      tbTrVpBorrhaal.recVaermepumpID, tbTrVpBorrhaal.intY, tbTrVpBorrhaal.intVinkel, tbTrVpVaermepump.recTillsynsobjektID,
                      dbo.tbTrVpBorrhaal.recBorrHaalID AS intRecnum
FROM         dbo.tbTrVpBorrhaal LEFT OUTER JOIN
                      dbo.tbTrVpVaermepump ON tbTrVpVaermepump.recVaermepumpID = tbTrVpBorrhaal.recVaermepumpID
go

