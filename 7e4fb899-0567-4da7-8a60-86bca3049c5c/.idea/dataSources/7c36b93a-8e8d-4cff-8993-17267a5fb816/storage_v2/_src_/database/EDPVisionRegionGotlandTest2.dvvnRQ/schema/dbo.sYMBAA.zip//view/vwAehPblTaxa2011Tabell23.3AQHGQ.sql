

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell23]
AS
SELECT     

recTabell23ID, 
recTaxa2011ID, 
recTabell23ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell23.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell23.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell23

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell23.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell23.recTjaenstID



go

