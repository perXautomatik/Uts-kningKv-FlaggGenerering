
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell07]
AS
SELECT     
	dbo.tbAehPblAvgiftTaxa2011Tabell07.recPblAvgiftTaxa2011Tabell07ID,
	dbo.tbAehPblAvgiftTaxa2011Tabell07.recPblAvgiftTaxa2011Tabell07ID AS intRecnum, 
	dbo.tbAehPblAvgiftTaxa2011Tabell07.recAvgiftID, 
	dbo.tbAehPblAvgiftTaxa2011Tabell07.bolDebiterad,
	dbo.tbAehPblAvgiftTaxa2011Tabell07.bolTidsersaettning, 
	dbo.tbAehPblAvgiftTaxa2011Tabell07.bolHandlaeggningsfaktor, 
	dbo.tbAehPblAvgiftTaxa2011Tabell07.decAvgiftTotalt,
	dbo.tbAehPblAvgiftTaxa2011Tabell07.decmPBB,
	dbo.tbAehPblAvgiftTaxa2011Tabell07.decN
FROM dbo.tbAehPblAvgiftTaxa2011Tabell07

go

