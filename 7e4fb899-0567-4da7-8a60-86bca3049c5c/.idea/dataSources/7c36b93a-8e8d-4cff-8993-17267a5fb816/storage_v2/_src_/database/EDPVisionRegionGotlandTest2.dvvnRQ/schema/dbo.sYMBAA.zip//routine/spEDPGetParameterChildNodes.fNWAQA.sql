
/****** Object:  StoredProcedure [dbo].[spEDPGetParameterChildNodes]    Script Date: 10/27/2006 16:45:08 ******/
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spEDPGetParameterChildNodes]
	-- Add the parameters for the stored procedure here
  @intParameterID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
SELECT     dbo.tbEDPParameter.intParameterID, dbo.tbEDPParameter.strParameterName, dbo.tbEDPParameter.intParameterTypeID, 
                      dbo.tbEDPParameter.intParentParameterID, dbo.tbEDPParameterType.strParameterTypeName
FROM         dbo.tbEDPParameter INNER JOIN
                      dbo.tbEDPParameterType ON dbo.tbEDPParameter.intParameterTypeID = dbo.tbEDPParameterType.intParameterTypeID
WHERE     (dbo.tbEDPParameter.intParentParameterID = @intParameterID) Order by tbEDPParameter.strParameterName

END
go

