CREATE VIEW [dbo].[vwEDPParameterValueType]
AS
SELECT     dbo.tbEDPParameter.strParameterName, dbo.tbEDPParameterDefaultValue.strParameterDefaultValue AS strParameterValueDefault, 
                      dbo.tbEDPValueType.strValueTypeName
FROM         dbo.tbEDPParameter INNER JOIN
                      dbo.tbEDPValueType ON dbo.tbEDPParameter.intParameterValueTypeID = dbo.tbEDPValueType.intValueTypeID LEFT OUTER JOIN
                      dbo.tbEDPParameterDefaultValue ON dbo.tbEDPParameter.intParameterID = dbo.tbEDPParameterDefaultValue.intParameterID
go

