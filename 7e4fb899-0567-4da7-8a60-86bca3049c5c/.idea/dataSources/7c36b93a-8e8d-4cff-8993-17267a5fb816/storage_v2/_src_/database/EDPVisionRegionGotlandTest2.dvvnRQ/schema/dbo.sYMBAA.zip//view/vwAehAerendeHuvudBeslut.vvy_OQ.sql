CREATE VIEW [dbo].[vwAehAerendeHuvudBeslut]
AS
SELECT dbo.tbAehAerendeHaendelse.recAerendeHaendelseID, dbo.tbAehAerendeHaendelse.recAerendeID,
  dbo.tbAehAerendeHaendelse.recHaendelseID, dbo.tbAehHaendelseBeslut.strBeslutsutfall,
  dbo.tbAehHaendelseBeslut.recHaendelseBeslutID, dbo.tbAehHaendelseBeslut.datBeslutsDatum,
  dbo.tbAehHaendelseBeslut.strBeslutsNummer
FROM dbo.tbAehAerendeHaendelse
INNER JOIN dbo.tbAehHaendelseBeslut
  ON dbo.tbAehAerendeHaendelse.recHaendelseID = dbo.tbAehHaendelseBeslut.recHaendelseID
  AND dbo.tbAehHaendelseBeslut.recHaendelseID =
    (SELECT TOP 1 a.recHaendelseID FROM tbAehAerendeHaendelse a
     INNER JOIN dbo.tbAehHaendelseBeslut ON a.recHaendelseID = dbo.tbAehHaendelseBeslut.recHaendelseID
     WHERE a.recAerendeID = tbAehAerendeHaendelse.recAerendeID AND a.bolHuvudbeslut = 1
     ORDER BY a.recHaendelseID DESC)
go

