
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell16]
AS
SELECT     

recTabell16ID, 
recTaxa2011ID, 
recTabell16ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell16.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell16.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell16

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell16.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell16.recTjaenstID


go

