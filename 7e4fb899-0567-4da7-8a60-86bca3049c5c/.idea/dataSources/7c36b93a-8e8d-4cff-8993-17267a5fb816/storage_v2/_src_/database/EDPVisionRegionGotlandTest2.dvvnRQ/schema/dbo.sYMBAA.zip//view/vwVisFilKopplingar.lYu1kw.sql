


CREATE VIEW [dbo].[vwVisFilKopplingar]
AS

SELECT recFileObjectID, 'Händelse' As Tabell FROM tbAehHaendelseFileObject
UNION ALL
SELECT recFileObjectID, 'Plan' As Tabell FROM tbAehPlPlanFileObject
UNION ALL
SELECT recFileObjectID, 'Möte' As Tabell FROM tbMhMoeteFileObject
UNION ALL
SELECT recFileObjectID, 'Mötespunkt' As Tabell FROM tbMhMoetespunktFileObject
UNION ALL
SELECT recFileObjectID, 'Mifo' As Tabell FROM tbMifoObjektFileObject
UNION ALL
SELECT recFileObjectID, 'Riktvärde' As Tabell FROM tbMmRiktvaerdetypFileObject
UNION ALL
SELECT recFileObjectID, 'Undersökning' As Tabell FROM tbMmUndersoekningFileObject
UNION ALL
SELECT recFileObjectID, 'Tillsynsbesök' As Tabell FROM tbTrTillsynsbesoekFileObject
UNION ALL
SELECT recFileObjectID, 'Tillsynsobjekt' As Tabell FROM tbTrTillsynsobjektFileObject
UNION ALL
SELECT recFileObjectID, 'Uppgift' As Tabell FROM tbVisUppgiftFileObject
go

