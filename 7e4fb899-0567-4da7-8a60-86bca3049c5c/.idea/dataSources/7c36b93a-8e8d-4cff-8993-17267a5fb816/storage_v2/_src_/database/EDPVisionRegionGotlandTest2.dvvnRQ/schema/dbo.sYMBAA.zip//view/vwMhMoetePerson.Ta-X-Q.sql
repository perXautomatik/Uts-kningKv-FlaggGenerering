

CREATE VIEW [dbo].[vwMhMoetePerson]
AS
SELECT		tbMhMoete.recMoeteID, tbMhMoetePerson.recMoetePersonID, tbMhMoetePerson.recPersonID,
					tbMhMoetePerson.bolDeltagit, dbo.vwMhPerson.strPartinamn, dbo.vwMhPerson.strNamn,
					dbo.tbMhMoetePerson.strKommentar, tbMhMoetePerson.strTid, tbMhMoetePerson.strMoetesRoll,
					CASE WHEN (strMoetesRoll =
                          (SELECT     tbMhMoetesRoll.strMoetesRoll
                            FROM          tbMhMoetesRoll
                            WHERE      guid = '0d52f0ea-0075-45c3-9e21-6f0833ed7729')
                    ) THEN strNamn  +
														CASE WHEN strPartifoerkortning IS NOT NULL
																		THEN ' (' + strPartifoerkortning + ')' + CHAR(13) + CHAR(10)
																		ELSE  CHAR(13) + CHAR(10)
																		END
											ELSE NULL
                      END AS strErsättarNamnPartiförkortning,
					CASE WHEN (strMoetesRoll <>
                          (SELECT     tbMhMoetesRoll.strMoetesRoll
                            FROM          tbMhMoetesRoll
                            WHERE      guid = '0d52f0ea-0075-45c3-9e21-6f0833ed7729')
                    ) AND (strMoetesRoll <>
															(SELECT     tbMhMoetesRoll.strMoetesRoll
																FROM          tbMhMoetesRoll
																WHERE      guid = '0abb0653-b007-4219-9491-123c6ade34eb')
                          ) THEN strNamn + ' (' + strMoetesRoll + ')' +
																	CASE WHEN strPartifoerkortning IS NOT NULL
																		THEN ' (' + strPartifoerkortning + ')' + CHAR(13) + CHAR(10)
																		ELSE  CHAR(13) + CHAR(10)
																		END
							 WHEN (strMoetesRoll <>
                          (SELECT     tbMhMoetesRoll.strMoetesRoll
                            FROM          tbMhMoetesRoll
                            WHERE      guid = '0d52f0ea-0075-45c3-9e21-6f0833ed7729')
                    ) THEN strNamn +
														CASE WHEN strPartifoerkortning IS NOT NULL
																		THEN ' (' + strPartifoerkortning + ')' + CHAR(13) + CHAR(10)
																		ELSE  CHAR(13) + CHAR(10)
																		END
											ELSE NULL
                      END AS strLedamotNamnMötesrollPartiförkortning, dbo.vwMhPerson.strEmail
FROM         dbo.tbMhMoete INNER JOIN
                      dbo.tbMhMoetePerson ON dbo.tbMhMoete.recMoeteID = dbo.tbMhMoetePerson.recMoeteID LEFT OUTER JOIN
                      dbo.vwMhPerson ON dbo.tbMhMoetePerson.recPersonID = dbo.vwMhPerson.recPersonID
go

