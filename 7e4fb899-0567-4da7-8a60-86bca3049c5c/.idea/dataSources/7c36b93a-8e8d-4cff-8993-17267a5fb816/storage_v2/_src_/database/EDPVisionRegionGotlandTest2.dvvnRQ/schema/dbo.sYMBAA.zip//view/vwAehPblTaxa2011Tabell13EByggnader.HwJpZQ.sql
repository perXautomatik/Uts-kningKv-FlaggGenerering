


CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell13EByggnader]
AS
SELECT     tbAehPblTaxa2011Tabell13EByggnader.recTabell13ID, 
           recEByggnaderID as 'intRecnum', 
		   recEByggnaderID,
		   strObjekt,
		   strBeskrivning,
		   intOf,
		   intHF1,
		   recTaxa2011ID,
		   intHF2
FROM         dbo.tbAehPblTaxa2011Tabell13EByggnader
LEFT OUTER JOIN vwAehPblTaxa2011Tabell13
ON vwAehPblTaxa2011Tabell13.recTabell13ID = tbAehPblTaxa2011Tabell13EByggnader.recTabell13ID


go

