
CREATE VIEW [dbo].[vwVisHandlaeggareEDPUser]
AS
SELECT dbo.tbVisHandlaeggare.recHandlaeggareID, 
  dbo.tbEDPUser.intUserID AS intRecnum, 
  dbo.tbVisHandlaeggare.bolHandlaeggare, 
  dbo.tbEDPUser.strPassword, 
  dbo.tbEDPUser.datLastChangedPassword,
  dbo.tbEDPUser.strUserSurName, 
  dbo.tbEDPUser.strUserWindowsAccount, 
  dbo.tbEDPUser.strUserFirstname, 
  dbo.tbEDPUser.intUserID, 
  dbo.tbEDPUser.datActivateAccount,
  dbo.tbEDPUser.datDeactivateAccount, 
  CASE 
  WHEN dbo.tbEDPUser.datDeactivateAccount IS NULL THEN 
    CAST(0  AS BIT)
  WHEN dbo.tbEDPUser.datDeactivateAccount > GETDATE() THEN 
    CAST(0  AS BIT)
  ELSE
    CAST(1  AS BIT)
  END AS bolEjAktuell, 
  dbo.tbEDPUser.strSignature, 
  dbo.tbEDPUser.strEmail, 
  dbo.tbEDPUser.strTelephone, 
  dbo.tbEDPUser.bolADIgnore,
  dbo.FnKomplettNamn(tbEDPUser.strUserSurName, tbEDPUser.strUserFirstname) AS strFullName,
  dbo.tbEDPUser.strTelephone2,
  dbo.tbVisHandlaeggare.strBefattning,
  ISNULL(dbo.tbVisHandlaeggare.bolEpostUppgifter, 0) As bolEpostUppgifter,
  ISNULL(dbo.tbVisHandlaeggare.bolEpostHaendelser, 0) As bolEpostHaendelser,
  ISNULL(dbo.tbVisHandlaeggare.bolBehoerigTillAllaKonton, 0) As bolBehoerigTillAllaKonton,
  dbo.tbVisHandlaeggare.strEkonomikod
  
FROM dbo.tbVisHandlaeggare
LEFT OUTER JOIN dbo.tbEDPUser 
  ON dbo.tbEDPUser.intUserID = dbo.tbVisHandlaeggare.intUserID
go

