
        CREATE TRIGGER TRG_tbAehHaendelseUser_INSERT_UPDATE_DELETE ON tbAehHaendelseUser
        AFTER INSERT, UPDATE, DELETE
        AS
        BEGIN
        SET NOCOUNT ON;

        DECLARE haendelse_user_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recHaendelseID FROM INSERTED WHERE bolHuvudhandlaeggare = 1 UNION SELECT recHaendelseID FROM DELETED WHERE bolHuvudhandlaeggare = 1
        OPEN haendelse_user_cursor
        DECLARE @recHaendelseID INT
        FETCH NEXT FROM haendelse_user_cursor INTO @recHaendelseID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehHaendelseUpdateHuvudHandlaeggare @recHaendelseID

            FETCH NEXT FROM haendelse_user_cursor INTO @recHaendelseID
        END
        CLOSE haendelse_user_cursor
        DEALLOCATE haendelse_user_cursor
        END
        go

