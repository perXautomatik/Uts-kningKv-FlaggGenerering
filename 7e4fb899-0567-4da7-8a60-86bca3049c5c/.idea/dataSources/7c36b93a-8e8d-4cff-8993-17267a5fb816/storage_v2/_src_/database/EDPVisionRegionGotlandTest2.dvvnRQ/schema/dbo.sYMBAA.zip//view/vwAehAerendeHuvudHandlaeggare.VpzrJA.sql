
            CREATE VIEW [dbo].[vwAehAerendeHuvudHandlaeggare]
            AS
            SELECT tbAehAerendeUser.recAerendeUserID, tbAehAerendeUser.recAerendeID,
              tbAehAerendeUser.intUserID, tbAehAerendeUser.bolHuvudhandlaeggare,
              tbEDPUser.strSignature
            FROM dbo.tbAehAerendeUser
            INNER JOIN dbo.tbEDPUser
              ON dbo.tbAehAerendeUser.intUserID = dbo.tbEDPUser.intUserID
            WHERE tbAehAerendeUser.bolHuvudhandlaeggare = 1
            go

