



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spEDPDeleteParameterSubParameter]
	-- Add the parameters for the stored procedure here
	@strParameterName varchar(200)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
DECLARE @intParameterID int
SET @intParameterID = (SELECT intParameterID from tbEDPParameter WHERE strParameterName = @strParameterName)

DELETE tbEDPParameterSubParameter WHERE intParameterID = @intParameterID

END

go

