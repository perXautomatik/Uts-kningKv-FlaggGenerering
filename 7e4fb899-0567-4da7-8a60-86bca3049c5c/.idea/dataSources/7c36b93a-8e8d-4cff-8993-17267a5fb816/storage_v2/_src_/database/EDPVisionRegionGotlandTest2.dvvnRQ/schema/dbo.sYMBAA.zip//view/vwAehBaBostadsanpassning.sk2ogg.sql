
CREATE VIEW [dbo].[vwAehBaBostadsanpassning]
AS
SELECT dbo.tbAehBaBostadsanpassning.recBostadsanpassningID,
			dbo.tbAehBaBostadsanpassning.recBostadsanpassningID as intRecnum, 
			dbo.tbAehBaBostadsanpassning.recAerendeID, 
			dbo.tbAehBaBostadsanpassning.strBidragstyp, 
			dbo.tbAehBaBostadsanpassning.strFunktionshinder, 
			dbo.tbAehBaBostadsanpassning.strByggnadstyp, 
			dbo.tbAehBaBostadsanpassning.intFoedelseaar, 
			dbo.tbAehBaBostadsanpassning.strKoen, 
			
			(
				SELECT SUM(ISNULL(Aatgaerd.decBeslutatBelopp,0)) 
				FROM tbAehBaBostadsanpassningAatgaerd as Aatgaerd 
				WHERE Aatgaerd.recBostadsanpassningID = dbo.tbAehBaBostadsanpassning.recBostadsanpassningID
				AND Aatgaerd.decBeslutatBelopp > 0
			) AS decSummaBeslutatBelopp,			
			
			(
				SELECT SUM(ISNULL(Utbetalning.decTotaltBelopp,0)) 
				FROM vwAehBaBostadsanpassningUtbetalning as Utbetalning 
				WHERE Utbetalning.recBostadsanpassningID = dbo.tbAehBaBostadsanpassning.recBostadsanpassningID
				AND Utbetalning.decTotaltBelopp > 0
			) AS decSummaUtbetalatBelopp,			
            
      dbo.tbAehBaBostadsanpassning.strBeslutsutfall,
      tbAehAerende.recAvdelningID  -- Behövs för postbehörigheter
FROM dbo.tbAehBaBostadsanpassning
LEFT OUTER JOIN	tbAehAerende
  ON tbAehAerende.recAerendeID = tbAehBaBostadsanpassning.recAerendeID


go

