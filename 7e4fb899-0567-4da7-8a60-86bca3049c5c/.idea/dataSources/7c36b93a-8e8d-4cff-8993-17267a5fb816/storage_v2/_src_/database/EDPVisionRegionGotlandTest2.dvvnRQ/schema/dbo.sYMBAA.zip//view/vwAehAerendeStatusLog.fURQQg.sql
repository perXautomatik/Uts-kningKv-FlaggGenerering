CREATE VIEW [dbo].[vwAehAerendeStatusLog]
AS
SELECT     dbo.tbAehAerendeStatusLog.recAerendeStatusLogID, dbo.tbAehAerendeStatusLog.recAerendeStatusLogTypID,
                      dbo.tbAehAerendeStatusLog.recAerendeID, dbo.tbAehAerendeStatusLog.intUserID, dbo.tbAehAerendeStatusLog.datDatum,
                      dbo.tbAehAerendeStatusLogTyp.strAerendeStatusLogTyp, dbo.tbAehAerendeStatusLogTyp.strLocalizationCode, dbo.tbEDPUser.strSignature,
                      dbo.tbAehAerendeStatusLog.recAerendeStatusLogID AS intRecnum, dbo.tbAehAerendeStatusLogTyp.strAerendeStatusPresent,
                      dbo.tbAehAerendeStatusLog.strKommentar
FROM         dbo.tbAehAerendeStatusLog INNER JOIN
                      dbo.tbAehAerendeStatusLogTyp ON
                      dbo.tbAehAerendeStatusLog.recAerendeStatusLogTypID = dbo.tbAehAerendeStatusLogTyp.recAerendeStatusLogTypID INNER JOIN
                      dbo.tbEDPUser ON dbo.tbAehAerendeStatusLog.intUserID = dbo.tbEDPUser.intUserID
go

