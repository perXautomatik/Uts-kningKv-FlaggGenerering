
CREATE PROCEDURE [dbo].[spEDPGetParameterByParameterID] 
  @intParameterID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

  SELECT     dbo.vwEDPParameter.intParameterID AS intRecnum, vwEDPParameter.intParameterID, vwEDPParameter.strParameterName, vwEDPParameter.strParameterDisplayName, vwEDPParameter.strParameterDescription, 
                        vwEDPParameter.strParameterValueLookUpID, vwEDPParameter.intParameterValueTypeID, vwEDPParameter.intParameterValueLength, 
                        tbEDPValueType.strValueTypeName, vwEDPParameter.strParameterValueDefault, vwEDPParameter.intParentParameterID, 
                        vwEDPParameter.intParameterTypeID, vwEDPParameter.intParameterTypeDecimalCount, vwEDPParameter.intParameterTypeFigureCount, vwEDPParameter.bolPasswordMask
  FROM         vwEDPParameter INNER JOIN
                        tbEDPValueType ON vwEDPParameter.intParameterValueTypeID = tbEDPValueType.intValueTypeID
  WHERE     (vwEDPParameter.intParameterID = @intParameterID)
END

go

