CREATE VIEW dbo.Livsmedel_test
AS
SELECT        A.recTillsynsobjektID, EDPVisionRegionGotlandTest.dbo.vwTrTillsynsobjektFastighet.strFastighetsbeteckning, A.strObjektsNamn, A.strAdress, A.strPostnummer, A.strOrt, B.intAntalAnstaellda, B.strParagraf, C.decX, C.decY, 
                         geometry::Point(C.decY, C.decX, 3015) AS Shape, A.recTillsynsobjektTypID
FROM            EDPVisionRegionGotlandTest.dbo.tbTrTillsynsobjekt AS A INNER JOIN
                         EDPVisionRegionGotlandTest.dbo.tbTrTillsynsobjektKoordinat AS D ON A.recTillsynsobjektID = D.recTillsynsobjektID INNER JOIN
                         EDPVisionRegionGotlandTest.dbo.tbVisKoordinat AS C ON D.recKoordinatID = C.recKoordinatID INNER JOIN
                         EDPVisionRegionGotlandTest.dbo.vwTrTillsynsobjektFastighet ON A.recTillsynsobjektID = EDPVisionRegionGotlandTest.dbo.vwTrTillsynsobjektFastighet.recTillsynsobjektID FULL OUTER JOIN
                         EDPVisionRegionGotlandTest.dbo.tbTrLiLivsmedel AS B ON A.recTillsynsobjektID = B.recTillsynsobjektID
WHERE        (C.decX IS NOT NULL) AND (C.decY IS NOT NULL) AND (A.recTillsynsobjektTypID = 7 OR
                         A.recTillsynsobjektTypID = 10)
go

